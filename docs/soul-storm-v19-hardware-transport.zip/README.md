# Soul Storm v19 opaque hardware transport

This is a static mesh-loader regression fixture from the winding-corrected v19 source. It is not a functional gunpack and does not supersede the full authoring scene.

The old v15 geometry had source-surface orientation defects. This fixture rebuilds the opaque hardware from the corrected source rather than reusing those bytes. The source SHA256 is in transport-manifest.json. Original axes and emitter groups are retained; hands, animation pivots and functional native bindings are not supplied.

## Explicit scope

- 46,316 hardware triangles; 10 mesh groups; 185,264 released-baker vertices.
- Excludes 2,880 original vortex-surface triangles, 96 reticle-energy triangles and 4 living-fire triangles. Authoring projectile cues also excluded separately. The effect surfaces require their own animated native material implementation.
- Six constant-color material swatches in a 256×32 image. This is not final texture work or PBR equivalence.
- Original JSON 5,119,795 bytes; compact float32-targeted JSON 3,946,341 bytes (22.92% smaller). Actual released TML 0.1.8 baker output matches in all 1,482,112 float values on Java17 and Java21 runtimes.
- The tests use exact released classes plus narrow graphics/logging stand-ins. No GPU/native game execution, FPS, hand fit, art acceptance or animated correctness is implied. The known fallback/VBO normal-path question still needs native tests.

## Reproduction

Run Blender 4.3.2 with --python-exit-code 1 and export_geometry.py -- --source path/to/soul-storm-v19.blend. Run pack_swatches.py with Pillow. Use the separately published tml-float32-export-v1 compactor and tml-export-regression-v3 harness with --expected-bones 10 --expected-vertices 185264. Keep source and compact JSON separate.

Source geometry winding and preservation evidence is copied beside the generated files. Those reports concern the original authoring geometry, not a substitute for native rendering acceptance.
