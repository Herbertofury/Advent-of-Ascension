"""Export a neutral-pose geometry transport fixture, not a functional gunpack."""
import bpy,json,sys,argparse,hashlib,re
from pathlib import Path
from mathutils import Matrix,Vector
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--source',required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]if '--'in sys.argv else[])
bpy.ops.wm.open_mainfile(filepath=str(Path(a.source).resolve()));bpy.context.scene.frame_set(0);dg=bpy.context.evaluated_depsgraph_get();M=Matrix(((0,-1,0),(0,0,1),(-1,0,0)));unit=4.0
palette_names=['Anodized indigo','Obsidian violet','Brushed silver','Grip inset','Spirit cyan','Core blue'];palette={name:i for i,name in enumerate(palette_names)};materials={};groups={};object_receipts=[];excluded=[];world_bad=[];excluded_materials={}
def ancestors(o):
 while o is not None:yield o;o=o.parent
def group_for(o,material):
 if material=='Original soul vortex VFX surface':return re.sub('[^a-z0-9]+','_',o.name.lower())+'_translucent_illuminated'
 if material=='Soul flame atlas surface':return 'soul_flame_frame_00_translucent_illuminated'
 parent=next((x.name for x in ancestors(o)if x.name.startswith('Emitter_')and x.name.endswith('_top_to_bottom')),'body');parent=parent.lower()
 return parent+('_illuminated'if material=='Spirit cyan'else'')
def uv_for(material,uv):
 i=palette[material];return ((i*40+20)/256,.5)
def pool(g,name,value):
 key=tuple(float(v)for v in value);cache=g['_'+name]
 if key not in cache:cache[key]=len(g[name]);g[name].append(list(key))
 return cache[key]
for name in palette_names:
 mat=bpy.data.materials[name];node=next(n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED');materials[name]={'linear_base_rgba':list(node.inputs['Base Color'].default_value),'metallic':node.inputs['Metallic'].default_value,'roughness':node.inputs['Roughness'].default_value,'emission_strength':node.inputs['Emission Strength'].default_value}
for o in bpy.data.objects:
 if o.type not in {'MESH','CURVE','SURFACE','FONT'}or o.hide_render:continue
 if any(x.name.startswith('Authoring_disc_')for x in ancestors(o)):
  excluded.append(o.name);continue
 evaluated=o.evaluated_get(dg);mesh=evaluated.to_mesh();mesh.calc_loop_triangles();world=o.matrix_world;normal_matrix=M@world.to_3x3().inverted().transposed();ntri=0
 for tri in mesh.loop_triangles:
  if tri.area<=1e-12:raise ValueError('Degenerate evaluated source triangle: '+o.name)
  mat=mesh.materials[tri.material_index].name
  if mat not in palette:
   excluded_materials[mat]=excluded_materials.get(mat,0)+1;continue
  name=group_for(o,mat)
  if name not in groups:groups[name]={'normalized_uvs':True,'positions':[],'normals':[],'uvs':[],'polys':[],'_positions':{},'_normals':{},'_uvs':{}}
  g=groups[name];poly=[]
  for li in tri.loops:
   vertex=mesh.vertices[mesh.loops[li].vertex_index];pos=M@(world@vertex.co)*unit;normal=(normal_matrix@mesh.corner_normals[li].vector).normalized()
   uv=mesh.uv_layers.active.data[li].uv if mesh.uv_layers.active else Vector((.5,.5));mapped=uv_for(mat,uv)
   poly.append([pool(g,'positions',pos),pool(g,'normals',normal),pool(g,'uvs',mapped)])
  ps=[Vector(g['positions'][x[0]])for x in poly]
  if (ps[1]-ps[0]).cross(ps[2]-ps[0]).length_squared<1e-20:world_bad.append({'object':o.name,'material':mat,'triangle':ntri})
  g['polys'].append(poly);ntri+=1
 object_receipts.append({'name':o.name,'triangles':ntri});evaluated.to_mesh_clear()
(R/'world-degeneracy.json').write_text(json.dumps(world_bad,indent=2)+'\n');assert not world_bad,'World-space collapsed triangles: inspect world-degeneracy.json'
bones=[{'name':'root','pivot':[0,0,0]}]
for name,g in sorted(groups.items()):bones.append({'name':name,'parent':'root','pivot':[0,0,0],'poly_mesh':{k:v for k,v in g.items()if not k.startswith('_')}})
geo={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.ascension_armory.soul_storm_transport','texture_width':256,'texture_height':32,'visible_bounds_width':8,'visible_bounds_height':8,'visible_bounds_offset':[0,0,0]},'bones':bones}]};(R/'soul_storm_transport.geo.json').write_text(json.dumps(geo,separators=(',',':'))+'\n')
manifest={'status':'v19 opaque hardware-only transport; effect surfaces explicitly omitted; not a complete weapon or drop-in gunpack','source_sha256':hashlib.sha256(Path(a.source).read_bytes()).hexdigest(),'blender_to_model_axes':['-Y','Z','-X'],'model_units_per_blender_unit':unit,'mesh_bones':len(groups),'triangles':sum(len(g['polys'])for g in groups.values()),'expected_tml_baked_vertices':4*sum(len(g['polys'])for g in groups.values()),'objects':object_receipts,'excluded_projectile_objects':excluded,'excluded_material_triangles':excluded_materials,'materials':materials,'atlas':{'size':[256,32],'swatch_width':40,'swatch_count':len(materials),'content':'Constant base-color swatches only; no effects/PBR texture transfer'},'limits':['No animation clips, native hand anchors, gun data or gameplay adapter','All effect surfaces omitted including living soul fire, procedural plasma and reticle; not covered by this hardware-only artifact','Source metal/roughness shaders are recorded but not translated into native materials','No native rendering, transparency, lighting, winding, shader or performance acceptance','No effect textures exported; constant material swatches only','Only authored projectile cues excluded; gameplay projectile integration remains separate']};(R/'transport-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:manifest[k]for k in ['mesh_bones','triangles','expected_tml_baked_vertices','excluded_material_triangles']}))
