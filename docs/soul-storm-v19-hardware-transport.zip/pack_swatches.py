from pathlib import Path
import json,hashlib
from PIL import Image
r=Path(__file__).resolve().parent;m=json.loads((r/'transport-manifest.json').read_text());im=Image.new('RGBA',(256,32))
def srgb(v):return max(0,min(255,round((12.92*v if v<=.0031308 else 1.055*v**(1/2.4)-.055)*255)))
for i,(name,v)in enumerate(m['materials'].items()):im.paste(tuple(srgb(c)for c in v['linear_base_rgba'][:3])+(255,),(i*40,0,(i+1)*40,32))
im.save(r/'soul_storm_transport.png');actual=Image.open(r/'soul_storm_transport.png').convert('RGBA');assert actual.tobytes()==im.tobytes()
(r/'swatch-check.json').write_text(json.dumps({'size':list(im.size),'swatches':len(m['materials']),'sha256':hashlib.sha256((r/'soul_storm_transport.png').read_bytes()).hexdigest(),'scope':'Constant base colors only. Not final textures, PBR or lighting equivalence.'},indent=2)+'\n')
