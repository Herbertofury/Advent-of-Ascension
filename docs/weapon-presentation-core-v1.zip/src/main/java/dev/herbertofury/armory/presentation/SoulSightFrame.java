package dev.herbertofury.armory.presentation;

/** Original renderer-independent sight frame math. No Minecraft/TaCZ hooks. */
public final class SoulSightFrame {
    private SoulSightFrame() {}
    public enum Sight { FLAME, CANDLE, GEM }
    public enum Pass { FIRST_PERSON, THIRD_PERSON, GUI, SHADOW }
    /** One reusable output per caller/render owner. Never share across concurrent renders. */
    public static final class Output {
        public boolean visible;
        public int frame, next;
        public float mix, u0, v0, u1, v1, nextU0, nextV0, nextU1, nextV1;
        public Sight sight;
        public void clear() {
            visible=false; frame=next=0; mix=u0=v0=u1=v1=nextU0=nextV0=nextU1=nextV1=0;
            sight=null;
        }
    }
    /**
     * presentationSeconds is caller-owned, paused game time, never wall time.
     * The caller supplies a resolved attachment and a known render pass.
     * GUI preview needs an explicit opt-in. No gameplay state is read or changed.
     * No offset is guessed: FLAME and CANDLE each require their authored leaf bone.
     */
    public static Output sample(Sight sight, Pass pass, boolean guiPreview,
                                boolean reducedMotion, double presentationSeconds, Output out) {
        if (out==null) throw new IllegalArgumentException("Caller-owned output required");
        out.clear(); // Fail closed even after a previous visible sample.
        if (sight==null || pass==null || !Double.isFinite(presentationSeconds) || presentationSeconds<0)
            throw new IllegalArgumentException("Invalid resolved sight, pass or presentation time");
        if (sight==Sight.GEM || pass==Pass.SHADOW || (pass==Pass.GUI && !guiPreview)) return out;
        double position=reducedMotion ? 0 : (presentationSeconds % 2.0) * 7.5;
        out.visible=true; out.sight=sight;
        out.frame=Math.min(14,(int)Math.floor(position));
        out.next=reducedMotion ? out.frame : (out.frame+1)%15;
        out.mix=reducedMotion ? 0 : (float)(position-out.frame);
        out.u0=(out.frame%4)*0.25f; out.v0=(out.frame/4)*0.25f;
        out.u1=out.u0+0.25f; out.v1=out.v0+0.25f;
        out.nextU0=(out.next%4)*0.25f; out.nextV0=(out.next/4)*0.25f;
        out.nextU1=out.nextU0+0.25f; out.nextV1=out.nextV0+0.25f;
        return out;
    }
}
