"""Read JSON with comments/trailing commas without altering quoted text. Not JSON5."""
import json,re
def loads(text):
 clean=re.sub(r'"(?:\\.|[^"\\])*"|//[^\r\n]*|/\*[\s\S]*?\*/',lambda m:m[0] if m[0].startswith('"') else ''.join('\n'if c=='\n'else' 'for c in m[0]),text)
 out=[];quote=False;escape=False
 for i,c in enumerate(clean):
  if quote:
   out.append(c)
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':quote=False
  elif c=='"':quote=True;out.append(c)
  elif c==',':
   k=i+1
   while k<len(clean)and clean[k].isspace():k+=1
   if k==len(clean)or clean[k]not in '}]':out.append(c)
  else:out.append(c)
 return json.loads(''.join(out))
if __name__=='__main__':
 assert loads('{"url":"https://x/a//b",/* c */"v":[1,2,],"literal":",}",}')=={'url':'https://x/a//b','v':[1,2],'literal':',}'}
 assert loads('{"s":"quote: \\\" // not comment",//real\n"x":true}')['x'] is True
 print('PASS comment/trailing-comma reader preserves quoted URL and delimiter literals')
