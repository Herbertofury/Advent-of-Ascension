Run audit.py against your own pinned TaCZ JAR with JDK17 javap and --out evidence.json. Read-only selected-class assertions. No game classes included. This is not native renderer execution.
