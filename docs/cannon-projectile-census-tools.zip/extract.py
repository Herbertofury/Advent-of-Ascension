from pathlib import Path
import json,re,subprocess,zipfile,hashlib
import argparse,shutil
parser=argparse.ArgumentParser();parser.add_argument('--jar',type=Path,required=True);parser.add_argument('--javap',default='javap');parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
Z=args.jar.resolve();J=Path(shutil.which(args.javap) or args.javap).resolve();R=args.out.resolve()
if hashlib.sha256(Z.read_bytes()).hexdigest()!='f417ecb337d4a3b2aebec559a9262d8a86cc93ee7910f4eea64108bff063193a':raise SystemExit('Wrong baseline JAR: expected AoA3-1.20.1-3.7.1-all.jar with documented SHA256')
if R.exists() and any(R.iterdir()):raise SystemExit('Use an empty output directory')
R.mkdir(parents=True,exist_ok=True)
registry=json.loads((Path(__file__).resolve().parent/'registry.json').read_text())['records']
classes=sorted({c for r in registry for c in r['constructor_classes']});base='net/tslat/aoa3/content/item/weapon/cannon/BaseCannon'
def inspect(classes,path):
 s=subprocess.check_output([str(J),'-c','-p','-classpath',str(Z),*[c.replace('/','.')for c in classes]],text=True);path.write_text(s);blocks={}
 for m in re.finditer(r'Compiled from "[^"]+"\n(public (?:abstract )?class ([\w.$]+).*?)(?=\nCompiled from |\Z)',s,re.S):blocks[m[2].replace('.','/')]=m[1]
 assert set(classes)<=blocks.keys(),set(classes)-blocks.keys();return blocks
blocks=inspect(sorted(set(classes+[base])),R/'cannon-classes.javap.txt')
def method(s,name):
 m=re.search(r'^  (?:public|protected)[^\n]*?\b'+re.escape(name)+r'\([^\n]+\n(.*?)(?=^  (?:public|protected|private)|\Z)',s,re.M|re.S);return m.group(0)if m else None
rows=[]
for r in registry:
 cs=r['constructor_classes'];assert len(cs)==1;c=cs[0];factory=method(blocks[c],'createProjectileEntity');inherited=factory is None
 if inherited:
  assert 'extends '+base.replace('/','.')+' 'in blocks[c],c
  factory=method(blocks[base],'createProjectileEntity')
 ps=sorted(set(re.findall(r'// class (net/tslat/aoa3/content/entity/projectile/[^\s]+)',factory)))
 rows.append({'id':r['id'],'weapon_class':c,'factory_inherited_from_BaseCannon':inherited,'projectile_classes':ps,'factory_disassembly':factory})
projectiles=sorted({p for r in rows for p in r['projectile_classes']});pb=inspect(projectiles,R/'projectile-classes.javap.txt')
with zipfile.ZipFile(Z)as z:
 basebullet='net/tslat/aoa3/content/entity/projectile/gun/BaseBullet'
 bs=inspect([basebullet],R/'base-bullet.javap.txt')[basebullet];bg=method(bs,'m_7139_');assert 'fconst_0'in bg and 'freturn'in bg
 evidence={}
 for p,s in pb.items():
  assert 'extends '+basebullet.replace('/','.')+' 'in s,p
  g=method(s,'m_7139_');v=None
  if g:
   assert re.findall(r'^\s*\d+:\s*(\S+)',g,re.M)==['ldc','freturn'],p
   m=re.search(r'// float ([\d.eE+-]+)f',g)
   if m and 'freturn'in g:v=float(m[1])
  evidence[p]={'class_sha256':hashlib.sha256(z.read(p+'.class')).hexdigest(),'direct_gravity_return':v,'resolved_gravity_return':v if g else 0.,'gravity_owner':p if g else basebullet,'gravity_disassembly':g,'scope':'Simple direct return or verified direct BaseBullet inheritance; not a complete runtime trajectory'}
 out={'release':'AoA3-1.20.1-3.7.1','jar_sha256':hashlib.sha256(Z.read_bytes()).hexdigest(),'base_bullet':{'class':basebullet,'sha256':hashlib.sha256(z.read(basebullet+'.class')).hexdigest(),'gravity_disassembly':bg},'weapons':rows,'projectiles':evidence,'native_tested':False,'scope':'Released class factory references and direct gravity overrides, not runtime trajectories or effective damage'}
 for r in rows:r['weapon_class_sha256']=hashlib.sha256(z.read(r['weapon_class']+'.class')).hexdigest()
 (R/'census.json').write_text(json.dumps(out,indent=2));print('weapons',len(rows),'projectiles',len(evidence),'unresolved',[r['id']for r in rows if not r['projectile_classes']]);print({p.split('/')[-1]:d['direct_gravity_return']for p,d in evidence.items()})
