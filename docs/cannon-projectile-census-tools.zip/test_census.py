import unittest,json,hashlib,zipfile,re,collections,argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--census',type=Path,required=True);p.add_argument('--jar',type=Path,required=True);args,rest=p.parse_known_args();D=json.loads(args.census.read_text());rows={r['id']:r for r in D['weapons']};ps=D['projectiles']
class Contract(unittest.TestCase):
 def test_counts(self):self.assertEqual(len(rows),50);self.assertEqual(len(D['weapons']),50);self.assertEqual(len(ps),41)
 def test_hashes(self):
  with zipfile.ZipFile(args.jar)as z:
   self.assertEqual(hashlib.sha256(args.jar.read_bytes()).hexdigest(),D['jar_sha256'])
   for r in rows.values():self.assertEqual(hashlib.sha256(z.read(r['weapon_class']+'.class')).hexdigest(),r['weapon_class_sha256'])
   for c,e in ps.items():self.assertEqual(hashlib.sha256(z.read(c+'.class')).hexdigest(),e['class_sha256'])
   self.assertEqual(hashlib.sha256(z.read(D['base_bullet']['class']+'.class')).hexdigest(),D['base_bullet']['sha256'])
 def test_factories(self):
  for r in rows.values():self.assertEqual(len(r['projectile_classes']),1);self.assertIn(r['projectile_classes'][0],ps);self.assertIn('createProjectileEntity(',r['factory_disassembly']);self.assertIn(r['projectile_classes'][0],r['factory_disassembly'])
 def test_inherited_factories(self):self.assertEqual(sum(r['factory_inherited_from_BaseCannon']for r in rows.values()),5)
 def test_ghoul(self):self.assertEqual(ps[rows['aoa3:ghoul_cannon']['projectile_classes'][0]]['resolved_gravity_return'],.05)
 def test_clown(self):self.assertEqual(ps[rows['aoa3:clown_cannon']['projectile_classes'][0]]['resolved_gravity_return'],.1)
 def test_zero_inheritance(self):
  inherited=[e for e in ps.values()if not e['gravity_disassembly']];self.assertEqual(len(inherited),15)
  for e in inherited:self.assertEqual(e['resolved_gravity_return'],0);self.assertEqual(e['gravity_owner'],D['base_bullet']['class'])
  self.assertIn('fconst_0',D['base_bullet']['gravity_disassembly'])
 def test_simple_overrides(self):
  for e in ps.values():
   if e['gravity_disassembly']:self.assertEqual(re.findall(r'^\s*\d+:\s*(\S+)',e['gravity_disassembly'],re.M),['ldc','freturn']);self.assertEqual(e['resolved_gravity_return'],e['direct_gravity_return'])
 def test_distribution(self):self.assertEqual(collections.Counter(e['resolved_gravity_return']for e in ps.values()),{0.:15,.1:15,.015:4,.05:3,.06:2,.075:2})
 def test_native(self):self.assertFalse(D['native_tested'])
if __name__=='__main__':unittest.main(argv=['test_census.py',*rest])
