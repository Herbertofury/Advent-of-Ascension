# Reproduce the cannon projectile census

Requires Python 3, a JDK exposing `javap`, and a separately obtained official AoA 3.7.1 / Minecraft 1.20.1 all JAR. No mod binaries are bundled.

Expected JAR SHA256: f417ecb337d4a3b2aebec559a9262d8a86cc93ee7910f4eea64108bff063193a

Run from this extracted directory:

```
python extract.py --jar /path/to/AoA3-1.20.1-3.7.1-all.jar --out output
python test_census.py --jar /path/to/AoA3-1.20.1-3.7.1-all.jar --census output/census.json
```

Use `--javap /path/to/javap` if it is not on PATH. The output directory must be empty. The baseline hash is checked before disassembly. Bundled registry.json is the project’s previously extracted 50-cannon class inventory, not a runtime registry dump.

The extractor records factory references and resolves simple direct gravity returns or verified direct BaseBullet inheritance. It rejects complex gravity-method instruction shapes rather than guessing from the first constant. This is not a full trajectory simulator: velocity, drag, custom updates, lifetime, collision, damage and native multiplayer need separate qualification.

Tested here using Python 3.12 and Amazon Corretto JDK17 on Linux. The clean portable run reproduced census.json byte-for-byte, and all ten contract test methods passed. This does not claim every OS/JDK combination has been tested.
