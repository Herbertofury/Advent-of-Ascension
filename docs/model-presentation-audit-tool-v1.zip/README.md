# Static TaCZ presentation audit

Original Python tooling. Requires Pillow. Run `python audit_pack.py /path/to/official-pack.zip result.json`; run `python test_audit.py` for the synthetic fixture test.

This reads actual display records, referenced main model JSON and textures. It distinguishes model-declared UV dimensions from actual PNG dimensions, counts per-face UV and rotated/zero-extent cuboids, and reports exact-path LOD references separately from files actually present. It does not substitute a similar filename for a missing reference.

Counts include every stored part, including mutually exclusive attachment variants; they are not submitted draw counts or runtime performance measures. A zero-extent cuboid can intentionally be a visual plane. A higher-resolution PNG can intentionally use a lower-resolution declared UV layout. Neither is automatically a defect. Missing local references can be supplied by another loaded resource pack; the audit makes no universal runtime-failure claim.

The source fixture test uses entirely generated dummy geometry/texture data. Reference packs and their assets are not included. Credit Koei for Ars Armorer; obtain that pack from its official project page and check its license before reusing assets.
