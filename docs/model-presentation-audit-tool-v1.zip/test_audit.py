import io,json,subprocess,sys,tempfile,unittest,zipfile
from pathlib import Path
from PIL import Image
class AuditTest(unittest.TestCase):
    def test_geometry_and_missing_lod_are_not_conflated(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);im=io.BytesIO();Image.new('RGBA',(128,128)).save(im,format='PNG')
            g={'minecraft:geometry':[{'description':{'texture_width':64,'texture_height':64},'bones':[{'name':'root','cubes':[{'size':[1,0,1],'rotation':[0,45,0],'uv':{'north':{'uv':[0,0],'uv_size':[1,1]}}}]}]}]}
            d={'model':'test:gun/model','texture':'test:gun/texture','lod':{'model':'test:gun/missing','texture':'test:gun/texture'}}
            with zipfile.ZipFile(p/'pack.zip','w') as z:
                z.writestr('assets/test/display/guns/gun.json',json.dumps(d));z.writestr('assets/test/geo_models/gun/model.json',json.dumps(g));z.writestr('assets/test/textures/gun/texture.png',im.getvalue())
            subprocess.run([sys.executable,str(Path(__file__).with_name('audit_pack.py')),str(p/'pack.zip'),str(p/'out.json')],check=True,capture_output=True)
            r=json.loads((p/'out.json').read_text())['guns'][0]
            self.assertEqual(r['geometry']['zero_extent_planes'],1);self.assertEqual(r['geometry']['rotated_cuboids'],1)
            self.assertEqual(r['geometry']['per_face_uv_cuboids'],1);self.assertEqual(r['geometry']['declared_texture_size'],[64,64])
            self.assertEqual(r['actual_texture_size'],[128,128]);self.assertFalse(r['lod']['model']['present_in_archive']);self.assertTrue(r['lod']['texture']['present_in_archive'])
            self.assertNotIn('geometry',r['lod'])
if __name__=='__main__':unittest.main()
