"""Static TaCZ gun model/UV/LOD inventory. No game loading or runtime inference."""
from pathlib import Path
import argparse,hashlib,io,json,zipfile
from PIL import Image

def resource(identifier,directory,extension):
    ns,local=identifier.split(':',1)
    return f'assets/{ns}/{directory}/{local}.{extension}'

def geometry(z,name):
    g=json.loads(z.read(name))['minecraft:geometry'][0]
    cubes=[c for b in g['bones'] for c in b.get('cubes',[])]
    return {'bones':len(g['bones']),'cuboids_including_planes':len(cubes),
            'zero_extent_planes':sum(0 in c.get('size',[]) for c in cubes),
            'rotated_cuboids':sum(any(c.get('rotation',[])) for c in cubes),
            'per_face_uv_cuboids':sum(isinstance(c.get('uv'),dict) for c in cubes),
            'declared_texture_size':[g['description']['texture_width'],g['description']['texture_height']],
            'sha256':hashlib.sha256(z.read(name)).hexdigest()}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('archive',type=Path);p.add_argument('output',type=Path);args=p.parse_args()
    results=[]
    with zipfile.ZipFile(args.archive) as z:
        names=set(z.namelist())
        for n in sorted(names):
            if '/display/guns/' not in n or not n.endswith('.json'):continue
            d=json.loads(z.read(n)); model=resource(d['model'],'geo_models','json'); texture=resource(d['texture'],'textures','png')
            row={'display':n,'display_sha256':hashlib.sha256(z.read(n)).hexdigest(),'model':model,'texture':texture,'geometry':geometry(z,model)}
            image=Image.open(io.BytesIO(z.read(texture)));row['actual_texture_size']=list(image.size)
            row['texture_sha256']=hashlib.sha256(z.read(texture)).hexdigest()
            row['lod']={}
            for k,v in d.get('lod',{}).items():
                if k not in ('model','texture'):continue
                candidate=resource(v,'geo_models' if k=='model' else 'textures','json' if k=='model' else 'png')
                row['lod'][k]={'declared':v,'exact_path':candidate,'present_in_archive':candidate in names}
            if row['lod'].get('model',{}).get('present_in_archive'):
                row['lod']['geometry']=geometry(z,row['lod']['model']['exact_path'])
            results.append(row)
    args.output.write_text(json.dumps({'scope':'Static archive-path and geometry inventory; no runtime failure/performance claim',
        'archive_sha256':hashlib.sha256(args.archive.read_bytes()).hexdigest(),'guns':results},indent=2)+'\n')
    print(f'Inspected {len(results)} gun models')
if __name__=='__main__':main()
