"""Verify the pinned 56-blaster baseline inventory; no game classes execute."""
import argparse,pathlib,json,hashlib,zipfile,os,shutil,subprocess
p=argparse.ArgumentParser();p.add_argument('jar',type=pathlib.Path);p.add_argument('dataset',type=pathlib.Path);a=p.parse_args();d=json.loads(a.dataset.read_text());assert hashlib.sha512(a.jar.read_bytes()).hexdigest()==d['jar_sha512'];rows=d['records'];assert len(rows)==len({r['id']for r in rows})==56
with zipfile.ZipFile(a.jar)as z:
 for r in rows:assert hashlib.sha256(z.read(r['constructor_class']+'.class')).hexdigest()==r['class_sha256'],r['id']
 assert hashlib.sha256(z.read('net/tslat/aoa3/common/registration/item/AoAWeapons.class')).hexdigest()==d['registry_sha256']
javap=str(pathlib.Path(os.environ['JAVA_HOME'])/'bin/javap')if os.getenv('JAVA_HOME')else shutil.which('javap');assert javap
base=subprocess.check_output([javap,'-p','-c','-classpath',str(a.jar),'net.tslat.aoa3.content.item.weapon.blaster.BaseBlaster'],text=True);cost=base.split('public float getEnergyCost(',1)[1].split('\n  public ',1)[0]
for needle in ['RECHARGE','GREED','float 0.3f','float 0.07f','Math.max','GHOULISH','float 0.7f']:assert needle in cost,needle
byid={r['id']:r for r in rows}
for key,charge in [('blast_chiller',20),('light_spark',10),('soul_spark',20),('laser_blaster',20)]:assert byid['aoa3:'+key]['stored_charge_ticks']==charge
for key in ['light_spark','soul_spark']:
 row=byid['aoa3:'+key];s=subprocess.check_output([javap,'-p','-c','-classpath',str(a.jar),row['constructor_class']],text=True);f=s.split('public float getEnergyCost(',1)[1].split('\n  public ',1)[0];assert 'float 200.0f' in f and 'BaseBlaster.getEnergyCost' in f
 impact=s.split('public boolean doEntityImpact(',1)[1].split('\n  public ',1)[0];assert 'consumeResource' in impact and 'SPIRIT' in impact and 'float 200.0f' in impact and 'isImmuneToSpecialAttacks' in impact
assert byid['aoa3:gravity_blaster']['stored_base_spirit']==120 and byid['aoa3:vortex_blaster']['stored_base_spirit']==130
print('PASS 56 released class hashes, exact registry, charge exceptions, modifier constants and two distinct display/start-use cost paths. Static audit only; native firing behavior untested.')
