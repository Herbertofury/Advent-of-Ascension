# Blaster stored-baseline audit
Use Python3 and a full JDK17+ (JAVA_HOME or javap on PATH):
python audit_baselines.py PATH_TO_AOA_1.20.1_3.7.1_JAR blaster-baselines-1.20.1.json
This verifies the pinned archive,56 class hashes,registry and selected inherited/override paths without booting or executing game code. Stored constructor values were mapped through all56 inspected constructors. Fifty use the simple DIIF forwarding path; six special constructors cover three fixed charge additions, Laser Blaster's explicit charge argument and two EPIC Item.Properties wrappers. No equivalent native damage/DPS/shot count claim.
Original AoA belongs to Tslat and contributors. No original mod binary or source is bundled. Recipe/damage overrides beyond the listed exceptions still require per-weapon review.
