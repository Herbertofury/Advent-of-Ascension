# Discharge v35: texture and grouped-mesh study

This is an editable authoring and transport package, not a playable mod or a final-art acceptance certificate. It retains the original four-projectile gameplay contract; the three visual recoil channels are presentation studies only.

## Open the current work

Open `discharge-texture-current-v35/grouped-normal-r3/discharge-grouped-study.blend` in Blender 4.3.2. The four texture maps are packed into the scene; separate PNGs are also supplied for controlled export work. Earlier source parts are retained hidden, and seven visible groups form the current preview. Do not unhide every source/atlas/group copy together.

The current scene comes from the corrected v33 recoil/exterior study and v34 capacitor-canopy study. It does not reuse the rejected v32-r2 enlarged-fastener scene. The v34 source is unchanged in silhouette by this texture/export work.

## Regenerate inspection/export artifacts

From this package root, using Blender 4.3.2:

```
blender -b -t 2 --python-exit-code 1 --python discharge-tml-transport-v35/export_geometry.py
blender -b -t 2 --python-exit-code 1 --python discharge-tml-transport-v35/export_clips.py
python discharge-tml-transport-v35/compact_float32.py discharge-tml-transport-v35/discharge_grouped.geo.json discharge-tml-transport-v35/discharge_grouped.compact.geo.json
blender -b -t 2 --python-exit-code 1 --python discharge-texture-current-v35/export_preview.py
```

The transport scripts intentionally assert this fixture’s seven groups and 75,188 triangles. Geometry edits require fresh checks and an updated fixture; old receipts must not be treated as current validation. The GLB is static browser/authoring inspection, while the `.geo.json` and separate animation JSON are TaCZ/TML-oriented transport studies. Neither constitutes a complete gunpack.

## Verified, bounded evidence

- Four 2048² maps: base color, emission color, raw roughness and positive-Y tangent-space normals.
- Zero degenerate UV triangles, zero sampled texel overlaps and zero positive triangle-intersection overlaps above the documented 1e-14 UV-area tolerance in the revised layout. 270 problematic triangles were isolated/reprojected; tiny slivers received a minimum UV span. This is not a final texel-density or mipmap certificate.
- 186 atlas parts grouped into seven equal-motion groups. 52,346,400 quarter-frame vertex samples preserve world positions within 1.09e-7 scene units, with exact UVs and preserved material assignments. This does not prove every interpolation time or alternate animation.
- The grouped normal-mapped scene closely matches its GLB roundtrip at the reviewed camera. The normal bake differs from the original procedural shading and still needs additional-angle/detail review.
- Three translation clips, two moving groups per clip, 37 keys per group. Sampled linear interpolation error stays below 0.005 model units. Sound, material curves, hands and confirmed-shot event binding are not exported by these clips.
- Unmodified released TML data-baker checks on Java 17/21 read seven mesh bones and 300,752 expanded vertices. Compact numeric encoding preserves all 2,406,016 consumed baked float values while reducing JSON from 17,180,376 to 12,608,390 bytes. This is a file-size result, not an FPS claim.
- Actual released TaCZ animation-parser classes parse three clips and 222 keys, using documented narrow helper stand-ins. No Minecraft launch occurred.

## Explicit blockers and unfinished quality

Stock TML’s flat-normal path reports eight faces with normal length below 0.99. Parsing success therefore does not accept lighting. A separate opt-in source candidate preserves authored normals across all 300,752 expanded corners with maximum component error 2.981e-8 and leaves default arrays bit-identical. That candidate is not an installed/released feature, and stock TML ignores its proposed field.

Native base/emission/roughness/normal binding, fallback/VBO normal parity, low-poly/LOD work, startup/memory/frame-time measurements, hand anchors, multiplayer/gameplay, all animation states, projectile/impact effects and accessibility remain open. The chamber pattern is baked at one source frame; native animated energy is not implemented by these PNGs.

The selected owner concept remains substantially more sculpted and ornamented. Grip finger contours, receiver detail, crown shapes, decorative metalwork, surface art, variants and the complete feedback package still need further work. Do not label this model concept-faithful, finished or breathtaking solely because the export checks pass.

## Attribution and dependencies

New geometry, scripts and texture studies are project authoring work. Original AoA identity belongs to Tslat and contributors. Upstream game/mod bytecode and dependency jars are not included. TML evidence refers to the official Forge 1.20.1 0.1.8 release; the separate normal candidate is a source proposal for VellEagle/TacZMeshLoader. See the published study pages for pinned sources and the candidate’s GPL-3.0 patch terms.
