"""Seven-group normalized-UV transport study; not a native-ready gunpack."""
import bpy,json,hashlib,math
from pathlib import Path
from mathutils import Matrix
R=Path(__file__).resolve().parent;source=R.parent/'discharge-texture-current-v35/grouped-normal-r3/discharge-grouped-study.blend';bpy.ops.wm.open_mainfile(filepath=str(source));bpy.context.scene.frame_set(1);bpy.context.view_layer.update();M=Matrix(((0,-1,0),(0,0,1),(-1,0,0)));unit=4.;bones=[{'name':'root','pivot':[0,0,0]}];receipts=[]
def pool(g,k,v):
 v=tuple(float(x)for x in v);assert all(math.isfinite(x)for x in v)
 if v not in g['_'+k]:g['_'+k][v]=len(g[k]);g[k].append(list(v))
 return g['_'+k][v]
for o in sorted(bpy.data.objects,key=lambda o:o.name):
 if o.type!='MESH'or o.hide_render:continue
 assert o.name.startswith('AtlasMotionGroup_'),o.name
 me=o.data;me.calc_loop_triangles();g={'normalized_uvs':True,'positions':[],'normals':[],'uvs':[],'polys':[],'_positions':{},'_normals':{},'_uvs':{}};nm=M@o.matrix_world.to_3x3().inverted().transposed();n=0
 for t in me.loop_triangles:
  poly=[]
  for li in t.loops:
   pos=M@(o.matrix_world@me.vertices[me.loops[li].vertex_index].co)*unit;normal=(nm@me.corner_normals[li].vector).normalized();uv=me.uv_layers.active.data[li].uv;assert all(0<=x<=1 for x in uv);poly.append([pool(g,'positions',pos),pool(g,'normals',normal),pool(g,'uvs',uv)])
  g['polys'].append(poly);n+=1
 name=o.name.lower();bones.append({'name':name,'parent':'root','pivot':[0,0,0],'poly_mesh':{k:v for k,v in g.items()if not k.startswith('_')}});receipts.append({'object':o.name,'bone':name,'triangles':n,'materials_not_bound':[m.name for m in me.materials]})
assert len(receipts)==7 and sum(x['triangles']for x in receipts)==75188
geo={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.ascension_armory.discharge_uv_motion_study','texture_width':2048,'texture_height':2048,'visible_bounds_width':8,'visible_bounds_height':8,'visible_bounds_offset':[0,0,0]},'bones':bones}]};(R/'discharge_grouped.geo.json').write_text(json.dumps(geo,separators=(',',':'))+'\n');report={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'mesh_bones':7,'triangles':75188,'expected_baked_float_values':75188*4*8,'objects':receipts,'axis_mapping':['-Y','Z','-X'],'scale':4,'uv_policy':'Retained loop UVs, no material-swatch substitution','native_accepted':False,'limits':['No complete gunpack, hand anchors or native animation binding','Original source materials are not bound by this geometry file','Explicit normal/emission/roughness native shader paths remain unqualified','High-poly authoring mesh; native frame-time, LOD and memory budget remain open','Released TML flat-normal defaults require separate candidate/fallback validation']};(R/'manifest.json').write_text(json.dumps(report,indent=2));print({k:report[k]for k in ['mesh_bones','triangles','expected_baked_float_values']})
