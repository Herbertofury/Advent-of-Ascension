"""Transport grouped world translations into matching TaCZ-style bone tracks."""
import bpy,json,numpy as np,math,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;source=R.parent/'discharge-texture-current-v35/grouped-normal-r3/discharge-grouped-study.blend';bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene;objects=sorted([o for o in bpy.data.objects if o.type=='MESH'and not o.hide_render],key=lambda o:o.name);assert len(objects)==7;s.frame_set(1);bpy.context.view_layer.update();rest={o.name:np.linalg.inv(np.array(o.matrix_world))for o in objects};M=np.array([[0,-1,0],[0,0,1],[-1,0,0]],dtype=float);clips={};maximum=0;bonecounts=[]
def translations(frame):
 s.frame_set(math.floor(frame),subframe=frame%1);bpy.context.view_layer.update();out={}
 for o in objects:
  delta=np.array(o.matrix_world)@rest[o.name];assert np.allclose(delta[:3,:3],np.eye(3),rtol=0,atol=1e-6),'Nontranslation motion needs a rotation export path';out[o.name.lower()]=(M@delta[:3,3]*4)
 return out
for ci,start in enumerate([1,166,331]):
 samples=[translations(start+j/4)for j in range(37)];active=[o.name.lower()for o in objects if any(np.linalg.norm(v[o.name.lower()])>1e-6 for v in samples)];bones={name:{'position':{f'{j/240:.9f}':v[name].tolist()for j,v in enumerate(samples)}}for name in active};bonecounts.append(len(bones));assert len(bones)==2
 for j in range(361):
  actual=translations(start+9*j/360);k=min(35,j//10);f=j/10-k
  for name in active:maximum=max(maximum,float(np.max(np.abs(actual[name]-(samples[k][name]*(1-f)+samples[k+1][name]*f)))))
 clips[f'shoot_emitter_{ci+1}']={'animation_length':.15,'loop':False,'bones':bones}
assert maximum<.005;geo=json.loads((R/'discharge_grouped.geo.json').read_text());names={b['name']for b in geo['minecraft:geometry'][0]['bones']};assert all(set(c['bones'])<=names for c in clips.values());(R/'discharge_recoil.animation.json').write_text(json.dumps({'format_version':'1.8.0','animations':clips},indent=2)+'\n');report={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'clips':3,'animated_bones_per_clip':bonecounts,'keys_per_bone':37,'sampled_validation_points_per_clip':361,'maximum_linear_sample_error_model_units':maximum,'geometry_bone_names_match':True,'native_accepted':False,'scope':'Matching grouped presentation geometry and sampled translation clips only; original four-projectile gameplay burst unchanged, no native scheduler/binding/hand acceptance'};(R/'clip-export-qa.json').write_text(json.dumps(report,indent=2));print(report)
