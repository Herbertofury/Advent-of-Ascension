# Spirit Shower source study
Run audit.py with the pinned AoA 3.7.1 JAR and a local JDK javap path:

    python audit.py /path/to/AoA3-1.20.1-3.7.1-all.jar --javap /path/to/jdk/bin/javap

The script inspects bytecode and packaged JSON without executing game classes. Source JAR is not bundled. Concepts are art proposals and remain unaccepted for native use. released-evidence.json records exact hashes and evidence limits.
