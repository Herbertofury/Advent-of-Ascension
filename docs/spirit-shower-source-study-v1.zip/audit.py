"""Read-only pinned Spirit Shower release audit. Does not run game classes."""
import argparse,hashlib,json,subprocess,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('jar',type=Path);p.add_argument('--javap',required=True);p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args();a.out.mkdir(exist_ok=True)
sha=hashlib.sha256(a.jar.read_bytes()).hexdigest();assert sha=='f417ecb337d4a3b2aebec559a9262d8a86cc93ee7910f4eea64108bff063193a'
classes=['net.tslat.aoa3.common.registration.item.AoAWeapons','net.tslat.aoa3.content.item.weapon.blaster.SpiritShower','net.tslat.aoa3.content.item.weapon.blaster.ApocoShower','net.tslat.aoa3.content.item.weapon.blaster.BaseBlaster','net.tslat.aoa3.content.entity.projectile.blaster.ShowerShotEntity','net.tslat.aoa3.content.entity.projectile.blaster.WeightedShowerShotEntity','net.tslat.aoa3.content.entity.projectile.blaster.HeavyShowerShotEntity','net.tslat.aoa3.client.render.entity.projectile.blasters.ShowerShotRenderer']
with zipfile.ZipFile(a.jar) as z:
 dec={c.rsplit('.',1)[-1]:subprocess.check_output([a.javap,'-classpath',str(a.jar),'-p','-c','-constants',c],text=True)for c in classes}
 reg=next(part for part in dec['AoAWeapons'].split('private static')if '// class net/tslat/aoa3/content/item/weapon/blaster/SpiritShower' in part)
 assert all(x in reg for x in ['dconst_0','sipush        2870','bipush        10','float 100.0f'])
 src=dec['SpiritShower'];fire=src.split('public void fireBlaster(')[1].split('public void doBlockImpact(')[0]
 assert fire.count('Level.m_7967_')==3 and fire.count('bipush        60')==3
 assert src.count('float 2.5f')==2 and 'ITEM_SPIRIT_SHOWER_FIRE' in src
 grav={'ShowerShotEntity':.05,'WeightedShowerShotEntity':.1,'HeavyShowerShotEntity':.2}
 for k,v in grav.items():assert f'float {v}f' in dec[k]
 lootpath='data/aoa3/loot_tables/entities/jawe.json';loot=json.loads(z.read(lootpath));pool=next(p for p in loot['pools']if p.get('name')=='loot');entry=next(e for e in pool['entries']if e.get('name')=='aoa3:spirit_shower');weight=sum(e.get('weight',1)for e in pool['entries']);assert entry['weight']==4 and weight==162 and pool['rolls']==1
 recipepath='data/aoa3/recipes/upgrade_kit_apoco_shower.json';recipe=json.loads(z.read(recipepath));assert recipe['input']['item']=='aoa3:spirit_shower'
 sprite='assets/aoa3/textures/item/spirit_shower.png';(a.out/'original.png').write_bytes(z.read(sprite))
 report={'release':'AoA 3.7.1 / Minecraft 1.20.1','jar_sha256':sha,'class_sha256':{c:hashlib.sha256(z.read(c.replace('.','/')+'.class')).hexdigest()for c in classes},'sprite_sha256':hashlib.sha256(z.read(sprite)).hexdigest(),'inputs':{'base_direct_damage':0,'durability':2870,'delay_ticks':10,'base_spirit_cost':100,'spawn_attempts':3,'projectile_age_parameter_each':60,'gravity_returns':grav,'explosion_strength_input':2.5},'upgrade':{'recipe':recipe,'effect':'Apoco Shower retains inspected three-path attack and explosion inputs; registered durability becomes3760 and base Spirit cost80'},'acquisition':{'table':lootpath,'sha256':hashlib.sha256(z.read(lootpath)).hexdigest(),'selected_entry_weight':4,'pool_total_weight':162,'base_single_roll_fraction':'4/162 = 2/81','boundary':'Packaged loot-table calculation only. Does not establish active spawning or guaranteed obtainable content in this release.'},'entity_impact_boundary':'Explosion effect is conditional on inherited energy attack helper accepting the zero direct-damage attack; requires native tests.','lore_boundary':'Jawe loot association verified; no asserted maker, dimension, or material lore.','native_accepted':False}
(a.out/'released-evidence.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS: Spirit Shower inputs, three paths, kit lineage and Jawe table')
