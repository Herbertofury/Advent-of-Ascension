"""Sample owned recoil transforms into TaCZ-style position tracks; native binding untested."""
import bpy,json,math,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;src=R/'discharge-recoil-study.blend';bpy.ops.wm.open_mainfile(filepath=str(src));s=bpy.context.scene;manifest=json.loads((R/'manifest.json').read_text());clips={};max_error=0
for i,start in enumerate(manifest['shot_start_frames']):
 o=bpy.data.objects[f'Discharge_emitter_{i+1}_top_to_bottom'];keys={};sample_values=[]
 for j in range(37):
  frame=start+9*j/36;s.frame_set(math.floor(frame),subframe=frame%1);z=-4*o.location.x;t=9*j/36/60;keys[f'{t:.9f}']=[0,0,z];sample_values.append(z)
 for j in range(361):
  frame=start+9*j/360;s.frame_set(math.floor(frame),subframe=frame%1);actual=-4*o.location.x;k=min(35,int(j/10));f=j/10-k;approx=sample_values[k]*(1-f)+sample_values[k+1]*f;max_error=max(max_error,abs(actual-approx))
 clips[f'shoot_emitter_{i+1}']={'animation_length':.15,'loop':False,'bones':{o.name.lower():{'position':keys}}}
(R/'discharge_recoil.animation.json').write_text(json.dumps({'format_version':'1.8.0','animations':clips},indent=2)+'\n');report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'clips':3,'keys_per_clip':37,'sampled_points_per_clip':361,'maximum_linear_sample_error_model_units':max_error,'axis_mapping':'Blender -X becomes model +Z at 4 model units per Blender unit','native_parser_tested':False,'native_game_tested':False,'limits':['Geometry must export matching bone names and coordinate frame','Material/glow keyframes are not carried in these position-only clips','These are presentation clips, not a firing scheduler or gameplay behavior']};(R/'clip-export-qa.json').write_text(json.dumps(report,indent=2)+'\n');print(report);assert max_error<.005
