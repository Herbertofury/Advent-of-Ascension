"""Original three-channel cosmetic recoil authoring fixture, not native gameplay."""
import bpy,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'discharge-finish-study-v15/discharge-finish-study.blend'));root=bpy.data.objects['Discharge_Root'];centers=[1.16,.68,.2];groups=[];mapping=[]
for i,zc in enumerate(centers):
 e=bpy.data.objects.new('Discharge_emitter_'+str(i+1)+'_top_to_bottom',None);bpy.context.collection.objects.link(e);e.parent=root;groups.append(e)
 glow=bpy.data.materials['Discharge capacitor red'].copy();glow.name='Discharge emitter '+str(i+1)+' local glow'
 for o in list(bpy.data.objects):
  if o.hide_render or not o.name.startswith(('Owned white muzzle housing','Owned dark muzzle liner','Muzzle horizontal segment','Muzzle inner red edge')):continue
  if o.type not in {'MESH','CURVE'}:continue
  z=sum((o.matrix_world@Vector(c)).z for c in o.bound_box)/8
  nearest=min(range(3),key=lambda j:abs(centers[j]-z))
  if nearest!=i:continue
  assert abs(z-zc)<.23,(o.name,z,zc)
  world=o.matrix_world.copy();o.parent=e;o.matrix_world=world
  for slot in o.material_slots:
   if slot.material and slot.material.name=='Discharge capacitor red':slot.material=glow
  mapping.append({'object':o.name,'emitter_index':i,'bone':e.name})
 start=1+i*165
 for frame,x in [(1,0),(start,0),(start+2,-.075),(start+5,.008),(start+9,0),(340,0)]:e.location.x=x;e.keyframe_insert('location',frame=frame)
 p=glow.node_tree.nodes.get('Principled BSDF')
 for frame,strength in [(1,2.8),(start,2.8),(start+1,6),(start+3,2.8),(340,2.8)]:p.inputs['Emission Strength'].default_value=strength;p.inputs['Emission Strength'].keyframe_insert('default_value',frame=frame)
 if e.animation_data:
  for fc in e.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.interpolation='BEZIER';k.handle_left_type='AUTO_CLAMPED';k.handle_right_type='AUTO_CLAMPED'
s=bpy.context.scene;s.render.fps=60;s.render.fps_base=1;s.frame_start=1;s.frame_end=340;s.frame_set(1);bpy.context.view_layer.update()
assert all(any(row['emitter_index']==i for row in mapping)for i in range(3))
bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-recoil-study.blend'))
(R/'manifest.json').write_text(json.dumps({'status':'unaccepted cosmetic authoring fixture','mapping':mapping,'fps':60,'shot_start_frames':[1,166,331],'timing_note':'Nominal 55 ticks at 20TPS represented at 60 authoring FPS; not an implemented fire-rate scheduler','native_tested':False,'original_projectile_burst_count':4,'visual_channels':3,'limits':['No native clip export or confirmed-shot binding','No full sweep collision, hands or ammo animation QA','Local material keyframes need separate native implementation']},indent=2)+'\n')
print('Mapped',len(mapping),'parts to',len(groups),'emitter owners')
