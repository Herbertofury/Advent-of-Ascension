# Discharge three-channel cosmetic recoil study

Unaccepted authoring/transport fixture based on the published v 15 exterior model, not a playable gunpack.

18 authored pieces are assigned to three independently owned channel groups, top to bottom. Each has a short recoil/recovery curve and its own glow material. The fixture uses shot starts at frames 1,166,331 at 60 fps, reflecting the baseline's nominal 55 ticks/20 TPS interval for illustration. It does not schedule game firing. Each accepted original burst still has four projectiles; channel count is not pellet count.

`check.py` evaluates 340 integer frames and 6,120 part transforms: maximum owner-follow/inactive-motion error 0, all three glow materials return to neutral outside their active window. This is not continuous collision, interpolation, hand or play-feel acceptance.

`export_clips.py` emits three position-only clips with 37 keys each,0.15 seconds long. Blender-X maps to model+Z at 4 model units per authoring unit. Maximum linear sample error over 361 points/clip is 0.003077 model units. Glow/shader keys are not exported in these clips.

The actual released TaCZ 1.1.8-hotfix 2 animation-parser bytecode accepted all 3 clips/111 keys onJava 17 andJava 21. The harness validates 18 hash-pinned released classes and five pinned library JARs; documented narrow Minecraft/logging helpers are stand-ins. This does not test a real game, native animation playback, model bones, resource binding, audio, multiplayer or performance.

To reproduce authoring checks, run Blender 4.3.2 with `--python-exit-code 1 --python build.py`, then check.py and export_clips.py. `check_released_parser.py` expects the separately documented released-tacz-parser-study cache and local Java 17/21 tools; it does not download them. Do not put these sources in a Mods folder.

A future native adapter must resolve matching bones once per asset generation, select only the confirmed channel, reconcile local prediction without adding network latency, preserve original resources/cadence and restore interrupted poses. The generic confirmed-shot component is published separately.
