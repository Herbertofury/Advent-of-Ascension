"""Original source-material bake for export study. Does not certify final art or native materials."""
import bpy,json,hashlib,math,runpy,sys
from pathlib import Path
from mathutils import Matrix,Vector
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R));from owner_selection import select_owner_pair
source=R.parent/'discharge-finish-study-v15/discharge-finish-study.blend';runpy.run_path(str(R/'preflight.py'),run_name='__main__');s=bpy.context.scene;dg=bpy.context.evaluated_depsgraph_get();objects=[];originals=[]
for o in list(bpy.data.objects):
 if o.type not in {'MESH','CURVE'}or o.hide_render:continue
 e=o.evaluated_get(dg);me=bpy.data.meshes.new_from_object(e,preserve_all_data_layers=True,depsgraph=dg);part_id=len(objects);part_attribute=me.attributes.new('SourcePartId','INT','FACE');
 for entry in part_attribute.data:entry.value=part_id
 me.transform(o.matrix_world);n=bpy.data.objects.new('Bake_'+o.name,me);bpy.context.collection.objects.link(n);objects.append(n);originals.append(o);o.hide_render=True
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.join();model=bpy.context.object;model.name='Discharge_baked_export_study'
# Remove inherited partial UVs before constructing one complete atlas.
while model.data.uv_layers:model.data.uv_layers.remove(model.data.uv_layers[0])
model.data.uv_layers.new(name='ExportUV');bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=math.radians(66),island_margin=.004,area_weight=.5,correct_aspect=True,scale_to_bounds=True);bpy.ops.object.mode_set(mode='OBJECT')
# Prioritize the fine energy pattern instead of increasing every material's resolution.
uv_data=model.data.uv_layers.active.data
for poly in model.data.polygons:
 if model.data.materials[poly.material_index].name.startswith('Discharge patterned core'):
  for li in poly.loop_indices:uv_data[li].uv*=2.0
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.select_all(action='SELECT');bpy.ops.uv.pack_islands(rotate=True,margin=.004);bpy.ops.object.mode_set(mode='OBJECT')
for item in model.data.uv_layers.active.data:item.uv=item.uv*(1-8/1024)+Vector((4/1024,4/1024))
# Bake from the untouched original objects, retaining their actual Generated-coordinate behavior.
for i,mat in enumerate(model.data.materials):model.data.materials[i]=mat.copy()
for o in originals:o.hide_render=False;o.select_set(True)
model.select_set(True);bpy.context.view_layer.objects.active=model
s.render.engine='CYCLES';s.cycles.samples=8;s.cycles.use_denoising=False;s.render.bake.margin=4;s.render.bake.use_selected_to_active=True;s.render.bake.cage_extrusion=.003;s.render.bake.max_ray_distance=.01;s.render.bake.use_pass_direct=False;s.render.bake.use_pass_indirect=False;s.render.bake.use_pass_color=True
# Rebuild separately owned parts from explicit source IDs; retain UVs and corner normals.
part_attr=model.data.attributes.get('SourcePartId');assert part_attr is not None
parts=[];uvs=model.data.uv_layers.active.data;normals=model.data.corner_normals
for part_id,original in enumerate(originals):
 polys=[p for p in model.data.polygons if part_attr.data[p.index].value==part_id];assert polys,original.name
 vertices=sorted({v for p in polys for v in p.vertices});mapping={old:new for new,old in enumerate(vertices)}
 me=bpy.data.meshes.new('AtlasPart_'+original.name);me.from_pydata([model.data.vertices[v].co for v in vertices],[],[[mapping[v]for v in p.vertices]for p in polys]);me.update()
 for mat in model.data.materials:me.materials.append(mat)
 uv=me.uv_layers.new(name='ExportUV');custom=[]
 for dst,src in zip(me.polygons,polys):
  dst.material_index=src.material_index;dst.use_smooth=src.use_smooth
  for dl,sl in zip(dst.loop_indices,src.loop_indices):uv.data[dl].uv=uvs[sl].uv;custom.append(tuple(normals[sl].vector))
 me.normals_split_custom_set(custom)
 obj=bpy.data.objects.new('AtlasPart_'+original.name,me);bpy.context.collection.objects.link(obj);obj.parent=original;obj.matrix_parent_inverse=original.matrix_world.inverted();parts.append(obj)
model.hide_render=True
(R/'part-ownership.json').write_text(json.dumps({'parts':len(parts),'owners':[{'part':o.name,'owner':o.parent.name}for o in parts],'scope':'Authoring parent ownership and atlas reconstruction; native animation/export remains untested'},indent=2)+'\n')

textures={}
for kind,name in [('DIFFUSE','discharge-basecolor'),('EMIT','discharge-emission'),('ROUGHNESS','discharge-roughness')]:
 im=bpy.data.images.new(name,1024,1024,alpha=True);im.colorspace_settings.name='Non-Color' if kind=='ROUGHNESS' else 'sRGB';im.generated_color=(0,0,0,0)
 for mat in model.data.materials:
  mat.use_nodes=True
  for node in mat.node_tree.nodes:node.select=False
  node=mat.node_tree.nodes.new('ShaderNodeTexImage');node.image=im;node.select=True;mat.node_tree.nodes.active=node
 # Bake raw shader input colors through unit emission, avoiding diffuse-lobe weighting.
 replacements=[]
 unique={mat.name:mat for obj in originals for mat in obj.data.materials if mat and mat.use_nodes}
 for mat in unique.values():
  tree=mat.node_tree;pbr=tree.nodes.get('Principled BSDF');output=next((n for n in tree.nodes if n.type=='OUTPUT_MATERIAL'and n.is_active_output),None)
  if not pbr or not output:continue
  socket=pbr.inputs[{'DIFFUSE':'Base Color','EMIT':'Emission Color','ROUGHNESS':'Roughness'}[kind]];old=[link.from_socket for link in list(output.inputs['Surface'].links)];em=tree.nodes.new('ShaderNodeEmission');em.inputs['Strength'].default_value=1
  if socket.is_linked:tree.links.new(socket.links[0].from_socket,em.inputs['Color'])
  else:em.inputs['Color'].default_value=(socket.default_value,socket.default_value,socket.default_value,1) if kind=='ROUGHNESS' else socket.default_value
  tree.links.new(em.outputs[0],output.inputs['Surface']);replacements.append((tree,output,old,em))
 try:
  for index,(owner,target)in enumerate(zip(originals,parts)):
   select_owner_pair(owner,target,originals,parts);s.render.bake.use_clear=(index==0);bpy.ops.object.bake(type='EMIT');print('OWNER_BAKE',kind,index,owner.name,flush=True)
 finally:
  for tree,output,old,em in replacements:
   tree.nodes.remove(em)
   for socket in old:tree.links.new(socket,output.inputs['Surface'])
 im.filepath_raw=str(R/(name+'.png'));im.file_format='PNG';im.save();textures[name]=im
for o in originals:o.hide_render=True;o.select_set(False)
for obj in parts:obj.hide_render=False
# Preserve material metal/roughness values; replace original procedural color/energy with the baked maps.
for mat in model.data.materials:
 n=mat.node_tree.nodes;l=mat.node_tree.links;p=n.get('Principled BSDF')
 if not p:continue
 color=n.new('ShaderNodeTexImage');color.image=textures['discharge-basecolor'];color.interpolation='Linear';l.new(color.outputs['Color'],p.inputs['Base Color'])
 emission=n.new('ShaderNodeTexImage');emission.image=textures['discharge-emission'];emission.interpolation='Linear';l.new(emission.outputs['Color'],p.inputs['Emission Color']) # Preserve original per-material emission intensity
 rough=n.new('ShaderNodeTexImage');rough.image=textures['discharge-roughness'];rough.interpolation='Linear';l.new(rough.outputs['Color'],p.inputs['Roughness'])
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-baked-study.blend'));s.cycles.samples=32;s.render.filepath=str(R/'baked-hero.png');bpy.ops.render.render(write_still=True)
model.data.calc_loop_triangles();uv=model.data.uv_layers.active.data
report={'status':'Unaccepted v15 source export with owner-isolated color/emission/roughness maps; animated chamber frozen at source frame','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'triangles':len(model.data.loop_triangles),'uv_loop_count':len(uv),'uv_bounds':[[min(v.uv[i]for v in uv),max(v.uv[i]for v in uv)]for i in [0,1]],'texture_size':[1024,1024],'textures':{n:hashlib.sha256((R/(n+'.png')).read_bytes()).hexdigest()for n in textures},'native_acceptance':False,'limits':['No target renderer material binding','Base/emission and raw linear roughness exported; linked normal/bump remains an authoring-only dependency','Per-owner pair selection asserted each bake; hidden merged mesh explicitly deselected; comparison still required','No atlas mip/bleed acceptance','Procedural authoring materials baked, not final texture-art pass','Separate atlas parts retain original authoring object parents; native rig export still untested']};(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n')
