# Discharge v15 material export study

This export is tied to the published v15 source, not the later receiver study. It is unaccepted for native use.

The corrected per-owner bake produces 1024×1024 base-color, emission-color and linear roughness maps. 142 separately owned parts preserve 113,160 UV corners: position and UV errors are zero; maximum corner-normal vector error is 0.00033557; the controlled owner-translation check is zero. The roughness PNG has equal RGB channels and is treated as non-color data. Its alpha is not a reliable geometry coverage mask.

The authoring chamber animation is frozen at the source frame in this atlas. Linked bump/normal effects still depend on authoring nodes; they are not exported normal maps. Native material/shader support and animated energy remain separate work. Do not present this as a completed PBR or animated texture pipeline.

The 64-sample matched render has whole-image mean absolute RGB error 0.001382, weapon crop 0.003750 and chamber crop 0.016141 on a 0–1 scale. The much larger local chamber error exposes blur that a background-heavy whole-image average would hide. Render noise is included; these numbers are not acceptance thresholds.

No sampled base-texel source-owner overlap was found. Simple 16×16 box footprints mix owners in 598 occupied blocks. This is conditional mip risk, not measured native bleeding; dilation, same-owner islands and bilinear/trilinear/anisotropic sampling still need investigation.

Rebuild with Blender 4.3.2: run bake.py, check_parts.py, then render_comparison.py. The sibling discharge-finish-study-v15 source comes from the earlier published authoring ZIP. The published atlas-mip ownership checker can reproduce mip-ownership.json. Neither native rendering, hand poses, collision, complete animation nor performance is certified.
