import bpy
from pathlib import Path
R=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(R/'discharge-baked-study.blend'))
s=bpy.context.scene;s.cycles.samples=64;s.cycles.seed=0;s.render.filepath=str(R/'matched-hero.png');bpy.ops.render.render(write_still=True)
