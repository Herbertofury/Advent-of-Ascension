"""Explicit selection contract: hidden merged targets must never become bake sources."""
import bpy
def select_owner_pair(owner,target,originals,parts):
 bpy.ops.object.select_all(action='DESELECT')
 for obj in originals+parts:obj.hide_render=True
 owner.hide_render=False;target.hide_render=False;owner.select_set(True);target.select_set(True);bpy.context.view_layer.objects.active=target;bpy.context.view_layer.update()
 expected={owner.name,target.name};actual={o.name for o in bpy.context.selected_objects}
 assert actual==expected,(actual,expected)
