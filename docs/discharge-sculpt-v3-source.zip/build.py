"""Original concept-directed Discharge blockout/material study, not accepted native weapon."""
import bpy,math,json
from mathutils import Vector
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);made=[]
def mat(name,color,metal,rough,wear=False,emission=0):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;p=n.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 if emission:p.inputs['Emission Color'].default_value=(*color,1);p.inputs['Emission Strength'].default_value=emission
 if wear:
  tc=n.new('ShaderNodeTexCoord');scale=n.new('ShaderNodeVectorMath');scale.operation='SCALE';scale.inputs[3].default_value=32;floor=n.new('ShaderNodeVectorMath');floor.operation='FLOOR';noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=.6;noise.inputs['Detail'].default_value=1;l=m.node_tree.links;l.new(tc.outputs['Generated'],scale.inputs[0]);l.new(scale.outputs[0],floor.inputs[0]);l.new(floor.outputs[0],noise.inputs['Vector']);ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.70;ramp.color_ramp.elements[0].color=(*color,1);ramp.color_ramp.elements[1].position=.77;ramp.color_ramp.elements[1].color=(.12,.13,.14,1);l.new(noise.outputs['Fac'],ramp.inputs[0]);l.new(ramp.outputs[0],p.inputs['Base Color'])
 return m
white=mat('Discharge ceramic-white worn armor',(.65,.67,.65),.7,.32,True);red=mat('Discharge crimson worn enamel',(.28,.003,.006),.35,.36,True);steel=mat('Discharge dark machined steel',(.055,.06,.065),.8,.28);black=mat('Discharge grip charcoal',(.012,.014,.017),.05,.65);silver=mat('Discharge bright edges',(.58,.62,.63),.85,.24);glow=mat('Discharge capacitor red',(.75,.001,.003),.1,.22,False,2.8)
# Bounded lightning-like source pattern, not a uniformly emissive pink tube.
core=mat('Discharge patterned core',(.055,.001,.003),.2,.25)
n=core.node_tree.nodes;l=core.node_tree.links;pbr=n.get('Principled BSDF');coord=n.new('ShaderNodeTexCoord');vor=n.new('ShaderNodeTexVoronoi');vor.feature='DISTANCE_TO_EDGE';vor.inputs['Scale'].default_value=7;l.new(coord.outputs['Generated'],vor.inputs['Vector']);mask=n.new('ShaderNodeMath');mask.operation='LESS_THAN';mask.inputs[1].default_value=.035;l.new(vor.outputs['Distance'],mask.inputs[0]);mix=n.new('ShaderNodeMixRGB');mix.inputs[1].default_value=(.055,.001,.003,1);mix.inputs[2].default_value=(.8,.002,.006,1);l.new(mask.outputs[0],mix.inputs[0]);l.new(mix.outputs[0],pbr.inputs['Base Color']);l.new(mix.outputs[0],pbr.inputs['Emission Color']);pbr.inputs['Emission Strength'].default_value=1.2
root=bpy.data.objects.new('Discharge_Root',None);bpy.context.collection.objects.link(root)
def finish(o,n,m,p=root,bevel=0):
 o.name=n;o.parent=p;o.data.materials.append(m);made.append(o.name)
 if bevel:mod=o.modifiers.new('Machined bevel','BEVEL');mod.width=bevel;mod.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 return o
def box(n,loc,size,m,p=root,bevel=.04):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,m,p,min(bevel,min(size)*.2))
def prism(n,outline,y,depth,m,p=root):
 v=[(x,y+d,z)for d in [-depth/2,depth/2]for x,z in outline];N=len(outline);f=[tuple(range(N-1,-1,-1)),tuple(range(N,2*N))]+[(i,(i+1)%N,(i+1)%N+N,i+N)for i in range(N)];me=bpy.data.meshes.new(n);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(o);return finish(o,n,m,p,.025)
def cyl(n,loc,r,depth,m,p=root):
 bpy.ops.mesh.primitive_cylinder_add(vertices=40,radius=r,depth=depth,location=loc,rotation=(0,math.pi/2,0));o=bpy.context.object
 for f in o.data.polygons:f.use_smooth=len(f.vertices)==4
 return finish(o,n,m,p,.015)
def path(n,pts,r,m,p=root):
 c=bpy.data.curves.new(n,'CURVE');c.dimensions='3D';c.resolution_u=1;c.bevel_depth=r;c.bevel_resolution=2;sp=c.splines.new('POLY');sp.points.add(len(pts)-1)
 for v,pt in zip(sp.points,pts):v.co=(*pt,1)
 o=bpy.data.objects.new(n,c);bpy.context.collection.objects.link(o);return finish(o,n,m,p)
# Dark structural receiver and restrained rear service assembly.
box('Receiver spine',(.2,0,.65),(5.7,1.05,.95),steel,bevel=.13)
cyl('Rear receiver joint',(-2.72,0,.66),.44,.9,steel)
box('Rear red service housing',(-3.45,0,.84),(1.25,.85,.44),red,bevel=.10)
for y in [-.5,.5]:
 prism('Rear white angled plate',[(-3.9,.62),(-3.45,.58),(-3.0,1.28),(-3.5,1.36)],y,.13,white)
 for x in [-3.5,-3.05]:cyl('Rear side fastening form',(x,y,.65),.13,.14,steel)
# Mirrored layered side armor around exposed fictional capacitor chambers.
for side in [-1,1]:
 y=side*.64
 prism('Upper white shell',[(2.95,1.22),(2.63,1.49),(-1.7,1.38),(-1.98,1.06),(-.95,1.0),(.65,.9)],y,.17,white)
 prism('Crimson spear armor',[(2.68,1.12),(2.3,1.30),(-.9,1.22),(-.45,.87),(.95,.82)],y+side*.105,.06,red)
 prism('Lower sculpted rail',[(-1.9,.15),(-1.42,-.2),(2.75,-.22),(3.02,.12),(2.55,.28),(-.8,.31)],y,.19,white)
 prism('Lower crimson inset',[(-1.15,.14),(-.92,.31),(2.52,.23),(2.68,.07),(1.42,.02)],y+side*.115,.045,red)
 cyl('Exposed red capacitor',(.25,y+side*.08,.65),.245,1.65,core)
 for x in [-.68,1.18]:
  cyl('Capacitor dark collar',(x,y+side*.08,.65),.30,.16,steel);cyl('Capacitor silver band',(x-.08,y+side*.08,.65),.285,.035,silver)
 for phase in [0,math.pi]:
  pts=[(-.55+1.58*t,y+side*.08+.255*math.cos(t*math.tau*2+phase),.65+.255*math.sin(t*math.tau*2+phase))for t in [k/40 for k in range(41)]];path('Capacitor bright pulse helix',pts,.013,silver)
 for x in [-1.25,1.75,2.6]:
  prism('Inset red signal gem',[(x-.12,.55),(x,.73),(x+.12,.55),(x,.4)],y+side*.12,.07,glow)
 for x in [-1.1,0,1.1,2.2]:
  box('Underrail dark slot',(x,side*.77,-.13),(.56,.035,.16),steel,bevel=.025)
# Deliberate edge trim and four-point heraldry, rather than undifferentiated color blocks.
for side in [-1,1]:
 y=side*.78
 path('Upper engraved edge',[(2.70,y,1.35),(1.6,y,1.29),(.4,y,1.27),(-.65,y,1.31)],.018,silver)
 x=-1.32;z=.66
 star=[(x-.24,z),(x-.075,z+.075),(x,z+.27),(x+.075,z+.075),(x+.24,z),(x+.075,z-.075),(x,z-.27),(x-.075,z-.075)]
 prism('Capacitor heraldic silver star',star,y,.055,silver)
 prism('Heraldic crimson inset',[(x-.08,z),(x,z+.12),(x+.08,z),(x,z-.12)],y+side*.04,.035,red)
 for xx in [-1.65,-.9,.0,1.5,2.75]:
  bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=6,radius=.043,location=(xx,y,.18));finish(bpy.context.object,'Seated armor rivet',steel)
# Two raised concept-A capacitor fins with red insets.
for x in [.0,1.15]:
 outline=[(x-.32,1.1),(x-.42,2.05),(x+.28,2.2),(x+.52,1.12)]
 prism('Raised white capacitor fin',outline,0,.85,white)
 for side in [-1,1]:
  prism('Fin red recessed stripe',[(x-.15,1.25),(x-.24,1.94),(x+.02,1.99),(x+.23,1.25)],side*.44,.035,red)
  path('Fin bright red core',[(x-.08,side*.466,1.34),(x-.12,side*.466,1.88)],.035,glow)
# Hollow segmented muzzle face: visible ports, never a closed glowing plug.
for z in [.2,.68,1.16]:
 for y in [-.48,.48]:box('Muzzle side segment',(3.25,y,z),(.68,.18,.32),steel,bevel=.055)
 for dz in [-.17,.17]:box('Muzzle horizontal segment',(3.25,0,z+dz),(.68,1.0,.09),steel,bevel=.025)
 for y in [-.36,.36]:path('Muzzle inner red edge',[(3.61,y,z-.10),(3.61,y,z+.10)],.022,glow)
# Curved full-size grip and open guard, with distinct trigger clearance.
N=24;v=[]
for j in range(10):
 t=j/9;cx=-2.65-.36*t;cz=.37-1.67*t;rx=.39+.06*math.sin(math.pi*t);ry=.43
 for k in range(N):ang=2*math.pi*k/N;v.append((cx+rx*math.cos(ang),ry*math.sin(ang),cz))
f=[tuple(range(N-1,-1,-1)),tuple(range(9*N,10*N))]
for j in range(9):
 for k in range(N):a=j*N+k;b=j*N+(k+1)%N;f.append((a,b,b+N,a+N))
me=bpy.data.meshes.new('Curved grip');me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new('Curved grip',me);bpy.context.collection.objects.link(o);finish(o,o.name,black)
for f in me.polygons:f.use_smooth=True
for side in [-1,1]:
 prism('Grip red heel accent',[(-3.43,-1.12),(-3.32,-1.38),(-2.72,-1.38),(-2.6,-1.13)],side*.43,.07,red)
 path('Grip engraved chevron',[(-2.98,side*.445,-.15),(-2.77,side*.445,-.38),(-3.00,side*.445,-.75)],.015,steel)
path('Open trigger guard',[(-2.28,0,.32),(-1.55,0,.28),(-1.45,0,-.37),(-2.50,0,-.42)],.065,silver)
path('Curved trigger',[(-2.0,0,.25),(-1.92,0,-.04),(-2.03,0,-.19)],.045,steel)
# Concept-directed open underrail cutouts and elliptical muzzle shroud.
for o in bpy.data.objects:
 if o.name.startswith(('Lower sculpted rail','Underrail dark slot')):o.hide_render=True
for side in [-1,1]:
 y=side*.70
 path('Continuous lower support', [(-1.8,y,.18),(2.75,y,.18)],.06,silver)
 for x in [-1.15,-.1,.95,2.0]:
  pts=[(x-.41,y,.18),(x-.39,y,-.22),(x-.27,y,-.32),(x+.27,y,-.32),(x+.39,y,-.22),(x+.41,y,.18)]
  path('Sculpted open underrail loop',pts,.052,silver)
  path('Lower red seam',[(x-.25,y+side*.035,-.32),(x+.25,y+side*.035,-.32)],.018,red)
 # Layered scalloped trim on the white forebody, seated on the panel face.
 path('Forebody silver contour',[(2.75,y+side*.08,1.25),(2.25,y+side*.08,1.28),(1.85,y+side*.08,1.12),(1.45,y+side*.08,1.20),(1.15,y+side*.08,1.08)],.026,silver)
# An open ellipse wraps the segmented ports without plugging their passage.
N=48;vs=[]
for x in [3.12,3.60]:
 for ry,rz in [(.70,.90),(.62,.82)]:
  for k in range(N):a=2*math.pi*k/N;vs.append((x,ry*math.cos(a),.68+rz*math.sin(a)))
fs=[]
for k in range(N):
 j=(k+1)%N
 fs.extend([(k,j,j+N,k+N),(k+2*N,k+3*N,j+3*N,j+2*N),(k,k+2*N,j+2*N,j),(k+N,j+N,j+3*N,k+3*N)])
me=bpy.data.meshes.new('Open elliptical muzzle housing');me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new('Open elliptical muzzle housing',me);bpy.context.collection.objects.link(o);finish(o,o.name,steel,bevel=.018)
# Flush curved grip heel cap replaces two disconnected flat flanges.
for o in bpy.data.objects:
 if o.name.startswith('Grip red heel accent'):o.hide_render=True
vs=[];N=24
for zz,rx,ry in [(-1.20,.405,.445),(-1.35,.40,.44)]:
 for k in range(N):a=2*math.pi*k/N;vs.append((-3.0+rx*math.cos(a),ry*math.sin(a),zz))
fs=[tuple(range(N-1,-1,-1)),tuple(range(N,2*N))]+[(k,(k+1)%N,(k+1)%N+N,k+N)for k in range(N)]
me=bpy.data.meshes.new('Fitted Discharge grip endcap');me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new('Fitted Discharge grip endcap',me);bpy.context.collection.objects.link(o);finish(o,o.name,red,bevel=.02)
# V3: shaped armor with actual negative space, closer to concept A landmarks.
for o in bpy.data.objects:
 if o.name.startswith(('Upper white shell','Crimson spear armor','Forebody silver contour','Upper engraved edge','Sculpted open underrail loop','Continuous lower support','Lower red seam','Lower crimson inset','Raised white capacitor fin','Fin red recessed stripe','Fin bright red core')):o.hide_render=True
for side in [-1,1]:
 y=side*.72
 # The forward armor is a tapered toothed wedge, not a full-length rectangular lid.
 outline=[(3.02,1.36),(2.75,1.52),(.36,1.30),(.18,1.15),(.72,1.03),(1.04,.87),(1.28,.93),(1.49,.68),(1.74,.77),(2.00,.44),(2.28,.55),(2.55,.20),(2.90,.13)]
 prism('V3 sculpted forward armor',outline,y,.16,white)
 inset=[(2.78,1.26),(.73,1.18),(1.13,.96),(1.41,1.03),(1.65,.81),(1.91,.91),(2.18,.61),(2.45,.75),(2.68,.55)]
 prism('V3 crimson stepped shield',inset,y+side*.10,.045,red)
 path('V3 silver shield lip',[(x,y+side*.13,z)for x,z in inset+[inset[0]]],.019,silver)
 # Solid pierced-looking lower plate: notches are open through the bottom edge.
 outline=[(-1.25,.10),(-1.05,-.10),(2.58,-.12),(2.73,-.32),(2.49,-.49),(2.20,-.49),(2.18,-.29),(1.65,-.29),(1.62,-.49),(1.15,-.49),(1.12,-.29),(.58,-.29),(.55,-.49),(.08,-.49),(.05,-.29),(-.48,-.29),(-.51,-.49),(-.94,-.49),(-1.20,-.32)]
 prism('V3 notched underbody plate',outline,side*.70,.13,steel)
 path('V3 underbody silver border',[(x,side*.79,z)for x,z in outline+[outline[0]]],.023,silver)
 path('V3 underbody crimson seam',[(-1.03,side*.80,-.12),(.1,side*.80,-.16),(2.40,side*.80,-.18)],.017,red)
 # Seated layered rear crest frames the capacitor and breaks the plain black slab.
 outline=[(-1.61,1.15),(-1.16,1.21),(-.79,.94),(-.84,.33),(-1.13,.07),(-1.58,.11),(-1.33,.43),(-1.52,.84)]
 prism('V3 rear core crest',outline,side*.77,.14,white)
 prism('V3 rear crest red insert',[(-1.36,.91),(-1.02,.87),(-1.06,.38),(-1.36,.28),(-1.23,.55)],side*.86,.045,red)
 for xx,zz in [(-1.4,1.04),(-1.12,1.03),(-1.43,.18),(2.77,1.34)]:
  bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=6,radius=.038,location=(xx,side*.88,zz));finish(bpy.context.object,'V3 recessed fastener',steel)
 # Fins wrap the crown as thin sheet shells rather than deep solid box blocks.
 for x in [.0,1.15]:
  outline=[(x-.30,1.24),(x-.42,2.02),(x+.23,2.17),(x+.46,1.26),(x+.16,1.19),(x+.03,1.57),(x-.06,1.60),(x+.02,1.21)]
  prism('V3 thin crown shell',outline,side*.42,.095,white)
  prism('V3 crown recessed energy bed',[(x-.20,1.38),(x-.27,1.97),(x+.07,2.03),(x+.23,1.38)],side*.43,.055,steel)
  path('V3 crown red energy',[(x-.05,side*.49,1.39),(x-.13,side*.49,1.91)],.027,glow)
  path('V3 crown red border',[(x-.22,side*.49,1.40),(x-.30,side*.49,1.98),(x+.09,side*.49,2.05),(x+.25,side*.49,1.40)],.024,red)
  # Curved arch across the top links paired shell sides.
  path('V3 crown cross rib',[(x-.40,-.45,2.03),(x-.43,-.2,2.11),(x-.43,.2,2.11),(x-.40,.45,2.03)],.049,white)
# Recessed-looking grip panel and close-fit perimeter create readable grip material zones.
for side in [-1,1]:
 outline=[(-2.95,.10),(-2.52,.06),(-2.69,-.40),(-2.86,-1.14),(-3.22,-1.16),(-3.24,-.84)]
 prism('V3 inset grip panel',outline,side*.425,.025,black)
 path('V3 grip panel edge',[(x,side*.45,z)for x,z in outline+[outline[0]]],.012,steel)
 for j in range(8):
  z=-.23-j*.10;x=-2.90-.14*j/8
  path('V3 grip traction chevron',[(x-.09,side*.448,z+.03),(x+.04,side*.448,z),(x+.12,side*.448,z+.05)],.008,steel)

# Narrow the bevel only on thin inlays that failed world-space triangle QA.
for o in bpy.data.objects:
 if o.name.startswith(('Heraldic crimson inset','V3 crimson stepped shield')):
  for mod in o.modifiers:
   if mod.type=='BEVEL':mod.width=.006

# Rendering setup only. No TaCZ or game-resource implementation is implied.
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.use_denoising=False;s.render.resolution_x=1500;s.render.resolution_y=950;s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.015,.015,.015,1);s.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.4;s.view_settings.view_transform='AgX';s.view_settings.exposure=-.4
for name,loc,power,col in [('Key',(1,7,10),1500,(1,.94,.90)),('Rim',(-3,-5,6),1200,(1,.15,.12)),('Fill',(5,3,1),700,(.7,.8,1))]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.size=6;o.data.color=col;o.rotation_euler=(Vector((0,0,.4))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(4,16,5));cam=bpy.context.object;cam.rotation_euler=(Vector((0,0,.45))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=11.5;s.camera=cam
s.use_nodes=True;n=s.node_tree.nodes;n.clear();rl=n.new('CompositorNodeRLayers');gl=n.new('CompositorNodeGlare');gl.glare_type='FOG_GLOW';gl.threshold=2;gl.mix=-.85;out=n.new('CompositorNodeComposite');s.node_tree.links.new(rl.outputs['Image'],gl.inputs['Image']);s.node_tree.links.new(gl.outputs['Image'],out.inputs['Image'])
bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-v3.blend'));s.render.filepath=str(R/'hero.png');bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'Concept-directed first authoring study; all visual/native QA open','objects':made,'baseline':'AoA1.20.1/3.7.1 uses Discharge Capsules; no resource or damage change implemented','target':'Owner-selected A core design; B/C remain subsequent variants','limits':['Not accepted as matching concept','No playable gunpack','No full hands/reload/native animation','Procedural material prototype, not baked TaCZ texture atlas']},indent=2)+'\n')
