# Discharge v3: unaccepted concept-directed blockout

Open discharge-v3.blend in Blender 4.3.2, or rebuild with build.py. Materials remain procedural authoring prototypes. This is not a playable TaCZ gunpack and does not change the AoA weapon's resource or damage behavior.

The third study replaces box-like fins with thinner shells, shapes a stepped front shield and an integrated notched lower rail, adds a rear crest and grip panel, and seats the lower trigger-guard endpoint against the grip.

Static evaluated geometry QA found 108 degenerate triangles on four thin beveled inlays. Narrowing only those bevels to 0.006 produced zero degenerates across 32,004 triangles. The before/final JSONs retain evidence. This is a triangle-area check, not collision, hand fit or gameplay certification.

visual-review.json records remaining problems. The model remains visibly simpler than the selected concept: rear structure, crown contour, shaped surfaces, original UV textures and functional animation still need work. Six-view renders are inspection evidence, not acceptance.

Concept A remains the main target. B/C are separate future craftable variants. Every variant needs the full weapon feature contract, including projectiles, effects, crafting, audio, animations and native testing.
