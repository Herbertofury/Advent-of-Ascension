import argparse,pathlib,hashlib,json,zipfile,subprocess,os,shutil
p=argparse.ArgumentParser();p.add_argument('jar');p.add_argument('evidence');a=p.parse_args();d=json.load(open(a.evidence));assert hashlib.sha512(pathlib.Path(a.jar).read_bytes()).hexdigest()==d['jar_sha512']
with zipfile.ZipFile(a.jar) as z:
 for n,h in d['class_sha256'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h,n
 assert not any(b'vortex_blaster' in z.read(n) for n in z.namelist() if n.startswith('data/') and n.endswith('.json'))
tool=str(pathlib.Path(os.environ['JAVA_HOME'])/'bin/javap') if os.getenv('JAVA_HOME') else shutil.which('javap');assert tool
s=subprocess.check_output([tool,'-c','-p','-classpath',a.jar,'net.tslat.aoa3.content.item.weapon.blaster.VortexBlaster'],text=True)
for x in ['ITEM_GRAVITY_BLASTER_FIRE','doScaledKnockback','float 7.0f','AABB.m_82377_','Level.m_45976_']:assert x in s,x
print('PASS pinned archive,4 class hashes,negative data-JSON scan and selected knockback paths. No native game acceptance.')
