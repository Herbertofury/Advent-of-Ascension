# Vortex Blaster released-file study

Original mod: Tslat and contributors. Target AoA3-1.20.1-3.7.1-all.jar. The source comparison pin is newer; only explicitly matched methods are used, with released class hashes recorded. Concept art is original generated exploration, not an in-game screenshot or physical production design.

Run `python audit_vortex.py JAR EVIDENCE_JSON` with a full JDK available (`JAVA_HOME` or javap on PATH). It verifies the pinned archive/classes and selected static paths only, without launching game classes. The evidence JSON is in the documentation.

Source sprite is the pinned JAR item texture. V1 concept preserved. V2 fixes visual trigger reach/guard; no hand, mesh or native animation acceptance is implied.
