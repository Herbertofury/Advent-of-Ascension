package dev.herbertofury.armory.presentation;
import java.util.*;
public final class CosmeticLifetimePoolTest {
    static int checks;
    static void check(boolean value) { checks++; if(!value)throw new AssertionError("check "+checks); }
    static void rejects(Runnable r) { try { r.run(); } catch(IllegalArgumentException|IllegalStateException ok){checks++;return;}throw new AssertionError("Expected rejection"); }
    public static void main(String[] args) {
        rejects(()->new CosmeticLifetimePool(0));rejects(()->new CosmeticLifetimePool(4097));
        var p=new CosmeticLifetimePool(3);rejects(()->p.add(1));p.advance(0);
        long a=p.add(3),b=p.add(1),c=p.add(2);check(p.add(1)==0);check(p.size()==3);
        check(p.advance(0)==0);check(p.advance(.5)==0);check(p.isAlive(b));
        check(p.advance(1)==1);check(!p.isAlive(b));check(p.isAlive(a));
        long replacement=p.add(4);check(replacement!=b);check(!p.isAlive(b));check(p.isAlive(replacement));
        check(p.advance(2)==1);check(!p.isAlive(c));check(p.advance(5)==2);check(p.size()==0);
        for(double value:new double[]{-1,Double.NaN,Double.POSITIVE_INFINITY})rejects(()->p.advance(value));
        rejects(()->p.advance(4));check(p.size()==0);
        for(double value:new double[]{0,-1,61,Double.NaN,Double.POSITIVE_INFINITY})rejects(()->p.add(value));
        long old=p.add(2);p.resetWorld(0);check(!p.isAlive(old));check(p.add(2)!=old);check(!p.isAlive(0));check(!p.isAlive(-1));
        p.resetWorld(Double.MAX_VALUE);rejects(()->p.add(1));p.resetWorld(0);
        for(int capacity:new int[]{1,4096}) {
            var bound=new CosmeticLifetimePool(capacity);bound.advance(2);long[] handles=new long[capacity];
            for(int i=0;i<capacity;i++)handles[i]=bound.add(.125);
            check(bound.size()==capacity);check(bound.add(.125)==0);check(bound.advance(2.125)==capacity);
            for(long h:handles)check(!bound.isAlive(h));check(bound.size()==0);
        }
        // Same absolute lifetimes, different update rates, identical boundary result.
        for(int fps:new int[]{20,30,60,144,240}) {
            var clock=new CosmeticLifetimePool(64);clock.advance(0);long[] hs=new long[64];
            for(int i=0;i<64;i++)hs[i]=clock.add((i+1)/8.0);
            for(int frame=0;frame<=fps*8;frame++)clock.advance((double)frame/fps);
            check(clock.size()==0);for(long h:hs)check(!clock.isAlive(h));
        }
        // Independent map oracle across paused updates, random lifetimes, pressure and resets.
        var pool=new CosmeticLifetimePool(31);Map<Long,Double> oracle=new HashMap<>();Random random=new Random(34891);double time=0;pool.advance(time);
        for(int step=0;step<100000;step++) {
            if(step%997==0){var stale=new ArrayList<>(oracle.keySet());pool.resetWorld(0);oracle.clear();time=0;for(long h:stale)check(!pool.isAlive(h));}
            time+=random.nextInt(4)/32.0;final double boundary=time;int before=oracle.size();oracle.entrySet().removeIf(e->e.getValue()<=boundary);check(pool.advance(time)==before-oracle.size());
            double ttl=(1+random.nextInt(128))/16.0;long h=pool.add(ttl);
            if(oracle.size()==31)check(h==0);else{check(h>0);check(!oracle.containsKey(h));oracle.put(h,time+ttl);}
            check(pool.size()==oracle.size());for(long key:oracle.keySet())check(pool.isAlive(key));
        }
        System.out.println("CosmeticLifetimePoolTest PASS "+checks+" assertions; metadata only, no native/performance acceptance");
    }
}
