package dev.herbertofury.armory.presentation;

import java.util.UUID;
public final class ImpactVisualLedgerTest {
    static int checks;
    static void require(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
    static final UUID ACTOR=new UUID(0,1),WEAPON=new UUID(0,2);
    static ImpactVisualLedger.Key key(long world,long burst,int pellet,int impact,ImpactVisualLedger.Branch branch){return new ImpactVisualLedger.Key(world,ACTOR,WEAPON,burst,pellet,impact,branch);}
    public static void main(String[]args){
        var ledger=new ImpactVisualLedger(64,5);
        // Preserve both native logical branches for each of four pellet impacts.
        for(int pellet=0;pellet<4;pellet++)for(var branch:ImpactVisualLedger.Branch.values()){
            var k=key(5,10,pellet,0,branch);
            require(ledger.accept(k)==ImpactVisualLedger.Decision.ACCEPT,"Distinct branch/pellet was suppressed");
            require(ledger.accept(k)==ImpactVisualLedger.Decision.DUPLICATE,"Repeated cosmetic event accepted");
        }
        require(ledger.size()==8,"Unexpected branch count");
        require(ledger.accept(key(5,10,0,1,ImpactVisualLedger.Branch.PROJECTILE_IMPACT))==ImpactVisualLedger.Decision.ACCEPT,"Later impact suppressed");
        require(ledger.accept(key(4,11,0,0,ImpactVisualLedger.Branch.PROJECTILE_IMPACT))==ImpactVisualLedger.Decision.WRONG_WORLD,"Old world accepted");
        var otherActor=new ImpactVisualLedger.Key(5,new UUID(0,3),WEAPON,10,0,0,ImpactVisualLedger.Branch.WEAPON_IMPACT);
        var otherWeapon=new ImpactVisualLedger.Key(5,ACTOR,new UUID(0,4),10,0,0,ImpactVisualLedger.Branch.WEAPON_IMPACT);
        require(ledger.accept(otherActor)==ImpactVisualLedger.Decision.ACCEPT,"Actor cross-talk");
        require(ledger.accept(otherWeapon)==ImpactVisualLedger.Decision.ACCEPT,"Weapon cross-talk");
        for(int i=0;i<10000;i++){
            require(ledger.accept(key(5,100+i,0,0,ImpactVisualLedger.Branch.PROJECTILE_IMPACT))==ImpactVisualLedger.Decision.ACCEPT,"Unique event dropped");
            require(ledger.size()<=64,"Unbounded ledger");
        }
        // This is deliberately a finite window, not permanent replay prevention.
        require(ledger.accept(key(5,10,0,0,ImpactVisualLedger.Branch.WEAPON_IMPACT))==ImpactVisualLedger.Decision.ACCEPT,"Eviction semantics changed");
        ledger.resetWorld(6);require(ledger.size()==0,"Reset retained old state");
        require(ledger.accept(key(5,10,0,0,ImpactVisualLedger.Branch.WEAPON_IMPACT))==ImpactVisualLedger.Decision.WRONG_WORLD,"Old-world event after reset");
        require(ledger.accept(key(6,10,0,0,ImpactVisualLedger.Branch.WEAPON_IMPACT))==ImpactVisualLedger.Decision.ACCEPT,"New world blocked");
        try {new ImpactVisualLedger(0,1);throw new AssertionError("Zero capacity accepted");}catch(IllegalArgumentException expected){checks++;}
        try {key(6,-1,0,0,ImpactVisualLedger.Branch.WEAPON_IMPACT);throw new AssertionError("Invalid key accepted");}catch(IllegalArgumentException expected){checks++;}
        System.out.println("PASS "+checks+" assertions; cosmetic identity/window checks only, no gameplay deduplication");
    }
}
