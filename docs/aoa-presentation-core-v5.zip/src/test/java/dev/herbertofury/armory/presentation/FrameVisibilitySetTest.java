package dev.herbertofury.armory.presentation;
public final class FrameVisibilitySetTest {
    static int assertions;
    static void check(boolean value) { assertions++; if (!value) throw new AssertionError(); }
    static final class Part implements FrameVisibilitySet.Target {
        boolean visible=true; int writes;
        public void setVisible(boolean value) { visible=value; writes++; }
    }
    static int writes(Part[] parts) { int n=0; for (var p:parts)n+=p.writes; return n; }
    static void visible(Part[] parts,int selected) { for(int i=0;i<parts.length;i++)check(parts[i].visible==(i==selected)); }
    public static void main(String[] args) {
        Part[] parts=new Part[15];for(int i=0;i<parts.length;i++)parts[i]=new Part();
        FrameVisibilitySet.Binding[] bindings=new FrameVisibilitySet.Binding[15];for(int i=0;i<15;i++)bindings[i]=new FrameVisibilitySet.Binding(parts[i],parts[i]);
        var set=new FrameVisibilitySet(bindings);check(set.size()==15);check(writes(parts)==15);visible(parts,-1);
        set.select(0);check(writes(parts)==16);visible(parts,0);
        for(int i=0;i<10000;i++)set.select(0);check(writes(parts)==16);
        set.select(14);check(writes(parts)==18);visible(parts,14);
        try { set.select(15); throw new AssertionError(); } catch(IllegalArgumentException expected) { visible(parts,-1); }
        int before=writes(parts);set.hide();set.hide();check(writes(parts)==before);
        var out=new SoulSightFrame.Output();int transitions=0;int last=-1;
        for(int i=0;i<10000;i++){
            SoulSightFrame.sample(SoulSightFrame.Sight.FLAME,SoulSightFrame.Pass.FIRST_PERSON,false,false,i/1000.0,out);
            set.select(out.frame);if(out.frame!=last)transitions++;last=out.frame;visible(parts,last);
        }
        // First selected part costs one write, subsequent changes exactly two.
        check(writes(parts)-before==1+2*(transitions-1));
        SoulSightFrame.sample(SoulSightFrame.Sight.GEM,SoulSightFrame.Pass.FIRST_PERSON,false,false,10,out);
        if(!out.visible)set.hide();visible(parts,-1);
        set.select(3);set.close();visible(parts,-1);before=writes(parts);set.close();set.hide();check(writes(parts)==before);
        try{set.select(0);throw new AssertionError();}catch(IllegalStateException expected){check(true);}
        Part only=new Part();try{new FrameVisibilitySet(new FrameVisibilitySet.Binding[]{new FrameVisibilitySet.Binding(only,only),new FrameVisibilitySet.Binding(only,value->only.setVisible(value))});throw new AssertionError();}catch(IllegalArgumentException expected){check(only.writes==0);}
        try{new FrameVisibilitySet(new FrameVisibilitySet.Binding[]{new FrameVisibilitySet.Binding(only,only),null});throw new AssertionError();}catch(IllegalArgumentException expected){check(only.writes==0);}
        var other=new FrameVisibilitySet(new FrameVisibilitySet.Binding[]{new FrameVisibilitySet.Binding(only,only)});other.select(0);check(only.visible);visible(parts,-1);other.close();check(!only.visible);
        System.out.println("PASS FrameVisibilitySet "+assertions+" assertions; visibility writes bounded by frame changes. Not native/render performance acceptance.");
    }
}
