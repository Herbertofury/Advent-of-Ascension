package dev.herbertofury.armory.presentation;
import static dev.herbertofury.armory.presentation.SoulSightFrame.*;
public final class AtlasLayoutTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[]args){
  check(args.length==1);check(ROOTED_FIRE_16.cycleSeconds()==Double.parseDouble(args[0]));
  Output out=new Output();boolean[] seen=new boolean[16];
  for(int i=0;i<100000;i++){
   sample(Sight.FLAME,Pass.FIRST_PERSON,false,false,i/1937.0,ROOTED_FIRE_16,out);
   check(out.frame>=0&&out.frame<16&&out.next==(out.frame+1)%16);seen[out.frame]=true;
   check(out.u0>=(out.frame%4)*.25&&out.u1<=(out.frame%4+1)*.25&&out.u1>out.u0);
   check(out.v0>=(out.frame/4)*.25&&out.v1<=(out.frame/4+1)*.25&&out.v1>out.v0);
   check(out.mix>=0&&out.mix<1);
  }
  for(boolean b:seen)check(b);
  check(ROOTED_FIRE_16.cycleSeconds()==16.0/(60.0/4.0));
  sample(Sight.FLAME,Pass.FIRST_PERSON,false,false,1.0,ROOTED_FIRE_16,out);check(out.frame==15);
  sample(Sight.FLAME,Pass.FIRST_PERSON,false,false,ROOTED_FIRE_16.cycleSeconds()*15.5/16,ROOTED_FIRE_16,out);check(out.frame==15&&out.next==0);
  sample(Sight.FLAME,Pass.FIRST_PERSON,false,false,ROOTED_FIRE_16.cycleSeconds(),ROOTED_FIRE_16,out);check(out.frame==0&&out.mix==0);
  sample(Sight.FLAME,Pass.FIRST_PERSON,false,true,100,ROOTED_FIRE_16,out);check(out.frame==0&&out.next==0&&out.mix==0);
  sample(Sight.GEM,Pass.FIRST_PERSON,false,false,1,ROOTED_FIRE_16,out);check(!out.visible&&out.sight==null);
  try{sample(Sight.FLAME,Pass.FIRST_PERSON,false,false,1,null,out);throw new AssertionError();}catch(IllegalArgumentException expected){check(!out.visible);}
  sample(Sight.FLAME,Pass.FIRST_PERSON,false,false,Math.nextDown(ROOTED_FIRE_16.cycleSeconds()),ROOTED_FIRE_16,out);check(out.frame==15&&out.mix<1);
  sample(Sight.FLAME,Pass.FIRST_PERSON,false,false,1.234,ROOTED_FIRE_16,out);int paused=out.frame;float blend=out.mix;
  for(int i=0;i<100;i++){sample(Sight.FLAME,Pass.FIRST_PERSON,false,false,1.234,ROOTED_FIRE_16,out);check(out.frame==paused&&out.mix==blend);}
  double[] times={0,1,1e6,Double.MAX_VALUE};
  for(double t:times){sample(Sight.FLAME,Pass.FIRST_PERSON,false,false,t,ROOTED_FIRE_16,out);check(out.frame>=0&&out.frame<16);}
  try{new Atlas(4,4,17,2,0,0);throw new AssertionError();}catch(IllegalArgumentException expected){}
  try{new Atlas(4,4,16,Double.NaN,0,0);throw new AssertionError();}catch(IllegalArgumentException expected){}
  try{new Atlas(4,4,16,2,.125f,0);throw new AssertionError();}catch(IllegalArgumentException expected){}
  try{new Atlas(0,4,16,2,0,0);throw new AssertionError();}catch(IllegalArgumentException expected){}
  System.out.println("PASS explicit 16-frame atlas: 100000 samples, wrap, insets, reduced motion, invalid layout; native integration untested");
 }
}
