package dev.herbertofury.armory.presentation;
public final class EmissionClockTest {
    static int checks;
    static void require(boolean ok,String m){checks++;if(!ok)throw new AssertionError(m);}
    public static void main(String[] args){
        for(int fps:new int[]{20,30,60,144,240,1000,2000}){
            var clock=new EmissionClock(40,8,.25);require(clock.sample(0,true)==0,"Initialization burst");int total=0;
            for(int i=1;i<=10*fps;i++){
                double time=(double)i/fps;int count=clock.sample(time,true);require(count>=0&&count<=8,"Budget exceeded");total+=count;
                require(clock.sample(time,true)==0,"Repeated render timestamp emitted again");
            }
            require(total==400,"Rate changed with cadence: "+fps+" -> "+total);
        }
        var clock=new EmissionClock(40,8,.25);clock.sample(0,true);require(clock.sample(100,true)==8,"Stall catch-up unbounded");require(clock.sample(100,true)==0,"Stall backlog retained");
        require(clock.sample(100.025,true)==1,"Normal updates did not resume");clock.sample(101,false);require(clock.sample(501,true)==0,"Hidden time caused catch-up burst");require(clock.sample(501.025,true)==1,"Visible updates did not resume");
        int frozen=0;for(int i=0;i<100;i++)frozen+=clock.sample(501.025,true);require(frozen==0,"Paused clock emitted");
        require(clock.sample(1,true)==0,"Clock rollback emitted");require(clock.sample(1.025,true)==1,"Rollback reset failed");
        var other=new EmissionClock(40,8,.25);other.sample(0,true);require(other.sample(.025,true)==1,"Emitter state shared");
        var zero=new EmissionClock(0,8,.25);zero.sample(0,true);require(zero.sample(10,true)==0,"Zero-rate emitted");
        clock.reset();require(clock.sample(500,true)==0,"Explicit reset retained state");
        try{clock.sample(Double.NaN,true);throw new AssertionError("NaN accepted");}catch(IllegalArgumentException expected){checks++;}
        require(clock.sample(700,true)==0,"Invalid input did not clear timing state");
        try{new EmissionClock(-1,8,.25);throw new AssertionError("Invalid rate accepted");}catch(IllegalArgumentException expected){checks++;}
        System.out.println("PASS "+checks+" assertions; 400 scheduled requests at each simulated 20–2000 Hz cadence. No native FPS or visual-density acceptance.");
    }
}
