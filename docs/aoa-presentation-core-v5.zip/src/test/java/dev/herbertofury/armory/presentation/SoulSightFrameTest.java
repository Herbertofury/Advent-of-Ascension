package dev.herbertofury.armory.presentation;

public final class SoulSightFrameTest {
    private static int checks;
    private static void require(boolean ok,String message) {checks++;if(!ok)throw new AssertionError(message);}
    public static void main(String[] args) {
        var out=new SoulSightFrame.Output();
        for (var sight:SoulSightFrame.Sight.values()) for(var pass:SoulSightFrame.Pass.values())
            for(boolean gui:new boolean[]{false,true}) {
                out.visible=true;out.mix=.9f;
                var actual=SoulSightFrame.sample(sight,pass,gui,false,.3,out);
                boolean visible=sight!=SoulSightFrame.Sight.GEM && pass!=SoulSightFrame.Pass.SHADOW && (pass!=SoulSightFrame.Pass.GUI || gui);
                require(actual==out,"Output allocated/replaced"); require(actual.visible==visible,"Pass/attachment gate");
                if(!visible)require(out.sight==null && out.u1==0 && out.mix==0,"Stale output after gate");
            }
        for(int i=0;i<100000;i++) {
            SoulSightFrame.sample(SoulSightFrame.Sight.FLAME,SoulSightFrame.Pass.FIRST_PERSON,false,false,i*.00317,out);
            require(out.frame>=0&&out.frame<15&&out.next>=0&&out.next<15,"Unused atlas cell selected");
            require(out.mix>=0&&out.mix<=1,"Bad blend");
            require(out.u0>=0&&out.v0>=0&&out.u1<=1&&out.v1<=1,"Bad UV");
        }
        SoulSightFrame.sample(SoulSightFrame.Sight.FLAME,SoulSightFrame.Pass.FIRST_PERSON,false,false,1.99,out);
        require(out.frame==14&&out.next==0,"Loop seam");
        SoulSightFrame.sample(SoulSightFrame.Sight.FLAME,SoulSightFrame.Pass.FIRST_PERSON,false,false,2,out);
        require(out.frame==0&&out.mix==0,"Exact loop");
        SoulSightFrame.sample(SoulSightFrame.Sight.CANDLE,SoulSightFrame.Pass.THIRD_PERSON,false,true,51.923,out);
        require(out.frame==0&&out.next==0&&out.mix==0&&out.visible,"Reduced motion");
        for(double invalid:new double[]{Double.NaN,Double.POSITIVE_INFINITY,Double.NEGATIVE_INFINITY,-.01}) {
            try { SoulSightFrame.sample(SoulSightFrame.Sight.FLAME,SoulSightFrame.Pass.FIRST_PERSON,false,false,invalid,out);throw new AssertionError("Invalid accepted"); }
            catch(IllegalArgumentException expected){require(!out.visible&&out.sight==null,"Invalid frame retained flame");}
        }
        var other=new SoulSightFrame.Output();
        SoulSightFrame.sample(SoulSightFrame.Sight.FLAME,SoulSightFrame.Pass.FIRST_PERSON,false,false,.9,out);
        int before=out.frame;float uv=out.u0;
        SoulSightFrame.sample(SoulSightFrame.Sight.GEM,SoulSightFrame.Pass.FIRST_PERSON,false,false,.9,other);
        require(out.visible&&out.frame==before&&out.u0==uv,"Instance cross-talk");
        SoulSightFrame.sample(SoulSightFrame.Sight.FLAME,SoulSightFrame.Pass.FIRST_PERSON,false,false,.9,out);
        require(out.frame==before&&out.u0==uv,"Same paused presentation time changed sample");
        System.out.println("PASS "+checks+" assertions; renderer-independent Java core only");
    }
}
