package dev.herbertofury.armory.presentation;

/**
 * Fixed-capacity metadata pool for short-lived cosmetic effects.
 * Own on one presentation thread. Call advance with paused game time before adding.
 * No world/resource discovery, gameplay processing or native renderer ownership.
 */
public final class CosmeticLifetimePool {
    private final int capacity;
    private final long[] handles;
    private final double[] expires;
    private final int[] free, heap;
    private int freeCount, heapSize;
    private long serial;
    private double now;
    private boolean initialized;
    public CosmeticLifetimePool(int capacity) {
        if (capacity < 1 || capacity > 4096) throw new IllegalArgumentException("Capacity outside 1..4096");
        this.capacity = capacity;
        handles = new long[capacity]; expires = new double[capacity];
        free = new int[capacity]; heap = new int[capacity];
        clearSlots();
    }
    /** Absolute time must be finite, nonnegative and nondecreasing within a world. */
    public int advance(double gameSeconds) {
        requireTime(gameSeconds);
        if (initialized && gameSeconds < now) throw new IllegalArgumentException("Reset world before rewinding time");
        initialized = true; now = gameSeconds;
        int retired = 0;
        while (heapSize > 0 && expires[heap[0]] <= now) {
            int slot = pop(); handles[slot] = 0; free[freeCount++] = slot; retired++;
        }
        return retired;
    }
    /** Returns zero when full. Lifetime is cosmetic only and capped at 60 seconds. */
    public long add(double lifetimeSeconds) {
        if (!initialized) throw new IllegalStateException("Advance game time before adding effects");
        double end = now + lifetimeSeconds;
        if (!Double.isFinite(lifetimeSeconds) || lifetimeSeconds <= 0 || lifetimeSeconds > 60 ||
                !Double.isFinite(end) || end <= now) throw new IllegalArgumentException("Unrepresentable or invalid lifetime");
        if (freeCount == 0) return 0;
        // Never recycle a handle, including after world reset. Exhaustion fails closed.
        if (serial >= (Long.MAX_VALUE - capacity) / capacity) throw new IllegalStateException("Handle space exhausted");
        int slot = free[--freeCount];
        long handle = (++serial) * capacity + slot;
        handles[slot] = handle; expires[slot] = end;
        int index = heapSize++;
        while (index > 0) {
            int parent = (index - 1) >>> 1;
            if (expires[heap[parent]] <= end) break;
            heap[index] = heap[parent]; index = parent;
        }
        heap[index] = slot;
        return handle;
    }
    /** O(1) lookup; a stale handle cannot identify a replacement effect. */
    public boolean isAlive(long handle) {
        if (handle <= 0) return false;
        return handles[(int)(handle % capacity)] == handle;
    }
    public int size() { return heapSize; }
    public int capacity() { return capacity; }
    /** Clears resident metadata, keeps the serial monotonic, and permits a new time origin. */
    public void resetWorld(double gameSeconds) {
        requireTime(gameSeconds); clearSlots(); now = gameSeconds; initialized = true;
    }
    private void clearSlots() {
        for (int i = 0; i < capacity; i++) { handles[i] = 0; free[i] = i; }
        freeCount = capacity; heapSize = 0;
    }
    private static void requireTime(double value) {
        if (!Double.isFinite(value) || value < 0) throw new IllegalArgumentException("Invalid game time");
    }
    private int pop() {
        int result = heap[0], last = heap[--heapSize];
        if (heapSize == 0) return result;
        int index = 0;
        while (true) {
            int left = index * 2 + 1;
            if (left >= heapSize) break;
            int right = left + 1;
            int child = right < heapSize && expires[heap[right]] < expires[heap[left]] ? right : left;
            if (expires[last] <= expires[heap[child]]) break;
            heap[index] = heap[child]; index = child;
        }
        heap[index] = last;
        return result;
    }
}
