package dev.herbertofury.armory.presentation;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.UUID;

/** Bounded cosmetic duplicate suppression, never authoritative damage processing. */
public final class ImpactVisualLedger {
    public enum Branch { WEAPON_IMPACT, PROJECTILE_IMPACT }
    public enum Decision { ACCEPT, DUPLICATE, WRONG_WORLD }
    public record Key(long worldEpoch, UUID actor, UUID weaponInstance, long burst,
                      int pellet, int impactOrdinal, Branch branch) {
        public Key {
            if (worldEpoch<0 || actor==null || weaponInstance==null || burst<0 || pellet<0 ||
                impactOrdinal<0 || branch==null) throw new IllegalArgumentException("Invalid visual event identity");
        }
    }
    private final int capacity;
    private final HashSet<Key> recent;
    private final ArrayDeque<Key> insertionOrder;
    private long worldEpoch;
    public ImpactVisualLedger(int capacity,long worldEpoch) {
        if(capacity<1 || capacity>65536 || worldEpoch<0)throw new IllegalArgumentException("Invalid ledger bounds");
        this.capacity=capacity;this.worldEpoch=worldEpoch;
        recent=new HashSet<>(capacity);insertionOrder=new ArrayDeque<>(capacity);
    }
    /** Use on the owning presentation thread. Rejected duplicates do not refresh residency. */
    public Decision accept(Key key) {
        if(key==null)throw new IllegalArgumentException("Visual event identity required");
        if(key.worldEpoch()!=worldEpoch)return Decision.WRONG_WORLD;
        if(recent.contains(key))return Decision.DUPLICATE;
        if(insertionOrder.size()==capacity)recent.remove(insertionOrder.removeFirst());
        insertionOrder.addLast(key);recent.add(key);return Decision.ACCEPT;
    }
    /** Caller changes this generation on world/session teardown; not a server trust check. */
    public void resetWorld(long epoch) {
        if(epoch<0)throw new IllegalArgumentException("Invalid world generation");
        worldEpoch=epoch;recent.clear();insertionOrder.clear();
    }
    public int size(){return recent.size();}
}
