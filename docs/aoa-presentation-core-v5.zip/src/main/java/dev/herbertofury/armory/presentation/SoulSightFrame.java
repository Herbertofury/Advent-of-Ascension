package dev.herbertofury.armory.presentation;

/** Original renderer-independent sight frame math. No Minecraft/TaCZ hooks. */
public final class SoulSightFrame {
    private SoulSightFrame() {}
    public enum Sight { FLAME, CANDLE, GEM }
    public enum Pass { FIRST_PERSON, THIRD_PERSON, GUI, SHADOW }
    /** Immutable caller-selected atlas contract. UVs use top-origin image coordinates. */
    public record Atlas(int columns,int rows,int frameCount,double cycleSeconds,float insetU,float insetV) {
        public Atlas {
            if(columns<1 || columns>64 || rows<1 || rows>64 || frameCount<1 || frameCount>columns*rows ||
               !Double.isFinite(cycleSeconds) || cycleSeconds<=0 ||
               !Float.isFinite(insetU) || !Float.isFinite(insetV) || insetU<0 || insetV<0 ||
               insetU>=0.5f/columns || insetV>=0.5f/rows)
                throw new IllegalArgumentException("Invalid explicit atlas contract");
        }
    }
    public static final Atlas LEGACY_15 = new Atlas(4,4,15,2.0,0,0);
    /** 16 frames at fifteen frames/second (60-fps authoring scene, four frames per cell); half-texel inset for the 2048-square padded atlas. */
    public static final Atlas ROOTED_FIRE_16 = new Atlas(4,4,16,16.0/15.0,0.5f/2048,0.5f/2048);
    /** One reusable output per caller/render owner. Never share across concurrent renders. */
    public static final class Output {
        public boolean visible;
        public int frame, next;
        public float mix, u0, v0, u1, v1, nextU0, nextV0, nextU1, nextV1;
        public Sight sight;
        public void clear() {
            visible=false; frame=next=0; mix=u0=v0=u1=v1=nextU0=nextV0=nextU1=nextV1=0;
            sight=null;
        }
    }
    /**
     * presentationSeconds is caller-owned, paused game time, never wall time.
     * The caller supplies a resolved attachment and a known render pass.
     * GUI preview needs an explicit opt-in. No gameplay state is read or changed.
     * No offset is guessed: FLAME and CANDLE each require their authored leaf bone.
     */
    public static Output sample(Sight sight, Pass pass, boolean guiPreview,
                                boolean reducedMotion, double presentationSeconds, Output out) {
        return sample(sight,pass,guiPreview,reducedMotion,presentationSeconds,LEGACY_15,out);
    }
    public static Output sample(Sight sight, Pass pass, boolean guiPreview,
                                boolean reducedMotion, double presentationSeconds, Atlas atlas, Output out) {
        if (out==null) throw new IllegalArgumentException("Caller-owned output required");
        out.clear(); // Fail closed even after a previous visible sample.
        if (atlas==null || sight==null || pass==null || !Double.isFinite(presentationSeconds) || presentationSeconds<0)
            throw new IllegalArgumentException("Invalid resolved sight, pass or presentation time");
        if (sight==Sight.GEM || pass==Pass.SHADOW || (pass==Pass.GUI && !guiPreview)) return out;
        double position=reducedMotion ? 0 : (presentationSeconds % atlas.cycleSeconds()) / atlas.cycleSeconds() * atlas.frameCount();
        out.visible=true; out.sight=sight;
        out.frame=Math.min(atlas.frameCount()-1,(int)Math.floor(position));
        out.next=reducedMotion ? out.frame : (out.frame+1)%atlas.frameCount();
        out.mix=reducedMotion ? 0 : Math.min(Math.nextDown(1.0f), (float)(position-out.frame));
        float width=1f/atlas.columns(),height=1f/atlas.rows();
        out.u0=(out.frame%atlas.columns())*width+atlas.insetU(); out.v0=(out.frame/atlas.columns())*height+atlas.insetV();
        out.u1=((out.frame%atlas.columns())+1)*width-atlas.insetU(); out.v1=((out.frame/atlas.columns())+1)*height-atlas.insetV();
        out.nextU0=(out.next%atlas.columns())*width+atlas.insetU(); out.nextV0=(out.next/atlas.columns())*height+atlas.insetV();
        out.nextU1=((out.next%atlas.columns())+1)*width-atlas.insetU(); out.nextV1=((out.next/atlas.columns())+1)*height-atlas.insetV();
        return out;
    }
}
