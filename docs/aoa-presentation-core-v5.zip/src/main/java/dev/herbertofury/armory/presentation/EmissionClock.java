package dev.herbertofury.armory.presentation;
/** Per-emitter cosmetic scheduling from caller-supplied paused game time. */
public final class EmissionClock {
    private final double perSecond,maxCatchUpSeconds;
    private final int maxPerUpdate;
    private double lastSeconds,carry;
    private boolean initialized,wasEmitting;
    public EmissionClock(double perSecond,int maxPerUpdate,double maxCatchUpSeconds) {
        if(!Double.isFinite(perSecond)||perSecond<0||perSecond>1_000_000||maxPerUpdate<1||maxPerUpdate>4096||
           !Double.isFinite(maxCatchUpSeconds)||maxCatchUpSeconds<=0||maxCatchUpSeconds>1)
            throw new IllegalArgumentException("Invalid cosmetic budget");
        this.perSecond=perSecond;this.maxPerUpdate=maxPerUpdate;this.maxCatchUpSeconds=maxCatchUpSeconds;
    }
    /** Schedule once at the presentation update boundary, never per shader/camera pass. */
    public int sample(double gameSeconds,boolean emitting) {
        if(!Double.isFinite(gameSeconds)||gameSeconds<0){reset();throw new IllegalArgumentException("Invalid game time");}
        if(!initialized){initialized=true;wasEmitting=emitting;lastSeconds=gameSeconds;return 0;}
        double elapsed=gameSeconds-lastSeconds;lastSeconds=gameSeconds;
        if(!emitting){wasEmitting=false;carry=0;return 0;}
        if(!wasEmitting||elapsed<0){wasEmitting=true;carry=0;return 0;}
        double raw=carry+Math.min(elapsed,maxCatchUpSeconds)*perSecond;
        int whole=(int)Math.floor(raw+1e-9);
        carry=Math.max(0,raw-whole); // Discard capped whole events; never store an unbounded backlog.
        return Math.min(whole,maxPerUpdate);
    }
    public void reset(){initialized=false;wasEmitting=false;lastSeconds=0;carry=0;}
}
