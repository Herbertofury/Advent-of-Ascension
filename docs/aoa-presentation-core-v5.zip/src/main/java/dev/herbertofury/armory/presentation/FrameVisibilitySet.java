package dev.herbertofury.armory.presentation;

import java.util.IdentityHashMap;
/**
 * Owns visibility for a pre-bound set of discrete cosmetic frame parts.
 * Bind once per resource generation, use on one presentation thread, close on disposal.
 * This does not find native bones or implement a Minecraft/TaCZ adapter.
 */
public final class FrameVisibilitySet implements AutoCloseable {
    /** Adapter must perform a nonthrowing visibility assignment without gameplay side effects. */
    @FunctionalInterface public interface Target { void setVisible(boolean value); }
    /** identity must be the actual native part object, not a display name or wrapper. */
    public record Binding(Object identity, Target target) {}
    private final Target[] targets;
    private int current = -1;
    private boolean closed;
    public FrameVisibilitySet(Binding[] bindings) {
        if (bindings == null || bindings.length == 0) throw new IllegalArgumentException("Frame bindings required");
        this.targets = new Target[bindings.length];
        var identities = new IdentityHashMap<Object, Boolean>();
        for (int i=0; i<bindings.length; i++) {
            Binding binding=bindings[i];
            if (binding == null || binding.identity() == null || binding.target() == null
                    || identities.put(binding.identity(), Boolean.TRUE) != null)
                throw new IllegalArgumentException("Native part identities must be nonnull and distinct");
            this.targets[i]=binding.target();
        }
        // Validate the full set before mutating any target.
        for (Target target : this.targets) target.setVisible(false);
    }
    public int size() { return targets.length; }
    public int selected() { return current; }
    public void select(int frame) {
        if (closed) throw new IllegalStateException("Disposed frame binding");
        if (frame < 0 || frame >= targets.length) {
            hide();
            throw new IllegalArgumentException("Frame outside bound target set");
        }
        if (frame == current) return;
        hide();
        targets[frame].setVisible(true);
        current = frame;
    }
    public void hide() {
        if (current >= 0) {
            targets[current].setVisible(false);
            current = -1;
        }
    }
    @Override public void close() {
        if (!closed) {
            hide();
            closed = true;
        }
    }
}
