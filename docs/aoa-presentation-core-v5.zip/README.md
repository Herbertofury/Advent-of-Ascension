# Weapon presentation core v5 · bounded cosmetic lifetimes

Original engine-independent candidate, not an installed native adapter. The four v4 classes and five existing test classes are byte-for-byte preserved; only CosmeticLifetimePool and its test are added.

## Purpose

Avoid retained cosmetic metadata growing indefinitely when many Soul Storm impacts, decals or short-lived effects are created. The pool allocates fixed arrays once, retains at most its configured capacity (1–4096), expires entries by a minimum heap, and returns zero when full. This is a presentation budget only. Never skip damage, ammo accounting, accepted-shot ordinal processing, loot or other gameplay because the cosmetic pool is full.

Call advance(pausedGameSeconds) once at the presentation update boundary, then add(lifetimeSeconds) for accepted visual requests. The pool is single-threaded and pool-local; do not compare its handles across pools or treat them as server authentication. The existing ImpactVisualLedger handles bounded duplicate suppression, and ConfirmedShotPresentation handles trusted-event binding. This pool replaces neither.

Lifetimes must be representable, positive and at most 60 seconds. Time must be finite, nonnegative and nondecreasing. Use resetWorld(newTime) on teardown/time-origin changes. It clears resident metadata without resetting the monotonically increasing handle serial, so stale handles cannot identify a new effect. Zero indicates that a visual request was dropped due to capacity. No unbounded deferred queue is created.

Metadata expiry does not itself remove a native decal, particle, sound or GPU resource. A native adapter must own those lifetimes and release resources correctly. The pool does not scan worlds, discover assets, perform I/O, allocate meshes, change game blocks or render anything.

## Complexity and limits

Insertion is O(log capacity); an empty expiry update checks the heap root; retirement is O(expired entries × log capacity), capped by resident capacity. Lookups are O(1). These are source-level bounds, not measured Minecraft FPS improvements. No native render, GPU memory, multi-mod compatibility or visual-density acceptance is claimed.

Repeated updates at unchanged game time do not expire extra entries. Clock rewind rejects before mutation. Non-finite and unrepresentable time/lifetime values reject. Handle exhaustion fails closed instead of wrapping into an old identity. The pool does not implement priority arbitration, manual early cancellation or a native resource-release queue; those remain adapter decisions.

## Reproduction

Set JAVA_HOME to JDK 17 or newer, optionally SECONDARY_JAVA to another Java executable, then run python run_tests.py. It compiles --release 17 into a temporary directory and runs all six test suites. No network or Minecraft installation is required.

The new test uses an independent map oracle over 100,000 deterministic randomized steps, repeated paused times, random lifetimes, pressure, reset/reuse, capacity boundaries, invalid input and different update rates. Existing tests remain unchanged. Test counts are assertion counts, not independent native scenarios or performance benchmarks.
