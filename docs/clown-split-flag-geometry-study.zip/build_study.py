import bpy,math,json
from pathlib import Path
from mathutils import Vector
OUT=Path(__file__).resolve().parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,color,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=.32;return m
red=mat('Scarlet cloth',(.55,.006,.016));black=mat('Black pole',(.018,.022,.028),.7);railmat=mat('Neutral reference rail',(.12,.14,.17),.4)
def cube(name,loc,scale,m):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(m);return o
cube('Reference rail - not a weapon model',(0,0,.3),(5,.22,.18),railmat)
xs=[-1.7,0,1.7];idle=[1.85,2.3,1.65];center=2.;radius=.55;mount=.4
for i,(x,h) in enumerate(zip(xs,idle)):
 pole=cube('Pole_%d'%i,(x,0,(mount+h)/2),(.055,.055,h-mount),black)
 for frame,opening in [(1,0),(30,0),(90,1),(120,1),(180,0)]:
  tip=h+(center-radius-h)*opening;pole.location.z=(mount+tip)/2;pole.scale.z=tip-mount;pole.keyframe_insert('location',frame=frame);pole.keyframe_insert('scale',frame=frame)
 for side in [-1,1]:
  verts=[];focus=[];N=40;W=4
  for j in range(N+1):
   u=j/N
   for k in range(W+1):
    v=k/W
    # Two authored pennant halves, not collapsed guide vertices.
    verts.append((x+1.05*u,side*.012+.06*math.sin(u*math.pi*3)*u,h+(v-.5)*.19+side*.095+.05*math.sin(u*math.pi*2)*u))
    r=radius+.12*math.sin(math.pi*u)*(v-.5)
    focus.append((x,side*r*math.sin(math.pi*u),center-r*math.cos(math.pi*u)))
  faces=[]
  for j in range(N):
   for k in range(W):
    a=j*(W+1)+k;faces.append((a,a+1,a+W+2,a+W+1))
  mesh=bpy.data.meshes.new('Cloth mesh');mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new('Pole_%d_cloth_%s'%(i,'left'if side<0 else'right'),mesh);bpy.context.collection.objects.link(o);o.data.materials.append(red)
  o.shape_key_add(name='Idle authored pennant');key=o.shape_key_add(name='Focused half aperture')
  for v,co in zip(key.data,focus):v.co=co
  for frame,value in [(1,0),(30+i*5,0),(90+i*5,1),(120,1),(180,0)]:key.value=value;key.keyframe_insert('value',frame=frame)
  sol=o.modifiers.new('Cloth thickness','SOLIDIFY');sol.thickness=.008
  for poly in mesh.polygons:poly.use_smooth=True
# Perspective proof: center rays coincide in rear view; no pole above aperture bottom.
assert all(abs(center-(center-radius+radius))<1e-9 for _ in xs)
scene=bpy.context.scene;scene.frame_start=1;scene.frame_end=180;scene.render.fps=60
scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=False
scene.render.resolution_x=1280;scene.render.resolution_y=720;scene.render.resolution_percentage=100
scene.world.color=(.055,.055,.055)
for loc,energy,size in [((1,-4,6),1000,5),((-3,3,5),850,4)]:
 bpy.ops.object.light_add(type='AREA',location=loc);l=bpy.context.object;l.data.energy=energy;l.data.shape='DISK';l.data.size=size;l.rotation_euler=(Vector((0,0,1.4))-l.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.lens=52
views=[('idle-side',1,(5,-9,4),(0,0,1.5)),('opening-side',65,(5,-9,4),(0,0,1.5)),('focus-oblique',110,(5,-9,4),(0,0,1.5)),('focus-rear',110,(7,0,center),(-2,0,center))]
for name,frame,loc,target in views:
 scene.frame_set(frame);cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(OUT/(name+'.png'));bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'split-flag-geometry-study.blend'))
(OUT/'receipt.json').write_text(json.dumps({'kind':'3D game attachment geometry study','poles':3,'cloth_halves':6,'focus_centers':[[x,0,center]for x in xs],'focus_planes':'YZ, perpendicular to X aiming axis','pole_top':center-radius,'aperture_radius':radius,'native_accepted':False,'limits':['Simple authored morph, not cloth physics','Intermediate morph can stretch cloth','No weapon/hand rig or Minecraft renderer','Material proof not final concept art']},indent=2)+'\n')
