import bpy,json,math
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
P=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(P/'split-flag-geometry-study.blend'))
s=bpy.context.scene;s.frame_set(110);checks=[]
for x in [-1.7,0,1.7]:
 v=world_to_camera_view(s,s.camera,Vector((x,0,2.)));assert abs(v.x-.5)<1e-6 and abs(v.y-.5)<1e-6;checks.append({'center':[x,0,2.],'screen_center':[v.x,v.y]})
cloth=[o for o in s.objects if '_cloth_'in o.name];assert len(cloth)==6
for o in cloth:
 key=o.data.shape_keys.key_blocks['Focused half aperture'];assert abs(key.value-1)<1e-6
 for v in key.data:
  assert math.hypot(v.co.y,v.co.z-2.)>.48
for i in range(3):
 o=s.objects['Pole_'+str(i)];assert abs(o.location.z+o.scale.z/2-1.45)<1e-6
s.frame_set(180)
for o in cloth:assert o.data.shape_keys.key_blocks['Focused half aperture'].value==0
out={'status':'PASS','three_centers_project_to_same_screen_point':checks,'cloth_objects':6,'minimum_clear_center_radius':.48,'pole_top_below_aperture_center':True,'return_restores_idle_shape_key':True,'native_accepted':False,'scope':'Simple authored geometry/morph study only, no cloth physics or native rendering'}
(P/'geometry-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
