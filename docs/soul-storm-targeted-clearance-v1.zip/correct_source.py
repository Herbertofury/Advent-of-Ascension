import bpy,json,sys,argparse,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--render',action='store_true');p.add_argument('--out',required=True,type=Path);args=p.parse_args(sys.argv[sys.argv.index('--')+1:]if '--'in sys.argv else[])
R=args.out.resolve();R.mkdir(parents=True,exist_ok=True);bpy.ops.wm.open_mainfile(filepath=str(Path(args.source).resolve()));scene=bpy.context.scene;scene.frame_set(0)
emitter_count=sum(o.name.startswith('Emitter_') and o.name.endswith('_top_to_bottom') for o in bpy.data.objects);assert emitter_count in (4,5,6)
def inventory():
 dg=bpy.context.evaluated_depsgraph_get();rows=[]
 for o in bpy.data.objects:
  if o.type not in {'MESH','CURVE','SURFACE','FONT'} or o.hide_render:continue
  e=o.evaluated_get(dg);mesh=e.to_mesh();mesh.calc_loop_triangles();bad=sum(t.area<=1e-12 for t in mesh.loop_triangles);world_bad=0
  ancestor=o;cue=False
  while ancestor is not None:
   cue=cue or ancestor.name.startswith('Authoring_disc_');ancestor=ancestor.parent
  inactive_cue=cue and abs(o.matrix_world.to_3x3().determinant())<1e-20
  for t in mesh.loop_triangles:
   if inactive_cue:continue
   ps=[o.matrix_world@mesh.vertices[i].co for i in t.vertices]
   if (ps[1]-ps[0]).cross(ps[2]-ps[0]).length_squared<1e-20:world_bad+=1
  rows.append({'name':o.name,'source_type':o.type,'vertices':len(mesh.vertices),'triangles':len(mesh.loop_triangles),'zero_area_triangles':bad,'world_collapsed_triangles':world_bad,'inactive_projectile_triangles':len(mesh.loop_triangles)if inactive_cue else 0});e.to_mesh_clear()
 return {'objects':len(rows),'vertices':sum(x['vertices']for x in rows),'triangles':sum(x['triangles']for x in rows),'zero_area_triangles':sum(x['zero_area_triangles']for x in rows),'world_collapsed_triangles':sum(x['world_collapsed_triangles']for x in rows),'inactive_projectile_triangles':sum(x['inactive_projectile_triangles']for x in rows),'rows':rows}
def animation_digest():
 records=[]
 for action in bpy.data.actions:
  records.append([action.name,[[f.data_path,f.array_index,[[list(k.co),list(k.handle_left),list(k.handle_right),k.interpolation]for k in f.keyframe_points]]for f in action.fcurves]])
 return hashlib.sha256(json.dumps(records,sort_keys=True).encode()).hexdigest()
def core_uv_digest():
 rows=[]
 for o in bpy.data.objects:
  if o.name.startswith('Animated soul vortex surface') and o.type=='MESH':rows.append([o.name,[[tuple(v.uv)for v in layer.data]for layer in o.data.uv_layers]])
 return hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest()
actions_before=animation_digest();uv_before=core_uv_digest();before=inventory();changes=[];targets={x['name']for x in before['rows']if x['world_collapsed_triangles']>0}
for o in bpy.data.objects:
 if o.hide_render or o.type!='MESH' or o.name not in targets:continue
 for mod in o.modifiers:
  if mod.type!='BEVEL':continue
  extents=[max(v.co[i]for v in o.data.vertices)-min(v.co[i]for v in o.data.vertices)for i in range(3)]
  if min(extents)>0 and mod.width>min(extents)*.25:
   safe=min(extents)*.25;changes.append({'object':o.name,'from':mod.width,'to':safe});mod.width=safe
samples=[]
for frame in sorted(set(round(scene.frame_end*i/16)for i in range(17))):
 scene.frame_set(frame);q=inventory();samples.append({'frame':frame,'world_collapsed_triangles':q['world_collapsed_triangles'],'inactive_projectile_triangles':q['inactive_projectile_triangles']})
 assert q['world_collapsed_triangles']==0,('World-space collapsed triangles remain',frame)
scene.frame_set(0);after=inventory();assert animation_digest()==actions_before;assert core_uv_digest()==uv_before
report={'emitter_count':emitter_count,'scope':'Full-detail source bevel clearance correction; 17 sampled frames, not continuous collision/native acceptance','before':before,'after':after,'samples':samples,'changes':changes,'animation_digest_unchanged':True,'core_uv_digest_unchanged':True,'source_sha256':hashlib.sha256(Path(args.source).read_bytes()).hexdigest()};(R/'clearance-qa.json').write_text(json.dumps(report,indent=2)+'\n');bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'corrected-source.blend'))
if args.render:
 scene.cycles.samples=24;scene.cycles.use_denoising=False;scene.render.filepath=str(R/'preview.png');bpy.ops.render.render(write_still=True)
print('PASS full-detail clearance',emitter_count,'emitters',len(samples),'sampled frames',len(changes),'bevel fixes')
