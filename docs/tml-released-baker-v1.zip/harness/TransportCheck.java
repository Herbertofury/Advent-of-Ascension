import com.google.gson.*;
import com.example.taczmeshloader.core.PolyMesh;
import java.nio.file.*;
import java.util.*;
public class TransportCheck {
 public static void main(String[] args) throws Exception {
  JsonObject g=JsonParser.parseString(Files.readString(Path.of(args[0]))).getAsJsonObject().getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject();
  int total=0,bones=0;
  for(JsonElement e:g.getAsJsonArray("bones")) {
   JsonObject b=e.getAsJsonObject();if(!b.has("poly_mesh"))continue;
   JsonObject m=b.getAsJsonObject("poly_mesh");float[] pivot={0,0,0};
   if(b.has("pivot"))for(int j=0;j<3;j++)pivot[j]=b.getAsJsonArray("pivot").get(j).getAsFloat();
   PolyMesh p=new PolyMesh(m,2048,2048,pivot);int n=(int)BakerCheck.field(p,"vertexCount");
   BakerCheck.req(n==m.getAsJsonArray("polys").size()*4,"expanded count");
   String[] fields={"bakedX","bakedY","bakedZ","bakedU","bakedV","bakedNX","bakedNY","bakedNZ"};
   for(String f:fields){float[] a=(float[])BakerCheck.field(p,f);BakerCheck.req(a.length==n,"array size");for(float v:a){BakerCheck.req(Float.isFinite(v),"nonfinite "+f);if(f.equals("bakedU")||f.equals("bakedV"))BakerCheck.req(v>=0&&v<=1,"UV bounds");}}
   BakerCheck.req(((Map<?,?>)BakerCheck.field(p,"vboCache")).isEmpty(),"GPU cache touched");total+=n;bones++;
  }
  BakerCheck.req(bones==13&&total==81152,"unexpected transport count");
  System.out.println("PASS actual released TML baker: "+bones+" Soul Storm mesh bones, "+total+" baked vertices, finite geometry/normals, bounded UVs, empty GPU caches. Static geometry only; no rendering or game acceptance.");
 }
}
