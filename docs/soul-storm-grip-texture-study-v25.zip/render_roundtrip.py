import bpy,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-grip-texture-study.blend'));s=bpy.context.scene;s.frame_set(0);s.cycles.samples=32;s.cycles.use_denoising=False;s.cycles.seed=19;s.render.resolution_x=900;s.render.resolution_y=650;s.render.resolution_percentage=100;cam=s.camera;target=Vector((-3.35,0,-.65));cam.location=(-5.5,-9,2);cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=3.1
bpy.ops.object.light_add(type='AREA',location=(-4,-6,2));light=bpy.context.object;light.data.energy=400;light.data.size=4;light.rotation_euler=(target-light.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/'grip-procedural-close.png');bpy.ops.render.render(write_still=True)
o=bpy.data.objects['V25 leather grip baked material domain'];m=bpy.data.materials.new('V25 baked leather roundtrip');m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links;b=n.new('ShaderNodeBsdfPrincipled');b.inputs['Metallic'].default_value=0;b.inputs['Roughness'].default_value=.52
for kind in ['basecolor','normal']:
 im=bpy.data.images.load(str(R/('grip-'+kind+'.png')),check_existing=False);im.colorspace_settings.name='sRGB'if kind=='basecolor'else'Non-Color';t=n.new('ShaderNodeTexImage');t.image=im
 if kind=='basecolor':l.new(t.outputs['Color'],b.inputs['Base Color'])
 else:
  nm=n.new('ShaderNodeNormalMap');nm.space='TANGENT';l.new(t.outputs['Color'],nm.inputs['Color']);l.new(nm.outputs['Normal'],b.inputs['Normal'])
 im.pack()
out=n.new('ShaderNodeOutputMaterial');l.new(b.outputs[0],out.inputs['Surface']);o.data.materials.clear();o.data.materials.append(m);s.render.filepath=str(R/'grip-baked-close.png');bpy.ops.render.render(write_still=True);bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'soul-storm-grip-baked-roundtrip.blend'))
