# Soul Storm opaque grip texture study

Unaccepted authoring candidate. Five wraps now slope across the existing curved grip. One static grip material domain carries UV-mapped base color and tangent normal textures. The whole weapon and native TaCZ/TML integration are not included in the GLB.

The GLB embeds both 1024px PNG maps. It contains 1,176 triangles and one material. Open it in Blender for an editable grip mesh/material; do not install it as a gun pack. Native normal-map support and conventions remain unverified.

## Reproduce from preserved source without duplicating the full scene

Download the existing v22 source archive:
https://github.com/Herbertofury/Advent-of-Ascension/blob/main/docs/soul-storm-v22-authoring-study.zip

Put its v22/soul-storm-v22.blend at ../soul-storm-sculpt-v22/soul-storm-v22.blend relative to this extracted study folder. Keep this study folder intact. Use Blender 4.3.2:

blender -b -t 2 --python-exit-code 1 --python build_bake.py
blender -b -t 2 --python-exit-code 1 --python render_roundtrip.py
blender -b -t 2 --python-exit-code 1 --python check_export.py
blender -b -t 2 --python-exit-code 1 --python check_glb_roundtrip.py

These regenerate the packed authoring scene, maps, GLB and close-up comparisons. The existing v22 scene remains unchanged. This small package avoids another duplicate full-weapon Blender archive. The first three commands require that source; the exported GLB can be inspected independently.

## Interpretation

Geometry/UV and GLB checks passed their recorded subset. The actual GLB was reimported and rendered from the same camera. Full-frame mean RGB error versus the baked-material render was 0.000008871 on a 0–1 scale; this includes non-grip pixels and Monte Carlo noise. It is not a native rendering or beauty metric.

Visual review remains unaccepted: the grip still looks smoother and more rubber-like than the richer hand-wrapped concept, and surrounding heel/ornament work is unfinished. All hand fit, animation, attachment and native performance gates remain open. UV boundary counts reflect split indexing and do not alone prove geometric holes. No transparent Soul Flame material was baked or approved by this opaque-grip experiment.
