import bpy,json,hashlib,collections,math
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-grip-baked-roundtrip.blend'));s=bpy.context.scene;s.frame_set(0);o=bpy.data.objects['V25 leather grip baked material domain'];dg=bpy.context.evaluated_depsgraph_get();eo=o.evaluated_get(dg);me=eo.to_mesh();me.calc_loop_triangles();bad=[]
for i,t in enumerate(me.loop_triangles):
 v=[eo.matrix_world@me.vertices[j].co for j in t.vertices]
 if(v[1]-v[0]).cross(v[2]-v[0]).length_squared<1e-20:bad.append(i)
tri=len(me.loop_triangles);eo.to_mesh_clear();assert not bad
uv=o.data.uv_layers.active;assert uv and all(math.isfinite(c)and -1e-6<=c<=1+1e-6 for x in uv.data for c in x.uv)
bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
bpy.ops.export_scene.gltf(filepath=str(R/'soul-storm-grip-study.glb'),export_format='GLB',use_selection=True,export_animations=False,export_apply=True,export_image_format='AUTO',export_materials='EXPORT',export_yup=True)
report={'scope':'Static grip material-domain export only; not a complete weapon, native TaCZ gun or hand-fit approval','triangles':tri,'degenerate_triangles':len(bad),'uv_loops':len(uv.data),'native_accepted':False,'glb_sha256':hashlib.sha256((R/'soul-storm-grip-study.glb').read_bytes()).hexdigest(),'glb_bytes':(R/'soul-storm-grip-study.glb').stat().st_size};(R/'export-qa.json').write_text(json.dumps(report,indent=2));print(report)
