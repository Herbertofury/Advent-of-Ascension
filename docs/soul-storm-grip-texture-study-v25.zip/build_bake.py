import bpy,json,hashlib,math,bmesh
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'soul-storm-sculpt-v22/soul-storm-v22.blend'));s=bpy.context.scene;s.frame_set(0);s.render.engine='CYCLES';s.cycles.samples=8;s.cycles.use_denoising=False
# Follow the curved grip with five diagonal wraps; source v22 remains preserved separately.
wraps=sorted([o for o in s.objects if o.name.startswith('V16 flush grip wrap') and not o.hide_render],key=lambda o:o.name)
for j,wrap in enumerate(wraps):
 assert len(wrap.data.vertices)==48
 for ring,t0 in enumerate([.13+j*.15,.19+j*.15]):
  for k in range(24):
   a=2*math.pi*k/24;t=t0+.055*math.cos(a);x=-3.08-.55*t-.10*math.sin(math.pi*t);z=.12-1.74*t;rx=.43+.04*math.sin(math.pi*t)+.012;ry=.49-.035*t+.012
   wrap.data.vertices[ring*24+k].co=(x+rx*math.cos(a),ry*math.sin(a),z)
 bm=bmesh.new();bm.from_mesh(wrap.data);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(wrap.data);bm.free()
names=['V16 continuous curved grip']+[o.name for o in s.objects if o.name.startswith('V16 flush grip wrap') and not o.hide_render];assert len(names)==6
# Preserve all originals as hidden history and create one static material domain from evaluated geometry.
dg=bpy.context.evaluated_depsgraph_get();copies=[]
for name in names:
 o=bpy.data.objects[name];eo=o.evaluated_get(dg);me=bpy.data.meshes.new_from_object(eo,depsgraph=dg);copy=bpy.data.objects.new('V25 grip texture part '+name,me);s.collection.objects.link(copy);copy.matrix_world=o.matrix_world.copy();copies.append(copy);o.hide_render=True;o.hide_viewport=True
bpy.ops.object.select_all(action='DESELECT')
for o in copies:o.select_set(True)
bpy.context.view_layer.objects.active=copies[0];bpy.ops.object.join();o=bpy.context.object;o.name='V25 leather grip baked material domain';world=o.matrix_world.copy();o.parent=bpy.data.objects['SoulStorm_Root'];o.matrix_world=world
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=1.15192,island_margin=.035);bpy.ops.object.mode_set(mode='OBJECT')
m=bpy.data.materials.new('V25 fine indigo leather authoring');m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links;tex=n.new('ShaderNodeTexCoord');noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=85;noise.inputs['Detail'].default_value=3;l.new(tex.outputs['Generated'],noise.inputs['Vector']);fine=n.new('ShaderNodeTexVoronoi');fine.feature='DISTANCE_TO_EDGE';fine.inputs['Scale'].default_value=130;l.new(tex.outputs['Generated'],fine.inputs['Vector']);r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.18;r.color_ramp.elements[0].color=(.003,.002,.006,1);r.color_ramp.elements[1].position=.82;r.color_ramp.elements[1].color=(.012,.009,.018,1);l.new(noise.outputs['Fac'],r.inputs[0]);b=n.new('ShaderNodeBsdfPrincipled');b.inputs['Metallic'].default_value=0;b.inputs['Roughness'].default_value=.52;l.new(r.outputs[0],b.inputs['Base Color']);bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.28;bump.inputs['Distance'].default_value=.006;l.new(fine.outputs['Distance'],bump.inputs['Height']);l.new(bump.outputs['Normal'],b.inputs['Normal']);out=n.new('ShaderNodeOutputMaterial');l.new(b.outputs[0],out.inputs['Surface']);o.data.materials.clear();o.data.materials.append(m)
receipts=[]
for kind in ['basecolor','normal']:
 im=bpy.data.images.new('SoulStorm grip '+kind,1024,1024,alpha=True);im.colorspace_settings.name='sRGB'if kind=='basecolor'else'Non-Color';t=n.new('ShaderNodeTexImage');t.image=im;n.active=t;s.render.bake.margin=12
 if kind=='basecolor':s.render.bake.use_pass_direct=False;s.render.bake.use_pass_indirect=False;s.render.bake.use_pass_color=True;bpy.ops.object.bake(type='DIFFUSE')
 else:bpy.ops.object.bake(type='NORMAL')
 im.filepath_raw=str(R/('grip-'+kind+'.png'));im.file_format='PNG';im.save();receipts.append({'kind':kind,'file':'grip-'+kind+'.png','sha256':hashlib.sha256((R/('grip-'+kind+'.png')).read_bytes()).hexdigest()});im.pack();n.remove(t)
# Record procedural source; native transport and map interpretation remain separate checks.
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'soul-storm-grip-texture-study.blend'));(R/'manifest.json').write_text(json.dumps({'source_objects':names,'merged_domain':o.name,'unchanged_geometry_intent':False,'geometry_change':'Five wrap bands now follow a gentle diagonal across the curved grip; grip core, collar, heel, guard and all other weapon parts unchanged','maps':receipts,'native_accepted':False,'limits':['Bake seam and map roundtrip review pending','No native normal-map pipeline approval','No new hand-fit or gameplay acceptance']},indent=2))
s.cycles.samples=24;s.render.resolution_x=1200;s.render.resolution_y=800;s.render.resolution_percentage=100;s.render.filepath=str(R/'hero-procedural.png');bpy.ops.render.render(write_still=True)
