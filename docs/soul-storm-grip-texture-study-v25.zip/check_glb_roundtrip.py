import bpy,json,struct,math,collections,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;p=R/'soul-storm-grip-study.glb';raw=p.read_bytes();n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);assert len(g['meshes'])==len(g['materials'])==1;assert len(g['images'])==2 and all(i.get('mimeType')=='image/png'for i in g['images']);assert g['materials'][0].get('normalTexture');assert not g.get('animations')
bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-grip-baked-roundtrip.blend'));s=bpy.context.scene;s.frame_set(0);source=bpy.data.objects['V25 leather grip baked material domain'];dg=bpy.context.evaluated_depsgraph_get()
def triangles(o):
 eo=o.evaluated_get(dg);me=eo.to_mesh();me.calc_loop_triangles();rows=[]
 for t in me.loop_triangles:rows.append(tuple(sorted(tuple(round(c,4)for c in(eo.matrix_world@me.vertices[i].co))for i in t.vertices)))
 eo.to_mesh_clear();return collections.Counter(rows)
expected=triangles(source);source.hide_render=True;before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(p));new=[o for o in set(bpy.data.objects)-before if o.type=='MESH'];assert len(new)==1;dg=bpy.context.evaluated_depsgraph_get();actual=triangles(new[0]);assert expected==actual,'Roundtrip changed world-space triangle coordinates'
s.cycles.samples=32;s.cycles.use_denoising=False;s.cycles.seed=19;s.render.filepath=str(R/'grip-glb-reimport-close.png');bpy.ops.render.render(write_still=True)
r={'status':'PASS','glb_sha256':hashlib.sha256(raw).hexdigest(),'meshes':1,'materials':1,'embedded_png_images':2,'normal_texture_present':True,'roundtrip_world_triangles':sum(actual.values()),'coordinate_rounding':1e-4,'scope':'Blender glTF reimport only; no TaCZ or TML native material convention acceptance','native_accepted':False};(R/'glb-roundtrip-qa.json').write_text(json.dumps(r,indent=2));print(r)
