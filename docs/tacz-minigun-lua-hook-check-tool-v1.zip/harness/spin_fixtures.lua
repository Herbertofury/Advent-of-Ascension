-- Original context-boundary tests. Not a renderer or gameplay simulation.
local calls={}
local holding=true
local stopped=true
local now=1000
local context={}
function context:getTrack(line,track)return tostring(line)..":"..tostring(track)end
function context:isHolding(track)return holding end
function context:isStopped(track)return stopped end
function context:getLastShootTimestamp()return 1000 end
function context:getCurrentTimestamp()return now end
function context:getShootInterval()return 50 end
function context:runAnimation(...)table.insert(calls,{kind="animation",args={...}})end
function context:stopAnimation(...)table.insert(calls,{kind="stop",args={...}})end
function context:trigger(...)table.insert(calls,{kind="trigger",args={...}})end
local function clear()calls={}end
assert(M.spin_states.static.transition(M,context,"unrelated")==M.spin_states.normal)
stopped=false;assert(M.spin_states.static.transition(M,context,"unrelated")==nil)
assert(M.spin_states.normal.transition(M,context,INPUT_SHOOT)==M.spin_states.fire)
clear();M.spin_states.fire.entry(M,context)
assert(#calls==1 and calls[1].args[1]=="spin" and calls[1].args[4]==PLAY_ONCE_HOLD and calls[1].args[5]==0.2)
for _,t in ipairs({1149,1150})do
 clear();now=t;M.spin_states.fire.update(M,context)
 assert(#calls==1 and calls[1].kind=="animation" and calls[1].args[1]=="spin")
end
clear();now=1151;M.spin_states.fire.update(M,context)
assert(#calls==1 and calls[1].kind=="trigger" and calls[1].args[1]==M.INPUT_STOP_SHOOT)
clear();holding=false;now=9000;M.spin_states.fire.update(M,context);assert(#calls==0)
clear();local nextState=M.spin_states.fire.transition(M,context,M.INPUT_STOP_SHOOT)
assert(nextState==M.spin_states.normal and #calls==1 and calls[1].args[1]=="spin_low" and calls[1].args[4]==PLAY_ONCE_STOP)
clear();assert(M.spin_states.fire.transition(M,context,"unrelated")==nil and #calls==0)
clear();assert(M.spin_states.normal.transition(M,context,M.INPUT_STOP_SPIN)==M.spin_states.static and #calls==1 and calls[1].kind=="stop")
print("PASS actual released minigun Lua spin-state functions: hold-boundary restart, strict interval+100 threshold, stop/winddown and unknown-input guards. Mock context only; no interpolation or native game proof.")
function context:setShouldHideCrossHair(value)table.insert(calls,{kind="crosshair",value=value})end
clear();M.main_track_states.inspect.entry(M,context)
assert(#calls==2 and calls[1].kind=="trigger" and calls[1].args[1]==M.INPUT_STOP_SPIN and calls[2].kind=="crosshair" and calls[2].value==true)
clear();assert(M.main_track_states.inspect.transition(M,context,INPUT_SHOOT)==M.main_track_states.idle)
assert(#calls==1 and calls[1].kind=="stop")
clear();M.main_track_states.inspect.exit(M,context);assert(#calls==1 and calls[1].kind=="crosshair" and calls[1].value==false)
clear();stopped=true;M.main_track_states.inspect.update(M,context);assert(#calls==1 and calls[1].args[1]==M.INPUT_INSPECT_RETREAT)
clear();stopped=false;M.main_track_states.inspect.update(M,context);assert(#calls==0)
print("PASS actual inspect entry/exit, shoot interruption and completed-track retreat hooks. Engine invocation order remains outside this mock-context test.")
