# Default TaCZ minigun Lua boundary check

Run `python run_check.py /path/to/tacz-1.20.1-1.1.8-hotfix2.jar --out results.json` with a full JDK17+ (JAVA_HOME). Optional --java-extra runs a second JVM. No network/download is performed by this runner.

The exact released Lua state-machine file and its embedded LuaJ3.0.8-figura libraries are extracted and fingerprint-checked locally. Only the original Java/Lua harness and hash manifest are distributed. No reference gamepack source, class or library is bundled.

The actual script returns its state table; the harness invokes selected spin and inspect hooks with a mock context. It tests boundary thresholds, held-track guard, restart/winddown/stop calls, inspection crosshair restoration and shooting interruption. Engine mode/input constants use clearly named test sentinels, not native enum values. The native state-machine runner and interpolation are absent. This does not prove in-game phase continuity or event order.

A separate javap check records the released context clock's wall-time source. Do not mix its millisecond timestamps with paused game-time animation values. Gameplay, resource consumption and cadence remain untouched.

Reference credit: TaCZ developers. Official artifact: https://www.curseforge.com/minecraft/mc-mods/timeless-and-classics-zero/files/9037989 . Supply that matching JAR locally; no redistributable gunpack is produced.
