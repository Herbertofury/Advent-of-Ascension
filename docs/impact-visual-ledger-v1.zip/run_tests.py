"""Compile and test the original visual event ledger under the caller-selected JDK."""
from pathlib import Path
import os, shutil, subprocess, tempfile
root = Path(__file__).resolve().parent
suffix = '.exe' if os.name == 'nt' else ''
def tool(name):
    home = os.environ.get('JAVA_HOME')
    result = str(Path(home)/'bin'/(name+suffix)) if home else shutil.which(name)
    if not result or not Path(result).is_file():
        raise SystemExit('A full JDK is required. Set JAVA_HOME to the JDK directory.')
    return result
javac,java = tool('javac'),tool('java')
subprocess.run([javac,'-version'],check=True)
subprocess.run([java,'-version'],check=True)
with tempfile.TemporaryDirectory(prefix='aoa-impact-java-') as output:
    subprocess.run([javac,'--release','17','-d',output,*map(str,sorted((root/'src').glob('*.java')))],check=True)
    subprocess.run([java,'-cp',output,'ImpactVisualLedgerTest'],check=True)
