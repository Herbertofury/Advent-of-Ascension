# Branch-aware cosmetic event ledger

Original Java 17 helper for a future AoA presentation adapter. It is not a mod and does not alter, validate or deduplicate gameplay damage.

The released Discharge Shotgun can reach a weapon-impact callback followed by a projectile-impact callback for one pellet's entity hit. A cosmetic dispatcher keyed only by weapon/burst could incorrectly suppress distinct intended branches. This helper distinguishes world generation, actor, weapon instance, burst, pellet, impact ordinal and branch.

## Integration contract

- Call once per received logical cosmetic branch event on the owning presentation thread. Fan out that event to its configured visual channels after acceptance. Do not call per particle, camera, shader pass or render frame; doing so would suppress legitimate presentations.
- The native adapter must provide trustworthy, stable identities and must handle authoritative gameplay independently. This helper is neither a network authentication check nor a final hit/damage permission check.
- The memory window is bounded by the configured capacity, with insertion-order eviction. Once an old key is evicted, replaying it is accepted. This deliberately is not permanent replay prevention.
- Duplicate keys do not refresh their residency. New-world/reset calls clear the window, and old-world events are rejected against the active generation. The caller must supply a new generation for teardown/reload.
- Separate actors and weapon instances do not share identities. The helper is not thread-safe; use it only from its owner's dispatch thread or supply external synchronization.
- No inventory scan or render-loop particle queue is used. This does not establish native frame-time performance or an allocation-free event path.

## Reproduce

Set JAVA_HOME to a full JDK, then run `python run_tests.py`. The receipt used actual Amazon Corretto 17, compiling with --release17 in a temporary directory.

Tests preserve all eight distinct branch events for four pellets, reject repeats, distinguish later impacts/actors/weapons, exercise 10,000 unique events under a 64-entry bound, verify eviction behavior and world resets, and reject invalid construction inputs. They are pure-core tests without Minecraft or TaCZ.

Native event IDs, hook placement, logical-event-to-effect fan-out, late packet behavior, settings, views, resource reload and frame times remain untested. Never use this finite cosmetic window as the server's gameplay duplicate-prevention mechanism.
