"""Transfer generated roughness/metallic fields onto the repaired UV atlas.
Preserves reference PBR values rather than reusing invalid old UV coordinates.
"""
import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parent/'apoco-trial';O=R/'topology-review-v5';O.mkdir(exist_ok=True);bpy.ops.wm.open_mainfile(filepath=str(R/'topology-review-v3/rebaked-repair-study.blend'));target=bpy.data.objects['Topology repair experiment'];source=next(o for o in bpy.context.scene.objects if o.type=='MESH'and o!=target);source.hide_set(False);source.hide_render=False;bpy.ops.object.select_all(action='DESELECT');source.select_set(True);target.select_set(True);bpy.context.view_layer.objects.active=target;s=bpy.context.scene;s.cycles.samples=1;s.render.bake.use_selected_to_active=True;s.render.bake.max_ray_distance=.008;s.render.bake.cage_extrusion=.004;s.render.bake.margin=8
m=target.data.materials[0];n=m.node_tree.nodes;l=m.node_tree.links;bs=n.get('Principled BSDF');images={}
for field in ['Base Color','Roughness','Metallic']:
 saved=[]
 for sm in source.data.materials:
  sn=sm.node_tree.nodes;sl=sm.node_tree.links;out=next(x for x in sn if x.type=='OUTPUT_MATERIAL');shader=next(x for x in sn if x.type=='BSDF_PRINCIPLED');old=out.inputs['Surface'].links[0].from_socket;em=sn.new('ShaderNodeEmission');em.inputs['Strength'].default_value=1;inp=shader.inputs[field]
  if inp.links:sl.new(inp.links[0].from_socket,em.inputs['Color'])
  else:em.inputs['Color'].default_value=tuple(inp.default_value) if field=='Base Color' else (inp.default_value,)*3+(1,)
  sl.new(em.outputs[0],out.inputs['Surface']);saved.append((sm,old,out,em))
 im=bpy.data.images.new('Rebaked '+field,width=2048,height=2048,alpha=False);im.colorspace_settings.name='sRGB' if field=='Base Color' else 'Non-Color';tex=n.new('ShaderNodeTexImage');tex.image=im;n.active=tex
 print('Bake '+field,flush=True);bpy.ops.object.bake(type='EMIT');im.filepath_raw=str(O/(field.lower()+'.png'));im.file_format='PNG';im.save();l.new(tex.outputs['Color'],bs.inputs[field]);images[field]=im.filepath_raw
 for sm,old,out,em in saved:sm.node_tree.links.new(old,out.inputs['Surface']);sm.node_tree.nodes.remove(em)
source.hide_render=True;source.hide_set(True);source.select_set(False);target.select_set(True);m.use_backface_culling=True;bpy.ops.wm.save_as_mainfile(filepath=str(O/'repaired-pbr-study.blend'));bpy.ops.export_scene.gltf(filepath=str(O/'repaired-pbr-study.glb'),export_format='GLB',use_selection=True,export_apply=True);(O/'receipt.json').write_text(json.dumps({'scope':'Full generated PBR transfer to repaired UVs; no concept-fidelity acceptance','images':images,'geometry_parent':'topology-review-v3','native_accepted':False},indent=2)+'\n')
