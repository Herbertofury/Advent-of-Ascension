"""Non-destructive voxel-reconstruction experiment with nearest-surface UV transfer.
A manifold result still requires shape/material review and moving-part authoring.
"""
import bpy,bmesh,argparse,sys,json,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--scene',required=True);p.add_argument('--out',required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);out=Path(a.out);out.mkdir(exist_ok=True,parents=True);bpy.ops.wm.open_mainfile(filepath=a.scene)
source=next(o for o in bpy.context.scene.objects if o.type=='MESH');target=source.copy();target.data=source.data.copy();target.name='Topology repair experiment';bpy.context.collection.objects.link(target);source.hide_render=True;source.hide_set(True);bpy.ops.object.select_all(action='DESELECT');target.select_set(True);bpy.context.view_layer.objects.active=target
# Physical scale inherited unchanged from the generated GLB; voxel units are authoring units.
target.data.remesh_voxel_size=.002;target.data.use_remesh_preserve_volume=True;bpy.ops.object.voxel_remesh();before=len(target.data.polygons)
dec=target.modifiers.new('Bounded post-remesh simplification','DECIMATE');dec.ratio=min(1.,60000/max(before,1));bpy.ops.object.modifier_apply(modifier=dec.name)
if not target.data.uv_layers:target.data.uv_layers.new(name=source.data.uv_layers.active.name)
transfer=target.modifiers.new('Reference UV transfer diagnostic','DATA_TRANSFER');transfer.object=source;transfer.use_loop_data=True;transfer.data_types_loops={'UV'};transfer.loop_mapping='POLYINTERP_NEAREST';bpy.ops.object.modifier_apply(modifier=transfer.name)
for poly in target.data.polygons:poly.use_smooth=True
bm=bmesh.new();bm.from_mesh(target.data);bmesh.ops.triangulate(bm,faces=list(bm.faces));deg=sum(f.calc_area()<=1e-12 for f in bm.faces);non=sum(not e.is_manifold for e in bm.edges);boundary=sum(e.is_boundary for e in bm.edges);report={'scope':'Voxel reconstruction and nearest-surface UV transfer experiment; final appearance unaccepted','voxel_size':.002,'voxel_faces':before,'triangles':len(bm.faces),'vertices':len(bm.verts),'nonmanifold_edges':non,'boundary_edges':boundary,'near_zero_faces':deg,'native_accepted':False,'remaining':['Visual silhouette and UV transfer fidelity','Moving-part ownership','Native integration and performance']};bm.free()
bpy.ops.wm.save_as_mainfile(filepath=str(out/'topology-repair-study.blend'));(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
s=bpy.context.scene;s.render.filepath=str(out/'comparison.png');bpy.ops.render.render(write_still=True)
