"""Bounded download of the seven pinned Q8 res-512 model files; never executes weights."""
import urllib.request,json,pathlib,hashlib,concurrent.futures,time,os
R=pathlib.Path(__file__).resolve().parent;out=R/'models-q8-512';out.mkdir(exist_ok=True)
sha=json.loads((R/'model-metadata.json').read_text())['sha'];base='https://huggingface.co/ilintar/trellis2-gguf';names={'dinov3.gguf','ss_flow.gguf','ss_dec.gguf','shape_flow_512.gguf','shape_dec.gguf','tex_flow_512.gguf','tex_dec.gguf'}
rows=json.load(urllib.request.urlopen(base.replace('huggingface.co/','huggingface.co/api/models/')+'/tree/'+sha+'/q8?expand=false',timeout=60));selected=[x for x in rows if x['path'].split('/')[-1]in names];assert len(selected)==7;assert sum(x['size']for x in selected)<8_000_000_000
(R/'download-manifest.json').write_text(json.dumps({'model_revision':sha,'files':selected,'max_download_bytes':8_000_000_000},indent=2)+'\n');print('Total pinned bytes',sum(x['size']for x in selected),flush=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def download(row):
 name=row['path'].split('/')[-1];final=out/name;temp=out/(name+'.partial');expected=row['lfs']['oid']
 if final.exists()and final.stat().st_size==row['size']and digest(final)==expected:return {'file':name,'sha256':expected,'verified':True}
 for attempt in range(4):
  try:
   offset=temp.stat().st_size if temp.exists()else 0
   if offset<row['size']:
    req=urllib.request.Request(base+'/resolve/'+sha+'/'+row['path'],headers={'Range':f'bytes={offset}-'}if offset else{})
    with urllib.request.urlopen(req,timeout=90)as response:
     mode='ab'if offset and response.status==206 else'wb'
     if mode=='ab':assert response.headers.get('Content-Range','').startswith(f'bytes {offset}-')
     with temp.open(mode)as f:
      for chunk in iter(lambda:response.read(4*1024*1024),b''):
       f.write(chunk)
       if f.tell()>row['size']:raise RuntimeError('Download exceeds pinned size')
   assert temp.stat().st_size==row['size'],name
   actual=digest(temp);assert actual==expected,(name,actual,expected);temp.replace(final);print('Verified',name,row['size'],flush=True);return {'file':name,'sha256':actual,'bytes':row['size'],'verified':True}
  except Exception as e:
   print('Retry',name,attempt+1,type(e).__name__,str(e)[:200],flush=True)
   if attempt==3:raise
   time.sleep(3)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(download,selected))
(R/'download-receipt.json').write_text(json.dumps({'revision':sha,'files':results},indent=2)+'\n')
