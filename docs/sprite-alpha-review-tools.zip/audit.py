from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,argparse
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--docs',type=Path,required=True);p.add_argument('--sample',default='discharge-sniper-original.png');args=p.parse_args();D=args.docs
cat=json.loads((D/'weapon-concept-catalog.json').read_text());out=[]
for w in cat['weapons']:
 p=D/w['sprite'];im=Image.open(p).convert('RGBA');pixels=list(im.getdata());hidden=[v[:3]for v in pixels if v[3]==0];out.append({'id':w['id'],'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':list(im.size),'transparent_pixels':len(hidden),'distinct_hidden_rgb_colors':len(set(hidden)),'semitransparent_pixels':sum(0<v[3]<255 for v in pixels),'opaque_bbox':im.getchannel('A').getbbox()})
(R/'audit.json').write_text(json.dumps({'scope':'Pixel storage and alpha semantics only; no claim that previously generated concepts used incorrect pixels','entries':len(out),'entries_with_transparent_pixels':sum(x['transparent_pixels']>0 for x in out),'entries_with_varied_hidden_rgb':sum(x['distinct_hidden_rgb_colors']>1 for x in out),'records':out},indent=2)+'\n')
p=D/args.sample;src=Image.open(p).convert('RGBA');raw=src.convert('RGB').resize((512,512),Image.Resampling.NEAREST);right=Image.new('RGBA',src.size,(35,42,54,255));right.alpha_composite(src);right=right.convert('RGB').resize((512,512),Image.Resampling.NEAREST)
im=Image.new('RGB',(1160,690),'#101925');dr=ImageDraw.Draw(im);f=lambda n:ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',n);dr.text((35,20),'READ THE ALPHA, NOT HIDDEN RGB',font=f(29),fill='#e4f2ff');im.paste(raw,(35,105));im.paste(right,(610,105));dr.text((35,70),'Incorrect: transparency discarded',font=f(22),fill='#ffa79d');dr.text((610,70),'Correct: original alpha composited',font=f(22),fill='#92eedc');dr.text((35,638),'Same source PNG. Hidden RGB is not weapon geometry or material.',font=f(23),fill='#bfd2e4');im.save(R/'comparison.webp',quality=94)
print('Audited',len(out),'catalogued sprite files;',sum(x['distinct_hidden_rgb_colors']>1 for x in out),'have varied hidden RGB')
