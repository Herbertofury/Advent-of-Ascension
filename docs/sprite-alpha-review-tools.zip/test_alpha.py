from PIL import Image
import unittest
class Alpha(unittest.TestCase):
 def composite(self,px):
  im=Image.new('RGBA',(len(px),1));im.putdata(px);bg=Image.new('RGBA',im.size,(35,42,54,255));bg.alpha_composite(im);return list(bg.getdata())
 def test_hidden_rgb_invariance(self):self.assertEqual(self.composite([(0,0,0,0),(255,255,255,0),(255,0,130,0)]),[(35,42,54,255)]*3)
 def test_opaque_preservation(self):self.assertEqual(self.composite([(250,34,7,255)]),[(250,34,7,255)])
 def test_partial_alpha(self):
  out=self.composite([(255,0,0,128)])[0];expected=tuple(round(a*128/255+b*127/255)for a,b in zip((255,0,0),(35,42,54)))+(255,);self.assertEqual(out,expected)
if __name__=='__main__':unittest.main()
