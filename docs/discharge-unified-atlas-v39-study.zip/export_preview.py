"""Static authoring GLB for visual inspection only; not a Minecraft export."""
import bpy,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;src=R/'discharge-grouped-study.blend';bpy.ops.wm.open_mainfile(filepath=str(src));s=bpy.context.scene;s.frame_set(1);bpy.context.view_layer.update();parts=[o for o in bpy.data.objects if o.type=='MESH'and not o.hide_render];assert len(parts)==7
bpy.ops.object.select_all(action='DESELECT');preview=bpy.data.collections.new('Preview export');s.collection.children.link(preview);copies=[]
for old in parts:
 obj=old.copy();obj.data=old.data.copy();world=old.matrix_world.copy();obj.parent=None;obj.matrix_world=world;obj.animation_data_clear();preview.objects.link(obj);obj.select_set(True);copies.append(obj)
bpy.context.view_layer.objects.active=copies[0];dst=R/'discharge-static-preview.glb';bpy.ops.export_scene.gltf(filepath=str(dst),export_format='GLB',use_selection=True,export_materials='EXPORT',export_normals=True,export_texcoords=True,export_animations=False,export_yup=True);report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'glb_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'bytes':dst.stat().st_size,'selected_meshes':7,'frame':1,'animations_exported':False,'scope':'Static authoring preview, requires round-trip inspection; not native TaCZ/TML or final fidelity acceptance','native_accepted':False};(R/'preview-export.json').write_text(json.dumps(report,indent=2));print(report)
