# Discharge unified-atlas authoring study v39

This package preserves the grouped Blender scene with packed textures, static GLB, sampled recoil animation JSON, compact geometry transport and scoped QA receipts. It is not an installable gunpack. No native or final-art acceptance is claimed.

Blender 4.3.2: run export_geometry.py, export_clips.py and export_preview.py with --python-exit-code 1. The scene already contains the completed four-map 2048x2048 bake. This package reproduces exports from that scene; it does not claim to reproduce the upstream UV preparation or multi-hour bake from scratch.

python compact_float32.py discharge_grouped.geo.json rebuilt_compact.geo.json

Compare compact geometry, animation and GLB against the supplied artifacts. Geometry has 78,020 triangles and seven motion groups. The released TML baker expands it to 312,080 vertices. This remains high-poly authoring data; LOD and native memory/frame-time budgets are open.

v39 unifies the corrected grip and v38 collars into one four-map atlas. The earlier v37 fragmented grip bake failed visual QA and was not accepted. Native bindings for normal, roughness and emission remain unqualified. The stock flat-normal issue also remains; an opt-in authored-normal source patch has only headless validation.

The scoped render comparison shows close preservation of the current authoring scene, not fidelity to the much more ornate target concept. Sculpting, hand fit, full animation, projectiles/impacts, moving-camera mip behavior and gameplay still need work. Original gameplay is unchanged by these transport files.

No upstream game/mod binaries or third-party dependencies are included.
