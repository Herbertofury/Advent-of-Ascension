# Released ammo identity audit

Run: python reproduce.py PATH_TO_AOA3_1.20.1_3.7.1_JAR PATH_TO_released-weapon-behavior-map-1.20.1.json OUTPUT.json. Use a full JDK17 with JAVA_HOME. The map is published in the repository docs folder. The script pins its SHA256 and the original JAR SHA512, runs javap on40 relevant methods and two registries with a four-worker pool, and reads five named source comparisons from the official pinned AoA repository. It does not execute mod classes.

Only recognized constant-return getAmmoItem shapes are accepted. This is not a complete resource-consumption test. Reproduction cache is scoped by class hash; use a fresh --cache directory to recheck from scratch.

Run node test_explorer.cjs PATH_TO_weapon-ammo-explorer.html to check the browser's pure DOM logic with simulated elements. This is separate from a live browser or game test. The public HTML embeds the resolved data and existing image references.

Source code and reference JAR are acquired separately; this archive contains our analysis/test tooling only.
