"""Reproduce the bounded ammo lookup from a pinned JAR and published structural map.
This wrapper executes only javap; it never launches Minecraft or mod classes.
"""
import argparse,pathlib,subprocess,os,shutil,json,hashlib,urllib.request,concurrent.futures,re,zipfile,collections
p=argparse.ArgumentParser();p.add_argument('jar',type=pathlib.Path);p.add_argument('map',type=pathlib.Path);p.add_argument('out',type=pathlib.Path);p.add_argument('--cache',type=pathlib.Path,default=pathlib.Path('ammo-audit-cache'));a=p.parse_args();a.cache.mkdir(exist_ok=True);assert hashlib.sha256(a.map.read_bytes()).hexdigest()=='9b369cb7005ed796947f3068e42dfe2ccf242a0794282bf8df3087e74e155733','Wrong structural map';j=json.loads(a.map.read_text());assert hashlib.sha512(a.jar.read_bytes()).hexdigest()==j['jar_sha512'];z=zipfile.ZipFile(a.jar);lang=json.loads(z.read('assets/aoa3/lang/en_us.json'));home=os.getenv('JAVA_HOME');tool=str(pathlib.Path(home)/'bin/javap')if home else shutil.which('javap');assert tool,'Full JDK required'
classes=[n for n,v in j['classes'].items()if any('getAmmoItem('in m for m in v['declared_methods'])];extra=['net/tslat/aoa3/common/registration/item/AoAItems','net/tslat/aoa3/common/registration/item/AoAWeapons']
def dis(n):
 h=hashlib.sha256(z.read(n+'.class')).hexdigest();p=a.cache/(h+'.txt')
 if n in j['classes']:assert h==j['classes'][n]['class_sha256']
 if not p.exists():p.write_text(subprocess.check_output([tool,'-c','-p','-classpath',str(a.jar),n.replace('/','.')],text=True))
 return n,p.read_text()
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:texts=dict(pool.map(dis,classes+extra))
def registrations(text):
 found={};buf=[]
 for line in text.split('static {};',1)[1].splitlines():
  buf.append(line);m=re.search(r'putstatic.*// Field ([A-Z0-9_]+):Lnet/minecraftforge/registries/RegistryObject;',line)
  if m:
   b='\n'.join(buf);ss=re.findall(r'// String ([a-z0-9_]+)\s*$',b,re.M)
   if len(ss)==1 and re.search(r'// Method register\w*:\(Ljava/lang/String;',b):found[m[1]]='aoa3:'+ss[0]
   buf=[]
 return found
registry={n:registrations(texts[n])for n in extra}
vanilla={'net/minecraft/world/item/Items.f_42619_':('minecraft:carrot','cannon','CarrotCannon'),'net/minecraft/world/item/Items.f_42404_':('minecraft:wheat_seeds','gun','DartGun'),'net/minecraft/world/item/Items.f_42463_':('minecraft:leather_boots','gun','ShoeFlinger'),'net/minecraft/world/item/Items.f_42588_':('minecraft:nether_wart','gun','WartGun'),'net/minecraft/world/level/block/Blocks.f_50652_':('minecraft:cobblestone','cannon','JackRocker')};comparisons={}
for field,(id,family,name)in vanilla.items():
 url=f'https://raw.githubusercontent.com/Tslat/Advent-Of-Ascension/85d6beba07e3a09032834dcf79b5a01f411092c3/source/content/item/weapon/{family}/{name}.java';p=a.cache/(name+'-named.java')
 if not p.exists():p.write_bytes(urllib.request.urlopen(url).read())
 src=p.read_text();expected=('Blocks.'if 'Blocks.'in field else'Items.')+id.split(':')[1].upper();assert expected in re.search(r'public Item getAmmoItem\(\)\s*\{([^}]+)',src)[1];comparisons[field]={'id':id,'source_class':name,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_pin':'85d6beba07e3a09032834dcf79b5a01f411092c3'}
methods={}
for name in classes:
 body=re.search(r'public net.minecraft.world.item.Item getAmmoItem\(\);\n(.*?)(?=\n  (?:public|protected|private)|\n})',texts[name],re.S)[1];ops=re.findall(r'^\s+\d+: (\w+).*$',body,re.M);assert ops in [['getstatic','areturn'],['getstatic','invokevirtual','areturn'],['getstatic','invokevirtual','checkcast','areturn']],(name,ops);field=re.search(r'// Field (\S+):L',body)[1];owner,key=field.rsplit('.',1);id=registry[owner][key]if owner in registry else vanilla[field][0];methods[name]={'ammo_id':id,'released_field':field,'class_sha256':j['classes'][name]['class_sha256'],'method_text_sha256':hashlib.sha256(body.encode()).hexdigest(),'instructions':ops}
records=[]
for r in j['records']:
 if r['family']=='blaster':continue
 owner=next((n for n in r['class_chain']if n in methods),None);assert owner;records.append({'id':r['id'],'name':lang.get('item.'+r['id'].replace(':','.'),r['id']),'family':r['family'],'ammo_id':methods[owner]['ammo_id'],'declared_in':owner,'inherited':owner!=r['class_chain'][0]})
counts=collections.Counter(r['ammo_id']for r in records);assert len(records)==172 and len({r['id']for r in records})==172 and len(counts)==13
result={'release':'Minecraft 1.20.1 / AoA 3.7.1','scope':'Declared/inherited getAmmoItem identity for 172 conventional weapon IDs; not net consumption, exemptions, pouches, effects or gameplay acceptance. 56 blasters excluded from this item-ammo table.','jar_sha512':j['jar_sha512'],'weapon_count':len(records),'ammo_counts':dict(sorted(counts.items())),'methods':methods,'vanilla_named_source_comparisons':comparisons,'records':records};a.out.write_text(json.dumps(result,indent=2)+'\n');print('PASS 172 weapon IDs,13 ammo identities,40 constant-return methods; no native acceptance')
