import copy,json,struct,tempfile
from pathlib import Path
from preflight import validate
positions=struct.pack('<9f',0,0,0,1,0,0,0,1,0);normals=struct.pack('<9f',0,0,1,0,0,1,0,0,1);uv=struct.pack('<6f',0,0,1,0,0,1);indices=struct.pack('<3I',0,1,2);binary=positions+normals+uv+indices
base={'asset':{'version':'2.0'},'buffers':[{'byteLength':len(binary)}],'bufferViews':[{'buffer':0,'byteOffset':0,'byteLength':36},{'buffer':0,'byteOffset':36,'byteLength':36},{'buffer':0,'byteOffset':72,'byteLength':24},{'buffer':0,'byteOffset':96,'byteLength':12}],'accessors':[{'bufferView':0,'componentType':5126,'count':3,'type':'VEC3'},{'bufferView':1,'componentType':5126,'count':3,'type':'VEC3'},{'bufferView':2,'componentType':5126,'count':3,'type':'VEC2'},{'bufferView':3,'componentType':5125,'count':3,'type':'SCALAR'}],'meshes':[{'primitives':[{'attributes':{'POSITION':0,'NORMAL':1,'TEXCOORD_0':2},'indices':3}]}],'nodes':[{'mesh':0}],'scenes':[{'nodes':[0]}],'scene':0}
checks=[]
def write(path,g,b=binary):
 j=json.dumps(g,separators=(',',':')).encode();j+=b' '*((-len(j))%4);padded=b+b'\0'*((-len(b))%4);payload=struct.pack('<II',len(j),0x4E4F534A)+j+struct.pack('<II',len(padded),0x004E4942)+padded;path.write_bytes(struct.pack('<4sII',b'glTF',2,len(payload)+12)+payload)
with tempfile.TemporaryDirectory()as tmp:
 p=Path(tmp)/'test.glb';write(p,base);r=validate(p);assert r['triangles']==1 and r['checked_subset_pass']and not r['native_accepted']and not r['issues'];checks.append('valid static triangle')
 cases=[('view bounds',lambda g:g['bufferViews'][0].update(byteLength=999)),('accessor bounds',lambda g:g['accessors'][0].update(count=4)),('stride underflow',lambda g:g['bufferViews'][0].update(byteStride=4)),('stride overrun',lambda g:g['bufferViews'][0].update(byteStride=16)),('negative offset',lambda g:g['accessors'][0].update(byteOffset=-1)),('float offset',lambda g:g['accessors'][0].update(byteOffset=0.0)),('sparse unsupported',lambda g:g['accessors'][0].update(sparse={})),('external buffer',lambda g:g['buffers'][0].update(uri='https://example.invalid/data.bin')),('bad indices reference',lambda g:g['meshes'][0]['primitives'][0].update(indices=40)),('bad mode',lambda g:g['meshes'][0]['primitives'][0].update(mode=1)),('bad type',lambda g:g['accessors'][0].update(componentType=5123)),('budget',lambda g:g['accessors'][0].update(count=2_000_001)),('missing normals',lambda g:g['meshes'][0]['primitives'][0]['attributes'].pop('NORMAL')),('hierarchy cycle',lambda g:g['nodes'][0].update(children=[0])),('invalid scene',lambda g:g.update(scene=2)),('mixed transform',lambda g:g['nodes'][0].update(matrix=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],translation=[0,0,0])),('animation unsupported',lambda g:g.update(animations=[{}])),('skin unsupported',lambda g:g.update(skins=[{}])),('required extension',lambda g:g.update(extensionsRequired=['KHR_mesh_quantization'])),('material reference',lambda g:g['meshes'][0]['primitives'][0].update(material=3)),('texture reference',lambda g:g.update(textures=[{'source':5}])),('external image',lambda g:g.update(images=[{'uri':'https://example.invalid/image.png'}])),('nonfinite material',lambda g:g.update(materials=[{'pbrMetallicRoughness':{'roughnessFactor':float('nan')}}])),('invalid color',lambda g:g.update(materials=[{'pbrMetallicRoughness':{'baseColorFactor':[1,1,1,-1]}}])),('texture binding',lambda g:g.update(materials=[{'normalTexture':{'index':2}}]))]
 cases.extend([('empty scene',lambda g:g['scenes'][0].update(nodes=[])),('uninstanced mesh',lambda g:g['nodes'][0].pop('mesh')),('zero quaternion',lambda g:g['nodes'][0].update(rotation=[0,0,0,0])),('nonunit quaternion',lambda g:g['nodes'][0].update(rotation=[0,0,0,2])),('collapsed scale',lambda g:g['nodes'][0].update(scale=[1,0,1])),('absolute misalignment',lambda g:g['bufferViews'][0].update(byteOffset=1))])
 for name,mutate in cases:
  g=copy.deepcopy(base);mutate(g);write(p,g)
  try:validate(p)
  except ValueError:checks.append(name)
  else:raise AssertionError('Invalid fixture accepted: '+name)
 for name,b in [('index overrun',binary[:-12]+struct.pack('<3I',0,1,3)),('nonfinite',struct.pack('<f',float('nan'))+binary[4:]),('zero normals',binary[:36]+bytes(36)+binary[72:])]:
  write(p,base,b)
  try:validate(p)
  except ValueError:checks.append(name)
  else:raise AssertionError(name)
 write(p,base,positions[:12]*3+binary[36:]);r=validate(p);assert r['issues'][0]['count']==1;checks.append('degenerate triangle reported')
 g=copy.deepcopy(base);g['meshes'][0]['primitives'][0]['attributes']['COLOR_0']=2;write(p,g);assert validate(p)['issues'][0]['issue']=='Unreviewed vertex attributes';checks.append('unknown attributes surfaced')
 write(p,base);r=validate(p);assert r['meshes'][0]['topology']['indexed_boundary_edges']==3 and r['meshes'][0]['topology']['indexed_nonmanifold_edges']==0;checks.append('open triangle boundaries labeled')
 write(p,base,binary[:72]+bytes(24)+binary[96:]);r=validate(p);assert r['meshes'][0]['collapsed_uv_triangles']==1;checks.append('collapsed UV diagnosed')
 g=copy.deepcopy(base);b=binary+indices*2;g['buffers'][0]['byteLength']=len(b);g['bufferViews'][3]['byteLength']=36;g['accessors'][3]['count']=9;write(p,g,b);r=validate(p);assert r['meshes'][0]['topology']['duplicate_index_triangles']==2 and r['meshes'][0]['topology']['indexed_nonmanifold_edges']==3;checks.append('duplicate faces and over-shared edges diagnosed')
 write(p,base);p.write_bytes(p.read_bytes()[:-1])
 try:validate(p)
 except ValueError:checks.append('truncated GLB')
 else:raise AssertionError('Truncation accepted')
print(json.dumps({'status':'PASS','checks':len(checks),'fixtures':checks,'scope':'Synthetic supported-subset parsing and diagnostics only; no native or visual acceptance'},indent=2))
