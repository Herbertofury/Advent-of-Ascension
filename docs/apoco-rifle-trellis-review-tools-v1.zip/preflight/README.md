# Static weapon GLB preflight

Original validation wrapper for generated static weapon references, before native export or Blender import. It does not replace a complete glTF validator, visual inspection or native acceptance.

Run `python preflight.py candidate.glb --out report.json`. Exit 2 means unsupported or invalid input; a valid GLB outside this subset can be rejected. In particular, a historical TripoSR export without explicit NORMAL attributes is unsupported here, not necessarily corrupt.

The supported subset is GLB 2 with one embedded buffer, indexed triangle primitives, explicit float POSITION/NORMAL attributes, optional normalized-atlas float TEXCOORD_0, embedded PNG/JPEG/WebP images and static scene nodes. Skins, animations, sparse accessors, required extensions, external buffers/images and morph targets need separate handling rather than silent omission.

Checks include file/chunk lengths, buffer-view bounds, accessor strides/alignment/count budgets, index bounds, finite attributes, normal magnitudes, image dimensions, texture/material references and node hierarchy structure. Near-zero-area triangles and unreviewed extra vertex attributes are surfaced as issues. Metrics are in mesh-local coordinates; transforms are structurally checked but not applied to measurements.

A checked-subset pass never means the model is beautiful, correctly rigged, physically separated into moving parts, comfortable in the hand, native-compatible or fast. All reports retain `native_accepted: false`. Normals, PBR material interpretation, UV overlaps, winding/topology, multi-view concept fidelity, animation and gameplay need their own checks.

Run `python test_preflight.py` for 41 synthetic valid/invalid fixtures. The tests exercise this original validator; they do not execute Minecraft or validate a generated mesh that does not yet exist.

Additional diagnostics count duplicate indexed triangles, indexed boundary/over-shared edges and collapsed UV triangles. Vertex splits at UV/material seams mean index-space boundaries are not a watertightness verdict. The default scene must contain instantiated mesh primitives; quaternions must be unit length and explicit scales noncollapsed. No test establishes absence of self-intersections.
