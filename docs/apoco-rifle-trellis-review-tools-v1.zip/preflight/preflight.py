"""Original strict GLB2 preflight for generated static weapon meshes.
This is a bounded supported-subset validator, not a universal glTF validator or native acceptance.
"""
import argparse,json,struct,hashlib,io,sys
from pathlib import Path
import numpy as np
from PIL import Image
DT={5121:np.dtype('u1'),5123:np.dtype('<u2'),5125:np.dtype('<u4'),5126:np.dtype('<f4')};NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}
def require(test,message):
 if not test:raise ValueError(message)
def integer(v,label):
 require(type(v)is int and v>=0,label+' must be a nonnegative integer');return v
def validate(path):
 path=Path(path);require(path.stat().st_size<=256*1024*1024,'GLB exceeds 256MiB preflight limit');raw=path.read_bytes();require(len(raw)>=20,'Truncated GLB header');magic,version,total=struct.unpack_from('<4sII',raw);require(magic==b'glTF'and version==2 and total==len(raw),'Invalid GLB header/version/length');chunks=[];offset=12
 while offset<len(raw):
  require(offset+8<=len(raw),'Truncated chunk header');length,kind=struct.unpack_from('<II',raw,offset);offset+=8;require(length%4==0 and offset+length<=len(raw),'Invalid chunk bounds/alignment');chunks.append((kind,raw[offset:offset+length]));offset+=length;require(len(chunks)<=16,'Too many chunks')
 require(len(chunks)==2 and [k for k,b in chunks]==[0x4E4F534A,0x004E4942],'Expected JSON then embedded BIN');g=json.loads(chunks[0][1]);binary=chunks[1][1];require(g.get('asset',{}).get('version')=='2.0','Unsupported glTF asset version');buffers=g.get('buffers',[]);require(len(buffers)==1 and 'uri'not in buffers[0],'External/multiple buffers unsupported');declared=integer(buffers[0].get('byteLength'),'buffer length');require(declared<=len(binary)<=declared+3,'BIN length mismatch');views=g.get('bufferViews',[])
 for view in views:
  require(view.get('buffer',0)==0,'Invalid buffer index');start=integer(view.get('byteOffset',0),'view offset');size=integer(view.get('byteLength'),'view size');require(start+size<=declared,'Buffer view exceeds declared data')
 def view_bytes(index):
  require(type(index)is int and 0<=index<len(views),'Invalid bufferView reference');v=views[index];start=v.get('byteOffset',0);return binary[start:start+v['byteLength']]
 def accessor(index,kind,types):
  aa=g.get('accessors',[]);require(type(index)is int and 0<=index<len(aa),'Invalid accessor reference');a=aa[index];require('sparse'not in a,'Sparse accessor unsupported; do not silently ignore it');require(a.get('type')==kind and a.get('componentType')in types,'Unexpected accessor layout');require(not a.get('normalized',False),'Normalized accessor unsupported in this export subset');count=integer(a.get('count'),'accessor count');require(count<=2_000_000,'Accessor budget exceeded');vi=a.get('bufferView');data=view_bytes(vi);view=views[vi];dt=DT[a['componentType']];width=NC[kind];tight=width*dt.itemsize;start=integer(a.get('byteOffset',0),'accessor offset');stride=integer(view.get('byteStride',tight),'accessor stride');require(stride>=tight and stride%dt.itemsize==0 and start%dt.itemsize==0,'Invalid accessor stride/alignment');need=start+(count-1)*stride+tight if count else start;require((view.get('byteOffset',0)+start)%dt.itemsize==0,'Misaligned absolute accessor offset');require(need<=len(data),'Accessor exceeds its bufferView');arr=np.ndarray((count,width),dtype=dt,buffer=data,offset=start,strides=(stride,dt.itemsize)).copy();require(np.isfinite(arr).all(),'Nonfinite accessor');return arr
 require(not g.get('extensionsRequired'),'Required glTF extensions need a dedicated gate');require(not g.get('animations'),'Animations need a separate evaluated animation gate')
 images=[]
 for item in g.get('images',[]):
  require('uri'not in item,'External/data-URI images unsupported; pack images explicitly');payload=view_bytes(item.get('bufferView'));require(len(payload)<=64*1024*1024,'Embedded image exceeds limit');require(item.get('mimeType')in ['image/png','image/jpeg','image/webp'],'Unsupported image format')
  with Image.open(io.BytesIO(payload))as im:
   require(im.width<=8192 and im.height<=8192,'Image dimension budget exceeded');size=list(im.size);im.verify()
  images.append({'mime':item['mimeType'],'size':size,'bytes':len(payload)})
 for tex in g.get('textures',[]):require(type(tex.get('source'))is int and 0<=tex['source']<len(images),'Invalid texture source')
 for material in g.get('materials',[]):
  pbr=material.get('pbrMetallicRoughness',{})
  for owner,key in [(pbr,'baseColorTexture'),(pbr,'metallicRoughnessTexture'),(material,'normalTexture'),(material,'emissiveTexture'),(material,'occlusionTexture')]:
   if key in owner:
    ref=owner[key];require(type(ref.get('index'))is int and 0<=ref['index']<len(g.get('textures',[])),'Invalid material texture reference');require(ref.get('texCoord',0)==0,'Only TEXCOORD_0 material binding supported')
  for owner,key,length in [(pbr,'baseColorFactor',4),(material,'emissiveFactor',3)]:
   if key in owner:require(isinstance(owner[key],list)and len(owner[key])==length and all(type(v)in (int,float)and np.isfinite(v)and 0<=v<=1 for v in owner[key]),'Invalid material color factor')
  for key in ['metallicFactor','roughnessFactor']:
   if key in pbr:require(type(pbr[key])in (int,float)and np.isfinite(pbr[key])and 0<=pbr[key]<=1,'Invalid PBR factor')
  require(material.get('alphaMode','OPAQUE')in ['OPAQUE','MASK','BLEND'],'Invalid alpha mode')
 issues=[];meshes=[];total_triangles=0
 for mi,mesh in enumerate(g.get('meshes',[])):
  for pi,primitive in enumerate(mesh.get('primitives',[])):
   require(primitive.get('mode',4)==4,'Only triangle primitives supported');require('targets'not in primitive,'Morph targets require separate handling');attrs=primitive.get('attributes',{});require(not any(k.startswith(('JOINTS_','WEIGHTS_'))for k in attrs),'Skinning requires a separate rig gate');require('POSITION'in attrs and 'NORMAL'in attrs,'This static preflight requires explicit POSITION and NORMAL attributes');require('indices'in primitive,'This static preflight requires indexed triangles');extra=set(attrs)-{'POSITION','NORMAL','TEXCOORD_0'}
   if extra:issues.append({'mesh':mi,'primitive':pi,'issue':'Unreviewed vertex attributes','attributes':sorted(extra)})
   pos=accessor(attrs.get('POSITION'),'VEC3',{5126});norm=accessor(attrs.get('NORMAL'),'VEC3',{5126});require(len(pos)==len(norm),'Normal count mismatch');indices=accessor(primitive.get('indices'),'SCALAR',{5121,5123,5125}).reshape(-1);require(len(indices)%3==0 and len(indices)>0,'Invalid triangle index count');require(int(indices.max())<len(pos),'Triangle index exceeds positions');uv=None
   if 'TEXCOORD_0'in attrs:
    uv=accessor(attrs['TEXCOORD_0'],'VEC2',{5126});require(len(uv)==len(pos),'UV count mismatch');require(float(uv.min())>=-1e-6 and float(uv.max())<=1+1e-6,'UV outside supported normalized atlas range')
   elif images:issues.append({'mesh':mi,'primitive':pi,'issue':'Textured asset has no TEXCOORD_0'})
   lengths=np.linalg.norm(norm.astype(float),axis=1);require(np.all((lengths>.5)&(lengths<1.5)),'Invalid normal magnitude');tris=pos[indices.reshape(-1,3)].astype(float);area2=np.linalg.norm(np.cross(tris[:,1]-tris[:,0],tris[:,2]-tris[:,0]),axis=1);deg=int((area2<=1e-10).sum());total_triangles+=len(tris);require(total_triangles<=2_000_000,'Triangle budget exceeded')
   if deg:issues.append({'mesh':mi,'primitive':pi,'issue':'Degenerate or near-zero-area triangles','count':deg})
   tri_ids=indices.reshape(-1,3);canonical=np.sort(tri_ids,axis=1);duplicate_triangles=len(canonical)-len(np.unique(canonical,axis=0))
   edges=np.sort(np.concatenate([tri_ids[:,[0,1]],tri_ids[:,[1,2]],tri_ids[:,[2,0]]]),axis=1);unique_edges,edge_counts=np.unique(edges,axis=0,return_counts=True)
   topology={'duplicate_index_triangles':int(duplicate_triangles),'indexed_boundary_edges':int((edge_counts==1).sum()),'indexed_nonmanifold_edges':int((edge_counts>2).sum()),'boundary':'Index-space diagnostic; UV/material splits can duplicate geometric vertices. Does not prove watertightness or self-intersection freedom.'}
   if duplicate_triangles:issues.append({'mesh':mi,'primitive':pi,'issue':'Duplicate indexed triangles','count':int(duplicate_triangles)})
   if np.any(edge_counts>2):issues.append({'mesh':mi,'primitive':pi,'issue':'Indexed edges shared by more than two faces','count':int((edge_counts>2).sum())})
   uv_collapsed=None
   if uv is not None:
    ut=uv[tri_ids].astype(float);ua=ut[:,1]-ut[:,0];ub=ut[:,2]-ut[:,0];uv_collapsed=int((np.abs(ua[:,0]*ub[:,1]-ua[:,1]*ub[:,0])<=1e-12).sum())
    if uv_collapsed:issues.append({'mesh':mi,'primitive':pi,'issue':'Collapsed or near-zero UV triangles','count':uv_collapsed})
   material=primitive.get('material');require(material is None or(type(material)is int and 0<=material<len(g.get('materials',[]))),'Invalid material index');meshes.append({'mesh':mi,'primitive':pi,'vertices':len(pos),'topology':topology,'collapsed_uv_triangles':uv_collapsed,'triangles':len(tris),'degenerate_triangles':deg,'normal_unit_error_max':float(np.abs(lengths-1).max()),'bounds':[pos.min(axis=0).tolist(),pos.max(axis=0).tolist()],'material':material})
 require(meshes,'No supported mesh primitives');require(not g.get('skins'),'Skins require separate evaluation');nodes=g.get('nodes',[]);require(len(nodes)<=4096,'Node budget exceeded');parents={}
 for i,n in enumerate(nodes):
  if 'mesh'in n:require(type(n['mesh'])is int and 0<=n['mesh']<len(g.get('meshes',[])),'Invalid node mesh')
  for child in n.get('children',[]):
   require(type(child)is int and 0<=child<len(nodes),'Invalid child node');require(child not in parents,'Node has multiple parents or duplicate edges');parents[child]=i
  require(not('matrix'in n and any(k in n for k in ['translation','rotation','scale'])),'Node mixes matrix and TRS')
  for key,length in [('matrix',16),('translation',3),('rotation',4),('scale',3)]:
   if key in n:require(len(n[key])==length and all(type(v)in (int,float)and np.isfinite(v)for v in n[key]),'Invalid node transform')
  if 'rotation'in n:require(abs(sum(float(v)**2 for v in n['rotation'])-1)<1e-4,'Non-unit rotation quaternion')
  if 'scale'in n:require(all(abs(v)>1e-12 for v in n['scale']),'Collapsed node scale unsupported')
 def visit(i,stack):
  require(i not in stack,'Node hierarchy cycle');require(len(stack)<256,'Node hierarchy too deep')
  for child in nodes[i].get('children',[]):visit(child,stack|{i})
 for i in range(len(nodes)):visit(i,set())
 scenes=g.get('scenes',[]);require(scenes,'No scene declared');require(type(g.get('scene',0))is int and 0<=g.get('scene',0)<len(scenes),'Invalid default scene')
 for scene in scenes:
  for root in scene.get('nodes',[]):require(type(root)is int and 0<=root<len(nodes)and root not in parents,'Invalid scene root')
 reachable=set()
 def collect(i):
  reachable.add(i)
  for child in nodes[i].get('children',[]):collect(child)
 for root in scenes[g.get('scene',0)].get('nodes',[]):collect(root)
 require(any('mesh'in nodes[i] and g['meshes'][nodes[i]['mesh']].get('primitives')for i in reachable),'Default scene contains no mesh primitives')
 return {'default_scene_reachable_nodes':len(reachable),'file_sha256':hashlib.sha256(raw).hexdigest(),'checked_subset_pass':True,'issues':issues,'triangles':total_triangles,'meshes':meshes,'images':images,'animations':len(g.get('animations',[])),'double_sided_materials':sum(bool(x.get('doubleSided'))for x in g.get('materials',[])),'native_accepted':False,'limits':['Static supported-subset preflight only','Node transforms are validated structurally, not applied to geometry metrics','No moving-part ownership, hand fit, visual fidelity, topology, native material or gameplay acceptance']}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('file');p.add_argument('--out');a=p.parse_args();code=0
 try:result=validate(a.file)
 except Exception as error:result={'checked_subset_pass':False,'unsupported_or_invalid':str(error),'error_type':type(error).__name__,'native_accepted':False};code=2
 text=json.dumps(result,indent=2)+'\n'
 if a.out:Path(a.out).write_text(text)
 else:print(text)
 raise SystemExit(code)
