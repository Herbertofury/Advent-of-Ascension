"""Non-destructive concept-projection diagnostic, not a production texture bake.
Uses the authored reference camera to align source concept colors. Original generated atlas retained.
"""
import bpy,sys,argparse,json
from pathlib import Path
from mathutils import Vector
from PIL import Image
p=argparse.ArgumentParser();p.add_argument('--scene',required=True);p.add_argument('--concept',required=True);p.add_argument('--out',required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);out=Path(a.out);out.mkdir(exist_ok=True,parents=True);bpy.ops.wm.open_mainfile(filepath=a.scene)
s=bpy.context.scene;obs=[o for o in s.objects if o.type=='MESH'];points=[o.matrix_world@v.co for o in obs for v in o.data.vertices];lo=Vector(tuple(min(v[i]for v in points)for i in range(3)));hi=Vector(tuple(max(v[i]for v in points)for i in range(3)));center=(lo+hi)/2;size=max(hi-lo)
cam=s.camera;cam.location=center+Vector((0,2,.08))*size*2;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();rotation=cam.rotation_euler.to_matrix();right=rotation@Vector((1,0,0));up=rotation@Vector((0,1,0));xs=[(v-center).dot(right)for v in points];ys=[(v-center).dot(up)for v in points];xmin,xmax=min(xs),max(xs);ymin,ymax=min(ys),max(ys)
im=Image.open(a.concept).convert('RGBA');bbox=im.getchannel('A').point(lambda v:255 if v>16 else 0).getbbox();w,h=im.size;image=bpy.data.images.load(a.concept,check_existing=True)
for o in obs:
 uv=o.data.uv_layers.new(name='ConceptProjectionDiagnostic')
 for loop in o.data.loops:
  v=o.matrix_world@o.data.vertices[loop.vertex_index].co;u=((v-center).dot(right)-xmin)/(xmax-xmin);t=((v-center).dot(up)-ymin)/(ymax-ymin);uv.data[loop.index].uv=((bbox[0]+u*(bbox[2]-bbox[0]))/w,1-(bbox[3]-t*(bbox[3]-bbox[1]))/h)
 for idx,old in enumerate(o.data.materials):
  m=old.copy();m.name=old.name+' Concept projection diagnostic';o.data.materials[idx]=m;n=m.node_tree.nodes;l=m.node_tree.links;bs=next(x for x in n if x.type=='BSDF_PRINCIPLED');original=bs.inputs['Base Color'].links[0].from_socket
  coord=n.new('ShaderNodeUVMap');coord.uv_map=uv.name;tex=n.new('ShaderNodeTexImage');tex.image=image;tex.extension='EXTEND';l.new(coord.outputs['UV'],tex.inputs['Vector'])
  geometry=n.new('ShaderNodeNewGeometry');dot=n.new('ShaderNodeVectorMath');dot.operation='DOT_PRODUCT';dot.inputs[1].default_value=(0,1,0);l.new(geometry.outputs['Normal'],dot.inputs[0]);absolute=n.new('ShaderNodeMath');absolute.operation='ABSOLUTE';l.new(dot.outputs['Value'],absolute.inputs[0]);ramp=n.new('ShaderNodeMapRange');ramp.clamp=True;ramp.inputs['From Min'].default_value=.25;ramp.inputs['From Max'].default_value=.75;l.new(absolute.outputs[0],ramp.inputs['Value']);mask=n.new('ShaderNodeMath');mask.operation='MULTIPLY';l.new(ramp.outputs[0],mask.inputs[0]);l.new(tex.outputs['Alpha'],mask.inputs[1]);mix=n.new('ShaderNodeMixRGB');l.new(mask.outputs[0],mix.inputs[0]);l.new(original,mix.inputs[1]);l.new(tex.outputs['Color'],mix.inputs[2]);l.new(mix.outputs[0],bs.inputs['Base Color'])
  bs.inputs['Metallic'].default_value=.2
  for link in list(bs.inputs['Metallic'].links):l.remove(link)
  bs.inputs['Roughness'].default_value=.43
  for link in list(bs.inputs['Roughness'].links):l.remove(link)
  sep=n.new('ShaderNodeSeparateColor');l.new(tex.outputs['Color'],sep.inputs[0]);difference=n.new('ShaderNodeMath');difference.operation='SUBTRACT';l.new(sep.outputs['Green'],difference.inputs[0]);l.new(sep.outputs['Red'],difference.inputs[1]);threshold=n.new('ShaderNodeMath');threshold.operation='GREATER_THAN';threshold.inputs[1].default_value=.12;l.new(difference.outputs[0],threshold.inputs[0]);strength=n.new('ShaderNodeMath');strength.operation='MULTIPLY';l.new(threshold.outputs[0],strength.inputs[0]);l.new(mask.outputs[0],strength.inputs[1]);l.new(tex.outputs['Color'],bs.inputs['Emission Color']);l.new(strength.outputs[0],bs.inputs['Emission Strength'])
bounds=[Vector((x,y,z))for x in[lo.x,hi.x]for y in[lo.y,hi.y]for z in[lo.z,hi.z]]
for name,offset in [('reference_side',(0,2,.08)),('reference_oblique',(-1,2,.6)),('opposite_side',(0,-2,.08))]:
 cam.location=center+Vector(offset)*size*2;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();rot=cam.rotation_euler.to_matrix();r=rot@Vector((1,0,0));u=rot@Vector((0,1,0));xx=[(v-center).dot(r)for v in bounds];yy=[(v-center).dot(u)for v in bounds];cam.data.ortho_scale=max(max(xx)-min(xx),(max(yy)-min(yy))*s.render.resolution_x/s.render.resolution_y)*1.15;s.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(out/'concept-projection-diagnostic.blend'));(out/'receipt.json').write_text(json.dumps({'scope':'Concept color projection diagnostic; no new native implementation','limitations':['Baked concept lighting','Projection stretch and alignment mismatch','Mirrored opposite-side art not verified reference','Not final UV/PBR texturing','Original fused topology unchanged'],'native_accepted':False},indent=2)+'\n')
