import pathlib,json,subprocess,resource,time,datetime
R=pathlib.Path(__file__).resolve().parent;out=R/'apoco-trial';cmd=['stdbuf','-oL','-eL',str(R/'build/trellis-cli'),str(R/'apoco-rifle-input.png'),str(out/'apoco-rifle-reference.glb'),'--models',str(R/'models-q8-512'),'--gpu','-1','--backend','CPU','--threads','4','--res','512','--steps','12','--faces','60000','--atlas','2048','--webp','off','--dump-bg','--verbose']
def limits():resource.setrlimit(resource.RLIMIT_AS,(7_000_000*1024,7_000_000*1024))
start=time.monotonic()
with (out/'run.log').open('w')as f:
 result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,preexec_fn=limits)
r=resource.getrusage(resource.RUSAGE_CHILDREN);(out/'process-receipt.json').write_text(json.dumps({'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'max_rss_kib':r.ru_maxrss,'command':cmd,'native_acceptance':False},indent=2)+'\n');print('Trial exit',result.returncode,flush=True);raise SystemExit(result.returncode)
