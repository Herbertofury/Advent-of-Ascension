# Source and editable-art review bundle

This contains original study 0.0.8 code and the current v31 detailed atlas and v32 world-fit palette candidates. It is not an installable gunpack or accepted final artwork. No dependency JARs, runtime logs, player data or worlds are included.

Use Java17 and Gradle8.8 with the Forge MDK project in dev. Place your separately obtained, license-compliant reference archives in a references directory alongside dev: AoA3-1.20.1-3.7.1-all.jar, geckolib-forge-1.20.1-4.3.jar, tacz-1.20.1-1.1.8-hotfix2.jar and tacz-mesh-loader-forge-1.20.1-0.1.8.jar. Dependency resolution requires initial network preparation before offline use. The package removes the author's machine-specific Java path and points the flat dependency directory at this documented location.

The tested code was built in the isolated development workspace. Both treatments and the corrected v32 palette were verified in the combined AoA + TaCZ client. F9 selects the session-local texture treatment; geometry is shared and neither style is final art. This exact portable archive has not been independently rebuilt on another machine.

The authoring folder includes the editable original v29 geometry and the v31 baked-atlas Blender file. The bake script uses the included sibling geometry and original generated gold swatch and emits an atlas/static geometry review. It is not an automatic native hand-rig assembler. Do not replace native rig resources with the static-only export.

For standalone tests, set JAVA_HOME to a Java17 installation and GSON_JAR to a local Gson2.10 JAR, then run run_unit_checks.py. Run the Python audit tests with python3 -m unittest discover -s tests. These do not substitute for native acceptance.
