package io.github.herbertofury.shyrestudy;

import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

/**
 * Pinned return-value observer with opt-in audit and owner-only cosmetic notification.
 * No inventory writes or changes to the original method result.
 */
@Mod.EventBusSubscriber(modid = ShyreStudy.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ShyreFireReturnAudit {
    private static final Logger LOG = LogUtils.getLogger();
    private static final boolean ENABLED = Boolean.getBoolean("shyre.study.audit");
    private static long observationSequence;

    public static void observe(ServerLevel level, LivingEntity shooter, ItemStack stack,
                               InteractionHand hand, boolean result) {
        if (!"aoa3:shyre_blaster".equals(BuiltInRegistries.ITEM.getKey(stack.getItem()).toString()))
            return;
        // Do not silently generalize this pinned study to another AoA version.
        boolean pinned = ModList.get().getModContainerById("aoa3")
            .map(mod -> "3.7.1".equals(mod.getModInfo().getVersion().toString())).orElse(false);
        if (!pinned) return;
        // The original return is observed, not replaced. This is not proof of final world insertion.
        if (result && hand == InteractionHand.MAIN_HAND && shooter instanceof ServerPlayer player
                && player.getMainHandItem() == stack) {
            try { ShyreShotCosmetics.send(player); }
            catch (RuntimeException | LinkageError failure) {
                LOG.error("Shyre cosmetic notification failed; original firing return remains untouched", failure);
            }
        }
        if (!ENABLED) return;
        LOG.info("SHYRE_AUDIT fire_return observation={} tick={} shooter={} hand={} result={} damage_at_return={} dimension={}",
            ++observationSequence, level.getGameTime(), shooter.getId(), hand, result,
            stack.getDamageValue(), level.dimension().location());
    }

    @SubscribeEvent
    public static void stop(ServerStoppedEvent event) { observationSequence = 0; ShyreShotCosmetics.clear(); }
}
