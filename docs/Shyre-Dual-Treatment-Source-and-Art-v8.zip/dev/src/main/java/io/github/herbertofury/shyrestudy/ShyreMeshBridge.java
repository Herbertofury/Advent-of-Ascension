package io.github.herbertofury.shyrestudy;

import com.example.taczmeshloader.api.IPolyMeshBone;
import com.example.taczmeshloader.core.PolyMeshModel;
import com.google.gson.JsonObject;
import com.mojang.blaze3d.vertex.PoseStack;
import com.tacz.guns.client.model.BedrockAnimatedModel;
import com.tacz.guns.client.model.bedrock.BedrockPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.resources.ResourceLocation;
import java.util.List;

/** Original bridge: preserve native TaCZ transforms while drawing original polygon geometry. */
final class ShyreMeshBridge implements AutoCloseable {
    private final PolyMeshModel mesh;

    ShyreMeshBridge(BedrockAnimatedModel model, JsonObject geometry) {
        mesh = new PolyMeshModel(new Node(null, model.getShouldRender()), geometry);
        if (!mesh.hasMeshInSubtree("shyre_static_body")) {
            mesh.close();
            throw new IllegalArgumentException("Original Shyre polygon body was not loaded");
        }
    }

    void render(PoseStack pose, MultiBufferSource buffers, ResourceLocation texture, int light, int overlay) {
        // Consumer path first. VBO performance and shader compatibility need separate acceptance.
        mesh.renderCutoutOnly(pose, buffers, texture, light, overlay, false);
    }

    @Override public void close() { mesh.close(); }

    private static final class Node implements IPolyMeshBone {
        private final BedrockPart part;
        private final List<Node> children;

        Node(BedrockPart part, List<BedrockPart> children) {
            this.part = part;
            this.children = children.stream().map(child -> new Node(child, child.children)).toList();
        }
        @Override public String getName() { return part == null ? "shyre_render_root" : part.name; }
        @Override public float getPivotX() { return part == null ? 0 : part.x; }
        @Override public float getPivotY() { return part == null ? 0 : part.y; }
        @Override public float getPivotZ() { return part == null ? 0 : part.z; }
        @Override public float getRotX() { return part == null ? 0 : part.xRot; }
        @Override public float getRotY() { return part == null ? 0 : part.yRot; }
        @Override public float getRotZ() { return part == null ? 0 : part.zRot; }
        @Override public float getScaleX() { return part == null ? 1 : part.xScale; }
        @Override public float getScaleY() { return part == null ? 1 : part.yScale; }
        @Override public float getScaleZ() { return part == null ? 1 : part.zScale; }
        @Override public boolean isVisible() { return part == null || part.visible; }
        @Override public boolean isIlluminated() { return part != null && part.illuminated; }
        @Override public List<Node> getChildren() { return children; }
        @Override public void applyTransform(PoseStack pose) {
            if (part != null) part.translateAndRotateAndScale(pose);
        }
    }
}
