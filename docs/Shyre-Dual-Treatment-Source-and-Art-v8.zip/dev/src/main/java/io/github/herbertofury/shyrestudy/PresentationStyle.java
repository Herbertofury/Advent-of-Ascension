package io.github.herbertofury.shyrestudy;

/** Cosmetic atlas choice only. No item, server, resource-consumption or damage state. */
public enum PresentationStyle {
    CONCEPT_STUDY("textures/shyre_basecolor.png", "style.shyre_study.concept"),
    WORLD_FIT_STUDY("textures/shyre_world_fit.png", "style.shyre_study.world_fit");
    private final String texturePath;
    private final String translationKey;
    PresentationStyle(String texturePath, String translationKey) {
        this.texturePath = texturePath;
        this.translationKey = translationKey;
    }
    public String texturePath() { return texturePath; }
    public String translationKey() { return translationKey; }
    public PresentationStyle next() { return this == CONCEPT_STUDY ? WORLD_FIT_STUDY : CONCEPT_STUDY; }
}
