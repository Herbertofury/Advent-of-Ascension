package io.github.herbertofury.shyrestudy;

import java.util.Objects;

/** Pure diagnostic-preview ownership state. It never alters items or gameplay. */
final class PreviewLifecycle {
    private Object world;
    private int slot = -1;
    private String item = "";
    private boolean active;

    boolean update(boolean eligible, Object nextWorld, int nextSlot, String nextItem) {
        boolean changed = active && (!eligible || world != nextWorld || slot != nextSlot
            || !Objects.equals(item, nextItem));
        active = eligible;
        world = nextWorld;
        slot = nextSlot;
        item = nextItem;
        return changed;
    }

    void clear() {
        active = false;
        world = null;
        slot = -1;
        item = "";
    }
}
