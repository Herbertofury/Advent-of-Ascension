package io.github.herbertofury.shyrestudy;

/** Cosmetic-only replay/freshness guard. It never grants a shot or changes inventory. */
public final class ShotSignalGate {
    private long latest;
    public boolean accept(long sequence, long shotTick, long clientTick, boolean eligible) {
        if (sequence <= latest || sequence <= 0 || shotTick < 0 || clientTick < 0) return false;
        latest = sequence; // Ineligible events cannot be replayed after a later equip.
        long age = clientTick - shotTick;
        return eligible && age >= -10 && age <= 200;
    }
    public void clear() { latest = 0; }
}
