package io.github.herbertofury.shyrestudy.mixin;

import io.github.herbertofury.shyrestudy.ShyreFireReturnAudit;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Observes the pinned inherited method's result without altering it. */
@Pseudo
@Mixin(targets = "net.tslat.aoa3.content.item.weapon.gun.BaseGun", remap = false)
public abstract class ShyreFireReturnMixin {
    @Inject(method = "fireGun(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/InteractionHand;)Z",
        at = @At("RETURN"), require = 1, remap = false)
    private void shyreStudy$observeReturn(ServerLevel level, LivingEntity shooter, ItemStack stack,
                                         InteractionHand hand, CallbackInfoReturnable<Boolean> result) {
        ShyreFireReturnAudit.observe(level, shooter, stack, hand, result.getReturnValueZ());
    }
}
