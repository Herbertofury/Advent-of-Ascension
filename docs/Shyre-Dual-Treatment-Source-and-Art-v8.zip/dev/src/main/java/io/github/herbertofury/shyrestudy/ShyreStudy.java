package io.github.herbertofury.shyrestudy;

import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Original diagnostic item. No ammo, projectile, damage, recipe or authoritative firing implementation. */
@Mod(ShyreStudy.MOD_ID)
public final class ShyreStudy {
    public static final String MOD_ID = "shyre_study";
    private static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final RegistryObject<Item> PREVIEW = ITEMS.register("visual_probe", () -> new Item(new Item.Properties().stacksTo(1)));

    public ShyreStudy() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        ShyreShotCosmetics.register();
    }
}
