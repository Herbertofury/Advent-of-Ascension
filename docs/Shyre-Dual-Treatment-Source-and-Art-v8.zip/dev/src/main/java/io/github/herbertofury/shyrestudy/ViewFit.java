package io.github.herbertofury.shyrestudy;

import com.google.gson.JsonObject;

/** Bounded resource-only presentation transform. */
record ViewFit(double x, double y, double z, float scale, float pitch, float yaw, float roll) {
    static ViewFit parse(JsonObject value) {
        var translation = value.getAsJsonArray("translation");
        var rotation = value.getAsJsonArray("rotation_degrees");
        if (translation.size() != 3 || rotation.size() != 3) throw new IllegalArgumentException("Expected three view components");
        double[] t = new double[3];
        float[] r = new float[3];
        for (int i = 0; i < 3; i++) {
            t[i] = translation.get(i).getAsDouble();
            r[i] = rotation.get(i).getAsFloat();
            if (!Double.isFinite(t[i]) || Math.abs(t[i]) > 8 || !Float.isFinite(r[i]) || Math.abs(r[i]) > 360)
                throw new IllegalArgumentException("Invalid view transform");
        }
        float scale = value.get("scale").getAsFloat();
        if (!Float.isFinite(scale) || scale < 0.05 || scale > 4) throw new IllegalArgumentException("Invalid view scale");
        return new ViewFit(t[0], t[1], t[2], scale, r[0], r[1], r[2]);
    }
}
