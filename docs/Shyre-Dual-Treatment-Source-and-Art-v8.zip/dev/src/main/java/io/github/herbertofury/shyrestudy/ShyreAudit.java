package io.github.herbertofury.shyrestudy;

import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Opt-in read-only native QA instrumentation, enabled by -Dshyre.study.audit=true.
 * No packets, inventory edits, damage changes, event cancellation or firing hooks.
 * A projectile observation is not proof of a successful weapon-use return.
 */
@Mod.EventBusSubscriber(modid = ShyreStudy.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ShyreAudit {
    private static final Logger LOG = LogUtils.getLogger();
    private static final boolean ENABLED = Boolean.getBoolean("shyre.study.audit");
    private static final Map<UUID, String> LAST = new HashMap<>();
    private static String key(ItemStack stack) {
        return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
    }
    private static boolean isShyre(ItemStack stack) { return "aoa3:shyre_blaster".equals(key(stack)); }
    private static boolean holdsShyre(ServerPlayer player) {
        return isShyre(player.getMainHandItem()) || isShyre(player.getOffhandItem());
    }
    private static String stack(ItemStack stack) {
        return key(stack) + ":count=" + stack.getCount() + ":damage=" + stack.getDamageValue();
    }
    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent event) {
        if (!ENABLED || event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;
        if (!holdsShyre(player)) { LAST.remove(player.getUUID()); return; }
        int ammo = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack item = player.getInventory().getItem(i);
            if ("aoa3:cannonball".equals(key(item))) ammo += item.getCount();
        }
        String snapshot = "slot=" + player.getInventory().selected + " main=" + stack(player.getMainHandItem())
            + " off=" + stack(player.getOffhandItem()) + " cannonballs=" + ammo + " creative=" + player.isCreative();
        if (!snapshot.equals(LAST.put(player.getUUID(), snapshot))) {
            LOG.info("SHYRE_AUDIT inventory tick={} player={} {}", player.level().getGameTime(), player.getId(), snapshot);
        }
    }
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void projectile(EntityJoinLevelEvent event) {
        if (!ENABLED || event.getLevel().isClientSide()
                || !(event.getEntity() instanceof Projectile projectile)
                || !(projectile.getOwner() instanceof ServerPlayer player) || !holdsShyre(player)) return;
        LOG.info("SHYRE_AUDIT projectile_join tick={} owner={} entity={} type={} main={} off={} loaded_from_disk={}",
            event.getLevel().getGameTime(), player.getId(), projectile.getId(),
            BuiltInRegistries.ENTITY_TYPE.getKey(projectile.getType()), stack(player.getMainHandItem()),
            stack(player.getOffhandItem()), event.loadedFromDisk());
    }
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void damage(LivingDamageEvent event) {
        if (!ENABLED || event.getEntity().level().isClientSide()
                || !(event.getSource().getEntity() instanceof ServerPlayer player) || !holdsShyre(player)) return;
        LOG.info("SHYRE_AUDIT damage_event tick={} attacker={} target={} amount={} direct_type={}",
            player.level().getGameTime(), player.getId(), event.getEntity().getId(), event.getAmount(),
            event.getSource().getDirectEntity() == null ? "none"
                : BuiltInRegistries.ENTITY_TYPE.getKey(event.getSource().getDirectEntity().getType()));
    }
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent event) { LAST.remove(event.getEntity().getUUID()); }
    @SubscribeEvent public static void stop(ServerStoppedEvent event) { LAST.clear(); }
}
