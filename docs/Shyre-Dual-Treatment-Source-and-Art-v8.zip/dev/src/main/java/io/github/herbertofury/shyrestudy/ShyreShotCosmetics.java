package io.github.herbertofury.shyrestudy;

import java.util.UUID;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** Server-to-owning-client cosmetics only. No client request or gameplay writes. */
public final class ShyreShotCosmetics {
    private static final String PROTOCOL = "1";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(ShyreStudy.MOD_ID, "shot_cosmetics"), () -> PROTOCOL,
        PROTOCOL::equals, PROTOCOL::equals);
    private static long sequence;
    public record Shot(UUID player, ResourceLocation dimension, int slot, long tick, long sequence) {}
    public static void register() {
        CHANNEL.messageBuilder(Shot.class, 0, NetworkDirection.PLAY_TO_CLIENT)
            .encoder((shot, buffer) -> {
                buffer.writeUUID(shot.player()); buffer.writeResourceLocation(shot.dimension());
                buffer.writeVarInt(shot.slot()); buffer.writeLong(shot.tick()); buffer.writeLong(shot.sequence());
            })
            .decoder(buffer -> new Shot(buffer.readUUID(), buffer.readResourceLocation(),
                buffer.readVarInt(), buffer.readLong(), buffer.readLong()))
            .consumerMainThread((shot, context) -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ShyreVisualClient.confirmedShot(shot)))
            .add();
    }
    public static void send(ServerPlayer player) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new Shot(player.getUUID(),
            player.level().dimension().location(), player.getInventory().selected,
            player.level().getGameTime(), ++sequence));
    }
    public static void clear() { sequence = 0; }
}
