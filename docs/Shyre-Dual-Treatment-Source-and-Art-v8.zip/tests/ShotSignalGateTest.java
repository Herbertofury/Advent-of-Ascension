package io.github.herbertofury.shyrestudy;
public final class ShotSignalGateTest {
    private static int checks;
    private static void check(boolean actual, boolean expected) { checks++; if (actual != expected) throw new AssertionError("case " + checks); }
    public static void main(String[] args) {
        ShotSignalGate g=new ShotSignalGate();
        check(g.accept(0,100,100,true),false);
        check(g.accept(1,100,100,true),true);
        check(g.accept(1,100,100,true),false);
        check(g.accept(2,100,100,false),false);
        check(g.accept(2,100,100,true),false);
        check(g.accept(3,100,301,true),false);
        check(g.accept(4,100,300,true),true);
        check(g.accept(5,110,100,true),true);
        check(g.accept(6,111,100,true),false);
        check(g.accept(7,-1,100,true),false);
        check(g.accept(7,100,-1,true),false);
        check(g.accept(7,100,100,true),true);
        check(g.accept(6,100,100,true),false);
        g.clear();check(g.accept(1,200,200,true),true);
        check(g.accept(Long.MAX_VALUE,200,200,true),true);
        check(g.accept(Long.MIN_VALUE,200,200,true),false);
        System.out.println("PASS: "+checks+" cosmetic signal checks");
    }
}
