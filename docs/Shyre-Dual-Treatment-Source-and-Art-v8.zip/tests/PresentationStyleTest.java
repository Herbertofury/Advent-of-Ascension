package io.github.herbertofury.shyrestudy;
public final class PresentationStyleTest {
 public static void main(String[] args) {
  if(PresentationStyle.values().length!=2)throw new AssertionError("Two explicit cosmetic studies");
  for(PresentationStyle s:PresentationStyle.values()) {
   if(s.next()==s || s.next().next()!=s)throw new AssertionError("Exact reversible cycle");
   if(!s.texturePath().startsWith("textures/") || !s.texturePath().endsWith(".png") || s.texturePath().contains(".."))throw new AssertionError("Bounded atlas path");
   if(s.texturePath().equals(s.next().texturePath()) || s.translationKey().equals(s.next().translationKey()))throw new AssertionError("Distinct treatment and label");
  }
  System.out.println("PASS PresentationStyle: two distinct reversible local-only choices; native visual acceptance remains open");
 }
}
