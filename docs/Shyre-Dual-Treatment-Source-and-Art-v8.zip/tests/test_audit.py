import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from analyze_audit import analyze
F='[Server thread/INFO] SHYRE_AUDIT fire_return observation=1 tick=50 shooter=7 hand=MAIN_HAND result=true damage_at_return=1 dimension=minecraft:overworld'
J='SHYRE_AUDIT projectile_join tick=50 owner=7 entity=9 type=aoa3:cannonball main=aoa3:shyre_blaster:count=1:damage=0 off=minecraft:air:count=0:damage=0 loaded_from_disk=false'
class AuditTests(unittest.TestCase):
 def test_empty_is_not_pass(self):
  d=analyze('Minecraft started');self.assertFalse(d['has_actual_fire_return_evidence']);self.assertFalse(d['native_weapon_accepted'])
 def test_original_return_with_no_projectile(self):
  d=analyze(F);self.assertTrue(d['has_actual_fire_return_evidence']);self.assertEqual(d['return_correlations'][0]['same_tick_owner_projectile_candidates'],[])
 def test_same_tick_candidate_not_proof(self):
  d=analyze(J+'\n'+F);c=d['return_correlations'][0];self.assertEqual(len(c['same_tick_owner_projectile_candidates']),1);self.assertFalse(c['exact_shot_identity_proven'])
 def test_loaded_projectile_excluded(self):
  d=analyze(J.replace('disk=false','disk=true')+'\n'+F);self.assertEqual(d['return_correlations'][0]['same_tick_owner_projectile_candidates'],[])
 def test_other_owner_excluded(self):
  d=analyze(J.replace('owner=7','owner=8')+'\n'+F);self.assertEqual(d['return_correlations'][0]['same_tick_owner_projectile_candidates'],[])
 def test_missing_fields_rejected(self):self.assertTrue(analyze('SHYRE_AUDIT fire_return tick=0')['parse_errors'])
 def test_duplicate_field_rejected(self):self.assertTrue(analyze(F+' tick=51')['parse_errors'])
 def test_invalid_boolean_rejected(self):self.assertTrue(analyze(F.replace('true','yes'))['parse_errors'])
 def test_false_return_retained(self):self.assertEqual(analyze(F.replace('true','false'))['return_correlations'][0]['return_value'],'false')
 def test_ambiguous_two_projectiles_retained(self):
  d=analyze(J+'\n'+J.replace('entity=9','entity=10')+'\n'+F);self.assertEqual(len(d['return_correlations'][0]['same_tick_owner_projectile_candidates']),2)
if __name__=='__main__':unittest.main()
