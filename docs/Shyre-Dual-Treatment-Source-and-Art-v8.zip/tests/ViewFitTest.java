package io.github.herbertofury.shyrestudy;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public final class ViewFitTest {
    private static int checks;
    private static JsonObject json(String value) {
        return JsonParser.parseString(value).getAsJsonObject();
    }
    private static void reject(String value) {
        checks++;
        try {
            ViewFit.parse(json(value));
        } catch (RuntimeException expected) {
            return;
        }
        throw new AssertionError("Accepted invalid transform: " + value);
    }
    public static void main(String[] args) {
        ViewFit fit = ViewFit.parse(json("{\"translation\":[0.25,0.7,-1.1],\"rotation_degrees\":[0,-18,180],\"scale\":0.6}"));
        checks++;
        if (fit.x() != 0.25 || fit.roll() != 180 || fit.yaw() != -18 || fit.scale() != 0.6f)
            throw new AssertionError("Transform order changed");
        for (String value : new String[]{"0","-1","4.01","0.049","\"NaN\"","\"Infinity\""}) {
            reject("{\"translation\":[0,0,0],\"rotation_degrees\":[0,0,0],\"scale\":" + value + "}");
        }
        for (String values : new String[]{"[]","[0,0]","[0,0,0,0]","[9,0,0]","[0,\"NaN\",0]","[0,0,\"Infinity\"]"}) {
            reject("{\"translation\":" + values + ",\"rotation_degrees\":[0,0,0],\"scale\":1}");
        }
        for (String values : new String[]{"[]","[0,0]","[0,0,361]","[0,\"NaN\",0]","[0,0,\"Infinity\"]"}) {
            reject("{\"translation\":[0,0,0],\"rotation_degrees\":" + values + ",\"scale\":1}");
        }
        reject("{}");
        reject("{\"translation\":null,\"rotation_degrees\":[0,0,0],\"scale\":1}");
        ViewFit.parse(json("{\"translation\":[-8,8,0],\"rotation_degrees\":[-360,360,0],\"scale\":0.05}"));
        checks++;
        ViewFit.parse(json("{\"translation\":[0,0,0],\"rotation_degrees\":[0,0,0],\"scale\":4}"));
        checks++;
        System.out.println("PASS: " + checks + " view-transform checks");
    }
}
