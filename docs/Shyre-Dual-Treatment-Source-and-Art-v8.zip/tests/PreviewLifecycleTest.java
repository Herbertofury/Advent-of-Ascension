package io.github.herbertofury.shyrestudy;

public final class PreviewLifecycleTest {
    private static int checks;
    private static void check(boolean actual, boolean expected, String label) {
        checks++;
        if (actual != expected) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        PreviewLifecycle state = new PreviewLifecycle();
        Object world = new Object();
        check(state.update(false, null, -1, ""), false, "startup");
        check(state.update(true, world, 0, "probe"), false, "first equip");
        check(state.update(true, world, 0, "probe"), false, "stable ownership");
        check(state.update(true, world, 1, "probe"), true, "same item in different slot");
        check(state.update(true, world, 1, "shyre"), true, "different target item");
        check(state.update(false, world, 1, "shyre"), true, "offhand or left-arm fallback");
        check(state.update(false, world, 1, "shyre"), false, "fallback remains clear");
        check(state.update(true, world, 1, "shyre"), false, "fresh preview after fallback");
        check(state.update(true, new Object(), 1, "shyre"), true, "world changes");
        check(state.update(false, null, -1, ""), true, "disconnect");
        check(state.update(true, world, 1, "shyre"), false, "rejoin");
        state.clear();
        check(state.update(true, world, 1, "shyre"), false, "resource reload starts clean");
        check(state.update(false, world, 1, "shyre"), true, "toggle off");
        check(state.update(true, world, 1, "shyre"), false, "toggle on");
        System.out.println("PASS: " + checks + " preview ownership checks");
    }
}
