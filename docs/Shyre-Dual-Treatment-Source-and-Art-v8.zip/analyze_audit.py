"""Read-only audit-log extraction. Correlation is evidence, not gameplay acceptance."""
from pathlib import Path
import argparse, collections, hashlib, json, re
MARK='SHYRE_AUDIT '
FIELDS={
 'fire_return':{'observation','tick','shooter','hand','result','damage_at_return','dimension'},
 'inventory':{'tick','player','slot','main','off','cannonballs','creative'},
 'projectile_join':{'tick','owner','entity','type','main','off','loaded_from_disk'},
 'damage_event':{'tick','attacker','target','amount','direct_type'}}
def analyze(text):
    records=[];errors=[]
    for number,line in enumerate(text.splitlines(),1):
        if MARK not in line: continue
        tail=line.split(MARK,1)[1].strip();kind,_,body=tail.partition(' ')
        pairs=re.findall(r'(\w+)=([^\s]+)',body); fields=dict(pairs)
        if kind not in FIELDS: errors.append({'line':number,'reason':'unknown event kind'});continue
        if len(pairs)!=len(fields) or not FIELDS[kind].issubset(fields):
            errors.append({'line':number,'reason':'duplicate or missing fields'});continue
        try:
            if int(fields['tick'])<0:raise ValueError()
            for name in ('result','creative','loaded_from_disk'):
                if name in fields and fields[name] not in ('true','false'):raise ValueError()
            for name in ('observation','shooter','damage_at_return','player','slot','cannonballs','owner','entity','attacker','target'):
                if name in fields: int(fields[name])
            if 'amount' in fields:
                import math
                if not math.isfinite(float(fields['amount'])):raise ValueError()
        except ValueError:
            errors.append({'line':number,'reason':'invalid typed field'});continue
        records.append({'line':number,'kind':kind,**fields})
    counts=dict(collections.Counter(r['kind'] for r in records))
    returns=[r for r in records if r['kind']=='fire_return']
    joins=[r for r in records if r['kind']=='projectile_join' and r['loaded_from_disk']=='false']
    correlations=[]
    for fire in returns:
        candidates=[j for j in joins if j['owner']==fire['shooter'] and j['tick']==fire['tick']]
        correlations.append({'observation':fire['observation'],'return_value':fire['result'],
            'same_tick_owner_projectile_candidates':[{'entity':j['entity'],'type':j['type'],'line':j['line']} for j in candidates],
            'exact_shot_identity_proven':False})
    return {'scope':'Log observations only. Same-tick/owner correlation does not prove unique shot identity, final spawn success, applied damage or native gameplay acceptance.',
            'counts':counts,'parse_errors':errors,'records':records,'return_correlations':correlations,
            'has_actual_fire_return_evidence':bool(returns),
            'native_weapon_accepted':False,
            'limitations':['No automatic AoA/TaCZ presence verification from these audit lines','No inferred pass from an empty or startup-only log','Damage events may be altered after the observer','Inventory snapshots need an explicitly bounded test scenario','No gameplay changes are made by this analyzer']}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('log',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    out=analyze(a.log.read_text(errors='replace'));out['input_sha256']=hashlib.sha256(a.log.read_bytes()).hexdigest()
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ('counts','parse_errors','has_actual_fire_return_evidence','native_weapon_accepted')}))
