"""Original static-body atlas. No claim of animation, native lighting or final art acceptance."""
import bpy,math,json,hashlib
from pathlib import Path
from mathutils import Vector,Matrix
R=Path(__file__).resolve().parent;source=R.parent/'shyre-concept-fidelity-v29/shyre-v29.blend'
bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene
# AI-generated original painted gold material, mapped onto actual authored geometry.
gold_image=bpy.data.images.load(str(R/'sculpted-gold-material.png'))
for material in bpy.data.materials:
 if not material.use_nodes or not any(x in material.name for x in ['weathered warm','brighter edge']):continue
 n=material.node_tree.nodes;l=material.node_tree.links;p= n.get('Principled BSDF');old=p.inputs['Base Color'].links[0].from_socket
 tex=n.new('ShaderNodeTexImage');tex.image=gold_image;tex.projection='BOX';tex.projection_blend=.15;tex.extension='REPEAT'
 coord=n.new('ShaderNodeNewGeometry');scale=n.new('ShaderNodeVectorMath');scale.operation='SCALE';scale.inputs[3].default_value=.55;l.new(coord.outputs['Position'],scale.inputs[0]);l.new(scale.outputs[0],tex.inputs['Vector'])
 mix=n.new('ShaderNodeMixRGB');mix.blend_type='MIX';mix.inputs[0].default_value=.82;l.new(old,mix.inputs[1]);l.new(tex.outputs['Color'],mix.inputs[2]);l.new(mix.outputs[0],p.inputs['Base Color'])

# Stylized game-texture shading is authored into color, since the current native bridge
# does not transport the Blender metallic/roughness/normal shading model.
# This is a documented material treatment, not a screenshot or concept pasted on geometry.
for material in bpy.data.materials:
 if not material.use_nodes or not any(x in material.name for x in ['weathered warm','brighter edge','fractured charcoal']):continue
 tree=material.node_tree;n=tree.nodes;l=tree.links;p=n.get('Principled BSDF');inp=p.inputs['Base Color']
 if not inp.is_linked:continue
 original=inp.links[0].from_socket
 normal=n.new('ShaderNodeNewGeometry');xyz=n.new('ShaderNodeSeparateXYZ');l.new(normal.outputs['Normal'],xyz.inputs[0])
 ramp=n.new('ShaderNodeMapRange');ramp.inputs['From Min'].default_value=-1;ramp.inputs['From Max'].default_value=1;ramp.inputs['To Min'].default_value=.65;ramp.inputs['To Max'].default_value=1.18;l.new(xyz.outputs['Z'],ramp.inputs['Value'])
 shade=n.new('ShaderNodeMixRGB');shade.blend_type='MULTIPLY';shade.inputs[0].default_value=1;l.new(original,shade.inputs[1]);l.new(ramp.outputs[0],shade.inputs[2])
 ao=n.new('ShaderNodeAmbientOcclusion');ao.samples=16;ao.inputs['Distance'].default_value=.20;ao.only_local=True
 amount=n.new('ShaderNodeMath');amount.operation='MULTIPLY_ADD';amount.inputs[1].default_value=.36;amount.inputs[2].default_value=.64;l.new(ao.outputs['AO'],amount.inputs[0])
 mix=n.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1;l.new(shade.outputs[0],mix.inputs[1]);l.new(amount.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],p.inputs['Base Color'])
s.frame_set(1);bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();parts=[];receipt=[]
for ob in list(bpy.data.objects):
 if ob.type not in {'MESH','CURVE'} or ob.hide_render or not ob.parent:continue
 if any(x in ob.name.lower() for x in ['inspection','pulse','orbit','proxy']):continue
 ev=ob.evaluated_get(dg);mesh=bpy.data.meshes.new_from_object(ev,preserve_all_data_layers=True,depsgraph=dg);mesh.transform(ob.matrix_world)
 if not mesh.vertices:continue
 new=bpy.data.objects.new('Atlas '+ob.name,mesh);bpy.context.collection.objects.link(new);parts.append(new);receipt.append({'object':ob.name,'vertices':len(mesh.vertices)});ob.hide_render=True
bpy.ops.object.select_all(action='DESELECT')
for ob in parts:ob.select_set(True)
bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();model=bpy.context.object;model.name='Shyre v31 static atlas body'
while model.data.uv_layers:model.data.uv_layers.remove(model.data.uv_layers[0])
model.data.uv_layers.new(name='ExportUV');bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=math.radians(68),island_margin=.004,area_weight=.5,correct_aspect=True,scale_to_bounds=True);bpy.ops.object.mode_set(mode='OBJECT')
for x in model.data.uv_layers.active.data:x.uv=x.uv*(1-12/2048)+Vector((6/2048,6/2048))
s.render.engine='CYCLES';s.cycles.samples=4;s.cycles.use_denoising=False;s.render.bake.margin=4;s.render.bake.use_selected_to_active=False;s.render.bake.use_clear=True
textures={}
for channel,socket_name in [('basecolor','Base Color'),('emission','Emission Color')]:
 im=bpy.data.images.new('Shyre v31 '+channel,2048,2048,alpha=True);im.generated_color=(0,0,0,0);changes=[]
 for mat in set(model.data.materials):
  if not mat or not mat.use_nodes:continue
  nodes=mat.node_tree.nodes;links=mat.node_tree.links;pbr=nodes.get('Principled BSDF');out=next(n for n in nodes if n.type=='OUTPUT_MATERIAL' and n.is_active_output)
  image=nodes.new('ShaderNodeTexImage');image.image=im;nodes.active=image
  for n in nodes:n.select=False
  image.select=True
  old=[l.from_socket for l in out.inputs['Surface'].links];em=nodes.new('ShaderNodeEmission');em.inputs['Strength'].default_value=1;inp=pbr.inputs[socket_name]
  if inp.is_linked:links.new(inp.links[0].from_socket,em.inputs['Color'])
  else:em.inputs['Color'].default_value=inp.default_value
  links.new(em.outputs[0],out.inputs['Surface']);changes.append((mat,out,old,em))
 bpy.ops.object.bake(type='EMIT');im.filepath_raw=str(R/('shyre-'+channel+'-2048.png'));im.file_format='PNG';im.save();textures[channel]=im
 for mat,out,old,em in changes:
  mat.node_tree.nodes.remove(em)
  for sock in old:mat.node_tree.links.new(sock,out.inputs['Surface'])
 print('BAKED',channel,flush=True)
# An explicit baked-color material review. Normal/bump remains authoring-only and is disconnected here.
for mat in set(model.data.materials):
 p=mat.node_tree.nodes.get('Principled BSDF');n=mat.node_tree.nodes;l=mat.node_tree.links
 for channel,sock in [('basecolor','Base Color'),('emission','Emission Color')]:
  tex=n.new('ShaderNodeTexImage');tex.image=textures[channel];l.new(tex.outputs['Color'],p.inputs[sock])
 for link in list(p.inputs['Normal'].links):l.remove(link)
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'shyre-atlas-v31.blend'))
# Static geometry fixture using the established -Y,Z,-X transport axes.
mesh=model.data;mesh.calc_loop_triangles();M=Matrix(((0,-1,0),(0,0,1),(-1,0,0)));uv=mesh.uv_layers.active.data;g={'normalized_uvs':True,'positions':[],'normals':[],'uvs':[],'polys':[]};cache={k:{}for k in ['positions','normals','uvs']}
def add(k,v):
 t=tuple(float(x)for x in v)
 if t not in cache[k]:cache[k][t]=len(g[k]);g[k].append(list(t))
 return cache[k][t]
skipped_degenerate=0
for tri in mesh.loop_triangles:
 if tri.area<=1e-8:
  skipped_degenerate+=1;continue
 poly=[]
 for li in tri.loops:
  pos=M@mesh.vertices[mesh.loops[li].vertex_index].co*4;normal=(M@mesh.corner_normals[li].vector).normalized();coord=uv[li].uv
  assert all(math.isfinite(v)for v in [*pos,*normal,*coord]);assert all(0<=v<=1 for v in coord)
  poly.append([add('positions',pos),add('normals',normal),add('uvs',coord)])
 g['polys'].append(poly)
data={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.ascension_armory.shyre_v31_static_review','texture_width':2048,'texture_height':2048,'visible_bounds_width':8,'visible_bounds_height':8,'visible_bounds_offset':[0,0,0]},'bones':[{'name':'root','pivot':[0,0,0]},{'name':'shyre_static_body','parent':'root','pivot':[0,0,0],'poly_mesh':g}]}]}
(R/'shyre-v31-static.geo.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
report={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'parts':receipt,'triangles':len(g['polys']),'degenerate_triangles_omitted':skipped_degenerate,'uv_loops':len(uv),'texture_size':[2048,2048],'native_accepted':False,'art_accepted':False,'limitations':['Static body only; not native hand rig or animation','Stylized direction and local occlusion are deliberately baked into basecolor; emission is baked separately; procedural bump and metallic/roughness lighting are not included in native texture','No native material, mipmap or performance acceptance','Current concept fidelity remains under revision'],'textures':{k:hashlib.sha256(Path(v.filepath_raw).read_bytes()).hexdigest()for k,v in textures.items()}}
(R/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
s.cycles.samples=64;s.render.filepath=str(R/'baked-color-review.png');bpy.ops.render.render(write_still=True)
