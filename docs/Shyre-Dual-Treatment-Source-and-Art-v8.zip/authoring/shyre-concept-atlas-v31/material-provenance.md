# Original gold material input

Generated with the built-in image generation tool on October20,2026, then copied into this project and mapped with box projection onto the original Shyre model. It is not an upstream AoA texture. The first rough foil-like candidate was rejected. The flatter second candidate is the input sculpted-gold-material.png.

Final edit prompt: Keep the warm golden palette and edge-to-edge square texture, but make the surface much flatter and deliberately hand-painted. Remove crumpled foil/rocky relief and dense grain. Use broad calm angular planes, restrained tonal changes, fine short scratches and thin interrupted branching cracks. Avoid deep crevices, cobblestone cells, photographic highlights, mottled noise, text, borders, objects, logos and symbols. Aim for stylized thick sculpted fantasy gold armor and seamless edges.

The material was mixed with the original procedural basecolor, projected onto real geometry, and baked into an original UV atlas. Directional tone/local occlusion are deliberately included for the current game's non-PBR presentation. Exact seam/mip fidelity and final art quality remain under review. Original generated files remain unchanged.
