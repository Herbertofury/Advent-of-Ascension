"""Author a separate game-fit palette atlas on the unchanged existing mesh UVs."""
import bpy,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;source=R.parent/'shyre-concept-atlas-v31/shyre-atlas-v31.blend';bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene;model=bpy.data.objects['Shyre v31 static atlas body'];bpy.ops.object.select_all(action='DESELECT');model.select_set(True);bpy.context.view_layer.objects.active=model
palette=[]
for m in set(model.data.materials):
 if not m or not m.use_nodes:continue
 name=m.name.lower()
 if 'weathered warm' in name:color=(.61,.32,.045,1)
 elif 'brighter edge' in name:color=(.88,.61,.15,1)
 elif any(k in name for k in ['charcoal','stone']):color=(.038,.06,.075,1)
 elif any(k in name for k in ['cyan','crystal','mineral']):color=(.035,.53,.64,1)
 else:
  p=m.node_tree.nodes.get('Principled BSDF');color=tuple(p.inputs['Base Color'].default_value)
 n=m.node_tree.nodes;l=m.node_tree.links;out=next(x for x in n if x.type=='OUTPUT_MATERIAL'and x.is_active_output)
 geo=n.new('ShaderNodeNewGeometry');sep=n.new('ShaderNodeSeparateXYZ');l.new(geo.outputs['Normal'],sep.inputs[0]);r=n.new('ShaderNodeValToRGB');r.color_ramp.interpolation='CONSTANT';r.color_ramp.elements[0].position=0;r.color_ramp.elements[0].color=(.64,.64,.64,1);r.color_ramp.elements[1].position=.65;r.color_ramp.elements[1].color=(1,1,1,1);e=r.color_ramp.elements.new(.15);e.color=(.82,.82,.82,1);l.new(sep.outputs['Z'],r.inputs[0])
 mix=n.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1;mix.inputs[1].default_value=color;l.new(r.outputs[0],mix.inputs[2]);em=n.new('ShaderNodeEmission');l.new(mix.outputs[0],em.inputs['Color']);l.new(em.outputs[0],out.inputs['Surface']);palette.append({'material':m.name,'color':color})
image=bpy.data.images.new('Shyre world-fit palette 512',512,512,alpha=True);image.generated_color=(0,0,0,0)
for m in set(model.data.materials):
 n=m.node_tree.nodes;tex=n.new('ShaderNodeTexImage');tex.image=image
 for x in n:x.select=False
 tex.select=True;n.active=tex
s.render.engine='CYCLES';s.cycles.samples=1;s.cycles.use_denoising=False;s.render.bake.margin=1;s.render.bake.use_selected_to_active=False;s.render.bake.use_clear=True;bpy.ops.object.bake(type='EMIT');image.filepath_raw=str(R/'shyre-world-fit-512.png');image.file_format='PNG';image.save()
(R/'receipt.json').write_text(json.dumps({'source_blend_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'texture_sha256':hashlib.sha256(Path(image.filepath_raw).read_bytes()).hexdigest(),'texture_size':[512,512],'palette':palette,'geometry_unchanged':True,'uv_layout_unchanged':True,'scope':'Separate authored lower-frequency palette and stepped face shading. This is a texture-treatment study, not a completed low-poly mode or native acceptance.','native_accepted':False,'art_accepted':False},indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(R/'shyre-world-fit-atlas.blend'))
