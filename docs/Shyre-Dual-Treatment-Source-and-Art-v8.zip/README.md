# Shyre combined AoA + TaCZ presentation study

Version 0.0.7 is an original development study, **not a completed or visually accepted weapon port**. It runs with Minecraft 1.20.1, Forge 47.4.28, AoA 3.7.1, TaCZ 1.1.8-hotfix2, TML 0.1.8 and GeckoLib 4.3. AoA and TaCZ are mandatory together. Original AoA behavior remains in the separately installed upstream mod. AoA is by Tslat and contributors; TaCZ and TML remain separately credited dependencies.

## Current evidence, October 20, 2026

The owner approved the isolated experimental-world acknowledgment, which was accepted. The backed-up QA world loaded with AoA and TaCZ together. This is no longer blocked on that permission.

- Version 0.0.6 recorded three actual successful Shyre firing returns and same-owner/tick cannonball joins. Survival ammunition changed 16→13 and item damage 0→3. Empty-ammo attempts returned false with no added projectile or durability change in the observed interval.
- Version 0.0.7 added an owner-only server-to-client cosmetic signal. Five initial empty-ammo returns were false and did not reach the accepted cosmetic handler. A loaded shot produced a cannonball, consumed one round/durability and reached the client animation handler. With F7 disabled, the next original shot still consumed one round/durability but did not activate cosmetics. Re-enabling presentation allowed the third loaded shot to reach that handler again. No F8 input was used as evidence for these cases.
- This verifies the bounded signal path and resource observations, not every animation frame or complete gameplay compatibility. Return true alone is not proof of final world insertion; joins are separately recorded.
- The v29/v30 visual revisions rendered in the combined-mod client with original geometry, baked texture and actual player arms. The owner has rejected the previous art quality. **The new art is also still under review, not declared accepted.**

## What the implementation does

- `dev/` is the canonical Forge project.
- `ShyreMeshBridge` adapts the native bone hierarchy to TML's polygon renderer without copying upstream renderer classes or creating a fake TaCZ gun identity.
- `ShyreVisualClient` overrides the original Shyre main-hand presentation and a separate non-firing diagnostic item. Unsupported left-main-arm and occupied-offhand states retain the original renderer.
- `PreviewLifecycle` clears motion on slot, item, world, eligibility and enable-state changes.
- The non-cancellable, pinned `BaseGun.fireGun` RETURN observer never alters the original return, inventory, resource cost, projectiles, effects or damage.
- Successful main-hand Shyre returns for a server player send only an owning-client cosmetic notification. The channel is registered only in the server-to-client direction. No client firing request is added.
- The client checks player, dimension, slot, current item, presentation eligibility, screen/pause state, sequence and freshness before starting the existing candidate clip. Duplicate, stale and ineligible messages are rejected. Notification/animation failures are caught rather than changing original firing behavior.
- Optional audit logs separately record inventory snapshots, return observations, projectile joins and damage events. No runtime logs or worlds belong in the public source bundle.

## Visual assets and limitations

The revised static body has 9,278 exported triangles and a 2048×2048 baked basecolor atlas. Near-zero-area triangles are excluded by the exporter; native normals, indices and UV ranges are validated before staging. A separate emission map is not yet bound to the native renderer. Blender metallic, roughness and bump shaders do not automatically carry into Minecraft.

The larger armor introduced a new support-arm proxy intersection. A new candidate contact was measured instead of assuming the old v25 fit remained valid. Native hand fit, motion extremes and both player arm widths remain open acceptance gates. Generated material swatches, where used, are texture inputs mapped and baked onto actual original geometry, not images presented as completed game models.

## Controls

- F7 toggles the cosmetic presentation. Original AoA firing is independent.
- F8 runs a manual diagnostic motion preview. It is never a firing command or evidence of a real shot.
- F3+T reloads original model/texture/view resources for isolated development checks.

## Remaining gates

Dedicated server startup, multiplayer observers, precise cooldown/release timing, final applied damage, all offhand/left-arm/skin variants, progression, audio, save migration, optional renderer/shader compatibility and equivalent-work performance remain unaccepted. The signal currently serves only the owning client; remote-observer animation replication is not implemented. Full weapon-instance identity across unusual concurrent mutations is not certified.

## Build and tests

`run_build.py` uses the verified local Gradle 8.8 distribution and Java 17 compilation toolchain. It preserves the provided network route, does not disable TLS or mixins, and supports offline builds after dependency preparation. The TaCZ development refmap bridge follows its development configuration.

The offline build passed. Standalone checks passed: 16 cosmetic-signal cases, 14 lifecycle cases, 22 bounded-view-transform cases and 10 audit-parser cases. These are not substitutes for native tests. A normal Gradle `test` task currently has no sources; do not report it as the standalone suite.

The source bundle contains only original authored sources/resources, tests and required MDK notices. It does not bundle AoA, TaCZ, TML, GeckoLib, upstream classes, upstream assets, credentials, world saves or runtime logs. Dependency licensing and provenance remain applicable.


## Appearance selector checkpoint: 0.0.8

F7 still enables/disables the custom presentation. F9 now switches between the detailed 2048-pixel concept-study atlas and a separately authored 512-pixel world-fit palette atlas. These share the current geometry; this is not a finished low-poly/world-fit model or accepted concept-quality artwork. The choice is session-local and starts with concept-study after restart. Key mappings are rebindable through Minecraft Controls. F8 remains a manual diagnostic, never a firing action.

Both atlas dimensions are validated on resource reload; missing/invalid study resources leave the original renderer active. Switching style clears the current cosmetic clip and changes only the atlas selection. Gameplay, resources, durability, authoritative projectiles and original item identity remain source-owned. Left-main-arm and occupied-offhand cases still use the original renderer.

A bounded native combined-mod run verified both style renders, resource reload, four successful original shots (ammo 4 to 0; damage value 7 to 11), four cannonball joins, cosmetic notification acceptance for enabled shots 1–3, no cosmetic acceptance for the disabled-presentation shot 4, and empty-ammo rejection 5. The first palette candidate accidentally classified charcoal mineral as cyan; explicit charcoal precedence was corrected, re-baked, reloaded and inspected before the final comparison. The run saved and exited normally. These observations do not certify final art, every animation frame, multiplayer or performance.
