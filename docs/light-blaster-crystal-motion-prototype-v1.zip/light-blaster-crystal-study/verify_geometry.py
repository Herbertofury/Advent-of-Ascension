import bpy,math,json
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
P=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(P/'light-blaster-crystal-motion-blockout.blend'))
s=bpy.context.scene;shards=sorted([o for o in bpy.data.objects if o.name.startswith('Crystal_')],key=lambda o:o.name);assert len(shards)==8
center=Vector((0,0,1.7));minimum=99;triangles_checked=0
# Exact 2D projected triangle distance: covers interiors and edges, not only vertices.
def edge_dist(a,b):
 d=b-a
 if d.length_squared<1e-14:return a.length
 t=max(0,min(1,-a.dot(d)/d.length_squared));return(a+t*d).length

def tri_dist(a,b,c):
 cross=lambda u,v:u.x*v.y-u.y*v.x
 area=cross(b-a,c-a)
 if abs(area)>1e-12:
  signs=[cross(b-a,-a),cross(c-b,-b),cross(a-c,-c)]
  if min(signs)>=-1e-12 or max(signs)<=1e-12:return 0
 return min(edge_dist(a,b),edge_dist(b,c),edge_dist(c,a))
for frame in range(46,96):
 s.frame_set(frame);bpy.context.view_layer.update()
 for o in shards:
  assert all(abs(v-1)<1e-8 for v in o.scale)
  o.data.calc_loop_triangles()
  for t in o.data.loop_triangles:
   ps=[o.matrix_world@o.data.vertices[i].co-center for i in t.vertices]
   ds=tri_dist(*(Vector((v.y,v.z))for v in ps));minimum=min(minimum,ds);triangles_checked+=1
assert minimum>.5,minimum
for o in shards:
 edge_counts={}
 for face in o.data.polygons:
  vs=list(face.vertices)
  for a,b in zip(vs,vs[1:]+vs[:1]):k=tuple(sorted((a,b)));edge_counts[k]=edge_counts.get(k,0)+1
 assert all(n==2 for n in edge_counts.values()),'Non-manifold shard'
s.frame_set(90);bpy.context.view_layer.update();uv=world_to_camera_view(s,s.camera,center);assert abs(uv.x-.5)<1e-5 and abs(uv.y-.5)<1e-5
s.frame_set(1);start=[o.matrix_world.copy()for o in shards];s.frame_set(120);bpy.context.view_layer.update();assert all(max(abs(a-b)for ra,rb in zip(o.matrix_world,m)for a,b in zip(ra,rb))<1e-6 for o,m in zip(shards,start))
out={'shards':8,'focused_frames_checked':50,'projected_triangles_checked':triangles_checked,'minimum_projected_surface_clearance':minimum,'rear_projection':[uv.x,uv.y],'closed_manifold_shards':True,'idle_return':True,'scope':'Cosmetic isolated blockout; not weapon, native or full-motion collision acceptance','native_accepted':False};(P/'geometry-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
