import java.util.Random;
public final class LightCrystalFocusStateTest {
    static int checks;
    static void check(boolean v) { checks++; if (!v) throw new AssertionError("Check " + checks); }
    static void close(double a, double b) { check(Math.abs(a-b) < 1e-10); }
    static void rejects(Runnable r) { try { r.run(); } catch (IllegalArgumentException e) { checks++; return; } throw new AssertionError("Invalid input accepted"); }
    static double[] segmented(int fps) {
        LightCrystalFocusState s = new LightCrystalFocusState(.3);
        double[] durations = {.18,.06,.35,.1,.3}; boolean[] focus = {true,false,true,true,false}; boolean[] enabled={true,true,true,false,false};
        double[] samples = new double[durations.length];
        for (int i=0;i<durations.length;i++) {
            double left=durations[i];
            while(left>1e-12) { double dt=Math.min(left,1.0/fps); s.update(focus[i],enabled[i],dt); left-=dt; }
            samples[i]=s.pose();
        }
        return samples;
    }
    public static void main(String[] args) {
        for(double d:new double[]{0,-1,Double.NaN,Double.POSITIVE_INFINITY}) rejects(()->new LightCrystalFocusState(d));
        LightCrystalFocusState s=new LightCrystalFocusState(.3);
        for(double d:new double[]{-1,Double.NaN,Double.POSITIVE_INFINITY}) rejects(()->s.update(true,true,d));
        close(s.pose(),0); close(s.update(true,true,.15),.5); close(s.update(false,true,0),.5);
        check(s.update(false,true,.01)<.5); check(s.update(true,true,.01)<=.5+1e-10);
        close(s.update(true,true,100),1); close(s.update(true,false,100),0);
        for(int fps:new int[]{20,30,60,120,144,240}) { double[] a=segmented(fps),b=segmented(60); for(int i=0;i<a.length;i++) close(a[i],b[i]); }
        Random rng=new Random(72919); double old=s.progress();
        for(int i=0;i<10000;i++) { boolean focused=rng.nextBoolean(), enabled=rng.nextBoolean(); double dt=rng.nextDouble()*.04; double expected=focused&&enabled?Math.min(1,old+dt/.3):Math.max(0,old-dt/.3); double pose=s.update(focused,enabled,dt); close(s.progress(),expected); check(pose>=0&&pose<=1); check(Double.isFinite(pose)); old=s.progress(); }
        System.out.println("PASS: "+checks+" assertions; cosmetic controller only, not native integration");
    }
}
