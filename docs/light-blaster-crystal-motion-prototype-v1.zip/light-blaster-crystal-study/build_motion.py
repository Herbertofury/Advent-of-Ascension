"""Independent cosmetic geometry study. Not an AoA or TaCZ weapon implementation."""
import bpy,math,json
from pathlib import Path
from mathutils import Vector,Quaternion
OUT=Path(__file__).resolve().parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,c,metal=0,emission=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=.24;p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=emission;return m
crystal=mat('Lime crystal',(.33,.85,.015),.32,.25);dark=mat('Neutral mount',(.025,.04,.055),.7);floor=mat('Studio',(.012,.02,.032))
def cube(name,loc,scale,m):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(m);return o
cube('Neutral reference mount - NOT gun',(0,0,.35),(2.4,.45,.28),dark)
cube('Ground',(0,0,-.1),(200,200,.1),floor)
# Eight rigid faceted crystals, local long axis Z. No growth, duplication or scale changes.
verts=[(0,0,-.32),(0,0,.32)]+[(.10*math.cos(a*math.pi/2),.10*math.sin(a*math.pi/2),z)for z in [-.18,.18]for a in range(4)]
faces=[]
for k in range(4):
 n=(k+1)%4;faces += [(0,2+n,2+k),(1,6+k,6+n),(2+k,2+n,6+n,6+k)]
mesh=bpy.data.meshes.new('Rigid faceted shard');mesh.from_pydata(verts,[],faces);mesh.update();mesh.materials.append(crystal)
center=Vector((0,0,1.7));corners=[Vector((0,0,.9)),Vector((0,.9,0)),Vector((0,0,-.9)),Vector((0,-.9,0))]
shards=[];poses=[]
for i in range(8):
 edge=i//2;part=i%2;a=corners[edge];b=corners[(edge+1)%4];target=center+a.lerp(b,(part+.5)/2);direction=(b-a).normalized();q=Vector((0,0,1)).rotation_difference(direction)
 obj=bpy.data.objects.new('Crystal_%02d'%i,mesh.copy());bpy.context.collection.objects.link(obj);obj.rotation_mode='QUATERNION';shards.append(obj)
 poses.append((Vector((-.84+i*.24,(-1 if i%2 else 1)*.10,.86+.07*(i%3))),Quaternion((1,0,0),(-1 if i%2 else 1)*.13),target,q))
def smooth(u):u=max(0,min(1,u));return u*u*(3-2*u)
def focus(frame):
 if frame<16:return 0
 if frame<=45:return smooth((frame-15)/30)
 if frame<=95:return 1
 if frame<=110:return 1-smooth((frame-95)/15)
 return 0
scene=bpy.context.scene;scene.frame_start=1;scene.frame_end=120;scene.render.fps=30
scene.render.engine='CYCLES';scene.cycles.samples=8;scene.cycles.use_denoising=False
scene.render.resolution_x=960;scene.render.resolution_y=540;scene.render.resolution_percentage=100
scene.world.color=(.08,.08,.08)
for loc,power,size in [((1,-3,6),1100,5),((-3,3,4),900,4)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,1))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.lens=52
oblique=Vector((4.8,-6.2,3.6));rear=Vector((6,0,1.7));target_oblique=Vector((0,0,1.3))
min_clearance=99;idle_matrices=[];checks=0
for f in range(1,121):
 p=focus(f)
 for o,(start,qa,end,qb)in zip(shards,poses):
  o.location=start.lerp(end,p);o.rotation_quaternion=qa.slerp(qb,p);o.keyframe_insert('location',frame=f);o.keyframe_insert('rotation_quaternion',frame=f);checks+=1
 # Camera reaches rear only while aperture is fully formed.
 c=smooth((f-65)/15)if f<=95 else 1-smooth((f-95)/15)
 cam.location=oblique.lerp(rear,c);target=target_oblique.lerp(center,c);cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.keyframe_insert('location',frame=f);cam.keyframe_insert('rotation_euler',frame=f)
 scene.frame_set(f);bpy.context.view_layer.update()
 if p==1:
  for o in shards:
   for v in o.data.vertices:
    v=o.matrix_world@v.co;clearance=math.hypot(v.y,v.z-center.z);min_clearance=min(min_clearance,clearance)
 if f==1:idle_matrices=[o.matrix_world.copy()for o in shards]
 if f==120:
  for o,m in zip(shards,idle_matrices):assert max(abs(a-b)for ra,rb in zip(o.matrix_world,m)for a,b in zip(ra,rb))<1e-6
assert len(shards)==8 and min_clearance>.5
# Conservative triangle-distance proof is handled by the separate geometry validator.
for name,frame in [('idle',1),('forming',32),('focused-oblique',55),('focused-rear',90)]:
 scene.frame_set(frame);scene.render.filepath=str(OUT/(name+'.png'));bpy.ops.render.render(write_still=True)
scene.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'light-blaster-crystal-motion-blockout.blend'))
(OUT/'receipt.json').write_text(json.dumps({'kind':'Independent cosmetic 3D motion blockout','shards':8,'sampled_poses':checks,'focused_vertex_radial_clearance':min_clearance,'idle_return_verified':True,'native_accepted':False,'limits':['Neutral mount, not complete weapon model','Eight-shard prototype is not final source crystal count','No hand rig, native animation, collision or performance acceptance','No gameplay accuracy or magnification changes','Vertex clearance alone does not prove whole-face clearance']},indent=2)+'\n')
scene.render.resolution_x=640;scene.render.resolution_y=360;scene.render.image_settings.file_format='FFMPEG';scene.render.ffmpeg.format='MPEG4';scene.render.ffmpeg.codec='H264';scene.render.ffmpeg.constant_rate_factor='MEDIUM';scene.render.filepath=str(OUT/'light-blaster-crystal-motion-blockout.mp4');bpy.ops.render.render(animation=True)
