import bpy
from pathlib import Path
P=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(P/'light-blaster-crystal-motion-blockout.blend'))
s=bpy.context.scene;s.cycles.samples=96;s.render.resolution_x=960;s.render.resolution_y=540
for name,frame in [('idle',1),('forming',32),('focused-oblique',55),('focused-rear',90)]:
 s.frame_set(frame);s.render.image_settings.file_format='PNG';s.render.filepath=str(P/(name+'-clean.png'));bpy.ops.render.render(write_still=True)
s.cycles.samples=32;s.render.resolution_x=640;s.render.resolution_y=360;s.render.image_settings.file_format='FFMPEG';s.render.ffmpeg.format='MPEG4';s.render.ffmpeg.codec='H264';s.render.ffmpeg.constant_rate_factor='MEDIUM';s.render.filepath=str(P/'light-blaster-crystal-motion-clean.mp4');bpy.ops.render.render(animation=True)
