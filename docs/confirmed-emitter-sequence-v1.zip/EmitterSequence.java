import java.util.HashMap;
import java.util.Map;
/** Cosmetic routing only. The caller authenticates successful-shot events; never computes damage/ammo. */
public final class EmitterSequence {
 private static final class State {long last=-1;int count;State(int n){count=n;}}
 private final Map<String,State> active=new HashMap<>();private final int capacity;
 public EmitterSequence(int capacity){if(capacity<1||capacity>1024)throw new IllegalArgumentException("capacity");this.capacity=capacity;}
 private static void key(String key){if(key==null||key.isEmpty()||key.length()>256)throw new IllegalArgumentException("session key");}
 private static void count(int n){if(n<1||n>64)throw new IllegalArgumentException("emitter count");}
 /** Use a fresh epoch-bearing key for every equip/world/session lifecycle. No automatic eviction. */
 public void begin(String key,int count){key(key);count(count);if(active.containsKey(key))throw new IllegalStateException("already active");if(active.size()==capacity)throw new IllegalStateException("active capacity reached");active.put(key,new State(count));}
 /** Cosmetic configuration update; retains the successful-shot high-water mark. */
 public void configure(String key,int count){key(key);count(count);State s=active.get(key);if(s==null)throw new IllegalStateException("inactive");s.count=count;}
 /** Zero-based successful PRIMARY shot sequence. Unknown/closed, rejected, bonus and repeated events do not emit. */
 public int confirm(String key,long sequence,boolean accepted,boolean bonus){if(!accepted||bonus)return -1;key(key);if(sequence<0)throw new IllegalArgumentException("sequence");State s=active.get(key);if(s==null||sequence<=s.last)return -1;s.last=sequence;return (int)(sequence%s.count);}
 public void end(String key){key(key);active.remove(key);}public void reset(){active.clear();}public int activeCount(){return active.size();}
}
