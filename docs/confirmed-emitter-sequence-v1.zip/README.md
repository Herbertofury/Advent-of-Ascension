# Confirmed-shot cosmetic emitter routing

Original Java reference logic for Baronator's two barrels and Soul Storm's modular emitters. It generalizes the existing Baronator presentation sequence concept without changing gameplay, damage, resource cost or cadence. Compile with javac --release 17 and run EmitterSequenceTest. Tested on Java17 and21.

The caller must supply an authenticated, zero-based successful **primary** shot sequence, scoped to a fresh epoch-bearing weapon/session key. The helper does not establish authority, synchronize networking, generate shots or authenticate clients. Select a clip only for the returned index (0=top); -1 means no new visual event. Bonus grenade events do not advance the primary sequence.

Register active sessions explicitly. No LRU eviction: reaching capacity fails visibly instead of silently forgetting duplicate protection for a still-active weapon. Closing a session rejects its delayed events. Never reuse a closed key; generate a new epoch. `configure` preserves the sequence high-water mark when the active emitter count changes. Counts1..64 and active capacity1..1024 are bounded. Calls belong on one presentation-update owner thread; this helper is not thread-safe.

60,000 sequential acceptance fixtures across1/2/4/5/6/64 emitters, plus duplicate/stale/rejected/bonus/missing-event/count-change/Long.MAX_VALUE/capacity/session-reset cases pass. This is reference logic, not a Minecraft/TaCZ adapter or performance measurement. Missing successful-shot events preserve authoritative sequence modulo but cannot reconstruct unseen animations. Weapon swapping, server correction, save migration and native integration still require tests.
