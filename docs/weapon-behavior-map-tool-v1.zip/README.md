# Released first-target weapon implementation map

Original structural audit of AoA 3.7.1 / Minecraft 1.20.1. Requires Python 3.10+ and a full JDK with javap. The script reads classes; it does not execute game code.

Set JAVA_HOME and run:

    python build_map.py /path/to/AoA3-1.20.1-3.7.1-all.jar result.json

The archive SHA-512 and original registry class SHA-256 must match. The included registry evidence supplies the 228 relevant IDs and exact constructor class mapping. Each relevant class is inspected once, then required in-package superclasses are added. At most four javap processes run at once. Other weapon families and historical releases are outside this map.

Output includes class hashes, the class inheritance chain, actual declared method signatures, literal registration constants and projectile classes directly constructed by each class. Literal values are deliberately not auto-labeled as effective gameplay values. A projectile class referenced by a base class is not proof every subclass uses it. A method declaration is not a guarantee about the whole runtime call chain.

This supports profile authoring and regression prioritization. It does not complete 228 weapon profiles, art assets, compatibility tests or native upgrades. Original AoA belongs to Tslat and contributors; the released JAR and decoded classes are not included.
