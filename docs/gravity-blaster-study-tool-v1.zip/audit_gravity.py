"""Static released-file checks only. Does not boot Minecraft or execute mod classes."""
import argparse,hashlib,json,os,pathlib,shutil,subprocess,zipfile
p=argparse.ArgumentParser();p.add_argument('jar',type=pathlib.Path);p.add_argument('evidence',type=pathlib.Path);a=p.parse_args();e=json.loads(a.evidence.read_text());assert hashlib.sha512(a.jar.read_bytes()).hexdigest()==e['jar_sha512']
javap=str(pathlib.Path(os.environ['JAVA_HOME'])/'bin/javap') if os.getenv('JAVA_HOME') else shutil.which('javap');assert javap,'Full JDK required'
with zipfile.ZipFile(a.jar)as z:
 for path,h in e['file_sha256'].items():assert hashlib.sha256(z.read(path)).hexdigest()==h,path
 recipe=json.loads(z.read('data/aoa3/recipes/infusion_gravity_blaster.json'));assert recipe['input']['item']=='aoa3:blaster_frame' and recipe['result']['item']=='aoa3:gravity_blaster';assert recipe['ingredients']==[{'item':'aoa3:floating_stone'}]*4

def inspect(c):return subprocess.check_output([javap,'-p','-c','-classpath',str(a.jar),c],text=True)
s=inspect('net.tslat.aoa3.content.item.weapon.blaster.GravityBlaster')
for needle in ['HOSTILE_MOB','pushEntityAway','float 0.5f','doMiscEnergyAttack','double 2.0d','LivingEntity.m_5997_'] :assert needle in s,needle
p=inspect('net.tslat.aoa3.util.EntityUtil$Predicates');assert 'monster/Enemy' in p and 'NeutralMob' not in p
u=inspect('net.tslat.aoa3.util.EntityUtil');segment=u.split('public static void pushEntityAway(',1)[1].split('public static void pullEntityIn(',1)[0]
assert 'Math.min' in segment and 'Vec3.m_82505_' in segment and 'Vec3.m_82490_' in segment
assert 'normalize' not in segment and 'onLivingKnockBack' not in segment
print('PASS pinned release/resources, four-ingredient infusion, selected lift/energy/push paths and Enemy-only predicate. Static evidence only; no native acceptance.')
