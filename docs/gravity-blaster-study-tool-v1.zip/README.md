# Gravity Blaster released-file study
Run python audit_gravity.py PATH_TO_PINNED_JAR gravity-blaster-source-evidence.json with a full JDK available via JAVA_HOME or javap on PATH.
The exact AoA3-1.20.1-3.7.1-all.jar is hash checked. This does not boot Minecraft or execute game classes. Original release assets/classes are not bundled in this tool archive. Credit Tslat and contributors.
Named later source is a comparison, not baseline authority: its hostile predicate adds angry NeutralMob, whereas the pinned released predicate is Enemy-only.
The original generated concept's proposed movement/VFX panels are not native footage or implemented behavior. Prompt retained. Actual item sprite is displayed separately in the profile.
