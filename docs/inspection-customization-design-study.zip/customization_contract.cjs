'use strict';
// Original standalone design contract; not a Minecraft/TaCZ runtime adapter.
const CHANNELS = Object.freeze(['projectile','tracer','impact','defeat','finisher']);
function id(value){if(typeof value!=='string'||! /^[a-z0-9_.-]+:[a-z0-9_.-]+(?:\/[a-z0-9_.-]+)*$/.test(value) || value.split(':').at(-1).split('/').some(x=>x==='.'||x==='..'))throw Error('Invalid namespaced ID');return value;}
function finite(v,min,max,label){if(!Number.isFinite(v)||v<min||v>max)throw Error('Invalid '+label);return v;}
function resolveCustomization(input,registry,earned){
 if(!input||!registry||!(earned instanceof Set))throw Error('Invalid resolution context');
 const weapon=id(input.weapon),revision=input.revision;
 if(!Number.isSafeInteger(revision)||revision<0)throw Error('Invalid revision');
 const owned=(key,kind)=>{
  id(key);const record=registry[key];
  if(!record||record.kind!==kind)throw Error('Unknown '+kind);
  if(record.unlock&&!earned.has(record.unlock))throw Error('Locked '+kind);
  if(record.weapons&&!record.weapons.includes(weapon))throw Error('Incompatible '+kind);
  return record;
 };
 const sightId=input.sight??(weapon==='aoa3:soul_storm'?'aoa_upgrade:soul_flame':null);
 if(sightId)owned(sightId,'sight');
 const charms=input.charms??[];
 if(!Array.isArray(charms)||charms.length>4||new Set(charms).size!==charms.length)throw Error('Invalid charm slots');
 const bonuses={};
 for(const charm of charms){
  const record=owned(charm,'charm');
  for(const [stat,value] of Object.entries(record.bonuses??{})){
   if(!['damageAdd','capacityAdd','recoveryAdd','efficiencyAdd'].includes(stat))throw Error('Unknown bonus stat');
   finite(value,0,100000,'bonus'); bonuses[stat]=(bonuses[stat]??0)+value;finite(bonuses[stat],0,100000,'combined bonus');
  }
 }
 const effects={};
 for(const [channel,key] of Object.entries(input.effects??{})){
  if(!CHANNELS.includes(channel))throw Error('Unknown effect channel');
  const record=owned(key,'effect');if(record.channel!==channel)throw Error('Wrong effect channel');effects[channel]=key;
 }
 const decals=input.decals??[];
 if(!Array.isArray(decals)||decals.length>16)throw Error('Invalid decal count');
 const layers=new Set();
 const outDecals=decals.map(d=>{
  const record=owned(d.id,'decal');
  if(typeof d.surface!=='string'||!record.surfaces?.includes(d.surface))throw Error('Invalid decal surface');
  if(!Number.isInteger(d.layer)||d.layer<0||d.layer>15||layers.has(d.layer))throw Error('Invalid decal layer');layers.add(d.layer);
  if(!/^[0-9a-f]{64}$/.test(record.assetSha256))throw Error('Expected asset hash, not URL');
  return Object.freeze({id:d.id,surface:d.surface,layer:d.layer,u:finite(d.u,0,1,'u'),v:finite(d.v,0,1,'v'),scale:finite(d.scale,.01,4,'scale'),rotation:finite(d.rotation,-180,180,'rotation'),opacity:finite(d.opacity,0,1,'opacity'),glow:finite(d.glow,0,1,'glow'),assetSha256:record.assetSha256});
 }).sort((a,b)=>a.layer-b.layer);
 return Object.freeze({schema:1,weapon,revision,sight:sightId,charms:Object.freeze([...charms]),bonuses:Object.freeze(bonuses),effects:Object.freeze(effects),decals:Object.freeze(outDecals)});
}
module.exports={resolveCustomization,CHANNELS};
