'use strict';
// Original presentation-only timing core. No native game adapter or resource access.
const BEATS=Object.freeze([
 Object.freeze({at:0,name:'invitation'}),Object.freeze({at:.7,name:'curiosity'}),
 Object.freeze({at:1.4,name:'reveal'}),Object.freeze({at:2.3,name:'play'}),
 Object.freeze({at:3.7,name:'return'}),Object.freeze({at:4.5,name:'ready'})]);
class InspectionTimeline{
 constructor(){this.active=false;this.serial=0;}
 start(assemblyRevision){
  if(!Number.isSafeInteger(assemblyRevision)||assemblyRevision<0)throw Error('Invalid revision');
  if(this.active)throw Error('Cancel or finish existing inspection before restarting');
  this.revision=assemblyRevision;this.elapsed=0;this.next=1;this.active=true;this.serial++;
  return Object.freeze({type:'beat',name:'invitation',at:0,serial:this.serial});
 }
 cancel(reason='cancelled'){
  if(!this.active)return [];
  this.active=false;
  return [Object.freeze({type:'cleanup',reason,serial:this.serial,restorePose:true,removeTemporaryEffects:true})];
 }
 advance(deltaSeconds,{paused=false,assemblyRevision=this.revision}={}){
  if(!Number.isFinite(deltaSeconds)||deltaSeconds<0)throw Error('Invalid elapsed time');
  if(!this.active)return [];
  if(assemblyRevision!==this.revision)return this.cancel('assembly_changed');
  if(paused)return [];
  const previous=this.elapsed;
  this.elapsed=Math.min(4.5,previous+deltaSeconds);
  // A long stall must not replay all skipped flourish effects in one rendered frame.
  if(deltaSeconds>.5){
   if(this.elapsed>=4.5)return this.cancel('completed_after_stall');
   let current=0;while(current+1<BEATS.length&&BEATS[current+1].at<=this.elapsed)current++;
   this.next=current+1;
   return [Object.freeze({type:'resync',phase:BEATS[current].name,at:this.elapsed,serial:this.serial,removeTemporaryEffects:true})];
  }
  const events=[];
  while(this.next<BEATS.length&&BEATS[this.next].at<=this.elapsed+1e-10){
   const b=BEATS[this.next++];events.push(Object.freeze({type:'beat',name:b.name,at:b.at,serial:this.serial}));
  }
  if(this.elapsed>=4.5-1e-10)events.push(...this.cancel('completed'));
  return events;
 }
}
module.exports={InspectionTimeline,BEATS};
