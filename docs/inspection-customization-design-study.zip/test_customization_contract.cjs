'use strict';
const assert=require('node:assert/strict');
const {resolveCustomization:resolve}=require('./customization_contract.cjs');
const registry={
 'aoa_upgrade:soul_flame':{kind:'sight',weapons:['aoa3:soul_storm']},
 'aoa_upgrade:soul_gem':{kind:'sight',weapons:['aoa3:soul_storm']},
 'aoa_upgrade:lantern':{kind:'charm',unlock:'boss_fixture',bonuses:{efficiencyAdd:0.05}},
 'aoa_upgrade:trail':{kind:'effect',channel:'tracer'},
 'aoa_upgrade:sticker':{kind:'decal',surfaces:['body'],assetSha256:'a'.repeat(64)}
};
const base={weapon:'aoa3:soul_storm',revision:0};const earned=new Set(['boss_fixture']);
let count=0;function test(fn){fn();count++;}
test(()=>assert.equal(resolve(base,registry,earned).sight,'aoa_upgrade:soul_flame'));
test(()=>assert.equal(resolve({...base,sight:'aoa_upgrade:soul_gem'},registry,earned).sight,'aoa_upgrade:soul_gem'));
test(()=>assert.throws(()=>resolve({...base,charms:['aoa_upgrade:lantern']},registry,new Set()),/Locked/));
test(()=>assert.throws(()=>resolve({...base,charms:['aoa_upgrade:lantern','aoa_upgrade:lantern']},registry,earned),/slots/));
test(()=>assert.equal(resolve({...base,charms:['aoa_upgrade:lantern']},registry,earned).bonuses.efficiencyAdd,.05));
test(()=>assert.throws(()=>resolve({...base,effects:{impact:'aoa_upgrade:trail'}},registry,earned),/channel/));
test(()=>assert.throws(()=>resolve({...base,effects:{unknown:'aoa_upgrade:trail'}},registry,earned),/channel/));
const d={id:'aoa_upgrade:sticker',surface:'body',layer:0,u:.5,v:.5,scale:1,rotation:0,opacity:1,glow:.3};
test(()=>assert.throws(()=>resolve({...base,decals:[{...d,glow:Infinity}]},registry,earned),/glow/));
test(()=>assert.throws(()=>resolve({...base,decals:[{...d,surface:'muzzle_void'}]},registry,earned),/surface/));
test(()=>assert.throws(()=>resolve({...base,decals:[d,d]},registry,earned),/layer/));
test(()=>assert.throws(()=>resolve({...base,revision:NaN},registry,earned),/revision/));
test(()=>assert.throws(()=>resolve({...base,weapon:'http://bad.example'},registry,earned),/ID/));
test(()=>{let a={...base,charms:['aoa_upgrade:lantern'],decals:[d]};let r=resolve(a,registry,earned);a.charms.length=0;a.decals[0].glow=1;assert.equal(r.charms.length,1);assert.equal(r.decals[0].glow,.3);assert.throws(()=>{r.bonuses.efficiencyAdd=99;},TypeError);});
test(()=>{let bad={...registry,'aoa_upgrade:sticker':{...registry['aoa_upgrade:sticker'],assetSha256:'https://tracking.invalid/a.png'}};assert.throws(()=>resolve({...base,decals:[d]},bad,earned),/hash/);});
console.log(JSON.stringify({tests:count,status:'pass',scope:'Standalone design validation only; no native game integration or performance acceptance'}));
