'use strict';
const assert=require('node:assert/strict');const {InspectionTimeline:T}=require('./inspection_timeline.cjs');
function run(step){const t=new T(),events=[t.start(3)];for(let n=0;n<10000&&t.active;n++)events.push(...t.advance(step));assert.equal(t.active,false);return events;}
for(const step of [1/30,1/60,1/144,.5])assert.deepEqual(run(step),run(1/20));
{const q=new T();q.start(0);const e=q.advance(10);assert.equal(e.length,1);assert.equal(e[0].reason,'completed_after_stall');}
{const q=new T();q.start(0);const e=q.advance(2.5);assert.equal(e.length,1);assert.equal(e[0].type,'resync');assert.equal(e[0].phase,'play');assert.equal(q.advance(.1).length,0);}
let t=new T();t.start(1);assert.throws(()=>t.start(1),/existing/);assert.deepEqual(t.advance(100,{paused:true}),[]);assert.equal(t.elapsed,0);assert.equal(t.cancel('attack')[0].reason,'attack');assert.deepEqual(t.cancel(),[]);assert.deepEqual(t.advance(10),[]);
t.start(2);assert.equal(t.advance(.5,{assemblyRevision:3})[0].reason,'assembly_changed');assert.equal(t.active,false);
for(const n of [NaN,Infinity,-1])assert.throws(()=>new T().advance(n),/elapsed/);
assert.throws(()=>new T().start(-1),/revision/);
for(const cut of [0,.2,.7,1.4,2.3,3.7,4.49]){const q=new T();q.start(0);q.advance(cut);assert.equal(q.cancel('weapon_swap').length,1);assert.equal(q.advance(10).length,0);}
assert.equal(run(.1).filter(x=>x.type==='cleanup').length,1);
console.log(JSON.stringify({status:'pass',cadenceCases:4,stallCases:2,cancellationPoints:7,scope:'Presentation timing only; native pose blending, input priority and effects cleanup require game integration'}));
