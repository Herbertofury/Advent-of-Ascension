# Original standalone design study

Run node test_customization_contract.cjs and node test_inspection_timeline.cjs.
No Minecraft, Forge or TaCZ integration is included. This is not an installable mod. The first helper validates immutable proposed customization snapshots; the second emits presentation-only inspect beats, resynchronizes after long stalls, and requests cleanup on cancellation. Native input priority, pose blending, effect removal and multiplayer remain unimplemented.
