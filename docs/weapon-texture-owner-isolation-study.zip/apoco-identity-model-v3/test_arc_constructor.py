"""Execute the actual builder's constructor AST against thin-band regressions."""
import bpy,bmesh,math,ast,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;source=R/'build.py';tree=ast.parse(source.read_text());chosen=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in ['finish','mesh','arc_shell']];assert len(chosen)==3
bpy.ops.wm.read_factory_settings(use_empty=True);root=bpy.data.objects.new('Fixture root',None);bpy.context.collection.objects.link(root);M={'test':bpy.data.materials.new('test')};parts=[];rich=True;exec(compile(ast.Module(body=chosen,type_ignores=[]),str(source),'exec'));rows=[]
for rich in [False,True]:
 for width in [.005,.02,.055,.3]:
  for thickness in [.004,.02,.2]:
   o=arc_shell('Actual thin-band fixture',0,0,0,width,.5,.5+thickness,.25,math.pi-.1,'test');bpy.context.view_layer.update();e=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=e.to_mesh();me.calc_loop_triangles();bad=sum(t.area<=1e-12 for t in me.loop_triangles);bm=bmesh.new();bm.from_mesh(me);closed=all(x.is_manifold for x in bm.edges);volume=bm.calc_volume(signed=True);bm.free();rows.append({'rich':rich,'width':width,'radial_thickness':thickness,'triangles':len(me.loop_triangles),'degenerate':bad,'closed':closed,'signed_volume':volume});e.to_mesh_clear();bpy.data.objects.remove(o,do_unlink=True);assert bad==0 and closed and volume>0,rows[-1]
report={'builder_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'fixture_count':len(rows),'results':rows,'scope':'Actual constructor in listed positive finite ranges; not native rendering or all possible inputs'};(R/'arc-constructor-qa.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS',len(rows),'thin-band constructor fixtures')
