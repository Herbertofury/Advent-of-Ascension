"""Compact identity-first fictional prop study. Not native gameplay or completed art."""
import bpy,bmesh,math,json,sys,argparse
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--profile',choices=['minecraft_fit','concept_faithful'],default='concept_faithful');a=p.parse_args(sys.argv[sys.argv.index('--')+1:]if'--'in sys.argv else[]);OUT=R/a.profile;OUT.mkdir(exist_ok=True);rich=a.profile=='concept_faithful';bpy.ops.wm.read_factory_settings(use_empty=True);root=bpy.data.objects.new('Apoco_identity_root',None);bpy.context.collection.objects.link(root);parts=[]
def material(name,color,metal,rough):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;l=m.node_tree.links;b=n.get('Principled BSDF');b.inputs['Metallic'].default_value=metal;b.inputs['Roughness'].default_value=rough;geo=n.new('ShaderNodeTexCoord');noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=24 if rich else 5;noise.inputs['Detail'].default_value=3
 if rich:l.new(geo.outputs['Generated'],noise.inputs['Vector'])
 else:
  snap=n.new('ShaderNodeVectorMath');snap.operation='SNAP';snap.inputs[1].default_value=(.06,.06,.06);l.new(geo.outputs['Generated'],snap.inputs[0]);l.new(snap.outputs[0],noise.inputs['Vector'])
 ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].color=tuple(c*.65 for c in color)+(1,);ramp.color_ramp.elements[1].color=tuple(min(1,c*1.25)for c in color)+(1,);ramp.color_ramp.interpolation='LINEAR'if rich else'CONSTANT';l.new(noise.outputs['Fac'],ramp.inputs[0]);l.new(ramp.outputs[0],b.inputs['Base Color'])
 if rich:
  bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.10;bump.inputs['Distance'].default_value=.012;l.new(noise.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs['Normal'],b.inputs['Normal'])
 return m
M={k:material(k,*v)for k,v in {'Olive armored enamel':((.095,.14,.055),.55,.32),'Scarlet lacquer':((.32,.009,.006),.55,.25),'Aged gold':((.48,.25,.065),.75,.29),'Black steel':((.025,.032,.027),.7,.34),'Grip leather':((.018,.022,.016),.15,.68),'Edge steel':((.15,.17,.14),.8,.25)}.items()};m=bpy.data.materials.new('Red status crystal');m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.8,.005,.001,1);bs.inputs['Emission Color'].default_value=(1,.002,.001,1);bs.inputs['Emission Strength'].default_value=2;M['Red status crystal']=m

def finish(o,name,mat,bevel=0):
 o.name=name;o.data.materials.append(M[mat]);w=o.matrix_world.copy();o.parent=root;o.matrix_world=w
 if bevel:
  b=o.modifiers.new('Controlled bevel','BEVEL');b.width=bevel;b.segments=3 if rich else 1
 parts.append(name);return o

def box(name,loc,dim,mat):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,mat,min(.035,min(dim)*.18))

def mesh(name,v,f,mat,bevel=.02):
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(me);bm.free();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);return finish(o,name,mat,bevel)

def profile(name,xz,y,depth,mat):
 N=len(xz);v=[(x,y+d,z)for d in [-depth/2,depth/2]for x,z in xz];f=[tuple(reversed(range(N))),tuple(range(N,2*N))]+[(i,(i+1)%N,(i+1)%N+N,i+N)for i in range(N)];return mesh(name,v,f,mat,min(.025,depth*.15))

def tube(name,pts,radius,mat):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=1;c.bevel_depth=radius;c.bevel_resolution=3 if rich else 1;sp=c.splines.new('POLY');sp.points.add(len(pts)-1)
 for p,co in zip(sp.points,pts):p.co=(*co,1)
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);return finish(o,name,mat)

def cylinder(name,loc,radius,depth,mat,axis='X'):
 rot=(0,math.pi/2,0)if axis=='X'else(math.pi/2,0,0);bpy.ops.mesh.primitive_cylinder_add(vertices=48 if rich else 16,radius=radius,depth=depth,location=loc,rotation=rot);return finish(bpy.context.object,name,mat,min(.025,depth*.15,radius*.1))

def arc_shell(name,cx,cz,y,width,inner,outer,start,end,mat):
 steps=40 if rich else 16;v=[]
 for dy in [-width/2,width/2]:
  for radius in [inner,outer]:
   for i in range(steps+1):angle=start+(end-start)*i/steps;v.append((cx+y+dy,radius*math.cos(angle),cz+radius*math.sin(angle)))
 n=steps+1;f=[]
 for i in range(steps):
  f.extend([(i,i+1,n+i+1,n+i),(2*n+i,3*n+i,3*n+i+1,2*n+i+1),(i,2*n+i,2*n+i+1,i+1),(n+i,n+i+1,3*n+i+1,3*n+i)])
 f.extend([(0,n,3*n,2*n),(n-1,3*n-1,4*n-1,2*n-1)]);return mesh(name,v,f,mat,min(.012,(outer-inner)*.2,width*.2))
# Compact broad body; no inherited generic rifle stock or hanging magazine.
body=[(-2.75,.15),(-2.90,.60),(-2.55,1.3),(-1.5,1.42),(-.8,1.25),(.1,1.32),(2.45,1.2),(2.72,.94),(2.65,.22),(1.92,.12),(1.5,-.08),(.4,-.05),(.0,-.24),(-1.5,-.2),(-2.0,.03)]
profile('Compact olive main body',body,0,.86,'Olive armored enamel')
profile('Enclosed lower receiver',[(-2.55,.17),(-2.25,.4),(1.9,.3),(2.48,.1),(2.20,-.28),(.35,-.3),(-.1,-.65),(-.6,-.62),(-.8,-.2),(-2.4,-.15)],0,.68,'Black steel')
# Dense sculpted crimson rear housing with pronounced original rounded upper structures.
cylinder('Rear upper housing inner',(-2.15,0,1.45),.69,1.05,'Black steel','X')
arc_shell('Rear scarlet crown',-2.15,1.45,0,1.14,.67,.86,-.05,math.pi+.25,'Scarlet lacquer')
arc_shell('Rear gold crown band',-2.15,1.45,-.16,.13,.86,.90,.12,math.pi+.10,'Aged gold')
arc_shell('Rear status seam',-2.15,1.45,.18,.055,.86,.88,.25,math.pi-.1,'Red status crystal')
cylinder('Forward upper housing inner',(.50,0,1.40),.48,.95,'Black steel','X')
arc_shell('Forward scarlet crown',.50,1.40,0,1.04,.47,.68,.08,math.pi+.18,'Scarlet lacquer')
arc_shell('Forward gold crown band',.50,1.40,0,.16,.68,.72,.18,math.pi+.08,'Aged gold')
for side in [-1,1]:
 y=side*.52
 profile('Sculpted rear scarlet cheek '+str(side),[(-3.0,.55),(-2.9,1.0),(-2.5,1.48),(-1.9,1.39),(-1.60,1.02),(-1.15,.80),(-1.45,.53),(-2.0,.63),(-2.55,.35)],y,.19,'Scarlet lacquer')
 profile('Layered green flank '+str(side),[(-1.75,.42),(-1.5,.88),(-.8,.88),(-.3,1.06),(1.8,1.0),(2.3,.72),(2.12,.49),(.42,.50),(.12,.27),(-.35,-.31),(-.65,-.25),(-.54,.25)],side*.50,.15,'Olive armored enamel')
 profile('Forward scarlet bracket '+str(side),[(.65,.95),(1.8,1.21),(2.38,1.10),(2.13,.82),(1.08,.72),(1.22,.32),(1.80,.25),(1.63,.10),(.71,.22),(.42,.47)],side*.57,.15,'Scarlet lacquer')
 tube('Green armor edge seam '+str(side),[(-1.55,side*.59,.47),(-1.32,side*.59,.73),(-.72,side*.59,.73),(-.25,side*.59,.89),(1.7,side*.59,.84)],.014,'Edge steel')
 for x,z in [(-2.55,.78),(-1.72,.62),(-.70,.55),(.23,.37),(1.72,.67),(2.1,.91)]:cylinder('Seated armor fastener',(x,side*.65,z),.046,.035,'Aged gold','Y')
 profile('Compact lower gold tab '+str(side),[(-.15,-.50),(.05,-.70),(.18,-.63),(.24,-.30),(.01,-.22)],side*.40,.12,'Aged gold')
 box('Rear status inset '+str(side),(-2.65,side*.64,.55),(.28,.035,.09),'Red status crystal')
# Narrow forward barrel and open segmented fictional shroud.
cylinder('Forward barrel housing',(3.0,0,.67),.36,1.22,'Black steel')
cylinder('Gold forward collar',(2.65,0,.67),.49,.20,'Aged gold')
for x in [3.55,4.20]:
 # Closed annular ring whose central aperture is real geometry.
 N=48 if rich else 16;v=[]
 for xx in [x-.07,x+.07]:
  for radius in [.28,.46]:
   for i in range(N):t=math.tau*i/N;v.append((xx,radius*math.cos(t),.67+radius*math.sin(t)))
 f=[]
 for i in range(N):j=(i+1)%N;f.extend([(i,j,N+j,N+i),(2*N+i,3*N+i,3*N+j,2*N+j),(i,2*N+i,2*N+j,j),(N+i,N+j,3*N+j,3*N+i)])
 mesh('Open shroud ring '+str(x),v,f,'Black steel',.01)
for i in range(6):
 t=math.tau*i/6;o=box('Shroud axial rail '+str(i),(3.87,.40*math.cos(t),.67+.40*math.sin(t)),(.58,.16,.16),'Black steel')
 t+=math.pi/6;tube('Red recessed muzzle status '+str(i),[(3.70,.31*math.cos(t),.67+.31*math.sin(t)),(4.07,.31*math.cos(t),.67+.31*math.sin(t))],.025,'Red status crystal')
# Gold lower fittings and contained dark crossbar are key original silhouette landmarks.
cylinder('Underslung contained crossbar',(1.35,0,-.40),.13,1.75,'Black steel')
for x in [.57,2.10]:
 cylinder('Lower gold fitting '+str(x),(x,0,-.39),.27,.24,'Aged gold')
 for side in [-1,1]:box('Gold fitting lug '+str(x)+' '+str(side),(x,side*.22,-.40),(.28,.18,.30),'Aged gold')
# Compact ergonomic rear grip with a physically connected heel and guard.
grip=[(-2.74,.19),(-2.23,.09),(-2.20,-.22),(-2.44,-.50),(-2.57,-.98),(-2.91,-1.51),(-3.36,-1.44),(-3.12,-1.14),(-3.00,-.68),(-2.95,-.20)]
profile('Compact curved rear grip',grip,0,.56,'Grip leather')
profile('Fitted gold grip heel',[(-3.36,-1.44),(-2.91,-1.51),(-2.78,-1.31),(-3.22,-1.25)],0,.67,'Aged gold')
for side in [-1,1]:
 profile('Olive grip side inset '+str(side),[(-2.77,-.1),(-2.43,-.15),(-2.64,-.82),(-2.96,-1.22),(-3.11,-1.16),(-2.93,-.63)],side*.295,.035,'Olive armored enamel')
 for j in range(4):tube('Grip contour groove '+str(side)+' '+str(j),[(-2.91-j*.035,side*.323,-.40-j*.16),(-2.72-j*.05,side*.323,-.45-j*.16)],.011,'Black steel')
tube('Connected curved trigger guard',[(-2.20,0,.02),(-1.78,0,-.03),(-1.65,0,-.28),(-1.8,0,-.55),(-2.15,0,-.58),(-2.40,0,-.45)],.055,'Black steel')
profile('Trigger paddle',[(-2.06,.03),(-1.94,.03),(-1.97,-.26),(-2.08,-.34),(-2.12,-.27)],0,.12,'Aged gold')
# No gameplay/data behavior is generated by the visual-profile flag.
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.use_denoising=False;s.render.resolution_x=1600;s.render.resolution_y=1000;s.render.resolution_percentage=100;s.world=bpy.data.worlds.new('Dark studio');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.007,.009,.012,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.3;s.view_settings.view_transform='AgX';s.view_settings.exposure=-.5
bpy.ops.object.camera_add(location=(8,17,5));cam=bpy.context.object;cam.rotation_euler=(Vector((.3,0,.4))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=10.5;s.camera=cam
for name,loc,power,size in [('Key',(4,6,8),1400,6),('Fill',(-4,3,2),800,5),('Rim',(-1,-5,6),1800,5)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.size=size;o.rotation_euler=(Vector((.3,0,.5))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'apoco-identity.blend'));s.render.filepath=str(OUT/'hero.png');bpy.ops.render.render(write_still=True);(OUT/'manifest.json').write_text(json.dumps({'status':'Unaccepted compact identity study','profile':a.profile,'source_concept':'apoco-assault-rifle-canonical-concept-v2.png','part_names':parts,'geometry_and_material_qa':'pending','native_acceptance':False,'limits':['Profiles are authoring experiments, not implemented in-game switch','Procedural base materials are not finished texture work','No native hands, animation, effects or gameplay integration']},indent=2)+'\n')
