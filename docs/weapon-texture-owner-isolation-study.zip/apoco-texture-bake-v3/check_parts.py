import bpy,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'apoco-baked-study.blend'));model=bpy.data.objects['Apoco_baked_export_study'];ids=model.data.attributes['SourcePartId'].data;owners=json.loads((R/'part-ownership.json').read_text())['owners'];max_position=0;max_uv=0;max_normal=0;loop_count=0;errors=[];normal_errors=[]
for part_id,row in enumerate(owners):
 obj=bpy.data.objects[row['part']];source=[p for p in model.data.polygons if ids[p.index].value==part_id];vertices=sorted({v for p in source for v in p.vertices})
 if obj.parent.name!=row['owner']:errors.append('Wrong owner '+obj.name)
 if len(obj.data.polygons)!=len(source)or len(obj.data.vertices)!=len(vertices):errors.append('Topology count mismatch '+obj.name);continue
 for dst,src in zip(obj.data.vertices,vertices):max_position=max(max_position,(obj.matrix_world@dst.co-model.matrix_world@model.data.vertices[src].co).length)
 for dp,sp in zip(obj.data.polygons,source):
  if dp.material_index!=sp.material_index:errors.append('Material mismatch '+obj.name)
  for dl,sl in zip(dp.loop_indices,sp.loop_indices):
   max_uv=max(max_uv,(obj.data.uv_layers.active.data[dl].uv-model.data.uv_layers.active.data[sl].uv).length);loop_count+=1;error=(obj.data.corner_normals[dl].vector-model.data.corner_normals[sl].vector).length;max_normal=max(max_normal,error);
   if error>.001:normal_errors.append([obj.name,dl,sl,error])
part=bpy.data.objects[owners[0]['part']];owner=part.parent;bpy.context.view_layer.update();before=part.matrix_world@part.data.vertices[0].co;old=owner.location.copy();owner.location.x+=.125;bpy.context.view_layer.update();after=part.matrix_world@part.data.vertices[0].co;owner.location=old;bpy.context.view_layer.update();motion_error=(after-before-Vector((.125,0,0))).length
report={'parts':len(owners),'uv_loops_checked':loop_count,'maximum_world_position_error':max_position,'maximum_uv_error':max_uv,'maximum_corner_normal_vector_error':max_normal,'controlled_owner_translation_error':motion_error,'errors':errors,'normal_error_samples':sorted(normal_errors,key=lambda r:-r[3])[:20],'normal_error_count':len(normal_errors),'scope':'Rest-pose reconstruction and one controlled source-owner translation; no native animation or full clip acceptance'};(R/'part-reconstruction-qa.json').write_text(json.dumps(report,indent=2)+'\n');print(report);assert not errors and max_position<1e-5 and max_uv==0 and motion_error<1e-5 and max_normal<.001
