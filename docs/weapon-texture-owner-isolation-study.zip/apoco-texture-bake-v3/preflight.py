import bpy,bmesh,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;source=R.parent/'apoco-material-authoring-v1/apoco-painted-source.blend';bpy.ops.wm.open_mainfile(filepath=str(source));materials={m.name:m for o in bpy.data.objects if o.type in {'MESH','CURVE'}and not o.hide_render for m in o.data.materials if m};errors=[];rows=[]
for name,m in materials.items():
 p=m.node_tree.nodes.get('Principled BSDF')if m.use_nodes else None;output=next((n for n in m.node_tree.nodes if n.type=='OUTPUT_MATERIAL'and n.is_active_output),None)if m.use_nodes else None
 issues=[]
 if p is None or output is None:issues.append('Expected opaque Principled material')
 else:
  if p.inputs['Alpha'].is_linked or p.inputs['Alpha'].default_value!=1:issues.append('Alpha requires a separate tested export path')
  if p.inputs['Emission Strength'].is_linked:issues.append('Linked emission strength requires a separate tested export path')
  if len(output.inputs['Surface'].links)!=1 or output.inputs['Surface'].links[0].from_node!=p:issues.append('Mixed surface shader is unsupported by this study')
 rows.append({'material':name,'issues':issues});errors.extend(issues)
# Stop before an expensive bake if the source has collapsed triangles or inward closed solids.
mesh_checks=[];dg=bpy.context.evaluated_depsgraph_get()
for o in bpy.data.objects:
 if o.type not in {'MESH','CURVE'}or o.hide_render:continue
 e=o.evaluated_get(dg);me=e.to_mesh();me.calc_loop_triangles();bad=0
 for t in me.loop_triangles:
  pts=[o.matrix_world@me.vertices[i].co for i in t.vertices]
  if (pts[1]-pts[0]).cross(pts[2]-pts[0]).length_squared<1e-20:bad+=1
 bm=bmesh.new();bm.from_mesh(me);bm.transform(o.matrix_world);closed=bool(bm.edges)and all(edge.is_manifold for edge in bm.edges);volume=bm.calc_volume(signed=True)if closed else None;bm.free();e.to_mesh_clear()
 if bad:errors.append('Collapsed triangles in '+o.name)
 if volume is not None and volume<-1e-9:errors.append('Inward closed solid '+o.name)
 mesh_checks.append({'object':o.name,'degenerate_triangles':bad,'closed_volume':volume})
report={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'materials':rows,'mesh_checks':mesh_checks,'errors':errors,'scope':'This opaque Principled-source bake only; does not authorize reusing it for transparent Soul Storm fire or mixed shaders'};(R/'material-preflight.json').write_text(json.dumps(report,indent=2)+'\n');print('Checked',len(rows),'materials; errors',len(errors));assert not errors
