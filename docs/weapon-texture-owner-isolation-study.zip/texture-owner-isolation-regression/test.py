"""Tiny synthetic regression: baking a nearby removable part must not stain the owner's texture."""
import bpy,json,runpy,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;selector=R.parent/'apoco-texture-bake-v3/owner_selection.py';select_owner_pair=runpy.run_path(str(selector))['select_owner_pair'];bpy.ops.wm.read_factory_settings(use_empty=True)
def plane(name,z,color):
 bpy.ops.mesh.primitive_plane_add(size=2,location=(0,0,z));o=bpy.context.object;o.name=name;m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;n.clear();e=n.new('ShaderNodeEmission');e.inputs['Color'].default_value=(*color,1);out=n.new('ShaderNodeOutputMaterial');m.node_tree.links.new(e.outputs[0],out.inputs['Surface']);o.data.materials.append(m);return o
owner=plane('Red owner',0,(1,0,0));neighbor=plane('Removable blue neighbor',.001,(0,0,1));target=plane('Owner atlas target',0,(0,0,0));decoy=plane('Hidden previously selected merged mesh',.0005,(0,1,0));decoy.hide_render=True;s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=1;s.cycles.use_denoising=False;s.render.bake.use_selected_to_active=True;s.render.bake.cage_extrusion=.003;s.render.bake.max_ray_distance=.01;s.render.bake.margin=0;s.render.bake.use_clear=True;results={}
for isolated in [False,True]:
 bpy.ops.object.select_all(action='DESELECT');owner.select_set(True);target.select_set(True);neighbor.hide_render=isolated;neighbor.select_set(not isolated);bpy.context.view_layer.objects.active=target
 if isolated:
  decoy.select_set(True);select_owner_pair(owner,target,[owner,neighbor],[target]);assert not decoy.select_get()
 im=bpy.data.images.new('isolated'if isolated else'combined',64,64,alpha=True);m=target.data.materials[0];node=m.node_tree.nodes.new('ShaderNodeTexImage');node.image=im;m.node_tree.nodes.active=node;bpy.ops.object.bake(type='EMIT');pixel=list(im.pixels)[4*(32*64+32):4*(32*64+32)+4];results['per_owner'if isolated else'all_sources']=pixel;m.node_tree.nodes.remove(node)
assert results['all_sources'][2]>.99 and results['all_sources'][0]<.01,results
assert results['per_owner'][0]>.99 and results['per_owner'][2]<.01,results
(R/'result.json').write_text(json.dumps({'status':'passed synthetic isolation regression','samples':results,'hidden_selected_decoy_cleared':not decoy.select_get(),'selector_sha256':hashlib.sha256(selector.read_bytes()).hexdigest(),'finding':'All-source projection copied the blue neighbor onto the red owner. Isolating the source owner preserved red.','scope':'Selected-to-active source ownership only, not full UV or native correctness'},indent=2)+'\n');print(results)
