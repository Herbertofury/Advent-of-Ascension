"""Original fictional game-asset cutaway study; not a real firearm design or playable mod."""
from pathlib import Path
import json,copy,shutil,hashlib
R=Path(__file__).parent;S=R/'baronator-v2/assets/ascension_armory';D=R/'baronator-mechanism-study/assets/ascension_armory';D.mkdir(parents=True,exist_ok=True)
g=json.loads((S/'geo_models/gun/baronator_geo.json').read_text());geo=g['minecraft:geometry'][0];bones=geo['bones'];by={b['name']:b for b in bones}
a=json.loads((S/'animations/baronator.animation.json').read_text())
def translate(c,y=0,z=0):
 c['origin'][1]+=y;c['origin'][2]+=z
 if 'pivot' in c:c['pivot'][1]+=y;c['pivot'][2]+=z
# Reserve the entire rear hand assembly, without shrinking the hand opening.
for c in by['receiver']['cubes']:
 if c['origin'][1]<-2:translate(c,z=6)
for name in ['trigger','stock']:
 for c in by[name].get('cubes',[]):translate(c,z=6)
 by[name]['pivot'][2]+=6
for name in ['righthand_pos','thirdperson_hand','iron_view']:by[name]['pivot'][2]+=6
# Open the receiver shell; a solid filler block cannot be used as a feed channel.
old=by['receiver']['cubes'];template=copy.deepcopy(old[0]);by['receiver']['cubes']=[]
def cube(b,origin,size,material=None):
 c=copy.deepcopy(template);c['origin']=list(origin);c['size']=list(size);c.pop('rotation',None);c.pop('pivot',None)
 if material:c['uv']=copy.deepcopy(material['uv'])
 b.setdefault('cubes',[]).append(c);return c
for i,c in enumerate(old):
 if i in [0,4]:continue
 if i in [1,2,3]:c['size'][2]+=6
 by['receiver']['cubes'].append(c)
for x in [-2.5,2.15]:cube(by['receiver'],(x,-2.8,-4),(.35,2,17))
cube(by['receiver'],(-2.5,-.8,12.6),(5,4.8,.4))
# Put the magazine behind the barrel ends, beneath the actual transfer space.
for name in ['magazine','magwell']:
 for c in by[name]['cubes']:translate(c,y=-.4,z=7.7)
 by[name]['pivot'][1]-=.4;by[name]['pivot'][2]+=7.7
# Hollow magazine walls and bottom; no solid filler through the source cartridge.
mag=by['magazine'];body=mag['cubes'].pop(0);x,y,z=body['origin'];w,h,d=body['size']
for xx in [x,x+w-.25]:cube(mag,(xx,y,z),(.25,h,d),body)
for zz in [z,z+d-.25]:cube(mag,(x+.25,y,zz),(w-.5,h,.25),body)
# Both barrel rear ends align with their chamber axis, inside a hollow housing.
for name in ['upper_barrel','lower_barrel']:
 for c in by[name]['cubes'][:4]:c['size'][2]=1.5-c['origin'][2]
# An open muzzle must connect all the way through: remove the old visual black plugs.
for name in ['upper_barrel','lower_barrel']:
 by[name]['cubes']=[c for c in by[name]['cubes'] if c['size'][2] != .15]
# Roof-mounted charging sled clears the projectile axis; old solid lower housing becomes a sleeve.
for c in by['bolt']['cubes']:translate(c,y=1.8)
by['bolt']['pivot'][1]+=1.8
sleeve=by['grenade_breech'];finish=copy.deepcopy(sleeve['cubes'][0]);sleeve['cubes']=[]
for x in [-1.8,1.55]:cube(sleeve,(x,-3.35,-2.8),(.25,3.1,4.2),finish)
for y in [-3.35,-.5]:cube(sleeve,(-1.55,y,-2.8),(3.1,.25,4.2),finish)
for name,cy in [('upper',2),('lower',-1.8)]:
 b={'name':'chamber_housing_'+name,'parent':'root','pivot':[0,cy,2.5]};bones.append(b)
 for xx in [-1.75,1.45]:cube(b,(xx,cy-1.45,1.5),(.3,2.9,3))
 for yy in [cy-1.45,cy+1.15]:cube(b,(-1.45,yy,1.5),(2.9,.3,3))
# Move the decorative core out of the upper feed route; it is now a side indicator.
core=by['core']['cubes'][0];core['origin']=[2.85,2.3,8];core['size']=[.3,1.3,1.4];by['core']['pivot']=[3,2.95,8.7]
# Preview hands follow TaCZ's documented Steve arm convention. Engine fit remains unqualified.
# Right palm sits behind the guard; the support arm angles outward under a fixed foregrip.
by['righthand_pos']['pivot']=[6,-3.8,23.4];by['righthand_pos']['rotation']=[-90,0,0]
by['lefthand_pos']['pivot']=[-13.009, -5.45, 3.340];by['lefthand_pos']['rotation']=[-90,-25,0]
for name,offset in [('righthand_pos',[-8,0,-2]),('lefthand_pos',[4,0,-2])]:
 b=by[name];cube(b,[b['pivot'][i]+offset[i] for i in range(3)],[4,12,4],by['stock']['cubes'][1])
fore={'name':'support_grip','parent':'root','pivot':[-2,-3.6,-5.5]};bones.append(fore)
cube(fore,(-2.8,-4.1,-6.5),(2,1,2),by['receiver']['cubes'][0])
cube(fore,(-2.8,-3.1,-6.5),(.4,4.4,1),by['receiver']['cubes'][0])
locators={'ammo_supply':[0,-4.3,5.1],'feed_entry':[0,-3.6,5.1],'transfer_route':[0,.1,5.1],'chamber_upper':[0,2,2.5],'chamber_lower':[0,-1.8,2.5],'barrel_rear_upper':[0,2,1.5],'barrel_rear_lower':[0,-1.8,1.5]}
for name,pivot in locators.items():bones.append({'name':name,'parent':'root','pivot':pivot})
roundbone={'name':'demonstration_round','parent':'root','pivot':locators['ammo_supply']};bones.append(roundbone);cube(roundbone,(-.325,-4.625,4.6),(.65,.65,1),mag['cubes'][0])
carrier={'name':'transfer_carrier','parent':'root','pivot':locators['ammo_supply']};bones.append(carrier);cube(carrier,(-.6,-4.825,4.5),(1.2,.2,1.2))
guide={'name':'transfer_guides','parent':'root','pivot':[0,0,5.1]};bones.append(guide)
for x in [-.85,.73]:cube(guide,(x,-4.8,5.65),(.12,7.5,.12))
paths={}
for channel,cy in [('upper',2),('lower',-1.8)]:
 points=[locators['ammo_supply'],locators['feed_entry'],[0,cy,5.1],locators['chamber_'+channel]];paths[channel]=points
 a['animations']['mechanism_feed_'+channel]={'animation_length':3.2,'loop':False,'bones':{'demonstration_round':{'position':{str(t):[p[i]-locators['ammo_supply'][i] for i in range(3)] for t,p in zip([0,.4,1.2,1.8],points)}}}}
for channel,cy in [('upper',2),('lower',-1.8)]:
 clip=a['animations']['mechanism_feed_'+channel];roundkeys=clip['bones']['demonstration_round']['position'];roundkeys['3.2']=roundkeys['1.8']
 ck=copy.deepcopy(roundkeys);ck.pop('3.2');ck['2.2']=ck['1.8'];ck['2.65']=[0,cy-locators['ammo_supply'][1],0];ck['3.2']=[0,0,0]
 clip['bones']['transfer_carrier']={'position':ck}
# Slow inspection cycle: carrier clears before the visual shot. No ammo or damage side effects.
cycle_events={}
for channel in ['upper','lower']:
 cycle=copy.deepcopy(a['animations']['mechanism_feed_'+channel]);cycle['animation_length']=3.9
 cycle['bones']['demonstration_round']['scale']={'0':[1,1,1],'3.399999':[1,1,1],'3.4':[0,0,0],'3.9':[0,0,0]}
 for bone,tracks in a['animations']['shoot_'+channel]['bones'].items():
  cycle['bones'][bone]={key:{str(round(float(t)+3.4,6)):value for t,value in keys.items()} for key,keys in tracks.items()}
 a['animations']['mechanism_cycle_'+channel]=cycle
 cycle_events[channel]={'cartridge_seated':1.8,'carrier_home':3.2,'visual_discharge':3.4,'recoil_recovered':3.65,'scope':'inspection timing only, never native firing cadence or ammo logic'}
for rel,obj in [('geo_models/gun/baronator_geo.json',g),('animations/baronator.animation.json',a)]:
 p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n')
for rel in ['textures/gun/uv/baronator.png','display/guns/baronator_display.json']:
 p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(S/rel,p)
contract={'stage':'unpublished fictional mechanism blockout, unqualified','purpose':'Demonstrate a connected visible route before refining exterior art; does not certify real-world operation.','paths':paths,'inspection_cycle_events':cycle_events,'cartridge_proxy_size':[.65,.65,1],'hand_envelope':{'origin':[-1.1,-4.2,7.2],'size':[2.2,1.4,1.4]},'cutaway_hide':['receiver','upper_shroud','vent_left','vent_right','stock','sight'],'known_open':['transfer drive details, action gates and complete firing-cycle choreography','source-to-round ownership and reload state','actual AoA/TaCZ hand fit','all dynamic part contacts','native runtime','secondary grenade presentation'],'geometry_sha256':hashlib.sha256((D/'geo_models/gun/baronator_geo.json').read_bytes()).hexdigest()}
(R/'baronator-mechanism-study/layout-contract.json').write_text(json.dumps(contract,indent=2)+'\n');print(len(bones),'bones',sum(len(b.get('cubes',[])) for b in bones),'cuboids; two feed-path studies')
