# Baronator mechanism inspection study

Not an installable TaCZ gunpack. Original game-art blockout, generators and scoped QA. Read DESIGN-BRIEF.md inside baronator-mechanism-study and RESEARCH-AND-ACCEPTANCE.md. Full reload handoff, action logic, engine hands, native integration and performance remain unqualified. No upstream gunpack art or scripts are included.
