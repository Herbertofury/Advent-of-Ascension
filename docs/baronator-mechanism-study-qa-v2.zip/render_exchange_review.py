from pathlib import Path
import bpy,math,json
from mathutils import Vector,Euler
R=Path(__file__).resolve().parent
source=(R/'render_baronator_v2.py').read_text().replace("R/'baronator-v2/assets/ascension_armory'","R/'baronator-mechanism-study/assets/ascension_armory'").replace('baronator-v2-authoring.blend','baronator-exchange-review.blend').replace(';bpy.ops.render.render(write_still=True)','')
source=source.replace("bones[b['name']]=ob","bones[b['name']]=ob;ob.rotation_euler=(C@Euler(tuple(math.radians(v) for v in b.get('rotation',[0,0,0])),'XYZ').to_matrix()@C.inverted()).to_euler()")
exec(compile(source,str(R/'render_baronator_v2.py'),'exec'))
scene.render.resolution_x=900;scene.render.resolution_y=650;scene.display.shading.light='STUDIO';scene.display.shading.show_cavity=True;scene.display.shading.color_type='MATERIAL';cam.data.ortho_scale=40
base={n:o.location.copy() for n,o in bones.items()};base_r={b['name']:b.get('rotation',[0,0,0])for b in geo['bones']};clip=animations['mechanism_magazine_exchange'];out=R/'exchange-review';out.mkdir(exist_ok=True)
def sample(ks,t,default):
 if not ks:return default
 pairs=sorted((float(k),v) for k,v in ks.items())
 if t<=pairs[0][0]:return pairs[0][1]
 for (a,x),(b,y) in zip(pairs,pairs[1:]):
  if t<=b:return [u+(v-u)*(t-a)/(b-a) for u,v in zip(x,y)]
 return pairs[-1][1]
for angle,loc in [('side',(40,0,4)),('front',(-25,30,10)),('rear',(12,-32,8))]:
 cam.location=loc;cam.rotation_euler=(Vector((0,-2,-4))-cam.location).to_track_quat('-Z','Y').to_euler()
 for i,t in enumerate([0,.25,.35,.8,1.45,1.8,2.2]):
  for name,ob in bones.items():
   ch=clip['bones'].get(name,{});p=sample(ch.get('position'),t,[0,0,0]);rot=sample(ch.get('rotation'),t,[0,0,0]);ob.location=base[name]+Vector((p[0],-p[2],p[1]));ob.rotation_euler=(C@Euler(tuple(math.radians(rot[i]+base_r[name][i])for i in range(3)),'XYZ').to_matrix()@C.inverted()).to_euler();ob.scale=sample(ch.get('scale'),t,[1,1,1])
  scene.render.filepath=str(out/f'{angle}-{i}.png');bpy.ops.render.render(write_still=True)
print('Rendered 21 hand/magazine exchange review poses')
