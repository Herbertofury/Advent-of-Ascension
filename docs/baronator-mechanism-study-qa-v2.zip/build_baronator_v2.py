from pathlib import Path
import json,copy,shutil,hashlib
R=Path(__file__).parent;src=R/'prototype/assets/ascension_armory';dst=R/'baronator-v2/assets/ascension_armory';dst.mkdir(parents=True,exist_ok=True)
g=json.load(open(src/'geo_models/gun/baronator_geo.json'));geo=g['minecraft:geometry'][0];bones=geo['bones'];by={b['name']:b for b in bones}
# Separate reciprocating barrel parts from fixed red armor. V1's upper group contains both.
upper=by['upper_shroud'];assert len(upper['cubes'])==27;moving=upper['cubes'][:17];fixed=upper['cubes'][17:]
upper['cubes']=fixed;bones.append({'name':'upper_barrel','parent':'root','pivot':[0,2,-6],'cubes':moving});lower=by['lower_shroud'];lower['name']='lower_barrel';lower['pivot']=[0,-1.8,-5]
bones.extend([{'name':'muzzle_upper','parent':'upper_barrel','pivot':[0,2,-17]},{'name':'muzzle_lower','parent':'lower_barrel','pivot':[0,-1.8,-13]}])
a=json.load(open(src/'animations/baronator.animation.json'));clips=a['animations']
def keys(*p):return {str(t):v for t,v in p}
def shot(which):
 sign=-1 if which=='upper' else 1;barrel='upper_barrel' if which=='upper' else 'lower_barrel';flash=[0,0,0] if which=='upper' else [0,-3.8,4]
 return {'animation_length':.25,'loop':False,'bones':{'root':{'rotation':keys((0,[0,0,0]),(.025,[-6.8,.3*sign,1.3*sign]),(.085,[-3,.1*sign,.6*sign]),(.16,[.65,0,-.2*sign]),(.25,[0,0,0])),'position':keys((0,[0,0,0]),(.025,[0,.18,1.8]),(.085,[0,.05,.9]),(.18,[0,0,-.1]),(.25,[0,0,0]))},barrel:{'position':keys((0,[0,0,0]),(.025,[0,0,2.3]),(.085,[0,0,1.2]),(.20,[0,0,.1]),(.25,[0,0,0]))},'bolt':{'position':keys((0,[0,0,0]),(.025,[0,0,1.6]),(.09,[0,0,.4]),(.16,[0,0,0]),(.25,[0,0,0]))},'muzzle_flash':{'position':keys((0,flash),(.25,flash))}}}
clips['shoot_upper']=shot('upper');clips['shoot_lower']=shot('lower');clips['shoot']=copy.deepcopy(clips['shoot_upper'])
# A half-second preview contains two visual cues at the original nominal five-tick shot interval.
combined={}
for name,offset in [('shoot_upper',0),('shoot_lower',.25)]:
 for bone,ch in clips[name]['bones'].items():
  for channel,ks in ch.items():
   target=combined.setdefault(bone,{}).setdefault(channel,{})
   for t,v in ks.items():target[str(round(float(t)+offset,6))]=v
# Explicit neutral keys keep the inactive barrel still throughout the other barrel's shot.
combined['muzzle_flash']['position']['0.249999']=[0,0,0]
combined['upper_barrel']['position']['0.5']=[0,0,0];combined['lower_barrel']['position']['0']=[0,0,0];combined['lower_barrel']['position']['0.249999']=[0,0,0]
clips['alternating_barrage_preview']={'animation_length':.5,'loop':True,'bones':combined}
for rel,obj in [('geo_models/gun/baronator_geo.json',g),('animations/baronator.animation.json',a)]:
 p=dst/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n')
for rel in ['textures/gun/uv/baronator.png','display/guns/baronator_display.json']:
 p=dst/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src/rel,p)
policy={'weapon':'aoa3:baronator','status':'authored alternating-barrel prototype; native shot-ack adapter pending','ordering':['upper','lower'],'advance_on':'one confirmed successful native primary shot only','do_not_advance_on':['dry fire','rejected use','duplicate acknowledgement','inspect','reload animation','bonus grenade proc'],'cadence':'Preserve native shot interval; this model animation does not add damage, projectiles, ammo costs or firing delay.','recoil':'Strong model shove and barrel travel. Do not double-apply native gameplay/aim recoil. Reduced visual-motion profile required.','bonus_grenade':'Keep native server probability and behavior independent of barrel alternation.','visual_cue_events':[{'time':0,'locator':'muzzle_upper'},{'time':.25,'locator':'muzzle_lower'}],'qa_open':['first-person hands and camera alignment','real TaCZ lower-muzzle event routing','packet ordering and item lifecycle','sound mix','in-game frame times'],'files':[{'path':p.relative_to(R/'baronator-v2').as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(dst.rglob('*')) if p.is_file()]};(R/'baronator-v2/manifest.json').write_text(json.dumps(policy,indent=2)+'\n');print(len(bones),'bones; upper moving',len(moving),'fixed armor',len(fixed),'records',len(clips))
