# Baronator mechanism inspection study

Not an installable TaCZ gunpack. Original game-art blockout, generators and scoped QA. Read DESIGN-BRIEF.md inside baronator-mechanism-study and RESEARCH-AND-ACCEPTANCE.md. One hand/magazine exchange study is included; native interruption behavior, action logic, engine hands, integration and performance remain unqualified. No upstream gunpack art or scripts are included.
