from pathlib import Path
import bpy,json,math
from mathutils import Vector,Matrix,Euler
R=Path(__file__).resolve().parent
source=(R/'render_baronator_v2.py').read_text().replace("R/'baronator-v2/assets/ascension_armory'","R/'baronator-mechanism-study/assets/ascension_armory'").replace('baronator-v2-authoring.blend','baronator-mechanism-authoring.blend').replace(';bpy.ops.render.render(write_still=True)','')
source=source.replace("bones[b['name']]=ob","bones[b['name']]=ob;ob.rotation_euler=(C@Euler(tuple(math.radians(v) for v in b.get('rotation',[0,0,0])),'XYZ').to_matrix()@C.inverted()).to_euler()")
exec(compile(source,str(R/'render_baronator_v2.py'),'exec'))
scene=bpy.context.scene;scene.render.engine='BLENDER_WORKBENCH';scene.render.resolution_x=1000;scene.render.resolution_y=600;scene.display.shading.light='STUDIO';scene.display.shading.show_cavity=True;scene.display.shading.color_type='MATERIAL';cam=scene.camera;cam.location=(40,-1,4);cam.rotation_euler=(Vector((0,0,-1.5))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=39
# Deliberate inspection cutaway; hidden shell components remain in the exported model and collision audit.
for b in geo['bones']:
 for i,c in enumerate(b.get('cubes',[])):
  name=b['name'];ob=bpy.data.objects[name+'_'+str(i)]
  if (name=='receiver' and (c['origin'][1]>=-2 or c['size'][2]>6)) or name in ['upper_shroud','vent_left','vent_right','sight','core','lefthand_pos','righthand_pos'] or (name.startswith('chamber_housing') and i==1) or (name in ['upper_barrel','lower_barrel'] and i==1) or (name=='magazine' and c['origin'][0]>.5):ob.hide_render=True
out=R/'mechanism-cutaway';out.mkdir(exist_ok=True)
base={n:o.location.copy() for n,o in bpy.data.objects.items() if o.type=='EMPTY'};base_rot={n:bpy.data.objects[n].rotation_euler.copy() for n in base}
def sample(ks,t):
 pairs=sorted((float(k),v) for k,v in ks.items())
 if t<=pairs[0][0]:return pairs[0][1]
 for (a,x),(b,y) in zip(pairs,pairs[1:]):
  if t<=b:return [u+(v-u)*(t-a)/(b-a) for u,v in zip(x,y)]
 return pairs[-1][1]
for channel in ['upper','lower']:
 clip=animations['mechanism_feed_'+channel]
 for step,t in enumerate([0,.4,1.2,1.8,2.65,3.2]):
  for n,loc in base.items():
   ob=bpy.data.objects[n];ch=clip['bones'].get(n,{});p=sample(ch['position'],t) if 'position'in ch else [0,0,0];ob.location=loc+Vector((p[0],-p[2],p[1]));ob.rotation_euler=base_rot[n]
  scene.render.filepath=str(out/f'{channel}-{step}.png');bpy.ops.render.render(write_still=True)
print('Rendered 12 exported-geometry mechanism inspection poses')
