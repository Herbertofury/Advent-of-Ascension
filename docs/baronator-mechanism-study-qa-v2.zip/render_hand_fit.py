from pathlib import Path
import bpy,math
from mathutils import Vector
R=Path(__file__).resolve().parent
source=(R/'render_baronator_v2.py').read_text().replace("R/'baronator-v2/assets/ascension_armory'","R/'baronator-mechanism-study/assets/ascension_armory'").replace('baronator-v2-authoring.blend','baronator-mechanism-hand-fit.blend').replace(';bpy.ops.render.render(write_still=True)','')
source=source.replace("bones[b['name']]=ob","bones[b['name']]=ob;ob.rotation_euler=(C@Euler(tuple(math.radians(v) for v in b.get('rotation',[0,0,0])),'XYZ').to_matrix()@C.inverted()).to_euler()")
exec(compile(source,str(R/'render_baronator_v2.py'),'exec'))
scene.render.resolution_x=900;scene.render.resolution_y=600;scene.display.shading.light='STUDIO';scene.display.shading.show_cavity=True;scene.display.shading.color_type='MATERIAL';cam.data.ortho_scale=38
out=R/'mechanism-hand-fit';out.mkdir(exist_ok=True)
for name,loc in [('left',(-35,0,2)),('right',(35,0,2)),('rear',(12,-32,8)),('front',(-16,32,8))]:
 cam.location=loc;cam.rotation_euler=(Vector((0,-1,-1))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True)
