# Baronator: fictional mechanism blockout

This is a game-art mechanism study, not a finished asset, runtime implementation, or real-world firearm engineering design. It supersedes the disconnected forward magazine as a design direction; the live authoring preview is not yet replaced by this study.

## Preserve

- Red, dark-metal and brass fantasy identity.
- Approved upper/lower alternating primary recoil and heavy firing feel.
- Native AoA ammo, timing, cost and bonus grenade behavior. Inspected 1.20 source uses Limonite Bullet through BaseGun; do not casually relabel this an energy-only weapon.
- Full grip and trigger opening. Reloading remains independently optional in gameplay.

## Layout argument

The magazine sits behind the barrel ends, under a hollow action housing. It opens into a reserved transfer space behind both chamber pockets. A visible fictional carrier takes a limonite-ammunition proxy through that space to the selected upper or lower chamber, then withdraws. Each chamber aligns with its own barrel. The housing is built around this space; the path is not drawn through an opaque filler block.

The reference identity is a stylized heavy twin-channel weapon. The carrier is a visual science-fiction mechanism, not a claim that a real firearm can be manufactured or operated from this geometry.

## What is implemented in this study

- Hollow magazine, receiver shell and chamber housings.
- Separate upper/lower chamber and barrel-rear locators.
- Two slow inspection-feed clips with a visible ammunition proxy and returning carrier.
- Full-size rear hand space, separate from the supply and transfer route.
- Static proxy sweeps and exported-pose dynamic checks against all remaining solid cuboids.
- Six interaction-group clearance checks carried across from the earlier regression suite.

## What is still a blocker

- Complete firing-cycle sequencing: staged charge, ready state, discharge, recoil, return, refill and carrier clearance must be coordinated with the native confirmed shot.
- Transfer drive and opening/closing controls need deliberate visible motion; rails alone do not explain every action.
- Physical hand/magazine contact, ownership transitions and reloading interruptions.
- Native inventory supply versus optional magazine mode must remain consistent; cosmetic cartridges cannot debit or invent ammunition.
- The bonus grenade requires a clearly explained, separately confirmed AoA-special-effect presentation. Do not invent an extra consumable or a deterministic five-shot counter.
- Actual TaCZ loader, hand/FOV, multiplayer and performance qualification.

The 3.2-second feed demonstrations are deliberately slow inspection studies. They are not the weapon's fire interval and do not change its native five-tick registration input.

## Additional research-driven checks

The inspection study now traces the full chamber-to-muzzle corridor, rather than stopping at the feed destination. The original solid bore fillers, intrusive actuator and lower housing would fail this check. The study uses open sleeves and a roof-mounted charging sled. These are fictional presentation components, not a pressure-bearing or manufacturable mechanism specification.

The proposed visual language remains a solid-limonite-projectile launcher with a powered transfer assembly. Its charge/launch story and secondary AoA effect need deliberate final review; no real-world physical feasibility certification is claimed.

Documented TaCZ Steve and Alex arm-preview shapes are checked across the authored clips, allowing only named grip contacts within the distal hand region. These arm boxes do not establish completed reloading hand choreography, IK, finger articulation or in-game skin/FOV correctness.

Two slow inspection cycles demonstrate feeding, seating, carrier return, then a visual discharge with the approved recoil curves. They neither consume native ammo nor create a projectile in Minecraft.
