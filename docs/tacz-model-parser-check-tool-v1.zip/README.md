# Isolated TaCZ model-parser check

Run python run_check.py with JAVA_HOME pointing to JDK17+. It downloads nine pinned official TaCZ source files and three known Java libraries, verifies exact SHA256 values and compiles them unmodified with our harness. Gson/Guava versions come from the official Minecraft1.20.1 library manifest; jsr3053.0.2 supplies annotations. This is a model-deserialization study only.

The included net.minecraft.core.Direction is a six-value test stand-in, not the Minecraft class. The real client, rendering classes, GPU, animation deserializers, texture loading, display bindings, Forge and the game are not exercised. A PASS is not a native load/render/playtest pass.

Eight original authoring model files are included, seven distinct hashes, including historical variants and one duplicate copy. They are not eight finished weapons. Parent-first/finite/positive-size assertions are harness checks, not claims that the upstream parser enforces those rules itself. Our current solid-only models do not exercise intentional zero-extent effect planes.

The upstream source files/libraries are fetched from their original sources and are not redistributed in this package. Respect their licenses. Our original model JSON and test harness are the included artifacts.
