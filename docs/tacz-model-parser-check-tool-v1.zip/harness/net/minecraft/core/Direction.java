package net.minecraft.core;
/** Harness-only six-value stand-in. Not Minecraft's class or a native engine test. */
public enum Direction { DOWN, UP, NORTH, SOUTH, WEST, EAST }
