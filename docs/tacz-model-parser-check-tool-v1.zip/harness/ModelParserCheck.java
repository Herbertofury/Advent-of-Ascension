import com.google.gson.*;
import com.tacz.guns.client.resource.pojo.model.*;
import net.minecraft.core.Direction;
import java.nio.file.*;
import java.util.*;
public class ModelParserCheck {
  static final Gson GSON = new GsonBuilder().registerTypeAdapter(CubesItem.class,new CubesItem.Deserializer()).create();
  static void require(boolean b,String msg){if(!b)throw new AssertionError(msg);}
  public static void main(String[] args)throws Exception{
    int models=0,total=0;
    for(String filename:args){
      BedrockModelPOJO m=GSON.fromJson(Files.readString(Path.of(filename)),BedrockModelPOJO.class);
      require("1.12.0".equals(m.getFormatVersion()),"format");GeometryModelNew g=m.getGeometryModelNew().deco();Set<String> names=new HashSet<>();int cubes=0;
      require(g.getDescription().getTextureWidth()>0&&g.getDescription().getTextureHeight()>0,"UV dimensions");
      for(BonesItem b:g.getBones()){require(names.add(b.getName()),"duplicate bone");if(b.getParent()!=null)require(names.contains(b.getParent()),"parent ordering");
        if(b.getCubes()!=null)for(CubesItem c:b.getCubes()){cubes++;require(c.getSize().size()==3&&c.getOrigin().size()==3,"triples");require(c.getSize().stream().allMatch(v->Float.isFinite(v)&&v>0),"positive finite sizes");require(c.getFaceUv()!=null,"custom per-face UV adapter");for(Direction d:Direction.values()){FaceItem face=c.getFaceUv().getFace(d);require(face.getUv().length==2&&face.getUvSize().length==2,"face pair");}}
      }
      models++;total+=cubes;System.out.println("PARSED "+Path.of(filename).getFileName()+" bones="+names.size()+" cubes="+cubes);
    }
    String fixture="{\"format_version\":\"1.12.0\",\"minecraft:geometry\":[{\"bones\":[{\"name\":\"root\",\"mirror\":true,\"cubes\":[{\"size\":[1,1,1],\"origin\":[0,0,0],\"uv\":[0,0]},{\"size\":[1,1,1],\"origin\":[0,0,0],\"uv\":[0,0],\"mirror\":false}]}]}]}";
    var cubes=GSON.fromJson(fixture,BedrockModelPOJO.class).getGeometryModelNew().deco().getBones().get(0).getCubes();require(cubes.get(0).isMirror(),"inherited mirror");require(!cubes.get(1).isMirror()&&cubes.get(1).isHasMirror(),"explicit mirror false wins");
    System.out.println("PASS isolated upstream POJO parser: "+models+" models, "+total+" cuboids, mirror fixture. Direction is a harness stand-in; no native renderer/game acceptance.");
  }
}
