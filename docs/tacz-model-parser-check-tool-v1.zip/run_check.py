"""Fetch pinned public parser dependencies, compile with a full JDK, check bundled original models.
No Minecraft launch; no mod installation; Direction is a declared harness stand-in.
"""
import pathlib,json,hashlib,urllib.request,subprocess,os,shutil
R=pathlib.Path(__file__).resolve().parent;m=json.loads((R/'manifest.json').read_text());cache=R/'cache';cache.mkdir(exist_ok=True)
def fetch(url,path,sha):
 if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==sha:return
 b=urllib.request.urlopen(url).read();assert hashlib.sha256(b).hexdigest()==sha,url;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b)
for f in m['source_files']:fetch(f['url'],cache/f['path'],f['sha256'])
urls={'gson-2.10.jar':'https://libraries.minecraft.net/com/google/code/gson/gson/2.10/gson-2.10.jar','guava-31.1-jre.jar':'https://libraries.minecraft.net/com/google/guava/guava/31.1-jre/guava-31.1-jre.jar','jsr305-3.0.2.jar':'https://repo.maven.apache.org/maven2/com/google/code/findbugs/jsr305/3.0.2/jsr305-3.0.2.jar'}
for f in m['libraries']:fetch(urls[f['file']],cache/'lib'/f['file'],f['sha256'])
home=os.getenv('JAVA_HOME');javac=str(pathlib.Path(home)/'bin/javac')if home else shutil.which('javac');java=str(pathlib.Path(home)/'bin/java')if home else shutil.which('java');assert javac and java,'Set JAVA_HOME to full JDK17+';classes=cache/'classes';classes.mkdir(exist_ok=True);cp=str(cache/'lib/*')
sources=[*sorted((cache/'src').rglob('*.java')),*sorted((R/'harness').rglob('*.java'))];subprocess.run([javac,'--release','17','-cp',cp,'-d',str(classes),*map(str,sources)],check=True)
models=sorted((R/'models').glob('*.json'))
for p in models:assert hashlib.sha256(p.read_bytes()).hexdigest()==m['model_hashes'][p.name],p
subprocess.run([java,'-cp',str(classes)+os.pathsep+cp,'ModelParserCheck',*map(str,models)],check=True)
