"""Verify pinned published baseline data and source identity; no native game execution."""
import argparse,pathlib,json,zipfile,hashlib
p=argparse.ArgumentParser();p.add_argument('jar',type=pathlib.Path);p.add_argument('dataset',type=pathlib.Path);a=p.parse_args();raw=a.dataset.read_bytes();d=json.loads(raw);assert hashlib.sha256(raw).hexdigest()=='fa7841c26103761da8f4b2ffe0ad0242d8bdb860cdab6d41d1ddd9fbeb47df8f','Baseline dataset differs from reviewed version';assert hashlib.sha512(a.jar.read_bytes()).hexdigest()==d['jar_sha512'];rows=d['records'];assert len(rows)==len({r['id']for r in rows})==172
with zipfile.ZipFile(a.jar)as z:
 assert hashlib.sha256(z.read('net/tslat/aoa3/common/registration/item/AoAWeapons.class')).hexdigest()==d['registry_sha256']
 for r in rows:assert hashlib.sha256(z.read(r['constructor_class']+'.class')).hexdigest()==r['class_sha256'],r['id']
byid={r['id']:r for r in rows};dis=byid['aoa3:discharge_shotgun'];assert (dis['stored_base_damage'],dis['stored_pellets'],dis['stored_recoil_modifier'])==(0,4,13)
assert any('random' in f for f in byid['aoa3:lunar_assault_rifle']['flags'])
assert sum(r['family']=='gun'for r in rows)==78 and sum(r['family']=='shotgun'for r in rows)==17 and sum(r['family']=='sniper'for r in rows)==27 and sum(r['family']=='cannon'for r in rows)==50
print('PASS exact reviewed 172-record dataset, pinned registry/archive and all class hashes. Typed fields are constructor baselines, not effective combat/native acceptance.')
