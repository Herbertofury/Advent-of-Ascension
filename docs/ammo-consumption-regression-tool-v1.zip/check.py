"""Arithmetic regression fixtures; never launches Minecraft or claims native reproduction.
The observed loop is a small behavioral transcription of the released ItemUtil
multi-stack deduction path. Source pointers and class digest are in the report.
"""
import json,pathlib,itertools,sys
ROOT=pathlib.Path(__file__).resolve().parent
OUT=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/"ammo-consumption-regression.json"

def observed_deduction(counts, requested):
    selected=[]; found=0
    for c in counts:
        if c>0: selected.append(c); found+=c
        if found>=requested: break
    if found<requested:return None
    spent=[]
    for c in selected:
        debit=min(c,min(requested,found));spent.append(debit);found-=debit
    return spent

def proposed_plan(slots,requested):
    if requested<0:raise ValueError('negative request')
    unique={};eligible=[]
    for identity,count,protected in slots:
        if count<0:raise ValueError('negative snapshot count')
        if identity in unique:
            if unique[identity]!=(count,protected):raise ValueError('inconsistent aliased snapshot')
            continue
        unique[identity]=(count,protected)
        if not protected and count:eligible.append((identity,count))
    remaining=requested;out=[]
    for identity,count in eligible:
        if not remaining:break
        amount=min(count,remaining);out.append((identity,amount));remaining-=amount
    return None if remaining else out

assert observed_deduction([1,64],2)==[1,2]
assert observed_deduction([2,64],3)==[2,3]
assert observed_deduction([64],2)==[2]
assert observed_deduction([1],2) is None
checks=0
for counts in itertools.product(range(6),repeat=4):
 for request in range(0,24):
  slots=[(str(i),c,False)for i,c in enumerate(counts)]
  p=proposed_plan(slots,request)
  assert (p is not None)==(sum(counts)>=request)
  if p is not None:
   assert sum(c for _,c in p)==request
   assert len({i for i,_ in p})==len(p)
   assert all(0<c<=counts[int(i)]for i,c in p)
  checks+=1
assert proposed_plan([('main',1,False),('main',1,False)],2) is None
assert proposed_plan([('armor',1,True),('loose',2,False)],2)==[('loose',2)]
try:proposed_plan([('same',1,False),('same',2,False)],1)
except ValueError:pass
else:raise AssertionError('conflicting alias accepted')
report={'scope':'Standalone arithmetic fixtures and a proposed pure planner, not executed Minecraft/ItemUtil bytecode','released_class_sha256':json.loads((ROOT/'weapon-ammo-special-cases-1.20.1.json').read_text())['class_evidence']['ItemUtil']['sha256'],'source':'https://github.com/Tslat/Advent-Of-Ascension/blob/85d6beba07e3a09032834dcf79b5a01f411092c3/source/util/ItemUtil.java','observations':[{'input_counts':[1,64],'requested':2,'transcribed_debits':[1,2],'total':3},{'input_counts':[2,64],'requested':3,'transcribed_debits':[2,3],'total':5}], 'proposed_planner_exhaustive_cases':checks,'alias_and_protected_slot_fixtures':'PASS','native_acceptance':'PENDING: reproduce exact hand/inventory state, Greed level, server authority and mod interactions in pinned game','integration_contract':'No inventory is mutated. A game adapter must revalidate eligibility, item metadata and counts under the server inventory authority before all-or-nothing spending; no atomic commit implementation is provided.'}
OUT.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
