# Ammo cost regression study

Run `python check.py [report-output.json]` with Python 3. No third-party packages or network needed. This does not load Minecraft or patch any files.

The small observed-deduction function is a behavioral transcription of the release ItemUtil deduction loop, independently checked against javap. It is not an execution of that class. The pinned official source link and released class hash are included in the output. Arithmetic inputs are synthetic, not captured player inventories. AoA source credit: Tslat and contributors.

The proposed planner is original test code. It constructs exact-cost debit plans, deduplicates stable identities, rejects inconsistent aliased snapshots and excludes protected slots. It never mutates inventory. Production requires server-authoritative revalidation and an all-or-nothing commit adapter. No performance, compatibility or game-fix claim is made.

Native next checks: Greed with one small stack plus a larger stack, held-item aliases during off-hand firing, valuable/worn Leather Boots, creative players, daytime Sublimus and inventory modification between planning and commit. Preserve original saves before test sessions.
