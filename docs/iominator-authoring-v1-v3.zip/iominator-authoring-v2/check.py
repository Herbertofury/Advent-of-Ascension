"""Structural and selected spatial checks, not native or full hand/mesh QA."""
import json,math,pathlib,numpy as np
R=pathlib.Path(__file__).resolve().parent;P=R/'assets/ascension_armory';g=json.loads((P/'geo_models/gun/iominator_geo.json').read_text())['minecraft:geometry'][0];a=json.loads((P/'animations/iominator.animation.json').read_text())['animations'];names=set();count=0
for b in g['bones']:
 assert b['name'] not in names
 if 'parent'in b:assert b['parent']in names
 names.add(b['name'])
 for c in b.get('cubes',[]):
  count+=1;assert all(math.isfinite(x) for key in ['origin','size','rotation','pivot'] for x in c.get(key,[]));assert all(x>0 for x in c['size'])
  for uv in c['uv'].values():
   assert 0<=uv['uv'][0] and uv['uv'][0]+uv['uv_size'][0]<=128
   assert 0<=uv['uv'][1] and uv['uv'][1]+uv['uv_size'][1]<=96
for name,clip in a.items():
 for bone,channels in clip['bones'].items():
  assert bone in names
  for ch,keys in channels.items():
   assert ch in ['position','rotation','scale']; assert all(0<=float(t)<=clip['animation_length'] for t in keys)
   assert all(len(v)==3 and all(math.isfinite(x)for x in v) for v in keys.values())
# Selected world-authored cube OBBs. SAT considers rotations; not just unrotated bounding boxes.
def obb(c):
 angles=np.radians(c.get('rotation',[0,0,0]));x,y,z=angles;cx,sx,cy,sy,cz,sz=math.cos(x),math.sin(x),math.cos(y),math.sin(y),math.cos(z),math.sin(z)
 M=np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])@np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]])@np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]])
 center=np.array(c['origin'])+np.array(c['size'])/2;pivot=np.array(c.get('pivot',center));return pivot+M@(center-pivot),M,np.array(c['size'])/2

def overlaps(c,d):
 ca,A,ha=obb(c);cb,B,hb=obb(d);delta=cb-ca
 axes=[A[:,i]for i in range(3)]+[B[:,i]for i in range(3)]+[np.cross(A[:,i],B[:,k])for i in range(3)for k in range(3)]
 for axis in axes:
  if np.linalg.norm(axis)<1e-10:continue
  axis=axis/np.linalg.norm(axis);ra=sum(ha[i]*abs(axis@A[:,i])for i in range(3));rb=sum(hb[i]*abs(axis@B[:,i])for i in range(3))
  if abs(axis@delta)>ra+rb+1e-8:return False
 return True
bs={b['name']:b for b in g['bones']};trigger=bs['trigger']['cubes'][0];guard=bs['receiver']['cubes'][-2:]
assert all(not overlaps(trigger,q) for q in guard),'trigger intersects guard'
# Validate neutral endings; visual recoil must not accumulate on repeated shots.
for name in ['shoot','inspect','draw']:
 for channels in a[name]['bones'].values():
  for channel,keys in channels.items():assert list(keys.values())[-1]==[0,0,0]
receipt={'status':'PASS bounded checks only','bones':len(names),'cubes':count,'clips':list(a),'checks':['unique parent-first bones','positive finite cubes','UV tile bounds','finite in-range animation keys','trigger disjoint from two guard bars using oriented-box SAT','neutral final poses'],'not_tested':['Native TaCZ parsing/rendering','Actual hand models and wrist envelopes','All mesh collisions or moving attachment combinations','Gameplay/ammunition integration','Visual quality acceptance and performance']};(R/'qa.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
