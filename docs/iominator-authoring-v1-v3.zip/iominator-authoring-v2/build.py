"""Original concept-derived Iominator geometry study v2; not an installable gunpack."""
import json,math,pathlib
from PIL import Image,ImageDraw
R=pathlib.Path(__file__).resolve().parent;P=R/'assets/ascension_armory';bones=[];palette=['103d2c','237b4c','3dbf82','102735','185778','368bc7','50d9e7','ac8433','eed18a','121a20','77848b','bdefff']
for d in ['geo_models/gun','textures/gun/uv','animations']: (P/d).mkdir(parents=True,exist_ok=True)
im=Image.new('RGB',(128,96));dr=ImageDraw.Draw(im)
for i,c in enumerate(palette):
 x=i%4*32;y=i//4*32;dr.rectangle((x,y,x+31,y+31),fill='#'+c)
im.save(P/'textures/gun/uv/iominator.png')
def bone(name,parent='root',pivot=(0,0,0)):
 b={'name':name,'pivot':list(pivot)}
 if parent:b['parent']=parent
 b['cubes']=[];bones.append(b);return b
root=bone('root',None);body=bone('receiver');barrel=bone('barrel');rear=bone('rear_crown');grip=bone('grip');trigger=bone('trigger');sight=bone('sight');charm=bone('charm_anchor',pivot=(1.8,4,8));muzzle=bone('muzzle',parent='barrel',pivot=(0,4,-19))
def cube(b,c,s,col,rot=None):
 o=[c[i]-s[i]/2 for i in range(3)];uv=[col%4*32+2,col//4*32+2];q={'origin':o,'size':list(s),'uv':{face:{'uv':uv,'uv_size':[24,24]} for face in ['north','east','south','west','up','down']}}
 if rot:q.update(pivot=list(c),rotation=list(rot))
 b['cubes'].append(q)
# Receiver stepped enamel armor, deliberately more than an unshaped rectangular block.
cube(body,(0,4,-1),(3.2,3.6,21),0)
for side in [-1,1]:
 cube(body,(side*1.72,4,-1),(.4,2.55,19),1)
 for z in [-8,-3,2,7]:cube(body,(side*1.95,4.8,z),(.16,.75,3.2),2,(0,0,side*12))
 cube(body,(side*1.98,4.05,-1),(.15,.42,20.5),6)
 cube(body,(side*1.83,2.55,-1),(.32,.35,19),7)
 for z in [-7,-2,3]:cube(body,(side*2.05,4.05,z),(.12,.48,.75),11)
 for z in [-7.5,-2.5,2.5]:cube(body,(side*1.92,5.25,z),(.3,.75,2.2),7,(12,0,0))
cube(body,(0,5.9,-1),(2.65,.35,18),7)
for z in [-6,-2,2,6]:
 cube(body,(0,6.45,z),(2.5,.7,.7),8,(0,0,0));cube(body,(0,6.9,z),(1.7,.2,.45),7)
# Hollow eight-sided muzzle: radial wall pieces leave a real open central aperture.
for i in range(8):
 a=2*math.pi*i/8;x=1.15*math.cos(a);y=4+1.15*math.sin(a)
 cube(barrel,(x,y,-14.3),(.65,.65,7.4),9,(0,0,45*i))
 cube(barrel,(x*1.12,4+(y-4)*1.12,-17.7),(.75,.7,.65),7,(0,0,45*i))
 cube(barrel,(x*1.12,4+(y-4)*1.12,-11.4),(.75,.7,.65),10,(0,0,45*i))
# Large geometric rear loop. Segment orientation follows the ellipse tangent.
N=18;cy=1.3;cz=12.0;ry=4.8;rz=4.8
for i in range(N):
 a=(i+.5)*2*math.pi/N;y=cy+ry*math.sin(a);z=cz+rz*math.cos(a)
 # local z tangent transformed by X rotation: dy=-sin(rot), dz=cos(rot)
 angle=math.degrees(math.atan2(-ry*math.cos(a),-rz*math.sin(a)))
 for b,x,w,col in [(rear,0,2.2,3),(rear,-1.18,.22,5),(rear,1.18,.22,5)]:cube(b,(x,y,z),(w,1.1,1.8),col,(angle,0,0))
 for side in [-1,1]:cube(rear,(side*1.34,cy+(y-cy)*.86,cz+(z-cz)*.86),(.12,.22,1.45),6,(angle,0,0))
for side in [-1,1]:
 for z in [8.7,15.3]:cube(rear,(side*1.35,4.8,z),(.28,.65,1.0),8,(0,0,side*15))
# Main hand grip behind trigger. Rear loop and moving parts require hand-rig QA.
cube(grip,(0,-1.7,5.6),(2.2,5.8,2.5),9,(-13,0,0));cube(grip,(0,-4.5,6.2),(2.55,.65,3.0),7,(-13,0,0))
for side in [-1,1]:
 cube(grip,(side*1.15,-1.9,5.65),(.18,4.2,1.65),3,(-13,0,0))
 for y in [-3.1,-2.2,-1.3,-.4]:cube(grip,(side*1.26,y,5.6),(.1,.18,1.5),10,(-13,0,0))
 cube(grip,(side*1.3,-1.5,5.6),(.08,1.3,.3),6,(-13,0,0))
# Open guard. Trigger is separate and well inside it, no shrinking workaround.
cube(trigger,(0,.4,1.7),(.5,1.5,.35),8,(-17,0,0));cube(body,(0,-1.05,1.8),(.65,.4,5.1),7);cube(body,(0,.2,-.65),(.65,2.4,.45),7,(12,0,0))
# Sight and restrained decorative crystal, distinct from Soul Storm's flame sight.
cube(sight,(0,6.55,-8),(1.6,.8,2),3);cube(sight,(0,7.1,-8),(.8,.4,1.0),2,(0,0,0))
cube(charm,(2.5,3.3,8.1),(.45,.7,.45),8,(0,0,18))
# Second-pass sculptural armor: angular winglets, inlaid frames and crown collars.
orn=bone('sculpted_inlays')
for side in [-1,1]:
 for z in [-8,-3,2,6.5]:
  cube(orn,(side*2.02,5.25,z),(.42,1.25,2.7),1,(18,0,side*20))
  cube(orn,(side*2.25,5.65,z+.25),(.16,.18,2.7),8,(18,0,side*20))
  cube(orn,(side*2.17,5.4,z),(.12,.25,1.4),2,(18,0,side*20))
 for z in [-7,-2,3]:
  cube(orn,(side*2.1,3.05,z),(.26,.7,3.4),0,(-12,0,-side*18))
  cube(orn,(side*2.25,2.8,z),(.14,.18,3.6),8,(-12,0,-side*18))
 # Rear loop accents placed tangentially; preserve the large open void.
 for i in [1,4,7,10,13,16]:
  a=(i+.5)*2*math.pi/N;y=cy+ry*math.sin(a);z=cz+rz*math.cos(a);angle=math.degrees(math.atan2(-ry*math.cos(a),-rz*math.sin(a)))
  cube(orn,(side*1.5,y,z),(.22,1.15,.55),7,(angle,0,0))
  cube(orn,(side*1.64,y,z),(.1,.48,.22),8,(angle,0,0))
# Raised central arcane fin with two sloping facets rather than a square sight lump.
for side in [-1,1]:cube(sight,(side*.4,7.5,-8),(.65,.8,1.6),2,(0,0,side*32))
geo={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.ascension_armory.iominator','texture_width':128,'texture_height':96,'visible_bounds_width':4,'visible_bounds_height':3,'visible_bounds_offset':[0,.15,0]},'bones':bones}]}
(P/'geo_models/gun/iominator_geo.json').write_text(json.dumps(geo,indent=2)+'\n')
def ks(*args):return {str(t):v for t,v in args}
clips={'static_idle':{'loop':True,'bones':{}},'shoot':{'animation_length':.15,'loop':False,'bones':{'root':{'rotation':ks((0,[0,0,0]),(.025,[-2.8,.2,.6]),(.08,[-1,0,.2]),(.15,[0,0,0])),'position':ks((0,[0,0,0]),(.025,[0,.08,.5]),(.15,[0,0,0]))},'barrel':{'position':ks((0,[0,0,0]),(.025,[0,0,.4]),(.15,[0,0,0]))}}},'inspect':{'animation_length':3,'loop':False,'bones':{'root':{'rotation':ks((0,[0,0,0]),(.7,[0,-22,-12]),(1.5,[8,32,7]),(2.3,[0,10,0]),(3,[0,0,0]))},'charm_anchor':{'rotation':ks((0,[0,0,0]),(.8,[0,0,15]),(1.2,[0,0,-9]),(1.8,[0,0,5]),(3,[0,0,0]))}}},'draw':{'animation_length':.45,'loop':False,'bones':{'root':{'position':ks((0,[0,-5,3]),(.45,[0,0,0])),'rotation':ks((0,[15,0,-15]),(.45,[0,0,0]))}}}}
(P/'animations/iominator.animation.json').write_text(json.dumps({'format_version':'1.8.0','animations':clips},indent=2)+'\n')
(R/'manifest.json').write_text(json.dumps({'status':'editable geometry and cosmetic-animation study; not installable/native accepted','bones':len(bones),'cubes':sum(len(b['cubes']) for b in bones),'concept':'iominator-concept-exploration-v2.png','open':['Hand rig and actual animation collision','Ammunition feed/reload design','Native adapter and sound events','Textures beyond color atlas, LOD and export verification','Functional conversions and gameplay acceptance']},indent=2)+'\n');print(len(bones),sum(len(b['cubes']) for b in bones))
