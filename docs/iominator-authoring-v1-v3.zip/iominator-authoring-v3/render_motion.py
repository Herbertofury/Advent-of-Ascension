import bpy,json,math
from pathlib import Path
from mathutils import Vector,Euler,Matrix
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'iominator-authoring.blend'));scene=bpy.context.scene;scene.render.resolution_x=720;scene.render.resolution_y=456;scene.cycles.samples=12;scene.cycles.use_denoising=False
clips=json.loads((R/'assets/ascension_armory/animations/iominator.animation.json').read_text())['animations'];C=Matrix(((1,0,0),(0,0,-1),(0,1,0)));bases={o.name:o.location.copy() for o in bpy.data.objects if o.type=='EMPTY'}
def sample(keys,t):
 pairs=sorted((float(k),v)for k,v in keys.items())
 if t<=pairs[0][0]:return pairs[0][1]
 for (a,x),(b,y) in zip(pairs,pairs[1:]):
  if a<=t<=b:
   f=(t-a)/(b-a);return [x[i]*(1-f)+y[i]*f for i in range(3)]
 return pairs[-1][1]
for clip,times in [('inspect',[i*.25 for i in range(13)]),('shoot',[0,.025,.05,.08,.12,.15])]:
 folder=R/'motion'/clip;folder.mkdir(parents=True,exist_ok=True)
 for index,t in enumerate(times):
  for name,loc in bases.items():bpy.data.objects[name].location=loc;bpy.data.objects[name].rotation_euler=(0,0,0)
  for bone,chs in clips[clip]['bones'].items():
   o=bpy.data.objects[bone]
   if 'position'in chs:o.location=bases[bone]+C@Vector(sample(chs['position'],t))
   if 'rotation'in chs:
    rot=Euler(tuple(math.radians(v)for v in sample(chs['rotation'],t)),'XYZ').to_matrix();o.rotation_euler=(C@rot@C.inverted()).to_euler()
  scene.render.filepath=str(folder/f'{index:03d}.png');bpy.ops.render.render(write_still=True)
