# Iominator editable authoring study

Original concept-derived geometry and cosmetic animations. Not an installable TaCZ gunpack and not a native gameplay pass. The concept's sculpted silhouette and materials remain a higher target than this blockout.

Versions 1–3 are retained. v1 establishes silhouette; v2 adds rotated armor/inlays; v3 adds an original subtly textured color atlas and uses that atlas in the preview. The preview uses exported cuboids without render-only bevel geometry. Standard Blender studio materials/lighting are not native renderer/shader validation.

Run build.py with Python/Pillow, check.py (v2/v3) with NumPy, and blender --background --python render.py. Then render_motion.py (v3). The animation preview uses linear interpolation and explicitly maps Bedrock coordinates to Blender. Native interpolation, first-person hands, actual TaCZ display/state-machine bindings and shader parity are unverified.

v3: 10 bones,236 cubes, static_idle/shoot/inspect/draw clips. No reload clip is presented as done. No ammo feeding design or functional conversion has been accepted. Do not infer gameplay timing from the WebP replay, which contains a deliberate pause for reading.

QA covers positive finite cubes, UV bounds, parent references, finite animation keys, neutral endings, and the trigger against two guard bars via oriented-box SAT. It does not cover all geometry pairs, hands, attachment combinations or native parser behavior.
