# Hive Blaster released-file study

Original static audit tooling and built-in image-generation prompts. AoA source and original assets belong to Tslat and contributors. The original mod JAR and decoded classes are not included.

Set JAVA_HOME to a full JDK and run:

    python audit_hive.py /path/to/AoA3-1.20.1-3.7.1-all.jar hive-blaster-released-evidence.json

The audit checks the pinned archive, seven class hashes, upgrade recipe and selected source patterns. The profile's wider meaning comes from manually tracing the exact released classes. It does not execute Minecraft or certify runtime behavior, final damage or FPS.

The renderer's eight particle-loop iterations are per render invocation. Scale 1 and age modifier 3 are constructor inputs, not an observed per-second rate or a three-second lifetime. Mutable counter/toggle fields are renderer-owned. The replacement should avoid assuming per-entity game-time behavior from them.

Both generated concepts are retained. V2 changes the pixel inset's caption to describe it accurately as an inspired reconstruction. The separately published original sprite is exact. Swarm and resin designs are proposals; the inspected native Hive Blaster does not summon bees or apply honey.
