"""Verify a bounded Hive Blaster released-file audit without running game classes."""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess,zipfile
p=argparse.ArgumentParser(description=__doc__);p.add_argument('jar',type=Path);p.add_argument('evidence',type=Path);a=p.parse_args();d=json.loads(a.evidence.read_text())
expected='bdee7d12aab1903e1e74f377d4f0ae7ac948d791f46ec0368d191d86a3d5a03cfbd2e6d1295f1fe690f303b1fa709da89db980543e4d450fc0fdbbf6d9e694e6'
assert hashlib.sha512(a.jar.read_bytes()).hexdigest()==expected,'Wrong release JAR'
with zipfile.ZipFile(a.jar) as z:
 for name,sha in d['class_sha256'].items():assert hashlib.sha256(z.read(name)).hexdigest()==sha,name
 assert json.loads(z.read('data/aoa3/recipes/upgrade_kit_hive_blaster.json'))==d['recipe']
home=os.environ.get('JAVA_HOME');tool=str(Path(home)/'bin'/('javap.exe'if os.name=='nt'else'javap'))if home else shutil.which('javap')
if not tool:raise SystemExit('Set JAVA_HOME to a full JDK')
def read(name):return subprocess.check_output([tool,'-c','-p','-classpath',str(a.jar),name],text=True)
render=read('net.tslat.aoa3.client.render.entity.projectile.cannonshots.HiveBallRenderer');assert re.search(r'bipush\s+8\b',render);assert 'AoAParticleTypes.FLICKERING_SPARKLER' in render;assert 'Field counter:I' in render and 'Field toggle:Z' in render
projectile=read('net.tslat.aoa3.content.entity.projectile.cannon.HiveBallEntity');assert 'float 0.1f' in projectile
weapon=read('net.tslat.aoa3.content.item.weapon.cannon.HiveBlaster');assert 'HiveBallEntity' in weapon and 'ITEM_SHADOW_BLASTER_FIRE' in weapon
base=read('net.tslat.aoa3.content.entity.projectile.gun.BaseBullet');signature='net.minecraft.world.InteractionHand, int, float, int);';body=base.split(signature)[1];assert re.search(r'fload\s+6\s*\n\s*\d+: putfield\s+#\d+\s+// Field dmgMulti:F',body)
print('PASS pinned archive,7 class hashes,upgrade recipe and bounded renderer/projectile/damage-multiplier checks; not native game acceptance')
