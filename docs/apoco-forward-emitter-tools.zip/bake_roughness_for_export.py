"""Bake an authoring roughness operation into a standard glTF texture input."""
import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parent/'apoco-trial-1024';O=R/'forward-emitter-study-v11';O.mkdir(exist_ok=True);bpy.ops.wm.open_mainfile(filepath=str(R/'forward-emitter-study-v10/refined-emitter-study.blend'));body=bpy.data.objects['Reference shell with forward opening'];bpy.ops.object.select_all(action='DESELECT');body.select_set(True);bpy.context.view_layer.objects.active=body;s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=1;s.cycles.use_denoising=False;s.render.bake.use_selected_to_active=False;s.render.bake.margin=8
reports=[]
for i,mat in enumerate(body.data.materials):
 if not mat or not mat.use_nodes:continue
 nodes=mat.node_tree.nodes;links=mat.node_tree.links;bs=next(n for n in nodes if n.type=='BSDF_PRINCIPLED');out=next(n for n in nodes if n.type=='OUTPUT_MATERIAL');rough=bs.inputs['Roughness'];oldrough=list(rough.links);assert len(oldrough)==1;src=oldrough[0].from_socket
 im=bpy.data.images.new('Export roughness atlas '+str(i),width=2048,height=2048,alpha=False);im.colorspace_settings.name='Non-Color';tex=nodes.new('ShaderNodeTexImage');tex.image=im;nodes.active=tex;emit=nodes.new('ShaderNodeEmission');links.new(src,emit.inputs['Color']);oldout=[(l.from_socket,l.to_socket)for l in out.inputs['Surface'].links]
 for l in list(out.inputs['Surface'].links):links.remove(l)
 links.new(emit.outputs[0],out.inputs['Surface']);bpy.ops.object.bake(type='EMIT')
 for l in list(out.inputs['Surface'].links):links.remove(l)
 for a,b in oldout:links.new(a,b)
 nodes.remove(emit);links.remove(oldrough[0]);links.new(tex.outputs['Color'],rough);im.filepath_raw=str(O/('roughness-'+str(i)+'.png'));im.file_format='PNG';im.save();im.pack();reports.append({'material':mat.name,'atlas':Path(im.filepath_raw).name,'size':[2048,2048]})
bpy.ops.wm.save_as_mainfile(filepath=str(O/'exportable-emitter-study.blend'));bpy.ops.export_scene.gltf(filepath=str(O/'exportable-emitter-study.glb'),export_format='GLB');(O/'material-receipt.json').write_text(json.dumps({'roughness_bakes':reports,'scope':'Explicit unlit bake of authoring roughness floor into standard texture; export comparison pending','native_accepted':False},indent=2)+'\n')
