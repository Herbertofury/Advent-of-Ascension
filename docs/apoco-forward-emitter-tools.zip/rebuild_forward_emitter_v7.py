"""Fictional forward-facing emitter authoring study, not native gameplay."""
import bpy,bmesh,math,json,random
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parent/'apoco-trial-1024';O=R/'forward-emitter-study-v7';O.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=str(R/'repair-v1/repaired-isolated-triangles-removed.glb'));body=next(o for o in bpy.context.scene.objects if o.type=='MESH');body.name='Reference shell with forward opening';bpy.context.view_layer.objects.active=body;body.select_set(True);bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
bm=bmesh.new();bm.from_mesh(body.data);print('Before weld',len(bm.verts),len(bm.faces),sum(e.is_boundary for e in bm.edges),flush=True);groups={};targets={};
for v in bm.verts:
 key=tuple(v.co)
 if key in groups:targets[v]=groups[key]
 else:groups[key]=v
bmesh.ops.weld_verts(bm,targetmap=targets);print('After exact weld',len(bm.verts),len(bm.faces),sum(e.is_boundary for e in bm.edges),sum(not e.is_manifold for e in bm.edges),flush=True);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));print('Welded volume',bm.calc_volume(signed=True),flush=True);
if bm.calc_volume(signed=True)<0:bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
assert sum(not e.is_manifold for e in bm.edges)==0,'Input must be welded and manifold before Boolean';bm.to_mesh(body.data);bm.free();body.data.update()
# Authoring coordinates only: the weapon axis points toward negative X.
bpy.ops.mesh.primitive_cylinder_add(vertices=64,radius=.044,depth=.20,location=(-.46,0,.008),rotation=(0,math.pi/2,0));cut=bpy.context.object;cut.name='Temporary forward aperture cutter';bpy.ops.object.select_all(action='DESELECT');body.select_set(True);bpy.context.view_layer.objects.active=body;mod=body.modifiers.new('Forward aperture','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='FAST';mod.object=cut;bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(cut,do_unlink=True);print('Retained shell faces',len(body.data.polygons),flush=True);assert len(body.data.polygons)>100000,'Boolean removed too much shell; reject before rendering'
def material(name,color,metal=0,rough=.3,emission=0):
 m=bpy.data.materials.new(name);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;p.inputs['Emission Color'].default_value=(*color,1);p.inputs['Emission Strength'].default_value=emission;return m
rim=material('Dark emitter collar',(.035,.018,.016),.7,.24);red=material('Red capsule energy core',(.8,.009,.002),0,.2,1.5);hot=material('Plasma filaments',(1,.12,.025),0,.2,7)
def torus(name,x,major,minor,mat):
 bpy.ops.mesh.primitive_torus_add(major_segments=48,minor_segments=8,location=(x,0,.008),rotation=(0,math.pi/2,0),major_radius=major,minor_radius=minor);o=bpy.context.object;o.name=name;o.data.materials.append(mat)
 for f in o.data.polygons:f.use_smooth=True
 return o
torus('Forward aperture rim',-.478,.038,.004,rim);torus('Recessed energy ring',-.434,.029,.002,hot)
bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=16,radius=.025,location=(-.410,0,.008));core=bpy.context.object;core.name='Recessed fictional plasma core';core.data.materials.append(red)
for f in core.data.polygons:f.use_smooth=True
random.seed(42)
for n in range(8):
 curve=bpy.data.curves.new('Plasma arc '+str(n),'CURVE');curve.dimensions='3D';curve.resolution_u=2;curve.bevel_depth=.00045;curve.bevel_resolution=2;curve.use_fill_caps=True;sp=curve.splines.new('POLY');sp.points.add(47);phase=n*math.tau/8
 for j,point in enumerate(sp.points):
  t=(j/47)*math.pi*.85+.1;phi=phase+.4*math.sin(t*4+n);radius=.0255;point.co=(-.410-radius*math.cos(t),radius*math.sin(t)*math.cos(phi),.008+radius*math.sin(t)*math.sin(phi),1)
 obj=bpy.data.objects.new(curve.name,curve);bpy.context.collection.objects.link(obj);curve.materials.append(hot);bpy.context.view_layer.objects.active=obj;obj.select_set(True);body.select_set(False);core.select_set(False);bpy.ops.object.convert(target='MESH');bpy.context.object.select_set(False)
# Test the shell aperture only; not hands, moving parts or native projectile spawning.
bm=bmesh.new();bm.from_mesh(body.data);bvh=BVHTree.FromBMesh(bm);clear=[]
for y in [-.01,0,.01]:
 for z in [-.01,0,.01]:
  hit=bvh.ray_cast(Vector((-.447,y,.008+z)),Vector((-1,0,0)),.12);clear.append(hit[0]is None)
body_non=sum(not e.is_manifold for e in bm.edges);print('Post Boolean nonmanifold',body_non,flush=True);assert body_non==0,'Boolean introduces invalid topology';bm.free();bpy.ops.object.select_all(action='SELECT');bpy.ops.wm.save_as_mainfile(filepath=str(O/'forward-emitter-study.blend'));bpy.ops.export_scene.gltf(filepath=str(O/'forward-emitter-study.glb'),export_format='GLB',use_selection=True,export_apply=True);report={'scope':'Static fictional emitter authoring only; no native animation or game acceptance','axis':[-1,0,0],'aperture_shell_clear_rays':sum(clear),'sampled_rays':len(clear),'shell_nonmanifold_edges':body_non,'native_accepted':False,'remaining':['Inspect full silhouette and original side-disc remnants','Lime details and textures','Native player arms and moving parts','Actual renderer, projectile and performance tests']};(O/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
