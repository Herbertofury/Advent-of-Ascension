import bpy,json,math
from pathlib import Path
R=Path(__file__).resolve().parent/'apoco-trial-1024';O=R/'forward-emitter-study-v10';O.mkdir(exist_ok=True);bpy.ops.wm.open_mainfile(filepath=str(R/'forward-emitter-study-v9/refined-emitter-study.blend'));names=[]
for o in list(bpy.context.scene.objects):
 if o.type!='MESH' or not(o.name.startswith('Plasma arc')or o.name.startswith('Emitter cage support')):continue
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=math.radians(66),island_margin=.02);bpy.ops.object.mode_set(mode='OBJECT');names.append(o.name)
bpy.ops.wm.save_as_mainfile(filepath=str(O/'refined-emitter-study.blend'));bpy.ops.export_scene.gltf(filepath=str(O/'refined-emitter-study.glb'),export_format='GLB');(O/'uv-receipt.json').write_text(json.dumps({'reunwrapped_objects':names,'scope':'Nontextured emitter detail UV cap repair only; body texture atlas preserved','native_accepted':False},indent=2)+'\n')
