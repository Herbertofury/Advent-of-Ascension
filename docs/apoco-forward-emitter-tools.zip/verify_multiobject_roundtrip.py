import bpy,bmesh,json,sys,argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('output',type=Path);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=str(a.input));reports=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 bm=bmesh.new();bm.from_mesh(o.data);before=len(bm.faces);groups={};targets={}
 for v in bm.verts:
  key=tuple(v.co)
  if key in groups:targets[v]=groups[key]
  else:groups[key]=v
 bmesh.ops.weld_verts(bm,targetmap=targets)
 report={'object':o.name,'imported_faces':before,'welded_faces':len(bm.faces),'boundary_edges':sum(e.is_boundary for e in bm.edges),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'near_zero_area_faces':sum(f.calc_area()<=1e-12 for f in bm.faces)}
 assert before==len(bm.faces)and report['boundary_edges']==report['nonmanifold_edges']==report['near_zero_area_faces']==0,report
 reports.append(report);bm.free()
a.output.write_text(json.dumps({'objects':reports,'native_accepted':False,'scope':'Actual Blender importer and exact-position welded topology per object; no self-intersection/material/native proof'},indent=2)+'\n');bpy.ops.wm.save_as_mainfile(filepath=str(a.output.with_suffix('.blend')));print('Checked',len(reports),'mesh objects')
