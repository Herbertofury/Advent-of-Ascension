"""Concept-oriented static material/support study; fictional geometry only."""
import bpy,bmesh,math,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parent/'apoco-trial-1024';O=R/'forward-emitter-study-v9';O.mkdir(exist_ok=True);bpy.ops.wm.open_mainfile(filepath=str(R/'forward-emitter-study-v7/forward-emitter-study.blend'));body=bpy.data.objects['Reference shell with forward opening']
# Open structural cage leaves the fictional energy visible from the sides.
def curved_tube(name,points,radius,mat):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=2;c.bevel_depth=radius;c.bevel_resolution=3;c.use_fill_caps=True;sp=c.splines.new('POLY');sp.points.add(len(points)-1)
 for p,co in zip(sp.points,points):p.co=(*co,1)
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);c.materials.append(mat);bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH');return o
support=bpy.data.materials['Dark emitter collar']
for n in range(4):
 phi=math.tau*n/4+math.pi/4;points=[]
 for i in range(24):
  t=i/23;x=-.478+.115*t;rad=.039+.009*math.sin(math.pi*t/2);points.append((x,rad*math.cos(phi),.008+rad*math.sin(phi)))
 curved_tube('Emitter cage support '+str(n),points,.003,support)
# Preserve map structure, raise roughness floor to avoid the wax-like reflection dominating form.
for mat in body.data.materials:
 if not mat or not mat.use_nodes:continue
 bs=next((n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED'),None)
 if not bs:continue
 inp=bs.inputs['Roughness'];links=list(inp.links)
 if links:
  source=links[0].from_socket;mat.node_tree.links.remove(links[0]);n=mat.node_tree.nodes.new('ShaderNodeMath');n.operation='MAXIMUM';n.inputs[1].default_value=.45;mat.node_tree.links.new(source,n.inputs[0]);mat.node_tree.links.new(n.outputs[0],inp)
 else:inp.default_value=max(inp.default_value,.45)
placed=[];
bpy.ops.wm.save_as_mainfile(filepath=str(O/'refined-emitter-study.blend'));bpy.ops.export_scene.gltf(filepath=str(O/'refined-emitter-study.glb'),export_format='GLB');(O/'receipt.json').write_text(json.dumps({'scope':'Static concept material and support exploration; all art/native gates open','lime_nodes':placed,'native_accepted':False,'art_accepted':False,'remaining':['Exact concept proportions and deliberate textures','Self intersection and mount clearance','Native hand rig and movement','Exporter material equivalence: roughness math may require baking']},indent=2)+'\n')
