"""Remove only verified tiny isolated triangle components from an unaccepted reference.
Never cap isolated faces: that creates coincident duplicate faces, not a solid.
"""
from pathlib import Path
import sys,json,struct,collections,hashlib,numpy as np
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'source/tools'));import glb_metrics as m
p=R/'apoco-trial-1024/repair-v1/repaired-reference.glb';g,b=m.parse_glb(p)
assert len(g['meshes'])==1 and len(g['meshes'][0]['primitives'])==1
q=g['meshes'][0]['primitives'][0];v=m.read_accessor(g,b,q['attributes']['POSITION']);idx=m.read_accessor(g,b,q['indices']).reshape(-1,3).astype(np.uint32)
u,inv=np.unique(v,axis=0,return_inverse=True);faces=inv[idx];edges=collections.defaultdict(list);vertices=collections.defaultdict(set)
for i,f in enumerate(faces):
 for a in f:vertices[int(a)].add(i)
 for a,c in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(a),int(c))))].append(i)
removed=[]
for i,f in enumerate(faces):
 if all(len(edges[tuple(sorted((int(a),int(c))))])==1 for a,c in zip(f,np.roll(f,-1))) and all(vertices[int(a)]=={i} for a in f):
  area=float(np.linalg.norm(np.cross(u[f[1]]-u[f[0]],u[f[2]]-u[f[0]]))/2)
  assert 1e-12<area<1e-5
  removed.append({'face':i,'area':area,'positions':u[f].tolist()})
assert len(removed)==3,'Unexpected components; manual inspection required'
keep=np.ones(len(idx),dtype=bool);keep[[x['face']for x in removed]]=False;newidx=idx[keep].astype('<u4')
raw=newidx.tobytes();b+=bytes((-len(b))%4);offset=len(b);b+=raw
view=len(g['bufferViews']);g['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':len(raw),'target':34963})
acc=len(g['accessors']);g['accessors'].append({'bufferView':view,'componentType':5125,'count':int(newidx.size),'type':'SCALAR','min':[int(newidx.min())],'max':[int(newidx.max())]});q['indices']=acc;g['buffers'][0]['byteLength']=len(b)
j=json.dumps(g,separators=(',',':')).encode();j+=b' '*((-len(j))%4);b+=bytes((-len(b))%4)
payload=struct.pack('<4sII',b'glTF',2,28+len(j)+len(b))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(b),0x004e4942)+b
out=p.parent/'repaired-isolated-triangles-removed.glb';out.write_bytes(payload)
report={'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(payload).hexdigest(),'removed_isolated_faces':removed,'triangles_before':len(idx),'triangles_after':len(newidx),'native_accepted':False,'scope':'Only three tiny vertex-disconnected single-triangle components removed; original attribute and embedded texture buffers preserved; round-trip and visual gates still required'}
(out.parent/'isolated-removal-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
