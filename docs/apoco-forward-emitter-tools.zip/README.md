# Static forward-emitter study

Scripts document the authoring chain, not a one-click native gun exporter. Local stage paths must be adapted to the retained input study. Start with the corrected isolated-triangle-removed reference. All outputs remain unaccepted for final art, rig, hands and native gameplay. No game binaries or model weights included.
