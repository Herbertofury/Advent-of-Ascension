"""Multi-view Blender review of a generated GLB. Authoring images, never game captures."""
import bpy,argparse,sys,json,hashlib
from pathlib import Path
from mathutils import Vector
p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--views',default='front');a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);a.out.mkdir(exist_ok=True,parents=True)
bpy.ops.wm.open_mainfile(filepath=str(a.input));
for old in list(bpy.context.scene.objects):
 if old.type in {'LIGHT','CAMERA'}:bpy.data.objects.remove(old,do_unlink=True)
objects=[o for o in bpy.context.scene.objects if o.type=='MESH' and not o.hide_render];assert objects,'No mesh imported';verts=[o.matrix_world@v.co for o in objects for v in o.data.vertices];lo=Vector(tuple(min(v[i]for v in verts)for i in range(3)));hi=Vector(tuple(max(v[i]for v in verts)for i in range(3)));center=(lo+hi)/2;size=max(hi-lo);assert size>0
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.use_denoising=False;s.render.resolution_x=1200;s.render.resolution_y=850;s.render.resolution_percentage=100;s.render.film_transparent=True;s.view_settings.view_transform='AgX';s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.13,.13,.13,1);s.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.4
for name,offset,power,color in [('key',(-1,-2,3),100,(1,.92,.82)),('fill',(2,1,1),60,(.7,.8,1)),('rim',(-2,2,2),90,(1,.8,.7))]:
 bpy.ops.object.light_add(type='AREA',location=center+Vector(offset)*size);o=bpy.context.object;o.name='Review '+name;o.data.energy=power*size*size;o.data.size=2*size;o.data.color=color;o.rotation_euler=(center-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();s.camera=bpy.context.object;s.camera.data.type='ORTHO';bounds=[Vector((x,y,z))for x in [lo.x,hi.x]for y in [lo.y,hi.y]for z in [lo.z,hi.z]];views=[]
for name,offset in [('front',(0,-2,.08)),('oblique',(1,-2,.6)),('rear',(0,2,.08)),('left_end',(-2,0,.05)),('right_end',(2,0,.05)),('top',(0,0,2))]:
 if name not in a.views.split(','):continue
 s.camera.location=center+Vector(offset)*size*2;s.camera.rotation_euler=(center-s.camera.location).to_track_quat('-Z','Y').to_euler();rot=s.camera.rotation_euler.to_matrix();right=rot@Vector((1,0,0));up=rot@Vector((0,1,0));xs=[(v-center).dot(right)for v in bounds];ys=[(v-center).dot(up)for v in bounds];s.camera.data.ortho_scale=max(max(xs)-min(xs),(max(ys)-min(ys))*s.render.resolution_x/s.render.resolution_y)*1.15;s.render.filepath=str(a.out/(name+'.png'));bpy.ops.render.render(write_still=True);views.append(name)
report={'input_sha256':hashlib.sha256(a.input.read_bytes()).hexdigest(),'mesh_objects':len(objects),'materials':len(bpy.data.materials),'views':views,'bounds':[list(lo),list(hi)],'native_accepted':False,'scope':'Matched authoring inspection views; hidden-side geometry is generated, not source proof','remaining':['Visual concept fidelity','Moving-part ownership and hands','Topology and UV/material checks','Rig, animation and native integration']};(a.out/'render-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
