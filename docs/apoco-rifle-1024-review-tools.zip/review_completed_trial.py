"""Inspect a completed trial without treating generation as native acceptance."""
import argparse,json,subprocess,sys,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('trial',type=Path);p.add_argument('--render',action='store_true');a=p.parse_args();d=a.trial.resolve();receipt=d/'process-receipt.json'
if not receipt.exists(): raise SystemExit('Trial remains pending; no review or duplicate generation started.')
r=json.loads(receipt.read_text())
if r['exit_code']!=0: raise SystemExit('Generation failed; inspect the existing run.log before choosing a recovery.')
g=d/'apoco-rifle-reference.glb'
if not g.is_file(): raise SystemExit('Successful process receipt has no expected GLB; investigate.')
review=d/'review';review.mkdir(exist_ok=True)
checks=[]
for name,cmd in [('preflight',[sys.executable,str(R.parent/'weapon-glb-preflight/preflight.py'),str(g)]),('welded-topology',[sys.executable,str(R/'source/tools/glb_metrics.py'),str(g)])]:
 result=subprocess.run(cmd,capture_output=True,text=True);(review/(name+'.txt')).write_text(result.stdout+result.stderr);checks.append({'name':name,'exit_code':result.returncode,'note':'Diagnostic only; read the output, not merely the process exit status.'})
if a.render:
 result=subprocess.run(['/usr/bin/blender','--background','--threads','2','--python-exit-code','1','--python',str(R/'inspect_trial.py'),'--','--input',str(g),'--out',str(review)],stdout=(review/'render.log').open('w'),stderr=subprocess.STDOUT);checks.append({'name':'six-view-render','exit_code':result.returncode})
(review/'review-gates.json').write_text(json.dumps({'glb_sha256':hashlib.sha256(g.read_bytes()).hexdigest(),'checks':checks,'native_accepted':False,'required_manual_review':['Compare all six views with the supplied concept and original AoA identity','Check holes, grip, muzzle, small roots and silhouette for fused or invented forms','Inspect base color and material channels for missing lime details, baked lighting and seam artifacts','Require independent moving parts, animations and real native arm fit','Test actual gameplay, projectiles, impacts, sound, performance and compatibility'],'scope':'Offline diagnostic and authoring review only; no acceptance is automatic.'},indent=2)+'\n')
print('Review evidence prepared; manual and native acceptance remain open.')
