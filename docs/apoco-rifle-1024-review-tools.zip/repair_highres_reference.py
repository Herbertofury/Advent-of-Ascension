"""Independent repaired authoring reference with fresh UVs and unlit PBR transfer."""
import bpy,bmesh,json
from pathlib import Path
R=Path(__file__).resolve().parent/'apoco-trial-1024';O=R/'repair-v1';O.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=str(R/'apoco-rifle-reference.glb'));source=next(o for o in bpy.context.scene.objects if o.type=='MESH');target=source.copy();target.data=source.data.copy();bpy.context.collection.objects.link(target);target.name='Repaired high resolution reference';bpy.ops.object.select_all(action='DESELECT');target.select_set(True);bpy.context.view_layer.objects.active=target
target.data.remesh_voxel_size=.0015;target.data.use_remesh_preserve_volume=True;bpy.ops.object.voxel_remesh();target.data.calc_loop_triangles();before=len(target.data.loop_triangles);dec=target.modifiers.new('120k triangle budget','DECIMATE');dec.ratio=min(1,120000/max(before,1));bpy.ops.object.modifier_apply(modifier=dec.name)
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=1.15192,island_margin=.005);bpy.ops.object.mode_set(mode='OBJECT')
for poly in target.data.polygons:poly.use_smooth=True
m=bpy.data.materials.new('Repaired reference PBR');m.use_nodes=True;m.use_backface_culling=True;target.data.materials.clear();target.data.materials.append(m);n=m.node_tree.nodes;l=m.node_tree.links;bs=n.get('Principled BSDF');s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=1;s.cycles.use_denoising=False;s.render.bake.use_selected_to_active=True;s.render.bake.max_ray_distance=.006;s.render.bake.cage_extrusion=.003;s.render.bake.margin=8
source.select_set(True);images={}
for field in ['Base Color','Roughness','Metallic']:
 saved=[]
 for sm in source.data.materials:
  sn=sm.node_tree.nodes;sl=sm.node_tree.links;out=next(x for x in sn if x.type=='OUTPUT_MATERIAL');shader=next(x for x in sn if x.type=='BSDF_PRINCIPLED');old=out.inputs['Surface'].links[0].from_socket;em=sn.new('ShaderNodeEmission');em.inputs['Strength'].default_value=1;inp=shader.inputs[field]
  if inp.links:sl.new(inp.links[0].from_socket,em.inputs['Color'])
  else:em.inputs['Color'].default_value=tuple(inp.default_value)if field=='Base Color'else(inp.default_value,)*3+(1,)
  sl.new(em.outputs[0],out.inputs['Surface']);saved.append((sm,old,out,em))
 im=bpy.data.images.new('Repair '+field,width=2048,height=2048,alpha=False);im.colorspace_settings.name='sRGB'if field=='Base Color'else'Non-Color';tex=n.new('ShaderNodeTexImage');tex.image=im;n.active=tex;print('Baking '+field,flush=True);bpy.ops.object.bake(type='EMIT');im.filepath_raw=str(O/(field.lower()+'.png'));im.file_format='PNG';im.save();l.new(tex.outputs['Color'],bs.inputs[field]);images[field]=im.filepath_raw
 for sm,old,out,em in saved:sm.node_tree.links.new(old,out.inputs['Surface']);sm.node_tree.nodes.remove(em)
bm=bmesh.new();bm.from_mesh(target.data);bmesh.ops.triangulate(bm,faces=list(bm.faces));report={'voxel_size':.0015,'pre_decimation_triangles':before,'triangles':len(bm.faces),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'degenerate_faces':sum(f.calc_area()<=1e-12 for f in bm.faces),'images':images,'native_accepted':False,'scope':'Repaired static reference; muzzle direction, missing lime details and moving parts are NOT solved by this pass'};bm.free();source.select_set(False);source.hide_render=True;source.hide_set(True);target.select_set(True);bpy.ops.wm.save_as_mainfile(filepath=str(O/'repaired-reference.blend'));bpy.ops.export_scene.gltf(filepath=str(O/'repaired-reference.glb'),export_format='GLB',use_selection=True,export_apply=True);(O/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
