import bpy,bmesh,json
from pathlib import Path
R=Path(__file__).resolve().parent/'apoco-trial-1024/repair-v1';p=R/'repaired-isolated-triangles-removed.glb'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=str(p));reports=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 bm=bmesh.new();bm.from_mesh(o.data);before=len(bm.faces);groups={};targets={}
 for v in bm.verts:
  key=tuple(v.co)
  if key in groups:targets[v]=groups[key]
  else:groups[key]=v
 bmesh.ops.weld_verts(bm,targetmap=targets)
 report={'imported_faces':before,'welded_faces':len(bm.faces),'boundary_edges':sum(e.is_boundary for e in bm.edges),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'zero_area_faces':sum(f.calc_area()<=1e-12 for f in bm.faces)}
 assert before==119994 and report['welded_faces']==119994 and report['boundary_edges']==report['nonmanifold_edges']==report['zero_area_faces']==0,report
 reports.append(report);bm.free()
bpy.ops.export_scene.gltf(filepath=str(R/'roundtrip-verified-reference.glb'),export_format='GLB')
(R/'blender-roundtrip-receipt.json').write_text(json.dumps({'reports':reports,'native_accepted':False,'scope':'Blender import plus exact-position topology check; reexport requires independent parser check'},indent=2)+'\n');print(reports)
