import pathlib,json,subprocess,resource,time,datetime,os
R=pathlib.Path(__file__).resolve().parent;out=R/'apoco-trial-1024';out.mkdir(exist_ok=True);cmd=['stdbuf','-oL','-eL',str(R/'build/trellis-cli'),str(R/'apoco-rifle-input.png'),str(out/'apoco-rifle-reference.glb'),'--models',str(R/'models-q8-1024'),'--gpu','-1','--backend','CPU','--threads','8','--res','1024','--steps','12','--faces','120000','--atlas','2048','--webp','off','--dump-bg','--verbose']
def limits():resource.setrlimit(resource.RLIMIT_AS,(7_000_000*1024,7_000_000*1024))
start=time.monotonic()
with (out/'run.log').open('w')as f:
 result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,preexec_fn=limits,env={**os.environ,'TRELLIS_DUMP_POST':str(out/'decoded-source.post')})
r=resource.getrusage(resource.RUSAGE_CHILDREN);(out/'process-receipt.json').write_text(json.dumps({'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'max_rss_kib':r.ru_maxrss,'command':cmd,'native_acceptance':False},indent=2)+'\n');print('Trial exit',result.returncode,flush=True);raise SystemExit(result.returncode)
