"""Cap only isolated three-edge export holes; preserve existing embedded PBR data.
This repairs three tiny static reference holes, not animation or concept fidelity.
"""
from pathlib import Path
import sys,json,struct,collections,itertools,hashlib,numpy as np
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'source/tools'));import glb_metrics as m
p=R/'apoco-trial-1024/repair-v1/repaired-reference.glb';g,b=m.parse_glb(p);assert len(g['meshes'])==1 and len(g['meshes'][0]['primitives'])==1
q=g['meshes'][0]['primitives'][0];v=m.read_accessor(g,b,q['attributes']['POSITION']);uv=m.read_accessor(g,b,q['attributes']['TEXCOORD_0']);idx=m.read_accessor(g,b,q['indices']).reshape(-1,3).astype(np.uint32);u,inv=np.unique(v,axis=0,return_inverse=True);faces=inv[idx];edges=collections.defaultdict(list)
for f in faces:
 for a,c in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(a),int(c))))].append((int(a),int(c)))
boundary=[x[0]for x in edges.values()if len(x)==1];adj=collections.defaultdict(set)
for a,c in boundary:adj[a].add(c);adj[c].add(a)
seen=set();caps=[];reports=[]
for first in adj:
 if first in seen:continue
 comp=set();todo=[first]
 while todo:
  x=todo.pop()
  if x in comp:continue
  comp.add(x);todo.extend(adj[x]-comp)
 seen|=comp;assert len(comp)==3 and all(len(adj[x])==2 for x in comp),'Not a simple triangular hole'
 a,c=next(e for e in boundary if e[0]in comp);third=next(iter(comp-{a,c}));order=[c,a,third]
 assert all((int(y),int(x))in boundary for x,y in zip(order,np.roll(order,-1))),'Cap winding mismatch'
 geom_area=float(np.linalg.norm(np.cross(u[a]-u[c],u[third]-u[c]))/2);assert 1e-12<geom_area<1e-5,'Unexpected hole area'
 choices=[np.flatnonzero(inv==x).tolist()for x in order];best=None
 for trial in itertools.product(*choices):
  coords=uv[list(trial)];area=abs(float(np.linalg.det(np.stack([coords[1]-coords[0],coords[2]-coords[0]]))))/2
  if area<=1e-10:continue
  score=float(sum(np.sum((coords[i]-coords[(i+1)%3])**2)for i in range(3)))
  if best is None or score<best[0]:best=(score,trial,area)
 assert best is not None,'No noncollapsed existing UV assignment';caps.append(best[1]);reports.append({'positions':u[order].tolist(),'geometry_area':geom_area,'uv_area':best[2],'uv_perimeter_squared':best[0]})
assert len(caps)==3,'Unexpected number of holes; stop for inspection'
allidx=np.concatenate([idx,np.asarray(caps,dtype=np.uint32)]).astype('<u4');raw=allidx.tobytes();b=b+bytes((-len(b))%4);offset=len(b);b+=raw;view=len(g['bufferViews']);g['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':len(raw),'target':34963});acc=len(g['accessors']);g['accessors'].append({'bufferView':view,'componentType':5125,'count':int(allidx.size),'type':'SCALAR','min':[int(allidx.min())],'max':[int(allidx.max())]});q['indices']=acc;g['buffers'][0]['byteLength']=len(b);jb=json.dumps(g,separators=(',',':')).encode();jb+=b' '*((-len(jb))%4);b+=bytes((-len(b))%4);out=p.parent/'repaired-capped-reference.glb';payload=struct.pack('<4sII',b'glTF',2,12+8+len(jb)+8+len(b))+struct.pack('<II',len(jb),0x4e4f534a)+jb+struct.pack('<II',len(b),0x004e4942)+b;out.write_bytes(payload);(p.parent/'cap-receipt.json').write_text(json.dumps({'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(payload).hexdigest(),'caps':reports,'native_accepted':False,'scope':'Only three isolated triangular export holes; material channels unchanged; visual review required'},indent=2)+'\n');print('Added',len(caps),'small caps to',out)
