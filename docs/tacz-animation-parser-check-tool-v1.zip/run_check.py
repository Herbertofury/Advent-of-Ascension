"""Reproduce a numeric-animation parser study, not a game launch or native render test."""
import pathlib,json,hashlib,urllib.request,subprocess,os,shutil
R=pathlib.Path(__file__).resolve().parent;m=json.loads((R/'manifest.json').read_text());cache=R/'cache';cache.mkdir(exist_ok=True)
def fetch(entry):
 path=cache/entry['path']
 if path.exists()and hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256']:return
 b=urllib.request.urlopen(entry['url']).read();assert hashlib.sha256(b).hexdigest()==entry['sha256'],entry['url'];path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b)
for entry in m['downloads']:fetch(entry)
home=os.getenv('JAVA_HOME');javac=str(pathlib.Path(home)/'bin/javac')if home else shutil.which('javac');java=str(pathlib.Path(home)/'bin/java')if home else shutil.which('java');assert javac and java,'Set JAVA_HOME to a full JDK17+';classes=cache/'classes';classes.mkdir(exist_ok=True);cp=str(cache/'lib/*');sources=[*sorted((cache/'src').rglob('*.java')),*sorted((R/'harness').rglob('*.java'))]
subprocess.run([javac,'--release','17','-cp',cp,'-d',str(classes),*map(str,sources)],check=True)
files=sorted((R/'animations').glob('*.json'))
for p in files:assert hashlib.sha256(p.read_bytes()).hexdigest()==m['input_hashes'][p.name]
subprocess.run([java,'-cp',str(classes)+os.pathsep+cp,'AnimationParserCheck',*map(str,files)],check=True)
