# Isolated numeric animation parser check

Run python run_check.py with JAVA_HOME set to JDK17+. It fetches seven pinned unmodified upstream TaCZ Java files and four version-pinned libraries, verifies SHA256, compiles and checks eight original animation files (historical variants and a duplicate are included).

Explicit stand-ins: GunMod is a diagnostic counter, GsonHelper only accepts primitive numeric conversion, and ResourceLocation is an unused type placeholder. Sound records are deliberately rejected by this harness. The actual client, state machines, interpolation, sound resolution, hands and game are not tested.

Valid authored files must produce no unsupported-expression diagnostics. Synthetic fixtures separately prove that the pinned serializer drops a standalone Molang-style string and replaces a string vector component with zero; these are compatibility warnings, not expression support. Do not claim any native acceptance from this study.

Upstream source/dependency files are fetched from original public sources, not redistributed. Included model-animation JSON and test code are our original authoring work. Respect the dependencies' licenses.
