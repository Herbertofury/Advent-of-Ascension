package com.tacz.guns;
/** Captures parser diagnostics only; not the mod entrypoint. */
public final class GunMod {public static final Log LOGGER=new Log();public static final class Log {public int messages;public void debug(String template,Object value){messages++;}}}
