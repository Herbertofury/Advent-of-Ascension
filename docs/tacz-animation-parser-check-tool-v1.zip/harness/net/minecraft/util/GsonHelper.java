package net.minecraft.util;
import com.google.gson.*;
/** Narrow test stand-in: numeric conversion only. Not the Minecraft implementation. */
public final class GsonHelper {public static float convertToFloat(JsonElement e,String name){if(!e.isJsonPrimitive()||!e.getAsJsonPrimitive().isNumber())throw new JsonSyntaxException("Expected numeric "+name);return e.getAsFloat();}}
