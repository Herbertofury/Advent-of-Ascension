"""Verify narrow source claims from a pinned AoA release, without executing game code."""
from pathlib import Path
import argparse,hashlib,zipfile,subprocess,json
p=argparse.ArgumentParser();p.add_argument('jar',type=Path);p.add_argument('--javap',required=True);a=p.parse_args()
assert hashlib.sha256(a.jar.read_bytes()).hexdigest()=='f417ecb337d4a3b2aebec559a9262d8a86cc93ee7910f4eea64108bff063193a'
z=zipfile.ZipFile(a.jar)
def read(c):return subprocess.check_output([a.javap,'-classpath',str(a.jar),'-p','-c','-constants',c],text=True)
reg=read('net.tslat.aoa3.common.registration.item.AoAWeapons');base=read('net.tslat.aoa3.content.item.weapon.cannon.BaseCannon');assert 'AoAItems.CANNONBALL'in base
for cls,damage,durability,delay,recoil in [('MoonCannon',21,855,25,.18),('EnergyCannon',18.5,610,25,.21),('BalloonBomber',12.5,505,24,.22)]:
 c='net.tslat.aoa3.content.item.weapon.cannon.'+cls;s=read(c);part=next(t for t in reg.split('private static')if '// class '+c.replace('.','/')in t)
 for marker in [f'float {float(damage)}f',str(durability),str(delay),f'float {recoil}f']:assert marker in part,(cls,marker)
 assert 'bipush        120'in s and 'iconst_0'in s
 if cls!='BalloonBomber':
  assert 'float 0.75f'in s and 'float 0.25f'in s
  assert s.index('DamageUtil.doHeavyGunAttack')<s.index('DamageUtil.doEnergyProjectileAttack')
 else: assert 'AoAItems.BALLOON'in s
b=read('net.tslat.aoa3.content.entity.projectile.cannon.BalloonBombEntity');assert 'float 0.1f'in b and 'float 1.5f'in b and b.count('Method explode:')==2
recipe=json.loads(z.read('data/aoa3/recipes/infusion_energy_cannon.json'));assert recipe['type']=='aoa3:infusion'and len(recipe['ingredients'])==5
assert sum(x.get('item')=='aoa3:runic_energy'for x in recipe['ingredients'])==2
assert sum(x.get('tag')=='forge:ingots/elecanium'for x in recipe['ingredients'])==2
print(json.dumps({'status':'PASS','profiles':['Moon Cannon','Energy Cannon','Balloon Bomber'],'scope':'Pinned constructor inputs, selected damage routing markers, projectile inputs and recipe structure only','native_accepted':False}))
