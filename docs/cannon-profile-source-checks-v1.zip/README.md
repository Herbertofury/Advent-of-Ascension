Run verify_cannon_profiles.py against your own AoA 3.7.1 JAR with --javap pointing to JDK17 javap. Narrow marker/recipe checks only; no native acceptance. Game binaries are not included.
