import bpy,bmesh,json,argparse,sys
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--directory',type=Path,required=True);args=parser.parse_args(sys.argv[sys.argv.index('--')+1:]);R=args.directory;bpy.ops.wm.open_mainfile(filepath=str(R/'discharge-capacitor-canopy.blend'));new=[o for o in bpy.context.scene.objects if o.name.startswith('V34 arched capacitor canopy ')];assert len(new)==2;dg=bpy.context.evaluated_depsgraph_get();results=[]
for o in new:
 bm=bmesh.new();bm.from_mesh(o.data);nonmanifold=sum(not e.is_manifold for e in bm.edges);volume=bm.calc_volume(signed=True);bm.free();assert o.parent.name=='Discharge_Root';assert nonmanifold==0 and volume>0
 e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();bad=0
 for t in m.loop_triangles:
  a,b,c=[o.matrix_world@m.vertices[v].co for v in t.vertices];bad+=(b-a).cross(c-a).length_squared<1e-20
 results.append({'name':o.name,'nonmanifold_edges':nonmanifold,'volume':volume,'evaluated_triangles':len(m.loop_triangles),'degenerate':bad});e.to_mesh_clear();assert bad==0
(R/'geometry-qa.json').write_text(json.dumps({'scope':'Two added canopy solid/triangle checks only','meshes':results,'native_accepted':False,'art_accepted':False},indent=2));print(results)
