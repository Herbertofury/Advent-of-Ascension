# Discharge capacitor-canopy study v34

Two curved cosmetic sheets replace the visible thin cross-ribs on the capacitor assemblies. The old ribs remain in the editable scene, hidden rather than deleted. This is a partial concept-directed shape refinement, not a finished model or native weapon.

First build the corrected v33 combined scene from its published patch:
https://github.com/Herbertofury/Advent-of-Ascension/raw/refs/heads/main/docs/discharge-combined-authoring-v33-patch.zip

Keep its manifest.json next to discharge-recoil-study.blend. In Blender4.3.2:

blender -b -t 2 --python-exit-code 1 --python build.py -- --source /path/v33-output/discharge-recoil-study.blend --output /path/v34-output --render
blender -b -t 2 --python-exit-code 1 --python check.py -- --directory /path/v34-output
blender -b -t 2 --python-exit-code 1 --python check_surface_sweep.py -- --directory /path/v34-output

The build refuses a scene already carrying V34 objects, expects the three-channel/four-projectile authoring manifest and writes a new scene. It does not change gameplay. The two new meshes are closed positive-volume solids, 348 evaluated triangles each, with no degenerate triangles under the scoped area test. The existing recoil surface-sweep test reports119880 pair samples with no baseline/new intersections; this is not continuous collision, solid containment or player-hand proof.

The canopy remains an art study. Actual concept fidelity, ornaments, textures, hands, complete animation, native TaCZ/TML binding, optional integrations and measured performance remain open. Procedural Blender material appearance is not a native texture/export guarantee.
