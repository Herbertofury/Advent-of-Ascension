import bpy,bmesh,json,argparse,sys,hashlib
from pathlib import Path
from mathutils import Vector
parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--render',action='store_true');args=parser.parse_args(sys.argv[sys.argv.index('--')+1:]);R=args.output;R.mkdir(parents=True,exist_ok=True);source=args.source;recoil=json.loads((source.parent/'manifest.json').read_text());assert len(recoil['mapping'])==18 and recoil['visual_channels']==3 and recoil['original_projectile_burst_count']==4
bpy.ops.wm.open_mainfile(filepath=str(source));assert not any(o.name.startswith('V34 ')for o in bpy.data.objects),'Canopy patch already applied'
(R/'recoil-manifest.json').write_text(json.dumps(recoil,indent=2))
s=bpy.context.scene;s.frame_set(1);bpy.context.view_layer.update();root=bpy.data.objects['Discharge_Root'];made=[]
for i,x in enumerate([0,1.15]):
 rib=bpy.data.objects['V3 crown cross rib'+(''if i==0 else'.001')];M=rib.matrix_world.copy();ys=[-.45,-.35,-.2,0,.2,.35,.45];zs=[2.03,2.075,2.105,2.115,2.105,2.075,2.03];vs=[]
 for zoff in [0,-.055]:
  for dx in [-.43,-.13]:
   for y,z in zip(ys,zs):vs.append(tuple(M@Vector((x+dx,y,z+zoff))))
 n=len(ys);fs=[]
 for j in range(n-1):
  fs += [(j,j+1,n+j+1,n+j),(2*n+j,3*n+j,3*n+j+1,2*n+j+1),(j,2*n+j,2*n+j+1,j+1),(n+j,n+j+1,3*n+j+1,3*n+j)]
 fs += [(0,n,3*n,2*n),(n-1,3*n-1,4*n-1,2*n-1)]
 m=bpy.data.meshes.new('V34 arched canopy');m.from_pydata(vs,[],fs);m.update();bm=bmesh.new();bm.from_mesh(m);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(m);bm.free();o=bpy.data.objects.new('V34 arched capacitor canopy '+str(i+1),m);bpy.context.collection.objects.link(o);m.materials.append(bpy.data.materials['Discharge ceramic-white worn armor']);b=o.modifiers.new('Rounded sheet edges','BEVEL');b.width=.018;b.segments=3;o.modifiers.new('Weighted canopy normals','WEIGHTED_NORMAL');bpy.context.view_layer.update();world=o.matrix_world.copy();o.parent=root;o.matrix_world=world;rib.hide_render=True;rib.hide_viewport=True;made.append(o.name)
bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-capacitor-canopy.blend'));(R/'manifest.json').write_text(json.dumps({'scope':'Two cosmetic curved canopy sheets replace the visual role of thin cross-ribs; original ribs retained hidden','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'added':made,'hidden':['V3 crown cross rib','V3 crown cross rib.001'],'native_accepted':False,'art_accepted':False},indent=2))
if args.render:
 s.render.engine='CYCLES';s.cycles.samples=64;s.cycles.use_denoising=False;s.render.resolution_x=1200;s.render.resolution_y=850;s.render.resolution_percentage=100;c=s.camera;c.location=(5,15,6);c.rotation_euler=(Vector((-.2,0,.5))-c.location).to_track_quat('-Z','Y').to_euler();c.data.type='ORTHO';c.data.ortho_scale=10;s.render.filepath=str(R/'oblique.png');bpy.ops.render.render(write_still=True)
