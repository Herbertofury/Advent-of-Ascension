import bpy,json,hashlib,argparse,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--out',type=Path,required=True);args=p.parse_args(sys.argv[sys.argv.index('--')+1:]);bpy.ops.wm.open_mainfile(filepath=str(args.source.resolve()));dg=bpy.context.evaluated_depsgraph_get();seen={};duplicates=[]
for o in bpy.data.objects:
 if o.type not in {'MESH','CURVE'}or o.hide_render:continue
 e=o.evaluated_get(dg);me=e.to_mesh();me.calc_loop_triangles();positions=[tuple(round(x,7)for x in (o.matrix_world@v.co))for v in me.vertices];tris=sorted(tuple(sorted(positions[i]for i in t.vertices))for t in me.loop_triangles);key=hashlib.sha256(repr(tris).encode()).hexdigest();e.to_mesh_clear()
 if key in seen:duplicates.append([seen[key],o.name])
 else:seen[key]=o.name
args.out.write_text(json.dumps({'exact_coincident_surfaces_at_1e_7_quantization':duplicates,'source_sha256':hashlib.sha256(args.source.read_bytes()).hexdigest(),'scope':'Neutral pose only, evaluated triangle-coordinate multiset; review intentional overlays manually'},indent=2)+'\n');print(duplicates)

if duplicates:raise SystemExit(2)
