import bpy,bmesh,json,argparse,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);bpy.ops.wm.open_mainfile(filepath=str(a.source.resolve()));dg=bpy.context.evaluated_depsgraph_get();negative=[];closed=0;open_count=0
for o in bpy.data.objects:
 if o.type not in {'MESH','CURVE'}or o.hide_render:continue
 e=o.evaluated_get(dg);me=e.to_mesh();bm=bmesh.new();bm.from_mesh(me);bm.transform(o.matrix_world)
 if bm.edges and all(edge.is_manifold for edge in bm.edges):
  closed+=1;volume=bm.calc_volume(signed=True)
  if volume<-1e-9:negative.append({'object':o.name,'signed_world_volume':volume})
 else:open_count+=1
 bm.free();e.to_mesh_clear()
r={'closed_manifold_objects':closed,'open_or_nonmanifold_objects':open_count,'negative_closed_volumes':negative,'scope':'Neutral-pose closed-manifold signed volume; open surfaces need separate normal-side review'};a.out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
