import bpy,json,hashlib,argparse,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--report',type=Path,required=True);p.add_argument('--before',type=Path,required=True);p.add_argument('--after',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);names=[r['object']for r in json.loads(a.report.read_text())['corrected']]
def capture(file):
 bpy.ops.wm.open_mainfile(filepath=str(file.resolve()));d={}
 for name in names:
  o=bpy.data.objects[name];me=o.data;faces=[]
  for poly in me.polygons:
   corners=[]
   for li in poly.loop_indices:
    co=tuple(me.vertices[me.loops[li].vertex_index].co);uv=tuple((layer.name,tuple(layer.data[li].uv))for layer in me.uv_layers);corners.append((co,uv))
   faces.append((poly.material_index,tuple(sorted(corners))))
  d[name]={'surface_uv_material_hash':hashlib.sha256(repr(sorted(faces)).encode()).hexdigest(),'materials':[m.name if m else None for m in me.materials],'matrix_world':[list(row)for row in o.matrix_world]}
 return d
before=capture(a.before);after=capture(a.after);changed=[n for n in names if before[n]!=after[n]];result={'checked_objects':len(names),'changed_surface_uv_material_or_transform':changed,'scope':'Unoriented faces/corner UVs/material indices/transforms unchanged; normals intentionally corrected'};a.out.write_text(json.dumps(result,indent=2)+'\n');print(result);assert not changed
