"""Repair only verified closed negatively oriented meshes; never auto-repair open surfaces."""
import bpy,bmesh,json,argparse,sys,hashlib
from pathlib import Path
from mathutils import Vector
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--report',type=Path,required=True);p.add_argument('--radial-panel-prefix');a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);assert a.source.resolve()!=a.output.resolve();bpy.ops.wm.open_mainfile(filepath=str(a.source.resolve()));s=bpy.context.scene;s.frame_set(0);dg=bpy.context.evaluated_depsgraph_get();fixed=[]
def coordinates(me):return hashlib.sha256(repr(sorted(tuple(v.co)for v in me.vertices)).encode()).hexdigest()
for o in list(bpy.data.objects):
 if o.type!='MESH'or o.hide_render:continue
 e=o.evaluated_get(dg);me=e.to_mesh();bm=bmesh.new();bm.from_mesh(me);bm.transform(o.matrix_world);closed=bool(bm.edges)and all(x.is_manifold for x in bm.edges);vol=bm.calc_volume(signed=True)if closed else None;bm.free();e.to_mesh_clear();radial=False
 if a.radial_panel_prefix and o.name.startswith(a.radial_panel_prefix):
  center=o.matrix_world@(sum((v.co for v in o.data.vertices),Vector())/len(o.data.vertices));n=o.matrix_world.to_3x3().inverted().transposed();radial=sum((n@p.normal).y*center.y for p in o.data.polygons)<0
 if not(closed and vol<-1e-9)and not radial:continue
 assert o.matrix_world.to_3x3().determinant()>0,'Mirrored transform requires explicit export-normal handling: '+o.name
 assert o.data.shape_keys is None,'Shape-key mesh needs explicit handling: '+o.name
 if o.data.users>1:o.data=o.data.copy()
 before=coordinates(o.data);bm=bmesh.new();bm.from_mesh(o.data)
 if closed:
  assert all(e.is_manifold for e in bm.edges),'Base mesh differs from evaluated manifold: '+o.name
  bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
  world=bm.copy();world.transform(o.matrix_world)
  if world.calc_volume(signed=True)<0:bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
  world.free()
 else:bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
 bm.to_mesh(o.data);bm.free();o.data.update();assert before==coordinates(o.data),'Vertex positions changed'
 fixed.append({'object':o.name,'previous_signed_world_volume':vol,'reason':'closed negative winding'if closed else'explicit grip-panel outward-side check','vertex_positions_unchanged':True})
a.output.parent.mkdir(parents=True,exist_ok=True);bpy.ops.wm.save_as_mainfile(filepath=str(a.output.resolve()));a.report.write_text(json.dumps({'source_sha256':hashlib.sha256(a.source.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(a.output.read_bytes()).hexdigest(),'corrected':fixed,'scope':'Winding repair only; open surfaces, collision, hand fit and native rendering still require review'},indent=2)+'\n');print('Corrected',len(fixed),'objects')
