import bpy,sys
from pathlib import Path
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for name,x in [('Base',0),('Duplicate',0),('Separate',.01)]:
 bpy.ops.mesh.primitive_cube_add(size=1,location=(x,0,0));bpy.context.object.name=name
bpy.ops.wm.save_as_mainfile(filepath=str(Path(sys.argv[sys.argv.index('--')+1]).resolve()))
