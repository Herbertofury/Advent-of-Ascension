import bpy,json,math
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'soul-storm-sculpt-v17/soul-storm-v17.blend'));s=bpy.context.scene;s.frame_set(0);new=[]
steel=bpy.data.materials['Brushed silver'];indigo=bpy.data.materials['Anodized indigo'];cyan=bpy.data.materials['Spirit cyan']
def box(name,lo,hi,mat,parent):
 bpy.ops.mesh.primitive_cube_add(size=1,location=(Vector(lo)+Vector(hi))/2);o=bpy.context.object;o.dimensions=Vector(hi)-Vector(lo);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.name=name;o.parent=parent;o.data.materials.append(mat);m=o.modifiers.new('Subtle panel edge','BEVEL');m.width=.012;m.segments=2;new.append(o.name);return o
# Actual windows in the emitter side walls expose the contained fictional energy.
for o in list(bpy.data.objects):
 if o.name.startswith('Emitter side wall')and not o.hide_render:
  pts=[o.matrix_world@Vector(v)for v in o.bound_box];lo=Vector([min(v[i]for v in pts)for i in range(3)]);hi=Vector([max(v[i]for v in pts)for i in range(3)]);o.hide_render=True
  box('V18 rear channel collar',lo,(.65,hi.y,hi.z),indigo,o.parent);box('V18 front engraved armor',(2.56,lo.y,lo.z),hi,indigo,o.parent)
  # A thin border seats the opening; it does not fill the luminous cavity.
  for z in [lo.z,hi.z-.035]:box('V18 chamber edge',(.65,lo.y,z),(2.56,hi.y,z+.035),steel,o.parent)
 if o.name.startswith(('V15 branching soul inscription','V15 inscription fork')):
  world=o.matrix_world.copy();inv=world.inverted()
  if o.type=='MESH':
   for v in o.data.vertices:p=world@v.co;p.x+=1.85;v.co=inv@p
  elif o.type=='CURVE':
   for sp in o.data.splines:
    for v in sp.points:p=world@Vector(v.co[:3]);p.x+=1.85;v.co=(* (inv@p),1)
 if o.name.startswith(('Inlaid channel rune','V15 emitter silver bevel inlay')):o.hide_render=True
# Cosmetic energy filaments sit inside each opening and retain its moving emitter parent.
for e in [o for o in bpy.data.objects if o.name.startswith('Emitter_')and o.name.endswith('_top_to_bottom')]:
 coupler=next(o for o in e.children if o.name.startswith('Rear energy coupler'));pts=[coupler.matrix_world@Vector(v)for v in coupler.bound_box];z=(min(v.z for v in pts)+max(v.z for v in pts))/2
 for side in [-1,1]:
  for k in range(2):
   c=bpy.data.curves.new('V18 contained soul filament','CURVE');c.dimensions='3D';c.resolution_u=1;c.bevel_depth=.013;c.bevel_resolution=2;sp=c.splines.new('POLY');sp.points.add(24)
   for j,p in enumerate(sp.points):t=j/24;p.co=(.64+1.92*t,side*.59,z+.085*math.sin(t*math.tau*1.4+k*math.pi),1)
   o=bpy.data.objects.new('V18 contained soul filament',c);bpy.context.collection.objects.link(o);o.parent=e;o.data.materials.append(cyan);new.append(o.name)
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'soul-storm-v18.blend'));s.cycles.samples=32;s.render.filepath=str(R/'hero.png');bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'Unaccepted open-channel authoring experiment','new_objects':new,'native_acceptance':False,'open':['Full moving-part clearance and mesh checks','Concept fidelity and material finishing','Actual native effect and gameplay integration']},indent=2)+'\n')
