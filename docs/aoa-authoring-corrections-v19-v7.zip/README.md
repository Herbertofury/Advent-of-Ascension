# AoA authoring corrections: Soul Storm v19 and Discharge v7

Both are unfinished authoring prototypes. Neither is a playable TaCZ gunpack or accepted as matching the selected concept. Open the packed .blend files to inspect the latest geometry.

Soul Storm adds a fitted heel, a swept lower receiver/guard and open energy-channel windows. Its rooted flame/focus experiment remains from v16. The latest pass corrects 36 inward-facing closed parts without changing their geometry, UVs, materials or transforms. Texture art, full hand clearance, native effects and complete gameplay remain open.

Discharge adds a shaped rear service assembly, shallow grip contact grooves and curved side panels. Two duplicated crown ribs were removed in v4. v7 normalizes closed-face winding during generation, corrects the reviewed grip-panel orientation, and caps prism/cylinder bevels by thickness. Twenty actual-constructor regression fixtures pass. It still looks simpler than the chosen concept and lacks its complete animation/effect/native package.

## Rebuild dependencies

- Soul: obtain the published v16 source package as sibling soul-storm-sculpt-v16/. Run the included v17/build.py, then v18/build.py. Apply weapon-surface-audit/fix_closed_winding.py to the v18 blend to produce v19. The saved v19 blend itself is standalone with packed images.
- Discharge: the included v7/build.py is a self-contained generator with thickness-aware bevels and winding normalization. Run its area, winding, duplicate-surface and thin-part checks before using any export.
- Use Blender 4.3.2 and --python-exit-code 1. The source/hash reports identify the actual files used in the recorded checks.

Read the geometry-audit README before interpreting the reports. Full native culling, open surfaces and continuous spatial/animation QA remain unresolved. All older concepts and intentional alternate designs remain available separately.
