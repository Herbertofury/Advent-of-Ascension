import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-v19.blend'));s=bpy.context.scene;rows=[];focus_values=[];inactive=[];triangles_checked=0
for frame in range(101):
 s.frame_set(frame);focus_values.append(float(s['focus']));dg=bpy.context.evaluated_depsgraph_get();bad=[]
 for o in bpy.data.objects:
  if o.type not in {'MESH','CURVE'}or o.hide_render:continue
  e=o.evaluated_get(dg)
  ancestors=[];parent=o.parent
  while parent:ancestors.append(parent);parent=parent.parent
  inactive_parent=next((p for p in ancestors if p.name.startswith('Authoring_disc_')and max(abs(v)for v in p.scale)<1e-10),None)
  if inactive_parent:
   inactive.append({'frame':frame,'object':o.name,'authoring_parent':inactive_parent.name,'reason':'Explicit zero-scale inactive authoring projectile; not native visibility proof'})
   continue
  m=e.to_mesh();m.calc_loop_triangles();triangles_checked+=len(m.loop_triangles)
  for idx,t in enumerate(m.loop_triangles):
   pts=[o.matrix_world@m.vertices[v].co for v in t.vertices]
   if (pts[1]-pts[0]).cross(pts[2]-pts[0]).length_squared<1e-20:bad.append([o.name,idx])
  e.to_mesh_clear()
 if bad:rows.append({'frame':frame,'focus':s['focus'],'bad':bad})
assert len(set(round(v,6)for v in focus_values))>=15,'Focus snapped between states instead of morphing';assert abs(focus_values[25]-.5)<.01,'Midpoint morph missing'
(R/'full-focus-progress-qa.json').write_text(json.dumps({'samples':101,'unique_focus_values':len(set(round(v,6)for v in focus_values)),'midpoint':focus_values[25],'range':[min(focus_values),max(focus_values)],'native_acceptance':False},indent=2)+'\n')
(R/'full-active-geometry-qa.json').write_text(json.dumps({'samples':101,'active_triangles_checked':triangles_checked,'degenerate_active_frames':rows,'explicit_inactive_object_frame_records':inactive,'scope':'All visible nonzero-scale evaluated meshes; declared zero-scale authoring projectiles recorded separately','native_acceptance':False},indent=2)+'\n');print('Frames with degenerate active geometry:',len(rows));assert not rows,[(r['frame'],len(r['bad']))for r in rows[:5]]
