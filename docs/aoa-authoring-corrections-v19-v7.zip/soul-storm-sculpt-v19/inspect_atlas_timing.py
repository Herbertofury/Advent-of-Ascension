import bpy,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;source=R/'soul-storm-v19.blend';bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene;material=bpy.data.materials['V16 living soul fire'];node=next(n for n in material.node_tree.nodes if n.type=='VECT_MATH'and n.operation=='ADD');cells=[]
for frame in range(64):
 s.frame_set(frame);offset=node.inputs[1].default_value;col=round(offset[0]*4);row=3-round(offset[1]*4);cells.append(row*4+col)
assert cells==[frame//4 for frame in range(64)],cells
fps=s.render.fps/s.render.fps_base;report={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scene_fps':s.render.fps,'fps_base':s.render.fps_base,'authoring_frames_per_atlas_cell':4,'atlas_cells_per_second':fps/4,'cell_count':16,'cycle_seconds':16/(fps/4),'observed_cell_indices_frames_0_to_63':cells,'native_acceptance':False};(R/'atlas-timing-evidence.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified atlas rate',fps/4,'cells/s')
