import bpy,math,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'soul-storm-sculpt-v16/soul-storm-v16.blend'));s=bpy.context.scene;s.frame_set(0);root=bpy.data.objects['SoulStorm_Root'];steel=bpy.data.materials['Brushed silver'];indigo=bpy.data.materials['Anodized indigo'];cyan=bpy.data.materials['Spirit cyan'];dark=bpy.data.materials['Obsidian violet'];new=[]
def mesh(n,vs,fs,m):
 me=bpy.data.meshes.new(n);me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(o);o.parent=root;o.data.materials.append(m);new.append(o.name);return o
def prism(n,profile,y,depth,m):
 N=len(profile);vs=[(x,y+d,z)for d in [-depth/2,depth/2]for x,z in profile];fs=[tuple(range(N-1,-1,-1)),tuple(range(N,2*N))]+[(i,(i+1)%N,(i+1)%N+N,i+N)for i in range(N)];return mesh(n,vs,fs,m)
def tube(n,pts,r,m):
 c=bpy.data.curves.new(n,'CURVE');c.dimensions='3D';c.resolution_u=1;c.bevel_depth=r;c.bevel_resolution=2;sp=c.splines.new('POLY');sp.points.add(len(pts)-1)
 for p,co in zip(sp.points,pts):p.co=(*co,1)
 o=bpy.data.objects.new(n,c);bpy.context.collection.objects.link(o);o.parent=root;o.data.materials.append(m);new.append(o.name);return o
# Curved lower receiver fins tie the circular core to the rail architecture.
for side in [-1,1]:
 y=side*.73
 outline=[(-1.77,.23),(-1.38,.28),(-.89,.12),(-.24,-.02),(.48,.00),(1.14,.17),(.82,-.12),(.24,-.32),(-.46,-.34),(-1.10,-.17),(-1.59,.06)]
 prism('V17 swept lower receiver wing',outline,y,.11,indigo)
 tube('V17 receiver wing silver edge',[(x,y+side*.067,z)for x,z in outline+[outline[0]]],.018,steel)
 tube('V17 receiver wing soul seam',[(-1.35,y+side*.07,.16),(-.83,y+side*.07,-.04),(-.20,y+side*.07,-.17),(.44,y+side*.07,-.14)],.012,cyan)
# A curved guard connects to the grip and lower receiver; clearance remains to be tested.
pts=[]
for i in range(17):
 t=i/16;pts.append((-2.68+1.00*math.sin(math.pi*t),0,-.04-.72*t))
pts[-1]=(-2.95,0,-.76)
tube('V17 curved open grip guard',pts,.065,steel)
# Fitted faceted heel instead of a generic cylindrical end ring.
for o in bpy.data.objects:
 if o.name.startswith('V16 fitted heel cap'):o.hide_render=True
N=12;vs=[]
for t,inflate in [(.86,.035),(1.02,.10)]:
 x=-3.08-.55*t-.10*math.sin(math.pi*t);z=.12-1.74*t;rx=.43+.04*math.sin(math.pi*t)+inflate;ry=.49-.035*t+inflate
 for k in range(N):a=math.tau*k/N;vs.append((x+rx*math.cos(a),ry*math.sin(a),z))
fs=[tuple(range(N-1,-1,-1)),tuple(range(N,2*N))]+[(i,(i+1)%N,(i+1)%N+N,i+N)for i in range(N)];mesh('V17 faceted fitted heel armor',vs,fs,indigo)
for layer in [0,1]:tube('V17 heel silver perimeter',[vs[layer*N+k]for k in range(N)]+[vs[layer*N]],.018,steel)
# Small seated side crests remain within the heel footprint.
for side in [-1,1]:
 x=-3.62;z=-1.51;y=side*.52
 prism('V17 heel crest setting',[(x-.16,z),(x,z+.13),(x+.16,z),(x,z-.10)],y,.035,steel)
 prism('V17 heel cyan crest',[(x-.08,z),(x,z+.07),(x+.08,z),(x,z-.05)],y+side*.024,.018,cyan)
s.frame_set(0);s.cycles.samples=40;bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'soul-storm-v17.blend'));s.render.filepath=str(R/'hero.png');bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'Unaccepted authoring refinement','new_objects':new,'native_acceptance':False,'open':['Guard and receiver clearance','Concept fidelity and textures','Complete effects and gameplay']},indent=2)+'\n')
