# Existing weapon-review discovery

Links existing per-weapon feature-status manifests into weapon-feature-coverage.json. It changes only the manifest pointer and never promotes concept, implementation, QA, review or acceptance status.

python link_manifests.py --docs /path/to/Advent-of-Ascension/docs --receipt /path/receipt.json
python link_manifests.py --docs /path/to/Advent-of-Ascension/docs --receipt /path/check.json --check
python -m unittest test_link_manifests

Fails on unknown registry IDs, duplicate manifests for one weapon, conflicting existing pointers, invalid filenames or a different source target. Existing review records are not rewritten. Seven synthetic tests cover preservation, idempotence and failure cases. This is discovery/bookkeeping, not evidence of finished art or native gameplay.

Run after generating coverage and adding/updating manifests. The earlier profile-link refresh handles profile URLs separately; both discovery passes should be checked before publication.
