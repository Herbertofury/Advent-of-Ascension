"""Original Soul Storm sculpt v11, rebuilt after reset. Not native game geometry."""
import bpy, math, json
from mathutils import Vector
from pathlib import Path
R=Path(__file__).resolve().parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,color,metal=0,rough=.35,emission=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 if emission:p.inputs['Emission Color'].default_value=(*color,1);p.inputs['Emission Strength'].default_value=emission
 return m
indigo=mat('Anodized indigo',(0.055,.025,.19),.8,.28);dark=mat('Obsidian violet',(.012,.015,.032),.6,.31);steel=mat('Brushed silver',(.43,.52,.65),.85,.25);cyan=mat('Spirit cyan',(.008,.6,1),.1,.24,4);blue=mat('Core blue',(.005,.05,.75),.1,.22,3);rubber=mat('Grip inset',(.008,.012,.023),.05,.7)
root=bpy.data.objects.new('SoulStorm_Root',None);bpy.context.collection.objects.link(root)
def parent(o,p=root):o.parent=p;return o
def finish(o,name,m,p=root,bevel=0):
 o.name=name;o.data.materials.append(m);parent(o,p)
 if bevel:
  mod=o.modifiers.new('Soft machined edges','BEVEL');mod.width=bevel;mod.segments=3
  o.modifiers.new('Weighted face normals','WEIGHTED_NORMAL')
 return o

def box(name,loc,size,m,p=root,bevel=.08):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,m,p,bevel)
def torus(name,loc,r,t,m,rot=(math.pi/2,0,0),p=root):
 bpy.ops.mesh.primitive_torus_add(major_radius=r,minor_radius=t,major_segments=64,minor_segments=10,location=loc,rotation=rot);o=bpy.context.object
 for poly in o.data.polygons:poly.use_smooth=True
 return finish(o,name,m,p)
def path(name,points,width,m,p=root):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=2;c.bevel_depth=width;c.bevel_resolution=3;s=c.splines.new('POLY');s.points.add(len(points)-1)
 for dst,src in zip(s.points,points):dst.co=(*src,1)
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);return finish(o,name,m,p)
def ringarc(name,c,r,start,end,y,width,m):
 pts=[(c[0]+r*math.cos(t),y,c[1]+r*math.sin(t)) for t in [start+(end-start)*i/40 for i in range(41)]];return path(name,pts,width,m)
# Large circular spirit reservoir, the silhouette's primary AoA identity.
cx,cz=-2.4,1.65
for y in [-.62,.62]:
 torus('Core armor hoop',(cx,y,cz),1.52,.22,indigo)
 torus('Core silver rim',(cx,y*1.09,cz),1.36,.065,steel)
 torus('Core luminous seal',(cx,y*1.13,cz),1.24,.04,cyan)
 # Separate directional energy arcs rather than an opaque glowing ball.
 for j in range(5):
  pts=[]
  for i in range(65):
   f=i/64;a=f*math.pi*2+j*math.pi*2/5;r=.08+f*1.05
   pts.append((cx+r*math.cos(a),y*.98,cz+r*math.sin(a)))
  path('Core spiral filament',pts,.012+(.004 if j%2 else 0),cyan if j%2 else blue)
 for k in range(8):
  a=k*math.pi/4;x=cx+1.53*math.cos(a);z=cz+1.53*math.sin(a)
  o=box('Radial silver clamp',(x,y,z),(.31,.24,.48),steel,bevel=.045);o.rotation_euler[1]=math.pi/2-a
  gem=box('Clamp spirit inset',(x,y*1.22,z),(.12,.08,.19),cyan,bevel=.025);gem.rotation_euler[1]=math.pi/2-a
# Central luminous hub, recessed inside the frame.
for y in [-.44,.44]:
 bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,radius=.28,location=(cx,y,cz));finish(bpy.context.object,'Spirit vortex center',cyan)
# Upper and lower tapered swept armor horns, original stylized support geometry.
for y in [-.68,.68]:
 for s in [-1,1]:
  pts=[(cx-1.55,y,cz+s*.5),(cx-1.25,y,cz+s*1.35),(cx-.55,y,cz+s*1.8),(cx+.4,y,cz+s*1.6),(cx+1.35,y,cz+s*.95)]
  path('Swept armor spine',pts,.19,indigo)
  path('Silver swept ridge',[(x,y*1.22,z+.04*s)for x,y,z in pts],.047,steel)
# Four independently animated emitter assemblies. Real hollow slots, not closed glowing plugs.
levels=[2.85,2.02,1.19,.36];emitters=[]
for i,z in enumerate(levels):
 e=bpy.data.objects.new(f'Emitter_{i+1}_top_to_bottom',None);bpy.context.collection.objects.link(e);parent(e);emitters.append(e)
 # Widened housing and silver edging leave a true front aperture.
 box('Emitter upper armor',(2.78,0,z+.19),(5.2,1.75,.22),indigo,e)
 box('Emitter lower armor',(2.78,0,z-.19),(5.2,1.75,.22),indigo,e)
 for y in [-.82,.82]:
  box('Emitter side wall',(2.78,y,z),(5.2,.18,.37),dark,e,bevel=.04)
  box('Emitter external silver rim',(5.29,y,z),(.16,.2,.55),steel,e,bevel=.04)
  # Cyan channel occupies the open internal passage, recessed from the muzzle.
  path('Emitter contained energy',[(.2,y*.55,z),(2.9,y*.55,z),(5.15,y*.55,z)],.037,cyan,e)
 for zz in [z-.27,z+.27]:box('Emitter aperture lip',(5.3,0,zz),(.16,1.85,.12),steel,e,bevel=.025)
 box('Rear energy coupler',(.15,0,z),(.4,1.65,.55),dark,e)
 for x in [1.4,2.5,3.6]:
  # Small luminous accents, keeping large surfaces calm.
  for y in [-.925,.925]:
   o=box('Inlaid channel rune',(x,y,z+.05),(.31,.025,.055),cyan,e,.01);o.rotation_euler[1]=.35*(1 if i%2 else -1)
# Barrel braces link emitter units but don't cover their apertures.
for y in [-1.08,1.08]:
 box('Emitter structural saddle',(3.65,y,1.6),(.38,.25,3.35),steel,bevel=.06)
 box('Saddle indigo face',(3.65,y*1.12,1.6),(.24,.08,2.8),indigo,bevel=.035)
 for z in [.45,1.6,2.75]:
  o=box('Saddle cyan rune',(3.65,y*1.17,z),(.14,.035,.23),cyan,bevel=.025);o.rotation_euler[1]=math.pi/4
# Conduit visible under core to avoid pretending cartridges power this spirit weapon.
for y in [-.75,.75]:path('Spirit conduit',[(-1.2,y,1.5),(-.65,y,1.55),(.1,y,1.65)],.09,cyan)
# Full-size hand grip, downward and rearward of core. No undersized trigger workaround.
grip=box('Ergonomic main grip',(-3.15,0,-.85),(1.0,1.05,2.45),dark,bevel=.18);grip.rotation_euler[1]=-.28
for k in range(5):
 o=box('Grip rib',(-3.2-.11*k,0,-.15-.34*k),(1.08,1.13,.12),rubber,bevel=.05);o.rotation_euler[1]=-.28
box('Grip silver heel',(-3.65,0,-2.02),(1.18,1.25,.29),steel,bevel=.09)
box('Touch activation inset',(-2.72,-.58,-.13),(.28,.08,.43),cyan,bevel=.055)
# Default aiming ornament: animated soul flame. Gem is deliberately not the default.
socket=box('Sight socket',(cx,0,3.5),(.52,.63,.32),steel,bevel=.07)
origin=bpy.data.objects.new('flame_origin',None);bpy.context.collection.objects.link(origin);origin.location=(cx,0,3.63);parent(origin)
verts=[];faces=[];rings=14;segments=16
for j in range(rings):
 t=j/(rings-1);r=.23*(math.sin(math.pi*t)**.7);bend=.23*t*t
 for k in range(segments):
  a=k*math.tau/segments;verts.append((bend+r*math.cos(a),r*.65*math.sin(a),t*.92))
for j in range(rings-1):
 for k in range(segments):faces.append((j*segments+k,j*segments+(k+1)%segments,(j+1)*segments+(k+1)%segments,(j+1)*segments+k))
mesh=bpy.data.meshes.new('Soul flame mesh');mesh.from_pydata(verts,[],faces);mesh.update();fl=bpy.data.objects.new('Default soul flame',mesh);bpy.context.collection.objects.link(fl);finish(fl,'Default soul flame',cyan,origin)
for poly in mesh.polygons:poly.use_smooth=True
# Explicit authoring animation, four events only: top, next, next, bottom.
for i,e in enumerate(emitters):
 start=1+i*6
 for frame,x in [(0,0),(start,0),(start+2,-.28),(start+5,0),(30,0)]:e.location.x=x;e.keyframe_insert('location',frame=frame)
 if e.animation_data:
  for curve in e.animation_data.action.fcurves:
   for k in curve.keyframe_points:k.interpolation='BEZIER'
# v6 artistic correction: enclosed plasma reservoir, tapered armor, restrained exposure.
for ob in bpy.data.objects:
 if ob.name.startswith(('Core spiral filament','Spirit vortex center','Swept armor spine','Silver swept ridge')):
  ob.hide_render=True
plasma=bpy.data.materials.new('Animated contained soul plasma');plasma.use_nodes=True
nodes=plasma.node_tree.nodes;nodes.clear();links=plasma.node_tree.links
tex=nodes.new('ShaderNodeTexCoord');noise=nodes.new('ShaderNodeTexNoise');noise.noise_dimensions='4D';noise.inputs['Scale'].default_value=5;noise.inputs['Detail'].default_value=4;noise.inputs['Roughness'].default_value=.7
links.new(tex.outputs['Generated'],noise.inputs['Vector'])
for frame,w in [(0,0),(15,.4),(30,0)]:noise.inputs['W'].default_value=w;noise.inputs['W'].keyframe_insert('default_value',frame=frame)
ramp=nodes.new('ShaderNodeValToRGB');ramp.color_ramp.elements.remove(ramp.color_ramp.elements[1]);ramp.color_ramp.elements[0].position=.25;ramp.color_ramp.elements[0].color=(.002,.003,.025,1)
for pos,col in [(.4,(.002,.015,.13,1)),(.52,(.002,.12,.65,1)),(.63,(.01,.5,.95,1)),(.75,(.1,.8,1,1))]:ramp.color_ramp.elements.new(pos).color=col
links.new(noise.outputs['Fac'],ramp.inputs['Fac']);shader=nodes.new('ShaderNodeBsdfPrincipled');shader.inputs['Metallic'].default_value=.25;shader.inputs['Roughness'].default_value=.3;shader.inputs['Emission Strength'].default_value=1.8
links.new(ramp.outputs['Color'],shader.inputs['Base Color']);links.new(ramp.outputs['Color'],shader.inputs['Emission Color']);output=nodes.new('ShaderNodeOutputMaterial');links.new(shader.outputs[0],output.inputs['Surface'])
for yy in [-.61,.61]:
 bpy.ops.mesh.primitive_cylinder_add(vertices=96,radius=1.22,depth=.04,location=(cx,yy,cz),rotation=(math.pi/2,0,0));finish(bpy.context.object,'Contained soul plasma face',plasma)
 # Curved sharp armor plates with an outer silver edge; no round plumbing silhouette.
 for sign in [-1,1]:
  points=[];count=20
  for i in range(count):
   f=i/(count-1);ang=math.pi*(.08+.85*f);outer=1.78;inner=outer-(.08+.24*math.sin(math.pi*f));
   points.extend([(cx+outer*math.cos(ang),yy*1.08,cz+sign*outer*math.sin(ang)),(cx+inner*math.cos(ang),yy*1.08,cz+sign*inner*math.sin(ang))])
  faces=[(2*i,2*i+1,2*i+3,2*i+2)for i in range(count-1)]
  mesh=bpy.data.meshes.new('Tapered armor blade');mesh.from_pydata(points,[],faces);mesh.update();ob=bpy.data.objects.new('Tapered armor blade',mesh);bpy.context.collection.objects.link(ob);finish(ob,ob.name,indigo);sol=ob.modifiers.new('Plate thickness','SOLIDIFY');sol.thickness=.14;be=ob.modifiers.new('Plate edge bevel','BEVEL');be.width=.035;be.segments=2
  path('Blade silver inlay',[(x,y-.09 if yy<0 else y+.09,z) for x,y,z in points[::2]],.025,steel)
# Pointed, moving flame with internal material variation and a fixed root.
fl.data.materials.clear();fl.data.materials.append(plasma);import bmesh
bm=bmesh.new();bm.from_mesh(fl.data);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-6);bm.to_mesh(fl.data);bm.free();fl.data.update()
fl.shape_key_add(name='Basis');sway=fl.shape_key_add(name='Soul flame sway')
for i,v in enumerate(sway.data):
 t=v.co.z/.92;v.co.x+=.16*t*t;v.co.y+=.07*math.sin(math.pi*t)
for frame,value in [(0,0),(8,1),(16,0),(23,.65),(30,0)]:sway.value=value;sway.keyframe_insert('value',frame=frame)
# Lower emission and stronger color separation retain detail around the target.
cyan.node_tree.nodes.get('Principled BSDF').inputs['Emission Strength'].default_value=1.6
for ob in bpy.data.objects:
 if ob.name.startswith('Emitter upper armor'):
  # Thin inset center panel breaks up a blank slab without adding random greebles.
  box('Emitter spine inset',tuple(ob.location+Vector((-.3,0,.125))), (3.5,.8,.035),dark,ob.parent,.015)

# v7: polar spiral plasma instead of a flat cloud/noise disk.
coreplasma=plasma.copy();coreplasma.name='Contained spiral soul plasma';ns=coreplasma.node_tree.nodes;lk=coreplasma.node_tree.links
coord=next(n for n in ns if n.type=='TEX_COORD');rampnode=next(n for n in ns if n.type=='VALTORGB');noisenode=next(n for n in ns if n.type=='TEX_NOISE')
sub=ns.new('ShaderNodeVectorMath');sub.operation='SUBTRACT';sub.inputs[1].default_value=(.5,.5,0);lk.new(coord.outputs['Generated'],sub.inputs[0]);sep=ns.new('ShaderNodeSeparateXYZ');lk.new(sub.outputs[0],sep.inputs[0])
def mathnode(op,a,b=None):
 node=ns.new('ShaderNodeMath');node.operation=op
 for i,value in enumerate([a,b] if b is not None else [a]):
  if isinstance(value,(float,int)):node.inputs[i].default_value=value
  else:lk.new(value,node.inputs[i])
 return node.outputs[0]
x,y=sep.outputs['X'],sep.outputs['Y'];radius=mathnode('SQRT',mathnode('ADD',mathnode('MULTIPLY',x,x),mathnode('MULTIPLY',y,y)))
angle=mathnode('ARCTAN2',y,x);phase=mathnode('ADD',mathnode('MULTIPLY',angle,5),mathnode('MULTIPLY',radius,-24));phase=mathnode('ADD',phase,mathnode('MULTIPLY',noisenode.outputs['Fac'],2.5));wave=mathnode('ADD',mathnode('MULTIPLY',mathnode('SINE',phase),.5),.5)
for link in list(lk):
 if link.to_node==rampnode and link.to_socket==rampnode.inputs['Fac']:lk.remove(link)
filaments=mathnode('POWER',wave,12); turbulent=mathnode('MULTIPLY',filaments,mathnode('ADD',.3,mathnode('MULTIPLY',noisenode.outputs['Fac'],.7))); final=mathnode('ADD',.24,mathnode('MULTIPLY',turbulent,.5));lk.new(final,rampnode.inputs['Fac'])
for ob in bpy.data.objects:
 if ob.name.startswith('Contained soul plasma face'):ob.data.materials.clear();ob.data.materials.append(coreplasma)
# Four timed, visibly discrete flying soul discs, authoring cue only.
for i,z in enumerate(levels):
 group=bpy.data.objects.new(f'Authoring_disc_{i+1}',None);bpy.context.collection.objects.link(group);parent(group)
 disc=torus('Soul disc edge',(0,0,0),.65,.055,cyan,rot=(0,math.pi/2,0),p=group);disc.scale.x=.25
 bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,radius=1,location=(0,0,0));body=bpy.context.object;body.scale=(.05,.64,.16);finish(body,'Soul disc plasma',coreplasma,group)
 start=1+i*6
 for frame,xx,scale in [(0,5.7,0),(start+1,5.7,0),(start+2,5.9,1),(start+5,7.3,1),(start+5.99,7.8,0),(30,7.8,0)]:
  group.location=(xx,0,z);group.scale=(scale,scale,scale);group.keyframe_insert('location',frame=frame);group.keyframe_insert('scale',frame=frame)
 for curve in group.animation_data.action.fcurves:
  for key in curve.keyframe_points:key.interpolation='LINEAR'

# v11: tapered emitter housings and correctly wrapped grip ribs.
for ob in list(bpy.data.objects):
 if ob.name.startswith(('Emitter upper armor','Emitter lower armor')):
  center=ob.location.copy();upper='upper' in ob.name;ob.hide_render=True
  xx=[.18,1.4,3.6,5.38];width=[.49,.68,.875,.875];vs=[]
  for x,w in zip(xx,width):
   for zz in [-.11,.11]:
    for yy in [-w,w]:vs.append((x,yy,center.z+zz))
  fs=[(0,2,3,1),(12,13,15,14)]
  for i in range(3):
   a=4*i;b=a+4;fs.extend([(a,b,b+1,a+1),(a+2,a+3,b+3,b+2),(a,a+2,b+2,b),(a+1,b+1,b+3,a+3)])
  mesh=bpy.data.meshes.new('Tapered emitter shell');mesh.from_pydata(vs,[],fs);mesh.update();obj=bpy.data.objects.new('Tapered emitter shell',mesh);bpy.context.collection.objects.link(obj);finish(obj,obj.name,indigo,ob.parent,.045)
for k,ob in enumerate(o for o in bpy.data.objects if o.name.startswith('Grip rib')):
 ob.parent=grip;ob.location=(0,0,-.85+k*.36);ob.rotation_euler=(0,0,0)
 ob.dimensions=(1.04,1.1,.1)
# Small side tongues make the sight read as flame rather than one solid crystal leaf.
for side in [-1,1]:
 vv=[];ff=[];h=.55 if side<0 else .42
 for j in range(12):
  t=j/11;rad=.12*math.sin(math.pi*t)**.8
  for k in range(12):
   a=k*math.tau/12;vv.append((side*(.1+.2*t*t)+rad*math.cos(a),rad*.65*math.sin(a),t*h))
 for j in range(11):
  for k in range(12):ff.append((j*12+k,j*12+(k+1)%12,(j+1)*12+(k+1)%12,(j+1)*12+k))
 mesh=bpy.data.meshes.new('Flame side tongue');mesh.from_pydata(vv,[],ff);mesh.update();bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-6);bm.to_mesh(mesh);bm.free();mesh.update()
 ob=bpy.data.objects.new('Flame side tongue',mesh);bpy.context.collection.objects.link(ob);finish(ob,ob.name,plasma,origin)
 for poly in mesh.polygons:poly.use_smooth=True

# v11: turbulence-rich core with a bright center rather than a rigid five-spoke pinwheel.
# The existing shader is an authoring effect, not native shader parity.
phase=mathnode('ADD',mathnode('MULTIPLY',angle,2),mathnode('MULTIPLY',radius,-28))
phase=mathnode('ADD',phase,mathnode('MULTIPLY',noisenode.outputs['Fac'],9))
wave=mathnode('ADD',mathnode('MULTIPLY',mathnode('SINE',phase),.5),.5)
filaments=mathnode('POWER',wave,2.8)
center=mathnode('EXPONENT',mathnode('MULTIPLY',radius,-15))
combined=mathnode('ADD',mathnode('ADD',.28,mathnode('MULTIPLY',filaments,.4)),mathnode('MULTIPLY',center,.8))
for link in list(lk):
 if link.to_node==rampnode and link.to_socket==rampnode.inputs['Fac']:lk.remove(link)
lk.new(combined,rampnode.inputs['Fac'])
core_shader=next(n for n in ns if n.type=='BSDF_PRINCIPLED');core_shader.inputs['Emission Strength'].default_value=3.3;core_shader.inputs['Metallic'].default_value=0;core_shader.inputs['Roughness'].default_value=.65
# Add broad tapering silver armor accents instead of only narrow circular trim.
for yy in [-.78,.78]:
 for sign in [-1,1]:
  vv=[(cx-1.58,yy,cz+sign*.45),(cx-1.15,yy,cz+sign*1.45),(cx-.4,yy,cz+sign*1.77),(cx+.36,yy,cz+sign*1.6),(cx-.5,yy,cz+sign*1.48),(cx-1.04,yy,cz+sign*.95)]
  mm=bpy.data.meshes.new('Sculpted silver crescent');mm.from_pydata(vv,[],[(0,1,2,3,4,5)]);mm.update();ob=bpy.data.objects.new('Sculpted silver crescent',mm);bpy.context.collection.objects.link(ob);finish(ob,ob.name,steel);mod=ob.modifiers.new('Solid plate','SOLIDIFY');mod.thickness=.12;mod=ob.modifiers.new('Light catching edge','BEVEL');mod.width=.04;mod.segments=3
# The default sight uses the actual authored alpha atlas, not a crystal-shaped solid.
for ob in bpy.data.objects:
 if ob.name.startswith(('Default soul flame','Flame side tongue')):ob.hide_render=True
fm=bpy.data.materials.new('Soul flame atlas surface');fm.use_nodes=True;nn=fm.node_tree.nodes;nn.clear();ll=fm.node_tree.links
tex=nn.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(R/'soul-flame-atlas-candidate-v3.png'));tex.interpolation='Linear';uvn=nn.new('ShaderNodeTexCoord');scale=nn.new('ShaderNodeVectorMath');scale.operation='MULTIPLY';scale.inputs[1].default_value=(.25,.25,1);ll.new(uvn.outputs['UV'],scale.inputs[0]);add=nn.new('ShaderNodeVectorMath');add.operation='ADD';ll.new(scale.outputs[0],add.inputs[0]);ll.new(add.outputs[0],tex.inputs['Vector'])
for frame in range(0,121):
 idx=(frame//8)%15;add.inputs[1].default_value=((idx%4)*.25,1-(idx//4+1)*.25,0);add.inputs[1].keyframe_insert('default_value',frame=frame)
if fm.node_tree.animation_data:
 for curve in fm.node_tree.animation_data.action.fcurves:
  for key in curve.keyframe_points:key.interpolation='CONSTANT'
em=nn.new('ShaderNodeEmission');em.inputs['Strength'].default_value=2.3;ll.new(tex.outputs['Color'],em.inputs['Color']);tr=nn.new('ShaderNodeBsdfTransparent');mix=nn.new('ShaderNodeMixShader');ll.new(tex.outputs['Alpha'],mix.inputs[0]);ll.new(tr.outputs[0],mix.inputs[1]);ll.new(em.outputs[0],mix.inputs[2]);out=nn.new('ShaderNodeOutputMaterial');ll.new(mix.outputs[0],out.inputs[0])
# Two crossed presentation planes. Alpha sorting/native passes still require validation.
for anglef in [0,math.pi/2]:
 verts=[(-.7,0,-.14),(.7,0,-.14),(.7,0,1.26),(-.7,0,1.26)];mm=bpy.data.meshes.new('Soul flame atlas quad');mm.from_pydata(verts,[],[(0,1,2,3)]);mm.update();ob=bpy.data.objects.new('Default Soul Flame atlas plane',mm);bpy.context.collection.objects.link(ob);finish(ob,ob.name,fm,origin);ob.rotation_euler.z=anglef;uv=mm.uv_layers.new(name='UVMap')
 for li,pair in zip(mm.polygons[0].loop_indices,[(0,0),(1,0),(1,1),(0,1)]):uv.data[li].uv=pair
# Bright energy lanes sit inside the open emitter channels, not across the front aperture.
for e,z in zip(emitters,levels):
 for yy in [-.34,.34]:
  points=[(.35+4.8*t,yy+.08*math.sin(t*math.tau*2),z+.07*math.sin(t*math.tau*3))for t in [k/50 for k in range(51)]]
  path('Contained soul channel',points,.048,cyan,e)

# v11: replace the flat disc surface with a volumetric, layered plasma reservoir.
for ob in bpy.data.objects:
 if ob.name.startswith('Contained soul plasma face'):ob.hide_render=True
vm=bpy.data.materials.new('Contained volumetric soul storm');vm.use_nodes=True;vn=vm.node_tree.nodes;vn.clear();vl=vm.node_tree.links
vcoord=vn.new('ShaderNodeTexCoord');vnoise=vn.new('ShaderNodeTexNoise');vnoise.noise_dimensions='4D';vnoise.inputs['Scale'].default_value=4;vnoise.inputs['Detail'].default_value=5;vl.new(vcoord.outputs['Generated'],vnoise.inputs['Vector'])
for f,w in [(0,0),(15,.6),(30,0)]:vnoise.inputs['W'].default_value=w;vnoise.inputs['W'].keyframe_insert('default_value',frame=f)
vr=vn.new('ShaderNodeValToRGB');vr.color_ramp.elements[0].position=.25;vr.color_ramp.elements[0].color=(.001,.003,.025,1);vr.color_ramp.elements[1].position=.72;vr.color_ramp.elements[1].color=(.05,.7,1,1);vr.color_ramp.elements.new(.53).color=(.003,.08,.9,1);vl.new(vnoise.outputs['Fac'],vr.inputs[0]);pv=vn.new('ShaderNodeVolumePrincipled');pv.inputs['Density'].default_value=.8;pv.inputs['Anisotropy'].default_value=.15;pv.inputs['Emission Strength'].default_value=3.5;vl.new(vr.outputs['Color'],pv.inputs['Emission Color']);vo=vn.new('ShaderNodeOutputMaterial');vl.new(pv.outputs['Volume'],vo.inputs['Volume'])
bpy.ops.mesh.primitive_uv_sphere_add(segments=48,ring_count=24,radius=1,location=(cx,0,cz));ob=bpy.context.object;ob.scale=(1.22,.72,1.22);finish(ob,'Contained volume reservoir',vm)
# Irregular helical arcs lie at different depths; none represents a gameplay projectile.
for j in range(7):
 pts=[]
 for k in range(65):
  t=k/64;a=t*math.tau*1.3+j*.8;rad=.12+.94*t+.035*math.sin(t*37+j)
  pts.append((cx+rad*math.cos(a),-.56+.16*math.sin(t*math.tau+j),cz+rad*math.sin(a)))
 path('Contained turbulent filament',pts,.012+(j%3)*.005,cyan if j%2 else blue)
bpy.ops.object.light_add(type='POINT',location=(cx,-.28,cz));bpy.context.object.data.energy=35;bpy.context.object.data.color=(.05,.5,1);bpy.context.object.data.shadow_soft_size=.6
# Scene for a real mesh render (not image generation or game capture).
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=False;scene.render.resolution_x=1400;scene.render.resolution_y=900;scene.render.resolution_percentage=100;scene.render.film_transparent=False
scene.world.use_nodes=True;scene.world.node_tree.nodes.get('Background').inputs['Color'].default_value=(.004,.007,.02,1);scene.world.node_tree.nodes.get('Background').inputs['Strength'].default_value=.3;scene.view_settings.view_transform='AgX';scene.view_settings.exposure=-.7
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
for name,loc,power,size,color in [('Key',(1,-7,10),1100,7,(.65,.8,1)),('Rim',(0,5,7),1600,5,(.25,.4,1)),('Fill',(-6,-3,2),800,4,(.5,.25,1))]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=color;aim(o,(0,0,1))
bpy.ops.object.camera_add(location=(11,-15,8));camera=bpy.context.object;camera.data.type='ORTHO';camera.data.ortho_scale=13;aim(camera,(.4,0,1.1));scene.camera=camera
scene.use_nodes=True;nt=scene.node_tree;nt.nodes.clear();rl=nt.nodes.new('CompositorNodeRLayers');gl=nt.nodes.new('CompositorNodeGlare');gl.glare_type='FOG_GLOW';gl.quality='HIGH';gl.threshold=2;gl.mix=-.9;output=nt.nodes.new('CompositorNodeComposite');nt.links.new(rl.outputs['Image'],gl.inputs['Image']);nt.links.new(gl.outputs['Image'],output.inputs['Image'])
scene.frame_start=0;scene.frame_end=30;scene.render.fps=60;scene.frame_set(0)
bpy.ops.file.pack_all()
bpy.ops.wm.save_as_mainfile(filepath=str(R/'soul-storm-sculpt-v11.blend'))
scene.render.filepath=str(R/'hero.png');bpy.ops.render.render(write_still=True)
manifest={'status':'Original reconstructed v11 authoring sculpt; not recovered prior draft, not native TaCZ model','emitter_count':4,'firing_order':'top to bottom','sight_default':'Soul Flame','objects':len(bpy.data.objects),'native_acceptance':False,'limitations':['No actual hands or first-person aim test','No native exporter/UV pack/LOD','Source geometry and motion need visual QA','No gameplay projectile or damage implementation']}
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
