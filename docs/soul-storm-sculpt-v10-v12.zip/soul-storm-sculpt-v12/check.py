import bpy,json,math
from pathlib import Path
R=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-sculpt-v12.blend'))
emitters=[bpy.data.objects[f'Emitter_{i+1}_top_to_bottom'] for i in range(4)];scene=bpy.context.scene;violations=[]
for frame in range(121):
 scene.frame_set(frame//4,subframe=(frame%4)/4)
 moving=[]
 for i,e in enumerate(emitters):
  if not all(math.isfinite(x) for x in e.matrix_world.translation):violations.append('nonfinite pose')
  if not -.28001<=e.location.x<=.00001:violations.append(f'overshoot {i} {frame/4} {e.location.x}')
  if e.location.x<-.001:moving.append(i)
 if len(moving)>1:violations.append(f'overlapping recoil events at {frame/4}: {moving}')
scene.frame_set(0)
meshes=[o for o in bpy.data.objects if o.type=='MESH' and not o.hide_render]
zero=[];duplicate=[]
for o in meshes:
 bad=sum(p.area<1e-10 for p in o.data.polygons)
 if bad:zero.append([o.name,bad])
 coords=[tuple(round(x,7) for x in v.co)for v in o.data.vertices]
 if len(set(coords))<len(coords):duplicate.append([o.name,len(coords)-len(set(coords))])
report={'scope':'Blender authoring geometry/keyframe smoke test; no native hands or continuous collision proof','emitter_count':len(emitters),'samples':121,'recoil_violations':violations,'zero_area_polygons':zero,'duplicate_position_vertices':duplicate,'visible_meshes':len(meshes)}
(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
assert not violations, 'Recoil motion gate failed'
assert not zero, 'Zero-area polygon gate failed'
assert not any(name=='Default soul flame' for name,count in duplicate), 'Flame pole weld gate failed'
# Check all 15 atlas cells in the real animated material; unused cell15 is never sampled.
material=bpy.data.materials['Soul flame atlas surface'];add=next(n for n in material.node_tree.nodes if n.type=='VECT_MATH' and n.operation=='ADD')
observed=[]
for frame in range(0,121):
 scene.frame_set(frame);offset=add.inputs[1].default_value;expected=(frame//8)%15
 actual=int(round(offset[0]*4))+4*int(round((1-offset[1])*4-1));assert actual==expected,(frame,actual,expected);observed.append(actual)
assert set(observed)==set(range(15))
report['atlas_frames_seen']=sorted(set(observed));report['atlas_samples']=121;report['limitations']=['Not native renderer acceptance','Core texture has low nonzero border alpha; final asset cleanup/masking pending','No actual hands, shader-pass or continuous collision proof']
(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS bounded recoil/topology and 15-cell atlas sampling; native/visual acceptance open')
