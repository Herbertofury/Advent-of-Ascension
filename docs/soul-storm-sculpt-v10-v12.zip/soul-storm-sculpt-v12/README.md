# Soul Storm sculpt iterations10–12

Original reconstructed Blender studies, not native TaCZ exports or finished guns. All earlier versions remain separately preserved. v10 uses the existing fifteen-frame Soul Flame alpha atlas and a turbulent procedural core. v11 tried a volumetric reservoir and is retained as an unsuccessful visual experiment. v12 uses a newly generated original VFX texture mapped onto shallow curved animated mesh surfaces; it is an actual rendered material/mesh, not a generated whole-weapon picture.

The four authored recoil events remain top-to-bottom. No native shot cadence/projectile/damage implementation is asserted. The two-second preview samples30frames and loops the reservoir rotation and sight atlas. The body still needs substantially better sculpting/material work to approach the concept. Native export, hand fit, camera, shader/pass, LOD and performance acceptance remain open.

Rebuild: Blender4.3.2 --background --python build.py. Each build packs external textures into its .blend. check.py and render_motion.py belong to v12. The generated VFX source texture is unchanged and has low nonzero border alpha; final cleanup/masking is pending. The stored exact prompt and texture allow reproduction/inspection. No third-party textures are copied into this archive.

The .blend file contains source geometry/materials. Standard Blender volume/emission/shader behavior is not evidence of native Minecraft renderer support. The old solid flame meshes remain hidden as history; the visible default sight uses the alpha atlas.
