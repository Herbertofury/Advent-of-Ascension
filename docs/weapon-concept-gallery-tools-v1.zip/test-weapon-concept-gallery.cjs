'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),directory=process.argv[2]?path.resolve(process.argv[2]):__dirname,M=require(path.join(directory,'weapon-concept-gallery.js'));
const data=JSON.parse(fs.readFileSync(path.join(directory,'weapon-concept-catalog.json')));M.validate(data);let checks=1;
for(const w of data.weapons){for(const key of ['sprite','concept','thumbnail']){assert.ok(fs.existsSync(path.join(directory,w[key])));checks++;}assert.ok(w.profile.endsWith('-Weapon-Profile'));checks++;}
assert.equal(data.weapons.length,16);assert.equal(data.inventory_count,228);assert.equal(data.native_accepted,0);checks+=3;
assert.equal(M.filter(data.weapons,' APOCO ','all').length,3);assert.equal(M.filter(data.weapons,'soul','blaster').length,2);assert.equal(M.filter(data.weapons,'','sniper').length,0);assert.equal(M.filter(data.weapons,'not a weapon','all').length,0);checks+=4;
for(const mutate of [d=>d.weapons.push({...d.weapons[0]}),d=>d.weapons[0].concept='../other.png',d=>d.weapons[0].thumbnail='https://example.invalid/a.webp',d=>d.weapons[0].profile='javascript:alert(1)',d=>d.weapons[0].interactive='https://example.invalid/',d=>d.weapons[0].native_accepted=true,d=>d.inventory_count=1,d=>d.weapons[0].family='unknown']){const d=structuredClone(data);mutate(d);assert.throws(()=>M.validate(d));checks++;}
console.log(JSON.stringify({status:'PASS',checks,profiles:data.weapons.length,scope:'Catalog assets, search/filter and rejected unsafe/inconsistent records; real-browser visual/accessibility review separate'}));
