from pathlib import Path
import json,subprocess,hashlib,argparse
from PIL import Image
parser=argparse.ArgumentParser();parser.add_argument('--docs',type=Path,required=True);args=parser.parse_args();D=args.docs.resolve();q=json.loads((D/'arsenal-production-queue.json').read_text())
assets={
'abominator':('Abominator','abominator-original-sprite.png','abominator-concept-exploration-v1.png','Original-inspired heavy weapon and alternate barrel exploration'),
'apoco_assault_rifle':('Apoco Assault Rifle','apoco-assault-rifle-original-icon.png','apoco-lore-concept-v3.png','Vox Ponds-associated upgrade lineage; organic styling remains interpretation'),
'apoco_rifle':('Apoco Rifle','apoco-rifle-original.png','apoco-rifle-concept-v2.png','Explosive Discharge Capsule identity with a refined organic shell'),
'apoco_shower':('Apoco Shower','apoco-shower-original.png','apoco-shower-concept-v1.png','Spirit-powered three-path discharge and pale front-shroud concepts'),
'balloon_bomber':('Balloon Bomber','balloon-bomber-original.png','balloon-bomber-concept-v1.png','Red-gold carnival cannon, Balloon ammunition and playful inspection storyboard'),
'baronator':('Baronator','baronator-original-sprite.png','baronator-concept-exploration-v1.png','Alternating upper/lower barrel presentation; preserve the grenade distinction'),
'carrot_cannon':('Carrot Cannon','carrot-cannon-original-sprite.png','carrot-cannon-concept-v1.png','Carrot ammunition, botanical shape and rootwork design'),
'discharge_shotgun':('Discharge Shotgun','discharge-shotgun-sprite-preview.png','discharge-shotgun-owner-target-v1.png','Owner-selected scattercaster target with original four-projectile behavior'),
'energy_cannon':('Energy Cannon','energy-cannon-original.png','energy-cannon-concept-v1.png','Blue split-jaw cannon, illustrated infusion recipe and mixed damage identity'),
'fungal_cannon':('Fungal Cannon','fungal-cannon-original-sprite.png','fungal-cannon-concept-exploration-v1.png','Fungal silhouette and the original weakening-effect contract'),
'ghast_blaster':('Ghast Blaster','ghast-blaster-original.png','ghast-blaster-concept-v2.png','Dark purple cannon, heavy shadow projectile and conditional withering effect'),
'gravity_blaster':('Gravity Blaster','gravity-blaster-original-sprite.png','gravity-blaster-concept-v1.png','Self-launch and hostile-control identity with gravity-focused upgrades'),
'hive_blaster':('Hive Blaster','hive-blaster-sprite-preview.png','hive-blaster-concept-exploration-v2.png','Hive-inspired forms with original projectile and renderer caveats'),
'iominator':('Iominator','iominator-sprite-preview.png','iominator-concept-exploration-v2.png','Original green-spark identity; alternate feed-layout studies stay separate'),
'moon_cannon':('Moon Cannon','moon-cannon-original.png','moon-cannon-concept-v1.png','Forked magenta cannon with mixed heavy/energy damage and Lunar kit lineage'),
'minigun':('Minigun','minigun-original-sprite.png','minigun-concept-exploration-v2.png','Rotary weapon identity, purposeful moving parts and attachment studies'),
'rosid_rifle':('Rosid Rifle','rosid-rifle-original.png','rosid-rifle-concept-v1.png','Botanical sniper identity; friendly-Rosid tooltip differs from empty inspected impact hook'),
'shoe_flinger':('Shoe Flinger','shoe-flinger-sprite-preview.png','shoe-flinger-concept-exploration-v2.png','Boot ammunition, playful launch effects and equipment conservation'),
'soul_drainer':('Soul Drainer','soul-drainer-original-sprite.png','soul-drainer-concept-exploration-v1.png','Life-leech identity with an unmistakable soul-energy presentation'),
'spirit_shower':('Spirit Shower','spirit-shower-original.png','spirit-shower-concept-v1.png','Three descending Spirit projectiles, source-linked loot and Apoco upgrade'),
'soul_storm':('Soul Storm','soul-storm-original-sprite.png','soul-storm-anchored-flame-focus-concept-v1.png','Five-emitter Soul Flame sight study; the default upgrade has four emitters, with five/six as options'),
'vortex_blaster':('Vortex Blaster','vortex-blaster-original-sprite.png','vortex-blaster-concept-v2.png','Spirit-powered repulsion and readable vortex-focused feedback')}
rows=[];thumbs=[]
for r in q['records']:
 if not r.get('profile'):continue
 key=r['id'].split(':')[1];name,sprite,concept,brief=assets[key]
 for file in [sprite,concept]:
  assert (D/file).is_file(),file
  subprocess.run(['git','-C',str(D.parent),'cat-file','-e','origin/main:docs/'+file],check=True)
 thumb='concept-thumb-'+key+'.webp';im=Image.open(D/concept).convert('RGB');im.thumbnail((640,480),Image.Resampling.LANCZOS);im.save(D/thumb,'WEBP',quality=84,method=6);thumbs.append({'source':concept,'source_sha256':hashlib.sha256((D/concept).read_bytes()).hexdigest(),'thumbnail':thumb,'size':list(im.size),'bytes':(D/thumb).stat().st_size,'source_bytes':(D/concept).stat().st_size})
 rows.append({'thumbnail':thumb,'id':r['id'],'name':name,'family':r['family'],'sprite':sprite,'concept':concept,'brief':brief,'profile':r['profile'],'native_accepted':False,**({'interactive':'carrot-cannon-preview.html?revision=4e59c6f'}if key=='carrot_cannon'else{})})
rows.sort(key=lambda r:r['name']);assert len(rows)==22 and q['fully_accepted']==0
(D/'weapon-concept-catalog.json').write_text(json.dumps({'schema_version':1,'source_release':'AoA 3.7.1 / Minecraft 1.20.1','inventory_count':len(q['records']),'native_accepted':0,'scope':'Published concepts and source profiles within the first-target 228 firearm registrations. Other families and historical versions remain additional scope.','weapons':rows},indent=2)+'\n');(D/'weapon-concept-thumbnail-receipt.json').write_text(json.dumps({'scope':'Lossy UI thumbnails only; original full-resolution concepts retained','files':thumbs,'total_thumbnail_bytes':sum(x['bytes']for x in thumbs),'total_full_image_bytes':sum(x['source_bytes']for x in thumbs)},indent=2)+'\n');print('Verified',len(rows),'catalog entries and',len(rows)*2,'published image paths')
