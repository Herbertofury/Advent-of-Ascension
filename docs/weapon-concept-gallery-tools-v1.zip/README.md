# Weapon concept collection tooling

This rebuilds UI thumbnails and the source-versus-concept catalog for the existing Advent-of-Ascension repository. It does not generate weapon art or prove native implementation.

Requirements: Python with Pillow, Git, and Node supporting structuredClone.

- `python build_catalog.py --docs /path/to/Advent-of-Ascension/docs`
- `node test-weapon-concept-gallery.cjs /path/to/Advent-of-Ascension/docs`

The repository must contain the source images, arsenal-production-queue.json and current origin/main. Published image paths are checked against origin/main before generation. Full-resolution images remain untouched. The WebP files are lossy UI previews only; opening a concept in the collection loads the preserved full-resolution image.

The current snapshot covers 16 source-backed profiles within 228 first-target firearms, with 0 native upgrades accepted. Additional profiles require updating the explicit source/concept mapping and coverage assertions. Earlier art remains linked from the individual profiles.

Original AoA identity and sprites belong to Tslat and contributors. The gallery, tests and build tooling are original project work.
