"""Assign explicit outward front direction to the backed receiver glass insets."""
import bpy,bmesh,json
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'carrot-cannon-leaf-material-v11/carrot-cannon-motion.blend'));rows=[]
for o in bpy.data.objects:
 if o.type!='MESH' or not o.name.startswith('Faceted amber receiver jewel'):continue
 bm=bmesh.new();bm.from_mesh(o.data);side=1 if sum(v.co.y for v in bm.verts)>0 else -1;wrong=[f for f in bm.faces if f.normal.y*side<0]
 if wrong:bmesh.ops.reverse_faces(bm,faces=wrong)
 bm.normal_update();dots=[f.normal.y*side for f in bm.faces];assert min(dots)>0;rows.append({'object':o.name,'outward_y_sign':side,'reversed_faces':len(wrong),'minimum_outward_normal_component':min(dots)});bm.to_mesh(o.data);bm.free();o.data.update()
s=bpy.context.scene;s.frame_set(0);s.cycles.samples=64;bpy.ops.wm.save_as_mainfile(filepath=str(R/'carrot-cannon-motion.blend'));s.render.filepath=str(R/'hero.png');bpy.ops.render.render(write_still=True);(R/'open-face-qa.json').write_text(json.dumps({'status':'Explicit authoring front-face direction; native culling remains untested','receiver_glass':rows,'limits':['Backed inset surfaces intentionally remain open','Final native material and culling settings still require direct testing']},indent=2)+'\n')
