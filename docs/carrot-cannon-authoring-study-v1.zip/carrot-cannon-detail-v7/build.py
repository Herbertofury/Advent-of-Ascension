import bpy,math,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'carrot-cannon-texture-v6/carrot-cannon-texture-study.blend'))
def prism(name,points,y,depth,material):
 v=[(x,yy,z)for yy in [y-depth/2,y+depth/2]for x,z in points];n=len(points);f=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n)for i in range(n)];m=bpy.data.meshes.new(name);m.from_pydata(v,[],f);m.update();o=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(o);o.data.materials.append(bpy.data.materials[material]);b=o.modifiers.new('Small machined edge','BEVEL');b.width=.012;b.segments=2;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');return o
for o in list(bpy.data.objects):
 if o.name.startswith(('Receiver face plate','Amber muzzle inset')):bpy.data.objects.remove(o,do_unlink=True)
for side in [-1,1]:
 prism('Shaped receiver face',[(-.86,.87),(-.76,.72),(-.50,.72),(-.37,.9),(-.37,1.43),(-.49,1.60),(-.76,1.60),(-.86,1.43)],side*.43,.085,'Dark hammered iron')
 prism('Inset diamond bezel',[(-.62,1.47),(-.80,1.15),(-.62,.83),(-.44,1.15)],side*.485,.035,'Worn silver edges')
# New guarded amber rim modules with inlaid glass, not exposed floating chips.
for j in range(8):
 a=(j+.5)*math.pi/4
 bpy.ops.mesh.primitive_cube_add(size=1,location=(1.82,.79*math.sin(a),1.15+.79*math.cos(a)));o=bpy.context.object;o.name='Muzzle inset armor bezel';o.dimensions=(.14,.18,.22);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.rotation_euler.x=-a;o.data.materials.append(bpy.data.materials['Worn silver edges']);mod=o.modifiers.new('Armor edge','BEVEL');mod.width=.025;mod.segments=2;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 # Faceted ember is contained in the forward-facing rectangular bezel.
 v=[]
 for dy,dz in [(0,.075),(-.055,0),(0,-.075),(.055,0),(0,0)]:
  y=.79*math.sin(a)+dy*math.cos(a)+dz*math.sin(a);z=1.15+.79*math.cos(a)-dy*math.sin(a)+dz*math.cos(a);v.append((1.895 if len(v)<4 else 1.916,y,z))
 m=bpy.data.meshes.new('Muzzle glass');m.from_pydata(v,[],[(0,1,4),(1,2,4),(2,3,4),(3,0,4)]);m.update();o=bpy.data.objects.new('Faceted muzzle glass',m);bpy.context.collection.objects.link(o);m.materials.append(bpy.data.materials['Amber petal glass'])
leaf=bpy.data.materials['Leaf upper wax'];p=leaf.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.018,.14,.004,1);p.inputs['Roughness'].default_value=.44
# Procedural green variation stays a material study pending native bake.
n=leaf.node_tree.nodes;l=leaf.node_tree.links;noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=6;ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].color=(.008,.06,.002,1);ramp.color_ramp.elements[1].color=(.055,.25,.006,1);l.new(noise.outputs['Fac'],ramp.inputs['Fac']);l.new(ramp.outputs['Color'],p.inputs['Base Color'])
for name in ['Orange grown ceramic','Golden growth ridges']:
 m=bpy.data.materials[name];n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF');src=p.inputs['Base Color'].links[0].from_socket;mult=n.new('ShaderNodeMixRGB');mult.blend_type='MULTIPLY';mult.inputs[0].default_value=1;mult.inputs[2].default_value=(.83,.75,.65,1);l.new(src,mult.inputs[1]);l.new(mult.outputs[0],p.inputs['Base Color'])
s=bpy.context.scene;cam=s.camera;s.cycles.samples=64
for name,loc in [('hero',(5,-8,4)),('side',(0,-8,1.2)),('front',(8,0,1.15))]:
 cam.location=loc;cam.rotation_euler=(Vector((0,0,1))-cam.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/(name+'.png'));bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(R/'carrot-cannon-detail.blend'))
(R/'manifest.json').write_text(json.dumps({'status':'Unaccepted concept-detail study','changes':['Shaped central plates and diamond bezels','Faceted amber muzzle inlays seated in armor modules','Deeper leafy color variation','Darker painted orange surface'],'native_tested':False,'limits':['Mechanical hand fit and moving-part sweeps pending','No final native texture, rig or game testing','Original source rendering and upgrade semantics not altered']},indent=2)+'\n')
