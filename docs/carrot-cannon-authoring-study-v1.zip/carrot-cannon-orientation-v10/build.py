"""Repair measured closed-solid winding and intentional tube end caps only."""
import bpy,bmesh,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'carrot-cannon-motion-v9/carrot-cannon-motion.blend'));repairs=[];capped=[]
for o in bpy.data.objects:
 if o.type=='CURVE':o.data.use_fill_caps=True;capped.append(o.name)
 if o.type!='MESH' or not o.name.startswith(('Collar edge','Structural collar','Shaped receiver face','Inset diamond bezel','Octagonal muzzle guard')):continue
 bm=bmesh.new();bm.from_mesh(o.data);before_verts=len(bm.verts);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-7);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));closed=all(e.is_manifold for e in bm.edges);assert closed,o.name;volume=bm.calc_volume(signed=True)
 if volume<0:bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
 repairs.append({'object':o.name,'welded_vertices':before_verts-len(bm.verts),'positive_closed_volume':bm.calc_volume(signed=True)});assert bm.calc_volume(signed=True)>0;bm.to_mesh(o.data);bm.free();o.data.update()
s=bpy.context.scene;s.frame_set(0);s.cycles.samples=64;cam=s.camera;cam.location=(5,-8,4);cam.rotation_euler=(Vector((0,0,1))-cam.location).to_track_quat('-Z','Y').to_euler();bpy.ops.wm.save_as_mainfile(filepath=str(R/'carrot-cannon-motion.blend'));s.render.filepath=str(R/'hero.png');bpy.ops.render.render(write_still=True)
(R/'repair-manifest.json').write_text(json.dumps({'status':'Targeted authoring orientation repairs; native culling untested','closed_solid_repairs':repairs,'curve_end_caps_enabled':capped,'preserved_open_surfaces':['Continuous dark interior bore','Faceted glass insets intended to seat against backing surfaces'],'limits':['No native normal/culling/render test','Material and visual acceptance still open']},indent=2)+'\n')
