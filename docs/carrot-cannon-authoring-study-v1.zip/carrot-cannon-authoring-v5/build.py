"""Original, separated botanical-cannon authoring study. No native acceptance."""
import bpy, math, random, json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent; random.seed(18019)
bpy.ops.wm.read_factory_settings(use_empty=True)
def material(name,color,metal=0,rough=.4,emit=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;n=m.node_tree.nodes;p=n.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 if emit:p.inputs['Emission Color'].default_value=(*color,1);p.inputs['Emission Strength'].default_value=emit
 return m
orange=material('Orange grown ceramic',(.64,.095,.006),.06,.3);orange2=material('Golden growth ridges',(.71,.125,.008),.08,.35);metal=material('Dark hammered iron',(.065,.075,.07),.82,.35);edge=material('Worn silver edges',(.32,.32,.26),.85,.27);wood=material('Rosid root interpretation',(.10,.045,.015),.05,.53);green=material('Leaf upper wax',(.045,.24,.009),.02,.34);green2=material('Leaf edge',(.15,.36,.014),.02,.4);gold=material('Amber petal glass',(1,.23,.008),.35,.22,2);dark=material('Dark inner bore',(.014,.019,.01),.5,.48)
for m,scale,strength in [(orange,17,.12),(metal,31,.13),(wood,9,.25)]:
 n=m.node_tree.nodes;l=m.node_tree.links;noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=scale;noise.inputs['Detail'].default_value=3;b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=strength;b.inputs['Distance'].default_value=.045;l.new(noise.outputs['Fac'],b.inputs['Height']);l.new(b.outputs['Normal'],n.get('Principled BSDF').inputs['Normal'])
# Surface grain and color variation are tied to object space, independent of camera.
for mat,base,light,scale in [(orange,(.45,.045,.002,1),(.8,.16,.006,1),7),(wood,(.025,.009,.003,1),(.15,.055,.012,1),5)]:
 n=mat.node_tree.nodes;l=mat.node_tree.links;tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=scale;tex.inputs['Detail'].default_value=4;tex.inputs['Roughness'].default_value=.75
 coord=n.new('ShaderNodeTexCoord');mapping=n.new('ShaderNodeVectorMath');mapping.operation='MULTIPLY';mapping.inputs[1].default_value=(1,7,3) if mat==wood else (2,5,4);l.new(coord.outputs['Generated'],mapping.inputs[0]);l.new(mapping.outputs[0],tex.inputs['Vector'])
 ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.25;ramp.color_ramp.elements[0].color=base;ramp.color_ramp.elements[1].position=.75;ramp.color_ramp.elements[1].color=light;l.new(tex.outputs['Fac'],ramp.inputs['Fac']);l.new(ramp.outputs[0],n.get('Principled BSDF').inputs['Base Color'])
def mesh(name,v,f,m):
 d=bpy.data.meshes.new(name);d.from_pydata(v,[],f);d.update();o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.data.materials.append(m);return o
def bevel(o,w=.025):
 mod=o.modifiers.new('Controlled edge bevel','BEVEL');mod.width=w;mod.segments=2;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');return o
def lathe(name,profile,m,n=48):
 v=[(x,r*math.sin(2*math.pi*j/n),1.15+r*math.cos(2*math.pi*j/n)) for x,r in profile for j in range(n)];f=[]
 for i in range(len(profile)-1):
  for j in range(n):k=i*n+j;q=i*n+(j+1)%n;f.append((k,q,q+n,k+n))
 o=mesh(name,v,f,m)
 for p in o.data.polygons:p.use_smooth=True
 return o
def ring(name,x,r,w,m,th=.08,n=48):return lathe(name,[(x-w/2,r-th),(x-w/2,r),(x+w/2,r),(x+w/2,r-th),(x-w/2,r-th)],m,n)
def cube(name,loc,scale,m):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m);return bevel(o,min(.025,min(scale)*.2))
def tube(name,points,r,m):
 d=bpy.data.curves.new(name,'CURVE');d.dimensions='3D';d.bevel_depth=r;d.bevel_resolution=2;d.resolution_u=4;sp=d.splines.new('BEZIER');sp.bezier_points.add(len(points)-1)
 for p,co in zip(sp.bezier_points,points):p.co=co;p.handle_left_type=p.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);d.materials.append(m);return o
# Open continuous inner barrel and independent segmented exterior. X points toward muzzle.
lathe('Continuous dark interior', [(-1.85,.20),(-.7,.27),(.3,.3),(1.1,.48),(1.72,.62),(1.76,.64)],dark)
profile=[(-2,.28),(-1.8,.45),(-1.35,.48),(-.9,.37),(-.4,.32),(.15,.37),(.65,.51),(1.15,.66),(1.63,.74)]
for i in range(len(profile)-1):
 x0,r0=profile[i];x1,r1=profile[i+1]
 for j in range(12):
  a0=2*math.pi*(j+.012)/12;a1=2*math.pi*(j+.988)/12;v=[]
  for x,r in [(x0+.006,r0),(x1-.006,r1)]:
   for k in range(6):a=a0+(a1-a0)*k/5;v.append((x,r*math.sin(a),1.15+r*math.cos(a)))
  f=[(k,k+1,k+7,k+6)for k in range(5)];o=mesh('Orange shell segment %02d %02d'%(i,j),v,f,orange if j%3 else orange2);
  for face in o.data.polygons:face.use_smooth=True
  sol=o.modifiers.new('Shell wall','SOLIDIFY');sol.thickness=.045;bevel(o,.008)
for x,r,w in [(-1.8,.49,.12),(-1,.44,.17),(-.62,.43,.3),(.25,.46,.13),(1.38,.78,.24),(1.72,.79,.12)]:
 ring('Structural collar',x,r,w,metal);ring('Collar edge',x-w/2,r+.012,.035,edge,.04);ring('Collar edge',x+w/2,r+.012,.035,edge,.04)
 for j in range(8):
  a=2*math.pi*j/8;y=r*math.sin(a);z=1.15+r*math.cos(a)
  bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=6,radius=.037,location=(x,y,z));o=bpy.context.object;o.name='Collar rivet';o.data.materials.append(edge)
# Angular outer muzzle frame; actual hole preserved.
bevel(ring('Octagonal muzzle guard',1.76,.86,.16,metal,.16,n=8),.025)
for j in range(8):
 a=j*math.pi/4; o=cube('Amber muzzle inset',(1.855,.78*math.sin(a),1.15+.78*math.cos(a)),(.028,.11,.20),gold);o.rotation_euler.x=-a
# Distinct loading saddle and organically shaped grip with a clear finger space.
cube('Receiver saddle',(-.84,0,.76),(.87,.5,.24),metal)
tube('Main root grip',[(-1.27,0,.81),(-1.45,0,.42),(-1.25,0,-.08),(-1.1,0,-.17)],.13,wood)
tube('Root lower brace',[(-1.1,0,-.17),(-.58,0,-.22),(-.16,0,-.06),(-.10,0,.57),(-.36,0,.78)],.08,wood)
tube('Separate trigger',[(-.85,0,.612),(-.92,0,.44),(-.84,0,.30)],.025,metal)
# Root striation follows the grip rather than random floating strips.
for j in range(7):
 a=j*2*math.pi/7;tube('Grip bark strand',[(-1.27+.11*math.cos(a),.11*math.sin(a),.77),(-1.44+.11*math.cos(a),.11*math.sin(a),.42),(-1.24+.11*math.cos(a),.11*math.sin(a),-.07)],.017,wood)
# Parametric curled leaf blades with center veins, each independently owned.
def leaf(name,start,length,angle,lean,width):
 v=[];steps=16;cols=5
 direction=Vector((math.sin(angle)*.65+lean,math.cos(angle)*.65,.55)).normalized();side=Vector((1,0,0));side=(side-direction*side.dot(direction)).normalized();normal=direction.cross(side).normalized()
 def point(t,u):
  center=Vector(start)+direction*length*t+normal*(.12*math.sin(t*math.pi))-Vector((0,0,.22*t*t))
  width_at=width*max(.012,math.sin(math.pi*t))**.65*(1+.20*math.sin(t*math.pi*10))
  return center+side*(u*width_at)+normal*((1-u*u)*.04*math.sin(math.pi*t)+u*u*.07*math.sin(t*math.pi*2))
 for i in range(steps+1):
  for j in range(cols):v.append(tuple(point(i/steps,2*j/(cols-1)-1)))
 f=[]
 for i in range(steps):
  for j in range(cols-1):k=i*cols+j;f.append((k,k+cols,k+cols+1,k+1))
 o=mesh(name,v,f,green)
 for face in o.data.polygons:face.use_smooth=True
 sub=o.modifiers.new('Smooth leaf lobes','SUBSURF');sub.levels=0;sub.render_levels=0
 sol=o.modifiers.new('Leaf thickness','SOLIDIFY');sol.thickness=.006
 tube(name+' main vein',[tuple(point(t,0)+normal*.005)for t in [i/12 for i in range(13)]],.004,green2)
 for i in range(3,10,2):
  t=i/12
  for sign in [-1,1]:tube(name+' branching vein',[tuple(point(t,0)+normal*.005),tuple(point(t+.04,sign*.4)+normal*.005),tuple(point(t+.08,sign*.82)+normal*.005)],.0018,green2)
for cluster,x,z,num in [('Rear',-1.6,1.52,16),('Front',1.4,1.86,10),('Mid',-.15,1.45,6)]:
 for j in range(num):leaf(cluster+' crown leaf '+str(j),(x+random.uniform(-.18,.18),random.uniform(-.19,.19),z),random.uniform(.35,.77),random.uniform(-math.pi,math.pi),random.uniform(-.5,.45),random.uniform(.12,.21))
# Fine interwoven root ribs follow the existing brace; no disconnected ornamental strands.
for j in range(8):
 a=j*math.pi/4
 tube('Brace living root rib',[(x+.065*math.cos(a),.065*math.sin(a),z+.025*math.sin(a))for x,z in [(-1.1,-.17),(-.58,-.22),(-.16,-.06),(-.10,.57),(-.36,.78)]],.012,wood)
# Amber faceted receiver marker, with a solid framed backplate.
for side in [-1,1]:
 o=cube('Receiver face plate',(-.62,side*.43,1.15),(.34,.075,.62),metal)
 v=[(-.62,side*.49,1.42),(-.77,side*.49,1.15),(-.62,side*.49,.88),(-.47,side*.49,1.15),(-.62,side*.54,1.15)];mesh('Faceted amber receiver jewel',v,[(0,1,4),(1,2,4),(2,3,4),(3,0,4)],gold)
# Studio only. Authoring study, no performance or feature acceptance.
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.use_denoising=False;s.render.resolution_x=1500;s.render.resolution_y=950;s.render.resolution_percentage=100;s.world=bpy.data.worlds.new('Studio');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.045,.055,.07,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.4
for loc,power,size in [((0,-4,6),800,5),((2,3,4),1000,4),((-4,0,2),500,3)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.size=size;o.rotation_euler=(Vector((0,0,1))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(5,-8,4));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=5.3;s.camera=cam
for name,loc in [('hero',(5,-8,4)),('side',(0,-8,1.2)),('front',(8,0,1.15)),('rear',(-8,0,1.15))]:
 cam.location=loc;cam.rotation_euler=(Vector((0,0,1))-cam.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/(name+'.png'));bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(R/'carrot-cannon-authoring.blend'))
(R/'manifest.json').write_text(json.dumps({'status':'Unaccepted original separated authoring study','native_tested':False,'objects':len(bpy.data.objects),'limits':['Concept proportions and plant density require review','No final UV bake or native materials','No rig, loading cycle or native hand fit acceptance','No functional modifications or native runtime testing']},indent=2)+'\n')
