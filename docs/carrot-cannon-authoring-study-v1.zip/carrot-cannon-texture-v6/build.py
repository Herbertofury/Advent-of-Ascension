import bpy,math,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'carrot-cannon-authoring-v5/carrot-cannon-authoring.blend'))
image=bpy.data.images.load(str(R/'orange-grown-surface-v1.png'));image.colorspace_settings.name='sRGB';image.pack();changed=[]
for matname in ['Orange grown ceramic','Golden growth ridges']:
 m=bpy.data.materials[matname];n=m.node_tree.nodes;l=m.node_tree.links;tex=n.new('ShaderNodeTexImage');tex.image=image;tex.extension='REPEAT';uv=n.new('ShaderNodeUVMap');uv.uv_map='GrownSurface';l.new(uv.outputs['UV'],tex.inputs['Vector']);l.new(tex.outputs['Color'],n.get('Principled BSDF').inputs['Base Color']);n.get('Principled BSDF').inputs['Roughness'].default_value=.36
for o in bpy.data.objects:
 if not o.name.startswith('Orange shell segment'):continue
 layer=o.data.uv_layers.new(name='GrownSurface')
 for p in o.data.polygons:
  coordinates=[]
  for li in p.loop_indices:
   co=o.data.vertices[o.data.loops[li].vertex_index].co;a=math.atan2(co.y,co.z-1.15)%(2*math.pi);coordinates.append((li,a/(2*math.pi),(co.x+2)/3.9))
  crosses=max(x[1]for x in coordinates)-min(x[1]for x in coordinates)>.5
  for li,u,v in coordinates:layer.data[li].uv=(u+1 if crosses and u<.5 else u,v)
 changed.append(o.name)
s=bpy.context.scene;cam=s.camera
for name,loc in [('hero',(5,-8,4)),('side',(0,-8,1.2))]:
 from mathutils import Vector
 cam.location=loc;cam.rotation_euler=(Vector((0,0,1))-cam.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/(name+'.png'));bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(R/'carrot-cannon-texture-study.blend'))
(R/'manifest.json').write_text(json.dumps({'status':'Unaccepted painted surface material study','source_texture_sha256':hashlib.sha256((R/'orange-grown-surface-v1.png').read_bytes()).hexdigest(),'mapped_shell_parts':len(changed),'mapping':'Continuous cylindrical source-space UV, sRGB color image only','limits':['Generated texture contains painted shading; not claimed as measured physical albedo','Seam and mipmap behavior require review','No inferred normal map from color','No native renderer or final texture acceptance'],'native_tested':False},indent=2)+'\n')
