"""Authoring-only evaluated mesh and explicit moving-control clearance audit."""
import bpy,math,json
from mathutils.bvhtree import BVHTree
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'carrot-cannon-motion.blend'));dg=bpy.context.evaluated_depsgraph_get();records=[];trees={}
for o in bpy.data.objects:
 if o.type not in ('MESH','CURVE'):continue
 e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();v=[o.matrix_world@x.co for x in m.vertices];f=[tuple(t.vertices) for t in m.loop_triangles];bad=sum(not all(math.isfinite(c)for c in p)for p in v);deg=sum((v[b]-v[a]).cross(v[c]-v[a]).length<=1e-10 for a,b,c in f)
 records.append({'object':o.name,'triangles':len(f),'nonfinite_vertices':bad,'near_zero_area_triangles':deg});trees[o.name]=BVHTree.FromPolygons(v,f,all_triangles=True);e.to_mesh_clear()
checks=[]
for target in ['Main root grip','Root lower brace','Receiver saddle']:
 hits=trees['Separate trigger'].overlap(trees[target]);checks.append({'pair':['Separate trigger',target],'triangle_surface_intersections':len(hits),'scope':'Static authoring pose only; excludes intended root overlaps and does not prove hand fit or containment absence'})
result={'status':'Authoring audit; not native or visual acceptance','total_triangles':sum(x['triangles']for x in records),'objects':records,'control_clearance':checks,'limits':['Open inner barrel surfaces are intentional in this study','No native hands, animation sweeps, attachment variants or texture acceptance','Surface-only overlap test cannot detect full containment']};(R/'geometry-qa.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['status','total_triangles','control_clearance']}))
