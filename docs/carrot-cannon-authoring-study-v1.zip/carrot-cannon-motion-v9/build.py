"""Presentation-only rig and authored recoil. No ammo, damage or physics changes."""
import bpy,math,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'carrot-cannon-detail-v7/carrot-cannon-detail.blend'));s=bpy.context.scene
# Visible pivot seating solves the earlier tiny air gap; joint contact is intentional.
for y in [-.06,.06]:
 bpy.ops.mesh.primitive_cube_add(size=1,location=(-.85,y,.641));o=bpy.context.object;o.name='Trigger hinge bracket';o.dimensions=(.07,.04,.08);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(bpy.data.materials['Dark hammered iron']);mod=o.modifiers.new('Bracket edge','BEVEL');mod.width=.008;mod.segments=2
bpy.ops.mesh.primitive_cylinder_add(vertices=16,radius=.022,depth=.16,location=(-.85,0,.612),rotation=(math.pi/2,0,0));o=bpy.context.object;o.name='Trigger pivot pin';o.data.materials.append(bpy.data.materials['Worn silver edges'])
def empty(name,loc=(0,0,0)):
 o=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(o);o.location=loc;return o
root=empty('carrot_weapon_root');trigger=empty('carrot_trigger_pivot',(-.85,0,.612));trigger.parent=root
bpy.context.view_layer.update()
neutral_world={o.name:o.matrix_world.copy() for o in bpy.data.objects if o.type in ('MESH','CURVE')}
owners={}
for o in list(bpy.data.objects):
 if o.type not in ('MESH','CURVE'):continue
 parent=trigger if o.name=='Separate trigger'else root;world=o.matrix_world.copy();o.parent=parent;o.matrix_world=world;o['presentation_owner']=parent.name;owners[o.name]=parent.name
bpy.context.view_layer.update()
neutral_error=max(max(abs(o.matrix_world[i][j]-neutral_world[o.name][i][j]) for i in range(4) for j in range(4))for o in bpy.data.objects if o.name in neutral_world)
assert neutral_error<1e-6, ('Parenting changed neutral pose',neutral_error)
for f,x,rot in [(0,0,0),(2,-.095,-.025),(5,-.055,-.012),(12,-.008,0),(18,0,0),(48,0,0)]:
 root.location.x=x;root.rotation_euler.y=rot;root.keyframe_insert(data_path='location',frame=f);root.keyframe_insert(data_path='rotation_euler',frame=f)
for f,rot in [(0,0),(2,-.12),(5,-.12),(10,0),(48,0)]:trigger.rotation_euler.y=rot;trigger.keyframe_insert(data_path='rotation_euler',frame=f)
for owner in [root,trigger]:
 for fc in owner.animation_data.action.fcurves:
  for k in fc.keyframe_points:k.interpolation='BEZIER';k.handle_left_type=k.handle_right_type='AUTO_CLAMPED'
s.render.fps=60;s.frame_start=0;s.frame_end=48;s.frame_set(0)
cam=s.camera;cam.location=(5,-8,4);cam.rotation_euler=(Vector((0,0,1))-cam.location).to_track_quat('-Z','Y').to_euler();s.cycles.samples=48
bpy.ops.wm.save_as_mainfile(filepath=str(R/'carrot-cannon-motion.blend'))
for frame in [0,2,5,12,18]:s.frame_set(frame);s.render.filepath=str(R/('recoil-%02d.png'%frame));bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'Unaccepted presentation rig','objects':owners,'neutral_parenting_max_matrix_error':neutral_error,'frames':[0,2,5,12,18,48],'fps':60,'source_nominal_delay_ticks':16,'loop_duration_seconds':.8,'interpretation':'48-frame authoring fixture at 60 FPS; actual native fire timing is not established','intentional_joint_contacts':['Trigger pivot pin with trigger upper endpoint','Hinge brackets seated into receiver underside'],'native_tested':False,'limits':['Whole weapon motion requires native hand and camera reconciliation','Trigger swept clearance still requires checks','No functional reload, projectile or native effects implementation']},indent=2)+'\n')
