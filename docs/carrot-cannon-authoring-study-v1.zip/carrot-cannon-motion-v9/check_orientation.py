import bpy,bmesh,json
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'carrot-cannon-motion.blend'));dg=bpy.context.evaluated_depsgraph_get();rows=[]
for o in bpy.data.objects:
 if o.type not in ('MESH','CURVE'):continue
 e=o.evaluated_get(dg);m=e.to_mesh();bm=bmesh.new();bm.from_mesh(m);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-7);closed=all(x.is_manifold for x in bm.edges);vol=bm.calc_volume(signed=True);rows.append({'object':o.name,'closed_after_coincident_vertex_weld':closed,'signed_volume':vol,'negative_closed_volume':closed and vol< -1e-10});bm.free();e.to_mesh_clear()
(R/'orientation-qa.json').write_text(json.dumps({'status':'Evaluated local-space orientation diagnostic; native culling remains untested','records':rows},indent=2)+'\n');print('negative',[(x['object'],x['signed_volume'])for x in rows if x['negative_closed_volume']]);print('open',len([x for x in rows if not x['closed_after_coincident_vertex_weld']]))
