"""Replace problematic tiny vein tubes with parameter-aligned material veins."""
import bpy,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'carrot-cannon-orientation-v10/carrot-cannon-motion.blend'));removed=[];mapped=[]
for o in list(bpy.data.objects):
 if o.type=='CURVE' and ('main vein' in o.name or 'branching vein' in o.name):removed.append(o.name);bpy.data.objects.remove(o,do_unlink=True);continue
 if o.type=='MESH' and 'crown leaf' in o.name:
  assert len(o.data.vertices)==85,(o.name,len(o.data.vertices));uv=o.data.uv_layers.new(name='LeafSurface')
  for li,loop in enumerate(o.data.loops):i=loop.vertex_index;uv.data[li].uv=((i%5)/4,(i//5)/16)
  mapped.append(o.name)
m=bpy.data.materials['Leaf upper wax'];n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF');base=p.inputs['Base Color'].links[0].from_socket
uv=n.new('ShaderNodeUVMap');uv.uv_map='LeafSurface';split=n.new('ShaderNodeSeparateXYZ');l.new(uv.outputs[0],split.inputs[0])
def op(kind,a,b=0):
 o=n.new('ShaderNodeMath');o.operation=kind
 if hasattr(a,'is_output'):l.new(a,o.inputs[0])
 else:o.inputs[0].default_value=a
 if hasattr(b,'is_output'):l.new(b,o.inputs[1])
 else:o.inputs[1].default_value=b
 return o.outputs[0]
u=op('ABSOLUTE',op('SUBTRACT',split.outputs['X'],.5));main=op('SUBTRACT',1,op('MULTIPLY',u,55));main=op('MAXIMUM',main,0)
phase=op('FRACT',op('SUBTRACT',op('MULTIPLY',split.outputs['Y'],6),op('MULTIPLY',u,2.1)));branch=op('MAXIMUM',op('SUBTRACT',1,op('MULTIPLY',op('ABSOLUTE',op('SUBTRACT',phase,.5)),24)),0);branch=op('MULTIPLY',branch,.48);mask=op('MAXIMUM',main,branch)
mix=n.new('ShaderNodeMixRGB');l.new(mask,mix.inputs[0]);l.new(base,mix.inputs[1]);mix.inputs[2].default_value=(.09,.30,.009,1);l.new(mix.outputs[0],p.inputs['Base Color']);bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.22;bump.inputs['Distance'].default_value=.007;l.new(mask,bump.inputs['Height']);l.new(bump.outputs['Normal'],p.inputs['Normal'])
s=bpy.context.scene;s.frame_set(0);s.cycles.samples=64;cam=s.camera;cam.location=(5,-8,4);cam.rotation_euler=(Vector((0,0,1))-cam.location).to_track_quat('-Z','Y').to_euler();bpy.ops.wm.save_as_mainfile(filepath=str(R/'carrot-cannon-motion.blend'));s.render.filepath=str(R/'hero.png');bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'Unaccepted procedural leaf-vein material study','removed_tiny_vein_curves':len(removed),'leaf_surfaces_uv_mapped':len(mapped),'source_preserved':'orientation-v10 and earlier scenes remain unchanged','native_tested':False,'limits':['Native color/normal baking remains open','Matched close-up comparison needed before appearance acceptance','Not a measured frame-time gain']},indent=2)+'\n')
