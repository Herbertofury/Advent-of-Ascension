import bpy,json,math
from pathlib import Path
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'carrot-cannon-motion.blend'));s=bpy.context.scene;dg=bpy.context.evaluated_depsgraph_get()
def tree(o):
 e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();v=[o.matrix_world@x.co for x in m.vertices];f=[tuple(t.vertices)for t in m.loop_triangles];b=BVHTree.FromPolygons(v,f,all_triangles=True);e.to_mesh_clear();return b
names=['Main root grip','Root lower brace','Receiver saddle'];collisions=[];owner_errors=[];bounds=[];start={}
s.frame_set(0)
for o in bpy.data.objects:
 if o.type in ('MESH','CURVE'):start[o.name]=o.matrix_world.copy()
for j in range(193):
 f=j/4;s.frame_set(int(f),subframe=f%1);dg.update();t=tree(bpy.data.objects['Separate trigger'])
 for n in names:
  hits=t.overlap(tree(bpy.data.objects[n]))
  if hits:collisions.append({'frame':f,'pair':['Separate trigger',n],'surface_intersections':len(hits)})
 for o in bpy.data.objects:
  if o.type not in ('MESH','CURVE'):continue
  expected='carrot_trigger_pivot'if o.name=='Separate trigger'else'carrot_weapon_root'
  if o.parent is None or o.parent.name!=expected:owner_errors.append(o.name)
 root=bpy.data.objects['carrot_weapon_root'];bounds.append(root.location.x)
s.frame_set(48);drift=max(max(abs(o.matrix_world[i][j]-start[o.name][i][j])for i in range(4)for j in range(4))for o in bpy.data.objects if o.name in start)
out={'status':'Sampled authoring motion checks, not native hand fit','sampled_poses':193,'owner_errors':sorted(set(owner_errors)),'surface_collisions':collisions,'return_matrix_max_drift':drift,'recoil_x_bounds':[min(bounds),max(bounds)],'intentional_contacts_excluded':['Trigger pivot pin and bracket mating joints'],'limits':['Sampling does not prove continuous swept volume clearance','Surface intersections cannot detect complete containment','Native arms, camera and attachments absent','No frame-time, native animation parser or game behavior claim']};(R/'motion-qa.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out));assert not owner_errors and not collisions and drift<1e-6
