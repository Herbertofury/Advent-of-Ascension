import bpy,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent
for name,source in [('geometric-veins',R.parent/'carrot-cannon-orientation-v10/carrot-cannon-motion.blend'),('material-veins',R/'carrot-cannon-motion.blend')]:
 bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene;s.frame_set(0);s.cycles.samples=64;s.cycles.seed=17;s.cycles.use_animated_seed=False;s.render.resolution_x=1000;s.render.resolution_y=800;cam=s.camera;cam.location=(-1.4,-3,3.1);cam.rotation_euler=(Vector((-1.55,0,1.75))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=1.5;s.render.filepath=str(R/(name+'-closeup.png'));bpy.ops.render.render(write_still=True)
(R/'comparison-settings.json').write_text(json.dumps({'samples':64,'seed':17,'camera_location':[-1.4,-3,3.1],'target':[-1.55,0,1.75],'ortho_scale':1.5,'status':'Matched authoring comparison; not native performance or automatic visual acceptance'},indent=2)+'\n')
