import unittest,copy
from link_manifests import link
C={'weapons':[{'id':'aoa3:a','manifest':None,'status':'blocked','overrides':{'x':1}}]};M={'a-feature-status.json':{'weapon_id':'aoa3:a','target':{'minecraft':'1.20.1','aoa':'3.7.1'},'fully_accepted':False}}
class Tests(unittest.TestCase):
 def test_preserves_reviews(self):
  a=copy.deepcopy(C);b,c=link(a,M);self.assertEqual(a,C);self.assertEqual(b['weapons'][0]['status'],'blocked');self.assertEqual(b['weapons'][0]['overrides'],{'x':1});self.assertEqual(len(c),1)
 def test_idempotent(self):
  a,_=link(C,M);b,c=link(a,M);self.assertEqual(a,b);self.assertEqual(c,[])
 def test_duplicate(self):
  with self.assertRaises(ValueError):link(C,{**M,'b-feature-status.json':M['a-feature-status.json']})
 def test_unknown(self):
  m=copy.deepcopy(M);m['a-feature-status.json']['weapon_id']='aoa3:unknown'
  with self.assertRaises(ValueError):link(C,m)
 def test_target(self):
  m=copy.deepcopy(M);m['a-feature-status.json']['target']['aoa']='other'
  with self.assertRaises(ValueError):link(C,m)
 def test_conflict(self):
  c=copy.deepcopy(C);c['weapons'][0]['manifest']='other-feature-status.json'
  with self.assertRaises(ValueError):link(c,M)
 def test_path_escape(self):
  with self.assertRaises(ValueError):link(C,{'../a-feature-status.json':M['a-feature-status.json']})
if __name__=='__main__':unittest.main()
