import unittest,tempfile,shutil,json,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parent
class Integration(unittest.TestCase):
 def prepare(self,tmp):
  root=Path(tmp);tool=root/'tool';docs=root/'docs';tool.mkdir();docs.mkdir()
  for n in ['build_standard.py','refresh_coverage.py','link_manifests.py','coverage.json']:shutil.copyfile(R/n,tool/n)
  old=json.loads((R/'coverage.json').read_text());q={'scope':old['scope'],'registry_sha256':old['registry_sha256'],'records':[{'id':r['id'],'family':r['family'],'profile':r['existing_profile']}for r in old['weapons']]};(docs/'arsenal-production-queue.json').write_text(json.dumps(q));return tool,docs,old
 def runbuild(self,tool,docs):return subprocess.run([sys.executable,str(tool/'build_standard.py'),'--docs',str(docs)],capture_output=True,text=True)
 def test_current_reviews_override_archive_and_defaults(self):
  with tempfile.TemporaryDirectory()as t:
   tool,docs,old=self.prepare(t);row=next(x for x in old['weapons']if x['id']=='aoa3:soul_storm');row['status']='blocked_for_native_review';row['overrides']={'concept_fidelity':'newer owner direction','future_field':{'keep':True}};row['manifest']=None;(docs/'weapon-feature-coverage.json').write_text(json.dumps(old));(docs/'soul-storm-feature-status.json').write_text(json.dumps({'weapon_id':'aoa3:soul_storm','target':{'minecraft':'1.20.1','aoa':'3.7.1'}}));p=self.runbuild(tool,docs);self.assertEqual(p.returncode,0,p.stderr);out=json.loads((tool/'coverage.json').read_text());got=next(x for x in out['weapons']if x['id']==row['id']);self.assertEqual(got['status'],row['status']);self.assertEqual(got['overrides'],row['overrides']);self.assertEqual(got['manifest'],'soul-storm-feature-status.json');self.assertIsNone(row['manifest'])
 def test_preserve_unknown_override_when_adding_default(self):
  with tempfile.TemporaryDirectory()as t:
   tool,docs,old=self.prepare(t);row=next(x for x in old['weapons']if x['id']=='aoa3:iominator');row['overrides']={'future_key':42};(docs/'weapon-feature-coverage.json').write_text(json.dumps(old));p=self.runbuild(tool,docs);self.assertEqual(p.returncode,0,p.stderr);got=next(x for x in json.loads((tool/'coverage.json').read_text())['weapons']if x['id']==row['id']);self.assertEqual(got['overrides']['future_key'],42);self.assertIn('concept_fidelity',got['overrides'])
 def test_conflicting_manifest_rejected(self):
  with tempfile.TemporaryDirectory()as t:
   tool,docs,old=self.prepare(t);row=next(x for x in old['weapons']if x['id']=='aoa3:soul_storm');row['manifest']='other-feature-status.json';(docs/'weapon-feature-coverage.json').write_text(json.dumps(old));(docs/'soul-storm-feature-status.json').write_text(json.dumps({'weapon_id':'aoa3:soul_storm','target':{'minecraft':'1.20.1','aoa':'3.7.1'}}));p=self.runbuild(tool,docs);self.assertNotEqual(p.returncode,0);self.assertIn('Conflicting existing manifest',p.stderr)
if __name__=='__main__':unittest.main()
