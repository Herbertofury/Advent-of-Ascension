---
name: aoa-weapon-completeness
description: Enforce a complete feature, concept-fidelity and evidence checklist for every AoA weapon, craftable variant, attachment and effect package.
---

# AoA weapon completeness

Read GUIDELINE.md and feature-catalog.json before weapon work. Create a per-weapon record from weapon-manifest-template.json. Reconcile existing source/receipts rather than declaring earlier work absent or complete.

All 31 feature groups require separate concept/design, implementation and QA evidence. Preserve original behavior and version pins. Concepts and alternate builds are not substitutes for a canonical model. Do not pass canonical visual fidelity when the model diverges from its approved concept, even if numeric checks pass. Preserve owner-liked divergent models as separately identified craftable alternates.

Use the validator for structure and hashes; it cannot judge beauty, gameplay or the truth of evidence. Keep native and offline gates distinct. Record intentional omissions only with an owner-approved reason. Use GUIDELINE.md for the project’s mechanism, animation, spatial QA and fictional-design requirements.

Current priority corrections are in GUIDELINE.md. Never silently omit effects, animations, craftables, customization, textures or documented progression. Do not create agents when the owner asks for direct work.

Before exporting, follow section 9 of GUIDELINE.md: verify actual timing, evaluated geometry, winding and duplicates; stress thin constructors; preserve raw material inputs and part ownership; enforce numeric failures rather than only logging them. Keep unsupported transparent/mixed-material paths explicit. The observed fixes are additional scoped evidence, never native/artistic acceptance by themselves.

For illustrated source profiles and animated assemblies, read GUIDELINE.md section 10: distinguish generated recipe/sprite art from extracted evidence, resolve exact resource IDs and class registration, preserve shot-level decision scope, and supplement ownership/parser checks with explicitly bounded surface/clearance review.

For native event binding, reward rules or generated concept captions, read GUIDELINE.md section 11. The pinned AoA blaster path differs from conventional guns; use the existing confirmed-shot core and verify embedded image claims before publication.

For multi-view concept revisions or packaged Blender builds, read GUIDELINE.md section 12. It covers observed grip/view inconsistencies, misleading embedded labels, script exit handling, dependency updates and bundled effect-level semantics.

After adding or updating weapon profiles, run refresh_coverage.py against the production queue and coverage file, or rebuild with build_standard.py --docs. Preserve prior review state, then refresh the derived existing_profile links. The receipt records changed links; it is not feature acceptance. Read GUIDELINE.md section 13 for the observed stale-link failure.

When regenerating the register, use build_standard.py --docs and read section 14: current docs-side reviews take precedence over archived state, owner-direction defaults fill only missing keys, and actual feature manifests are discovered without status promotion. For reparented or scaled Blender parts, apply section 15 and inspect the rebuilt render.

When comparing projectile motion, simplifying geometry or packaging authoring changes, read GUIDELINE.md section 16. It addresses observed inheritance, numerical self-test and intermediate-file reproducibility failures without treating offline checks as native acceptance.
