---
name: aoa-weapon-completeness
description: Enforce a complete feature, concept-fidelity and evidence checklist for every AoA weapon, craftable variant, attachment and effect package.
---

# AoA weapon completeness

Read GUIDELINE.md and feature-catalog.json before weapon work. Create a per-weapon record from weapon-manifest-template.json. Reconcile existing source/receipts rather than declaring earlier work absent or complete.

All 31 feature groups require separate concept/design, implementation and QA evidence. Preserve original behavior and version pins. Concepts and alternate builds are not substitutes for a canonical model. Do not pass canonical visual fidelity when the model diverges from its approved concept, even if numeric checks pass. Preserve owner-liked divergent models as separately identified craftable alternates.

Use the validator for structure and hashes; it cannot judge beauty, gameplay or the truth of evidence. Keep native and offline gates distinct. Record intentional omissions only with an owner-approved reason. Follow the existing Craft Game Weapons skill for mechanism, animation, spatial QA and safe conceptual physics.

Current priority corrections are in GUIDELINE.md. Never silently omit effects, animations, craftables, customization, textures or documented progression. Do not create agents when the owner asks for direct work.
