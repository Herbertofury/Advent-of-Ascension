"""Discover existing per-weapon review records without changing review states."""
from pathlib import Path
import copy,json,argparse,re

def link(coverage,manifests):
 out=copy.deepcopy(coverage);rows={r['id']:r for r in out['weapons']}
 if len(rows)!=len(out['weapons']):raise ValueError('Duplicate coverage registry ID')
 seen=set();changes=[]
 for name,m in sorted(manifests.items()):
  if not re.fullmatch('[a-z0-9-]+-feature-status.json',name):raise ValueError('Invalid manifest filename')
  ident=m.get('weapon_id')
  if ident not in rows:raise ValueError('Unknown registry ID: '+str(ident))
  if ident in seen:raise ValueError('Multiple manifests for '+ident)
  seen.add(ident)
  if m.get('target',{}).get('minecraft')!='1.20.1' or m.get('target',{}).get('aoa')!='3.7.1':raise ValueError('Different source target: '+name)
  old=rows[ident].get('manifest')
  if old not in [None,name]:raise ValueError('Conflicting existing manifest: '+ident)
  if old!=name:rows[ident]['manifest']=name;changes.append({'id':ident,'previous':old,'current':name})
 return out,changes
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--docs',type=Path,required=True);p.add_argument('--receipt',type=Path,required=True);p.add_argument('--check',action='store_true');a=p.parse_args();path=a.docs/'weapon-feature-coverage.json';old=json.loads(path.read_text());manifests={f.name:json.loads(f.read_text())for f in a.docs.glob('*-feature-status.json')};new,changes=link(old,manifests)
 if a.check and changes:raise SystemExit('Unlinked existing manifests: '+str(changes))
 if not a.check and changes:path.write_text(json.dumps(new,indent=2)+'\n')
 report={'manifests_checked':len(manifests),'links_changed':changes,'review_states_changed':False};a.receipt.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
