import copy,unittest
from refresh_coverage import refresh_profiles
PREFIX='https://github.com/Herbertofury/Advent-of-Ascension/wiki/'
class Refresh(unittest.TestCase):
 def setUp(self):
  self.queue={'records':[{'id':'aoa3:a','family':'sniper','profile':PREFIX+'A-Weapon-Profile'}]}
  self.coverage={'required_features':['baseline'],'weapons':[{'id':'aoa3:a','family':'sniper','existing_profile':None,'manifest':'existing.json','status':'in_progress','overrides':{'custom':'keep'},'extension':{'unknown':[1,2]}}]}
 def test_new_link_preserves_every_other_field(self):
  before=copy.deepcopy(self.coverage);out,report=refresh_profiles(self.queue,self.coverage)
  self.assertEqual(self.coverage,before);self.assertEqual(out['weapons'][0]['existing_profile'],PREFIX+'A-Weapon-Profile')
  out['weapons'][0]['existing_profile']=None;self.assertEqual(out,before);self.assertEqual(report['changed_count'],1)
 def test_old_link_recorded(self):
  self.coverage['weapons'][0]['existing_profile']=PREFIX+'Old';out,r=refresh_profiles(self.queue,self.coverage);self.assertEqual(r['changed_profile_links'][0]['previous'],PREFIX+'Old')
 def test_missing_metadata_does_not_erase(self):
  self.queue['records'][0].pop('profile');self.coverage['weapons'][0]['existing_profile']=PREFIX+'Old';out,r=refresh_profiles(self.queue,self.coverage);self.assertEqual(out,self.coverage);self.assertEqual(r['changed_count'],0)
 def test_idempotent(self):
  out,_=refresh_profiles(self.queue,self.coverage);out2,r=refresh_profiles(self.queue,out);self.assertEqual(out,out2);self.assertEqual(r['changed_count'],0)
 def test_duplicate_queue_rejected(self):
  self.queue['records']*=2
  with self.assertRaises(ValueError):refresh_profiles(self.queue,self.coverage)
 def test_duplicate_coverage_rejected(self):
  self.coverage['weapons']*=2
  with self.assertRaises(ValueError):refresh_profiles(self.queue,self.coverage)
 def test_missing_id_rejected(self):
  self.queue['records']=[]
  with self.assertRaises(ValueError):refresh_profiles(self.queue,self.coverage)
 def test_family_drift_rejected(self):
  self.queue['records'][0]['family']='gun'
  with self.assertRaises(ValueError):refresh_profiles(self.queue,self.coverage)
 def test_invalid_url_rejected(self):
  self.queue['records'][0]['profile']='javascript:alert(1)'
  with self.assertRaises(ValueError):refresh_profiles(self.queue,self.coverage)
if __name__=='__main__':unittest.main()
