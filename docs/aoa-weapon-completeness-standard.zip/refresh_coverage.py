"""Refresh discovered profile links without promoting feature or runtime reviews."""
import argparse
import copy
import json
import re
from pathlib import Path

def refresh_profiles(queue, coverage):
    records=queue['records']; weapons=coverage['weapons']
    q={r['id']:r for r in records}; c={r['id']:r for r in weapons}
    if len(q)!=len(records) or len(c)!=len(weapons):
        raise ValueError('Duplicate weapon IDs')
    if set(q)!=set(c):
        raise ValueError('Queue and coverage IDs differ; reconcile inventory separately')
    result=copy.deepcopy(coverage); changes=[]
    for row in result['weapons']:
        source=q[row['id']]
        if source['family']!=row['family']:
            raise ValueError('Weapon family changed: '+row['id'])
        new=source.get('profile')
        if new is None:
            continue  # Missing queue metadata does not erase an earlier reference.
        if not isinstance(new,str) or not re.fullmatch(r'https://github\.com/Herbertofury/Advent-of-Ascension/wiki/[A-Za-z0-9-]+',new):
            raise ValueError('Invalid profile link: '+row['id'])
        before=row.get('existing_profile')
        if new!=before:
            changes.append({'id':row['id'],'previous':before,'current':new})
            row['existing_profile']=new
    return result,{'changed_profile_links':changes,'changed_count':len(changes),
                   'review_states_changed':False,'native_acceptance_inferred':False}

def main():
    p=argparse.ArgumentParser();p.add_argument('--queue',type=Path,required=True)
    p.add_argument('--coverage',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--receipt',type=Path,required=True);a=p.parse_args()
    result,receipt=refresh_profiles(json.loads(a.queue.read_text()),json.loads(a.coverage.read_text()))
    a.output.write_text(json.dumps(result,indent=2)+'\n');a.receipt.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'changed_count':receipt['changed_count'],'review_states_changed':False}))

if __name__=='__main__': main()
