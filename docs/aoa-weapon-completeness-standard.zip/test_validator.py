import json,copy,tempfile,hashlib
from pathlib import Path
from validate_manifest import validate
R=Path(__file__).resolve().parent;c=json.loads((R/'feature-catalog.json').read_text());t=json.loads((R/'weapon-manifest-template.json').read_text());t['weapon_id']='aoa3:soul_storm'
with tempfile.TemporaryDirectory()as root:
 e,i=validate(t,c,root);assert not e and len(i)==101
 x=copy.deepcopy(t);del x['features']['tracers_and_trails'];assert any('Missing feature' in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);x['fully_accepted']=True;assert any('contradicts'in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);x['features']['death_finishers']['disposition']='omitted';assert any('owner approval'in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);x['features']['projectiles']['qa']['status']='passed';assert any('without evidence'in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);x['visual_fidelity_review']['status']='accepted';assert any('reviewer'in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);x['features']['audio']['qa']={'status':'passed','evidence':[{'path':'../escape','sha256':'0'*64}]};assert any('leaves evidence root'in e for e in validate(x,c,root)[0])
 p=Path(root)/'evidence.txt';p.write_text('Synthetic fixture, not a real weapon acceptance.');a={'path':'evidence.txt','sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 x=copy.deepcopy(t);x['features']['audio']['qa']={'status':'passed','evidence':[a]};assert not validate(x,c,root)[0]
 x['features']['audio']['qa']['evidence'][0]['sha256']='0'*64;assert any('hash mismatch'in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);x['acceptance_gates']['runtime']={'status':'passed','evidence':[a]};assert any('native test log'in e for e in validate(x,c,root)[0])
print('PASS 10 structural/evidence regression cases; template remains incomplete, not accepted')
