from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
R=Path(__file__).parent;frames=[];font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
for i,p in enumerate(sorted((R/'motion-workbench').glob('*.png'))):
 im=Image.open(p).convert('RGBA');assert im.size==(640,400),(p,im.size);bg=Image.new('RGBA',(640,460),'#101a2c');bg.alpha_composite(im,(0,40));d=ImageDraw.Draw(bg);d.text((20,10),'BARONATOR | original animated authoring prototype',font=font,fill='#d7f9ef');clip='Equip' if i<12 else 'Fire / cycling' if i<22 else 'Inspect / vents' if i<86 else 'Grenade-proc cue' if i<99 else 'Idle';d.text((20,430),clip+' | Native AoA adapter still pending',font=font,fill='#e1bca0');frames.append(bg.convert('RGB'))
assert len(frames)==109
frames[0].save(R/'baronator-motion.webp',save_all=True,append_images=frames[1:],duration=50,loop=0,quality=85,method=4)
frames[42].save(R/'baronator-preview.png')
print(len(frames),'authored frames', (R/'baronator-motion.webp').stat().st_size)
