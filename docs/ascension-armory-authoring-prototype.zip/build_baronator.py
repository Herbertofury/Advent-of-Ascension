"""Original fantasy presentation prototype. No upstream meshes, textures or clips copied."""
from pathlib import Path
import json,math,hashlib
from PIL import Image,ImageDraw
R=Path(__file__).parent;P=R/'prototype/assets/ascension_armory';P.mkdir(parents=True,exist_ok=True)
def write(rel,d):
 p=P/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
colors={'shell':'#b51236','edge':'#f54259','dark':'#171e2e','metal':'#667388','bright':'#b7cad4','gold':'#d99a45','energy':'#57f7e4','black':'#080c14','leather':'#482b39'}
tex=Image.new('RGBA',(128,128));td=ImageDraw.Draw(tex);uv={}
for i,(name,col) in enumerate(colors.items()):
 x=(i%4)*32;y=(i//4)*32;td.rectangle((x,y,x+31,y+31),fill=col);uv[name]=[x+2,y+2]
 for k in range(2,30,6):td.line((x+2,y+k,x+29,y+k),fill=col,width=1)
(P/'textures/gun/uv').mkdir(parents=True,exist_ok=True);tex.save(P/'textures/gun/uv/baronator.png')
bones=[];lookup={}
def bone(name,parent='root',pivot=(0,0,0),rotation=None):
 b={'name':name,'pivot':list(pivot)}
 if parent:b['parent']=parent
 if rotation:b['rotation']=list(rotation)
 bones.append(b);lookup[name]=b;return b
def cube(b,origin,size,material='shell',rotation=None,pivot=None):
 c={'origin':list(origin),'size':list(size),'uv':{f:{'uv':uv[material],'uv_size':[8,8]} for f in ['north','south','east','west','up','down']}}
 if rotation:c['rotation']=list(rotation);c['pivot']=list(pivot or origin)
 lookup[b].setdefault('cubes',[]).append(c)
 return c
bone('root',None);bone('receiver');bone('upper_shroud');bone('lower_shroud');bone('bolt',pivot=(0,2,-1));bone('grenade_breech',pivot=(0,-1,0));bone('magazine',pivot=(0,-2,3));bone('core',pivot=(0,1,2));bone('vent_left',pivot=(-2.6,2,0));bone('vent_right',pivot=(2.6,2,0));bone('trigger',pivot=(0,-2,4));bone('stock');bone('sight');bone('muzzle_flash',pivot=(0,2,-17));bone('shell',pivot=(2.8,2,1));bone('iron_view',pivot=(0,5.2,10));bone('idle_view',pivot=(-5,7,15));bone('thirdperson_hand',pivot=(0,-3,4));bone('ground',pivot=(0,0,0));bone('fixed');bone('lefthand_pos',pivot=(-1,-2,-5));bone('righthand_pos',pivot=(0,-4,5));bone('refit_view',pivot=(0,2,1))
# Cohesive double-channel fantasy silhouette. Red armor, dark recessed workings, brass edge hardware.
cube('receiver',(-2.5,-1,-4),(5,5,11),'dark');cube('receiver',(-2.8,0,-3.6),(.5,3.3,10),'shell');cube('receiver',(2.3,0,-3.6),(.5,3.3,10),'shell');cube('receiver',(-2.2,3.5,-3.6),(4.4,.8,9.7),'shell');cube('receiver',(-1.9,-1.4,-1),(3.8,.6,7),'metal')
for z in [-3,-1,1,3,5]:
 for x in [-2.9,2.65]:cube('receiver',(x,.35,z),(.25,.35,.65),'gold')
# Two independent muzzle assemblies, each boxed and recessed rather than a solid plugged cylinder.
for b,y,front in [('upper_shroud',2,-17),('lower_shroud',-1.8,-13)]:
 cube(b,(-1.1,y-.9,front),(2.2,1.8,12),'metal')
 for x in [-1.55,1.1]:cube(b,(x,y-1.25,front-.2),(.45,2.5,2),'bright')
 for yy in [y-1.25,y+.8]:cube(b,(-1.1,yy,front-.2),(2.2,.45,2),'bright')
 cube(b,(-.9,y-.65,front+.05),(1.8,1.3,.15),'black')
 for z in [front+2,front+4,front+6,front+8]:
  cube(b,(-1.4,y-1.1,z),(2.8,.4,.7),'dark');cube(b,(-1.4,y+.7,z),(2.8,.4,.7),'dark')
# Angled red front cheeks and inset black ventilation.
for x,angle in [(-2.8,-12),(1.5,12)]:
 cube('upper_shroud',(x,-.1,-10),(1.3,4.6,5.8),'shell',(0,0,angle),(x,2,-7))
 for z in [-9.4,-8.1,-6.8]:cube('upper_shroud',(x-.08,1,z),(1.45,.6,.4),'black')
 cube('upper_shroud',(x-.1,3.8,-9.5),(1.5,.35,4.6),'edge')
# Stock has a split red tail, a dark pad and an open triangular grip/guard.
cube('stock',(-1.6,.7,7),(3.2,2.8,5),'shell');cube('stock',(-1.9,.4,11),(3.8,3.6,1),'dark');cube('stock',(-1.7,3.4,6.4),(3.4,.6,5),'edge')
cube('receiver',(-1,-5.8,4),(2,4.8,2.3),'leather',(-15,0,0),(0,-1,4));cube('receiver',(-1.2,-6.2,4),(2.4,.7,2.8),'metal',(-15,0,0),(0,-1,4))
for y in [-5,-4,-3]:cube('receiver',(-1.07,y,4),(2.14,.25,2.4),'dark',(-15,0,0),(0,-1,4))
cube('receiver',(-.65,-4.8,.4),(1.3,.5,4.8),'metal');cube('receiver',(-.65,-4.8,.4),(1.3,3.6,.5),'metal');cube('trigger',(-.3,-3,3),(.6,2.0,.45),'gold',(-18,0,0),(0,-2,4))
# Restore the full trigger-guard opening; move the magazine instead of crowding the hand.
# Moving upper bolt, lower breech, optional ceremonial energy cassette.
cube('bolt',(-1.25,2.1,-2.5),(2.5,.9,3.8),'metal');cube('bolt',(1.2,2.3,.4),(2,.4,.6),'bright');cube('grenade_breech',(-1.8,-2.6,-2.8),(3.6,1.8,4.2),'shell')
cube('magazine',(-1.4,-5.4,-1),(2.8,3.8,3.4),'dark');cube('magazine',(-1.6,-5.8,-1.2),(3.2,.7,3.8),'gold')
for x in [-1.5,1.3]:
 for y in [-4.6,-3.6,-2.6]:cube('magazine',(x,y,-.5),(.2,.45,2.3),'shell')
cube('core',(-1.1,1.2,2),(2.2,1.3,1.4),'energy')
for b,x in [('vent_left',-3.15),('vent_right',2.8)]:
 cube(b,(x,1.1,1),(.35,2.2,4),'shell')
 for z in [1.4,2.4,3.4]:cube(b,(x-.04,1.5,z),(.43,1.4,.35),'energy')
# Forward, lower magazine socket: preserve the full trigger/finger opening.
# Magazine clears the lower barrel underside at rest and moves only downward for removal.
for c in lookup['magazine']['cubes']:
 c['origin'][1]-=1.6;c['origin'][2]-=4
 if 'pivot' in c:c['pivot'][1]-=1.6;c['pivot'][2]-=4
lookup['magazine']['pivot']=[0,-3.6,-1]
bone('magwell')
# Open-sided socket, with support arms outside the reciprocating lower barrel.
for x in [-1.95,1.55]:
 for z in [-5.45,-1.55]:cube('magwell',(x,-3.85,z),(.4,3.05,.4),'metal')
 cube('magwell',(x,-3.85,-5.45),(.4,.6,4.3),'shell')
for z in [-5.45,-1.55]:cube('magwell',(-1.55,-3.85,z),(3.1,.6,.4),'dark')
# Distinct raised sights and fine engraved bands.
for z in [-10,5.2]:
 cube('sight',(-1,4.3,z),(2,.4,1),'dark')
 for x in [-1,.65]:cube('sight',(x,4.6,z),(.35,.9,.6),'bright')
 cube('sight',(-.2,4.6,z),(.4,.5,.5),'energy')
for z in [-3.4,-2.6,5.8]:cube('receiver',(-2.4,3.8,z),(4.8,.25,.25),'gold')
geo={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.ascension_armory.baronator','texture_width':128,'texture_height':128,'visible_bounds_width':4,'visible_bounds_height':3,'visible_bounds_offset':[0,0,0]},'bones':bones}]};write('geo_models/gun/baronator_geo.json',geo)
# Independent keyframes. Names follow TaCZ's published animation contract; poses are original.
def keys(*pairs):return {str(t):v for t,v in pairs}
def track(rot=None,pos=None,scale=None):return {k:v for k,v in [('rotation',rot),('position',pos),('scale',scale)] if v is not None}
animations={}
def clip(name,length,b,loop=False):animations[name]={'animation_length':length,'loop':loop,'bones':b}
clip('static_idle',2.4,{'root':track(rot=keys((0,[0,0,0]),(1.2,[.3,0,.2]),(2.4,[0,0,0])))},True)
clip('static_auto',0,{});clip('static_semi',0,{})
clip('draw',.6,{'root':track(rot=keys((0,[28,-12,-20]),(.24,[-4,3,2]),(.44,[1,0,-.5]),(.6,[0,0,0])),pos=keys((0,[0,-8,5]),(.3,[0,.4,-.4]),(.6,[0,0,0])))})
clip('put_away',.4,{'root':track(rot=keys((0,[0,0,0]),(.4,[28,-12,-20])),pos=keys((0,[0,0,0]),(.4,[0,-8,5])))})
clip('shoot',.25,{'root':track(rot=keys((0,[0,0,0]),(.035,[-3.5,0,-.7]),(.09,[.7,0,.2]),(.25,[0,0,0])),pos=keys((0,[0,0,0]),(.03,[0,.1,1.1]),(.11,[0,0,-.1]),(.25,[0,0,0]))),'bolt':track(pos=keys((0,[0,0,0]),(.035,[0,0,1.6]),(.105,[0,0,0]),(.25,[0,0,0]))),'trigger':track(rot=keys((0,[0,0,0]),(.035,[18,0,0]),(.12,[0,0,0]),(.25,[0,0,0])))})
clip('inspect',3.2,{'root':track(rot=keys((0,[0,0,0]),(.5,[5,-20,20]),(1.2,[5,-20,20]),(1.8,[-5,25,-16]),(2.5,[-5,25,-16]),(3.2,[0,0,0]))),'vent_left':track(rot=keys((0,[0,0,0]),(.8,[0,0,28]),(1.4,[0,0,28]),(2,[0,0,0]),(3.2,[0,0,0]))),'vent_right':track(rot=keys((0,[0,0,0]),(.8,[0,0,-28]),(1.4,[0,0,-28]),(2,[0,0,0]),(3.2,[0,0,0])))})
animations['inspect_empty']=json.loads(json.dumps(animations['inspect']))
clip('reload_tactical',2.2,{'root':track(rot=keys((0,[0,0,0]),(.3,[8,0,-16]),(1.6,[8,0,-16]),(2.2,[0,0,0]))),'magazine':track(pos=keys((0,[0,0,0]),(.4,[0,0,0]),(.8,[0,-7,0]),(1.1,[0,-7,0]),(1.45,[0,0,0]),(2.2,[0,0,0])))})
animations['reload_empty']=json.loads(json.dumps(animations['reload_tactical']));animations['reload_empty']['animation_length']=2.6;animations['reload_empty']['bones']['bolt']=track(pos=keys((0,[0,0,0]),(1.7,[0,0,0]),(1.9,[0,0,1.6]),(2.1,[0,0,0]),(2.6,[0,0,0])))
clip('vent',1.4,{'vent_left':track(rot=keys((0,[0,0,0]),(.2,[0,0,35]),(.8,[0,0,35]),(1.4,[0,0,0]))),'vent_right':track(rot=keys((0,[0,0,0]),(.2,[0,0,-35]),(.8,[0,0,-35]),(1.4,[0,0,0])))})
clip('grenade_proc',.65,{'grenade_breech':track(pos=keys((0,[0,0,0]),(.08,[0,0,1.3]),(.32,[0,0,1.3]),(.65,[0,0,0]))),'root':track(rot=keys((0,[0,0,0]),(.07,[-6,0,0]),(.3,[1,0,0]),(.65,[0,0,0])))})
write('animations/baronator.animation.json',{'format_version':'1.8.0','animations':animations})
write('display/guns/baronator_display.json',{'model':'ascension_armory:gun/baronator_geo','texture':'ascension_armory:gun/uv/baronator','animation':'ascension_armory:baronator','third_person_animation':'default','show_crosshair':False,'iron_zoom':1.2,'transform':{'scale':{'thirdperson':[.7,.7,.7],'ground':[.7,.7,.7],'fixed':[1,1,1]}}})
manifest={'weapon':'aoa3:baronator','asset_id':'ascension_armory:baronator','stage':'original authoring prototype; not game-tested or installable gunpack','baseline':{'minecraft':'1.20.1','aoa':'3.7.1','damage_input':3.0,'shot_interval_ticks':5,'durability':2480,'special_effect':'Native successful shot can request an extra grenade via oneInNChance(5); preserve native server path.'},'reload_policy':{'default':'native inventory ammunition; no added manual reload','optional_animation_only':['reload_tactical','reload_empty'],'warning':'These clips do not transfer ammunition. Gameplay reload conversion requires separate server policy.'},'tacz_source_pin':'b482eff8c94a733ac8d0910193fca3893954027c','geometry':{'bones':len(bones),'cubes':sum(len(b.get('cubes',[])) for b in bones)},'clips':list(animations),'ownership':'Original generated geometry, texture palette and keyframes; AoA identity credited to Tslat. No TaCZ default art or clips copied.','missing':['native AoA presentation adapter','first-person hands/pose validation','custom third-person choreography','sounds','runtime resource loading','multiplayer','performance benchmarks'],'files':[]}
for p in sorted(P.rglob('*')):
 if p.is_file():manifest['files'].append({'path':p.relative_to(R/'prototype').as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(R/'prototype/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(manifest['geometry'],len(animations),'clips')
