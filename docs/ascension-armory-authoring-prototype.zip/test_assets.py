from pathlib import Path
import json,math,hashlib
from PIL import Image
R=Path(__file__).parent;P=R/'prototype';M=json.load(open(P/'manifest.json'));root=P/'assets/ascension_armory';g=json.load(open(root/'geo_models/gun/baronator_geo.json'))['minecraft:geometry'][0];a=json.load(open(root/'animations/baronator.animation.json'))['animations'];names=[b['name'] for b in g['bones']];assert len(names)==len(set(names));checks=[]
for b in g['bones']:
 seen={b['name']};p=b.get('parent')
 while p:
  assert p in names and p not in seen,(b['name'],p);seen.add(p);p=next(x for x in g['bones'] if x['name']==p).get('parent')
 for c in b.get('cubes',[]):
  assert all(math.isfinite(v) for k in ['origin','size'] for v in c[k]);assert all(v>0 for v in c['size'])
  for face,uv in c['uv'].items():assert all(0<=uv['uv'][i] and uv['uv'][i]+uv['uv_size'][i]<=128 for i in [0,1])
checks+=['Acyclic complete bone hierarchy','Positive finite cuboids','All UV faces within 128px texture']
samples=0
for name,clip in a.items():
 assert clip['animation_length']>=0
 for bone,channels in clip['bones'].items():
  assert bone in names
  for channel,ks in channels.items():
   assert channel in ['position','rotation','scale'];ts=sorted(float(k) for k in ks);assert all(0<=t<=clip['animation_length']+1e-6 for t in ts)
   for t,v in ks.items():assert len(v)==3 and all(isinstance(n,(int,float)) and math.isfinite(n) for n in v)
   for i in range(round(clip['animation_length']*60)+1):
    t=i/60;lo=max((x for x in ts if x<=t),default=ts[0]);hi=min((x for x in ts if x>=t),default=ts[-1]);x=ks[str(lo)] if str(lo) in ks else ks[str(int(lo))];y=ks[str(hi)] if str(hi) in ks else ks[str(int(hi))];q=0 if lo==hi else (t-lo)/(hi-lo);assert all(math.isfinite(u+(v-u)*q) for u,v in zip(x,y));samples+=1
checks+=['Animation bone names resolve','All keyframes lie inside clips','60Hz linear sample values finite']
for f in M['files']:
 p=P/f['path'];assert p.stat().st_size==f['bytes'];assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
assert not list(P.glob('data/*/index/guns/*.json')),'Do not disguise presentation-only export as a functional gunpack'
assert M['reload_policy']['default'].startswith('native inventory')
checks+=['Export manifest hashes match','Presentation-only boundary explicit','Native-cost default recorded']
report={'checks_passed':checks,'sampled_channel_frames':samples,'bones':len(names),'cubes':sum(len(b.get('cubes',[])) for b in g['bones']),'animation_clips':len(a),'scope':'Static original-asset and deterministic interpolation checks only. No TaCZ renderer, game, hand-pose, multiplayer or performance certification.'};(R/'asset-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
