import bpy,json,math
from pathlib import Path
from mathutils import Matrix,Euler,Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'baronator-authoring.blend'));D=json.load(open(R/'prototype/assets/ascension_armory/animations/baronator.animation.json'))['animations'];scene=bpy.context.scene;C=Matrix(((1,0,0),(0,0,-1),(0,1,0)));base={n:o.location.copy() for n,o in bpy.data.objects.items() if o.type=='EMPTY'}
def sample(v,t,default):
 if not isinstance(v,dict):return v or default
 keys=sorted((float(k),val) for k,val in v.items())
 if not keys:return default
 if t<=keys[0][0]:return keys[0][1]
 for (a,x),(b,y) in zip(keys,keys[1:]):
  if t<=b:
   f=(t-a)/(b-a);return [u+(w-u)*f for u,w in zip(x,y)]
 return keys[-1][1]
scene.render.engine='CYCLES';scene.cycles.samples=8;scene.cycles.use_denoising=False;scene.render.resolution_x=640;scene.render.resolution_y=400;scene.render.resolution_percentage=100;scene.display.shading.light='STUDIO';scene.display.shading.color_type='MATERIAL';scene.display.shading.show_shadows=True;scene.display.shading.show_cavity=True;scene.display.shading.cavity_type='BOTH';scene.display.shading.curvature_ridge_factor=1.5;scene.display.shading.curvature_valley_factor=1.2;scene.render.film_transparent=True
frames=R/'motion-frames';frames.mkdir(exist_ok=True)
# Draw, two successful-shot visual examples, inspect, grenade proc. No ammunition simulation.
sequence=[('draw',.6),('shoot',.25),('shoot',.25),('inspect',3.2),('grenade_proc',.65),('static_idle',.5)]
i=0
for name,length in sequence:
 clip=D[name]
 for frame in range(max(1,round(length*20))):
  t=frame/20
  for n,loc in base.items():
   ob=bpy.data.objects[n];tr=clip['bones'].get(n,{});p=sample(tr.get('position'),t,[0,0,0]);rot=sample(tr.get('rotation'),t,[0,0,0]);ob.location=loc+Vector((p[0],-p[2],p[1]));ob.rotation_euler=(C@Euler(tuple(math.radians(a) for a in rot),'XYZ').to_matrix()@C.inverted()).to_euler()
  scene.render.filepath=str(frames/f'{i:04}.png');bpy.ops.render.render(write_still=True);i+=1
print('RENDERED',i,'SOURCE-KEYFRAME FRAMES')
