# Ascension Armory: original authoring prototype

An early, editable Baronator presentation study for the owner's Advent of Ascension upgrade. Original geometry, palette texture and keyframes were authored for this project. AoA and the Baronator identity are credited to Tslat and contributors. No TaCZ default model, texture, sound or animation is bundled.

## What is here

- Bedrock Entity geometry: 23 bones, 95 cuboids, 128×128 palette texture.
- Twelve named animation records, including static mode poses, equip/holster, firing/cycling, inspection, optional reload demonstrations, vent and grenade-effect cue.
- TaCZ-style display resource with named view, hand, muzzle and shell locator bones.
- Original Python generators, asset validation, Blender scene generation and motion rendering.
- A version-keyed coverage ledger: 412 inspected legacy weapons, 411 inspected modern weapons and the independently audited 78 direct guns in the initial 1.20.1 lane. These are version records, not 901 unique guns or completed remodels.

## Status

This is NOT an installable gunpack or functional AoA integration. There is deliberately no fake gun-index/data file that silently replaces AoA behavior with ordinary TaCZ bullets. The native item presentation adapter, in-game model loading, sights/hands, audio, third-person choreography, multiplayer and performance tests remain open.

The first native contract is AoA 3.7.1 / Minecraft1.20.1 Baronator: registered damage input3, shot interval5ticks, durability2480, full-auto default. These are configured inputs, not measured damage or speed. The source-observed special grenade branch must be preserved through the original server logic; the preview's grenade cue is illustrative and does not simulate the probability or gameplay.

Manual reloading is optional. The default target is the native ammo/resource behavior without new reload downtime. Reload clips in this prototype are authoring demonstrations only and never transfer ammunition.

## Editing and checking

Run build_baronator.py with Python/Pillow to regenerate original assets, then test_assets.py for static checks. The Bedrock geometry and animation JSON can be used as the starting point for Blockbench authoring. The renderer scripts use an installed Blender and the same exported geometry/keyframes; no game JAR is executed.

The supplied Blender scene can be regenerated with render_baronator.py. It is an authoring scene, not a TaCZ pose-certification fixture. animate_baronator_workbench.py renders the exported clips for visual review; package_motion.py creates the labeled animated WebP.

## Next quality gates

1. Inspect each native gun's exact behavior before implementing an adapter.
2. Add authored first-person hand interaction and validate actual TaCZ view alignment.
3. Add distinct sound design, muzzle/secondary effects and a reduced-motion option.
4. Implement presentation on native saved AoA items without duplicating server shots or costs.
5. Validate interrupts, missing optional backend, left-handed view, FOV and multiplayer.
6. Measure startup, memory and frame-time distributions before claiming no regression.
7. Iterate silhouette, material detail and motion with actual in-game footage before calling a weapon finished.

## Reference provenance

TaCZ API/format study pinned to MCModderAnchor/TACZ commit b482eff8c94a733ac8d0910193fca3893954027c, branch1.20.1. Official source: https://github.com/MCModderAnchor/TACZ/tree/b482eff8c94a733ac8d0910193fca3893954027c

The old documentation tree is not used as authority for current pack paths. This export uses the pinned source's assets/{namespace}/geo_models, animations, textures and display/guns structure. Default-pack examples were inspected privately for format only. Third-party reference downloads are excluded from this archive.
