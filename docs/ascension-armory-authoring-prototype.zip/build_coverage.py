from pathlib import Path
import json,hashlib,collections
R=Path(__file__).parent;D=R/'coverage-inputs' if (R/'coverage-inputs').exists() else R.parent/'aoa-expansion';rows=[]
old=json.load(open(D/'historical-weapon-census-1.12.2.json'))
for x in old['records']:rows.append(dict(version='1.12.2',release=old['release'],id=x['id'],name=x['name'],family=x['family'],registration_evidence='historical-weapon-census-1.12.2.json',status='not started'))
modern=json.load(open(D/'weapon-registration-factories-1.21.1.json'));names={r['id']:r['name'] for r in json.load(open(D/'inventory-data-1.21.1.json'))['records']}
for key,x in modern['records'].items():
 ids=[v for v in x['constants'] if isinstance(v,str)];assert len(ids)==1,(key,ids);id='aoa3:'+ids[0]
 owners=[i['member'][0] for f in x['factories'] for i in f.get('instructions',[]) if i.get('member',['',''])[1]=='<init>' and '/weapon/' in i['member'][0]]
 families={s.split('/weapon/')[1].split('/')[0] for s in owners};assert len(families)==1,(id,families)
 rows.append(dict(version='1.21.1',release='3.7.16.1',id=id,name=names.get(id,ids[0]),family=next(iter(families)),registration_evidence='weapon-registration-factories-1.21.1.json',status='not started'))
# Actual first target lane has a released-input audit for 78 guns, independent of modern catalog.
for x in json.load(open(D/'historical-gun-inputs-1.20.1.json'))['records']:
 rows.append(dict(version='1.20.1',release='3.7.1',id=x['id'],name=x['name'],family='gun',registration_evidence='historical-gun-inputs-1.20.1.json',status='authoring prototype' if x['id']=='aoa3:baronator' else 'not started',native_stat_inputs={k:x[k] for k in ['damage_input','durability_input','shot_interval_input_ticks','literal_fire_mode']}))
families=['gun','shotgun','sniper','cannon','blaster','archergun'];report={'scope':'Version-keyed coverage from three existing released-registration audits. Not a deduplicated all-history union; the 1.20.1 lane currently covers only its 78 audited direct guns.','counts':dict(collections.Counter(r['version'] for r in rows)),'gun_family_counts':dict(collections.Counter(r['version'] for r in rows if r['family'] in families)),'records':rows,'inputs':[{ 'path':n,'sha256':hashlib.sha256((D/n).read_bytes()).hexdigest()} for n in ['historical-weapon-census-1.12.2.json','weapon-registration-factories-1.21.1.json','historical-gun-inputs-1.20.1.json']]};(R/'weapon-coverage.json').write_text(json.dumps(report,indent=2)+'\n');print(report['counts'],report['gun_family_counts'])
