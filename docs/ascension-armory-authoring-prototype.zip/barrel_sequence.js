/* Presentation reference: server sequence advances only for successful native primary shots. */
class BarrelSequence {
 constructor(limit=32){if(!Number.isInteger(limit)||limit<1)throw Error('Invalid limit');this.limit=limit;this.last=new Map();}
 confirm(weaponSessionKey,successfulShotSequence,{accepted=true,bonusGrenade=false}={}){
  if(!accepted||bonusGrenade)return null;
  if(typeof weaponSessionKey!=='string'||!weaponSessionKey||weaponSessionKey.length>256||!Number.isSafeInteger(successfulShotSequence)||successfulShotSequence<0)throw Error('Invalid shot acknowledgement');
  const previous=this.last.get(weaponSessionKey);if(previous!==undefined&&successfulShotSequence<=previous)return null;
  this.last.delete(weaponSessionKey);this.last.set(weaponSessionKey,successfulShotSequence);while(this.last.size>this.limit)this.last.delete(this.last.keys().next().value);
  return successfulShotSequence%2===0?'upper':'lower';
 }
 reset(){this.last.clear();}
}
if(typeof module!=='undefined')module.exports=BarrelSequence;
