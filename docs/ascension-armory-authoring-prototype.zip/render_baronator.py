import bpy,json,math,sys
from pathlib import Path
from mathutils import Vector,Euler,Matrix
R=Path(__file__).resolve().parent;P=R/'prototype/assets/ascension_armory';geo=json.load(open(P/'geo_models/gun/baronator_geo.json'))['minecraft:geometry'][0];animations=json.load(open(P/'animations/baronator.animation.json'))['animations'];bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
# Coordinate conversion: Bedrock X,Y,Z -> Blender X,-Z,Y. Scene is an authoring preview, not TaCZ runtime.
def v(p):return Vector((p[0],-p[2],p[1]))
C=Matrix(((1,0,0),(0,0,-1),(0,1,0)));bones={};pivots={};col=['b51236','f54259','171e2e','667388','b7cad4','d99a45','57f7e4','080c14','482b39'];mats=[]
for i,h in enumerate(col):
 m=bpy.data.materials.new('palette_'+str(i));m.diffuse_color=tuple(int(h[j:j+2],16)/255 for j in [0,2,4])+(1,);m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=m.diffuse_color;bs.inputs['Metallic'].default_value=.55 if i in [3,4,5] else .15;bs.inputs['Roughness'].default_value=.36
 if i==6:bs.inputs['Emission Color'].default_value=m.diffuse_color;bs.inputs['Emission Strength'].default_value=1.5
 mats.append(m)
for b in geo['bones']:
 ob=bpy.data.objects.new(b['name'],None);bpy.context.collection.objects.link(ob);pivot=v(b.get('pivot',[0,0,0]));pivots[b['name']]=pivot
 if 'parent' in b:ob.parent=bones[b['parent']];ob.location=pivot-pivots[b['parent']]
 else:ob.location=pivot
 bones[b['name']]=ob
 for i,c in enumerate(b.get('cubes',[])):
  orig=Vector(c['origin']);sz=Vector(c['size']);center=orig+sz/2;bpy.ops.mesh.primitive_cube_add(size=1);q=bpy.context.object;q.name=b['name']+'_'+str(i);q.parent=ob;rot=Euler(tuple(math.radians(a) for a in c.get('rotation',[0,0,0])),'XYZ').to_matrix();cp=Vector(c.get('pivot',center));center=cp+rot@(center-cp);q.location=v(center)-pivot;q.rotation_euler=(C@rot@C.inverted()).to_euler();q.scale=(sz.x,sz.z,sz.y);uv=c['uv']['north']['uv'];idx=int(uv[1]//32)*4+int(uv[0]//32);q.data.materials.append(mats[idx])
# Soft studio lighting shows actual exported cuboids; no geometry-only render bevels.
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.render.resolution_x=1200;scene.render.resolution_y=760;scene.render.resolution_percentage=100;scene.world.color=(.06,.07,.1)
for name,loc,power,size,color in [('key',(15,8,25),2400,20,(.78,.88,1)),('rim',(-12,-8,12),1800,15,(1,.18,.3)),('fill',(2,-20,5),1800,12,(.3,1,.9))]:
 data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size;data.color=color;ob=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(ob);ob.location=loc;ob.rotation_euler=(Vector((0,2,0))-ob.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(30,35,19));cam=bpy.context.object;cam.rotation_euler=(Vector((0,3,0))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=35;scene.camera=cam
scene.render.film_transparent=True;scene.view_settings.view_transform='AgX';scene.render.image_settings.file_format='PNG';scene.render.filepath=str(R/'baronator-studio.png');bpy.ops.wm.save_as_mainfile(filepath=str(R/'baronator-authoring.blend'));bpy.ops.render.render(write_still=True)
