# Soul Storm neutral-pose TML transport fixture

Original four-emitter geometry exported from corrected world-LOD v2; this is **not an installable gunpack**. The 13 poly_mesh bones retain emitter grouping, 20,288 triangles and 81,152 expanded vertices. Eight authoring projectile meshes are excluded. Source and texture receipts are included.

Reproduce with Blender 4.3.2: blender -b -t 4 --python-exit-code 1 --python export_geometry.py -- --source /path/to/soul-storm-world-lod-candidate-v2.blend
Then: python pack_atlas.py --textures /path/to/extracted-v14-textures
The source scene comes from the published v14 source and world-LOD v2 reproduction script in the AoA repository docs.

The atlas copies the original core and 15 flame frames pixel-for-pixel into 2048x2048 with 4-pixel extrusion gutters; source palette values are converted from linear to sRGB. No repainting/resampling. Only flame frame zero is mapped. Source low-alpha border is retained; native mip bleeding and transparency are not accepted.

The actual released TML0.1.8 mesh baker passed bounded offline processing on Java17/21. Shader materials, winding, full normal correctness, hand anchors, animation clips, recoil/cadence, gameplay, attachments, PBR and native visual/performance acceptance remain open. Do not install this as a finished weapon or infer FPS gains from triangle counts.
