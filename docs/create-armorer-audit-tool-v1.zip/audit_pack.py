import argparse,zipfile,json,pathlib,hashlib,io,collections
from PIL import Image
from jsonc_reader import loads
p=argparse.ArgumentParser();p.add_argument('zip');p.add_argument('out');a=p.parse_args();raw=pathlib.Path(a.zip).read_bytes();z=zipfile.ZipFile(io.BytesIO(raw));names=set(z.namelist());records=[];issues=[]
def path(ref,kind,suffix):
 ns,n=ref.split(':');return f'assets/{ns}/{kind}/{n}{suffix}'
for n in sorted(names):
 if '/display/guns/'not in n or not n.endswith('.json'):continue
 d=loads(z.read(n).decode('utf-8-sig'));model=path(d['model'],'geo_models','.json');tex=path(d['texture'],'textures','.png');ani=path(d['animation'],'animations','.animation.json');g=loads(z.read(model).decode())['minecraft:geometry'][0];bones=g['bones'];cubes=[c for b in bones for c in b.get('cubes',[])];clips=loads(z.read(ani).decode())['animations'];lod=d.get('lod');lrec={}
 if lod:
  for k,kind,suf in [('model','geo_models','.json'),('texture','textures','.png')]:
   lp=path(lod[k],kind,suf);lrec[k]={'path':lp,'exists':lp in names}
   if lp not in names:issues.append({'display':n,'missing':lp})
 records.append({'display':n,'model':model,'texture':tex,'model_sha256':hashlib.sha256(z.read(model)).hexdigest(),'bones':len(bones),'cubes':len(cubes),'planes':sum(any(v==0 for v in c['size']) for c in cubes),'rotated_cubes':sum(any(v!=0 for v in c.get('rotation',[]))for c in cubes),'uv':[g['description']['texture_width'],g['description']['texture_height']],'image':list(Image.open(io.BytesIO(z.read(tex))).size),'animation':ani,'clip_names':list(clips),'clip_count':len(clips),'state_machine':d.get('state_machine'),'lod':lrec})
out={'archive_sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'file_count':len(names),'displays':len(records),'records':records,'missing_declared_lod_assets':issues,'script_hashes':{n:hashlib.sha256(z.read(n)).hexdigest()for n in sorted(names)if n.endswith('.lua')},'limits':'File census; not execution, visual quality acceptance or native compatibility testing'};pathlib.Path(a.out).write_text(json.dumps(out,indent=2)+'\n');print('displays',len(records),'missingLOD',len(issues));print('\n'.join(f"{pathlib.Path(x['display']).stem}: {x['bones']} bones/{x['cubes']} cubes/{x['clip_count']} clips/{x['planes']} planes"for x in records))
