from pathlib import Path
import json,unittest,math,struct
R=Path(__file__).resolve().parent;G=json.loads((R/'soul_storm_metal.geo.json').read_text());C=json.loads((R/'soul_storm_metal.compact.geo.json').read_text());M=json.loads((R/'manifest.json').read_text());bones=G['minecraft:geometry'][0]['bones'];meshes=[b['poly_mesh']for b in bones if 'poly_mesh'in b]
def fbits(x):return struct.pack('!f',float(x))
class Contract(unittest.TestCase):
 def test_counts(self):self.assertEqual(len(meshes),5);self.assertEqual(sum(len(m['polys'])for m in meshes),27472)
 def test_indices(self):
  for m in meshes:
   for p in m['polys']:
    self.assertEqual(len(p),3)
    for v in p:
     for i,k in enumerate(['positions','normals','uvs']):self.assertTrue(0<=v[i]<len(m[k]))
 def test_uvs(self):
  for m in meshes:
   self.assertTrue(m['normalized_uvs']);self.assertGreater(len(m['uvs']),50)
   for u in m['uvs']:self.assertTrue(all(math.isfinite(x)and 0<=x<=1 for x in u))
 def test_owners(self):self.assertEqual(len(M['objects']),136);self.assertEqual(len({o['source_object']for o in M['objects']}),136);self.assertEqual(len({o['bone']for o in M['objects']}),5)
 def test_compaction(self):
  cb=C['minecraft:geometry'][0]['bones'];self.assertEqual([b['name']for b in bones],[b['name']for b in cb])
  for a,b in zip(bones,cb):
   if 'poly_mesh'not in a:continue
   self.assertEqual(a['poly_mesh']['polys'],b['poly_mesh']['polys'])
   for k in ['positions','normals','uvs']:
    self.assertEqual(len(a['poly_mesh'][k]),len(b['poly_mesh'][k]))
    for x,y in zip(a['poly_mesh'][k],b['poly_mesh'][k]):self.assertEqual([fbits(v)for v in x],[fbits(v)for v in y])
 def test_no_acceptance(self):self.assertFalse(M['native_accepted']);self.assertTrue(M['excluded_visible_meshes'])
 def test_actual_released_parser(self):
  for runtime in ['17','21']:
   s=(R/('java'+runtime+'.log')).read_text();self.assertIn('879104 baked float values',s);self.assertIn('PASS clean isolated build',s)
if __name__=='__main__':unittest.main()
