import com.google.gson.*;import com.example.taczmeshloader.core.PolyMesh;import java.lang.reflect.*;import java.nio.file.*;import java.security.*;import java.nio.*;import java.util.*;
public class CandidateCheck{
 static Object field(Object p,String n)throws Exception{Field f=p.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(p);}static void req(boolean b,String s){if(!b)throw new AssertionError(s);}static void near(float a,float b){req(Math.abs(a-b)<1e-6,"normal mismatch "+a+" "+b);}
 static JsonObject mesh(){return JsonParser.parseString("{\"normalized_uvs\":true,\"positions\":[[0,0,0],[16,0,0],[0,16,0]],\"normals\":[[0.6,0,0.8],[0,0.6,0.8],[-0.6,0,0.8]],\"uvs\":[[0,0],[1,0],[0,1]],\"polys\":[[[0,0,0],[1,1,1],[2,2,2]]]} ").getAsJsonObject();}
 static PolyMesh bake(JsonObject m){return new PolyMesh(m,2048,2048,new float[]{0,0,0});}
 public static void main(String[] args)throws Exception{
  boolean candidate=Boolean.parseBoolean(args[1]);JsonObject m=mesh();PolyMesh def=bake(m);float[] dx=(float[])field(def,"bakedNX");for(float x:dx)near(x,0);
  if(candidate){
   m.addProperty("tml_normal_mode","authored");PolyMesh p=bake(m);float[] x=(float[])field(p,"bakedNX"),y=(float[])field(p,"bakedNY"),z=(float[])field(p,"bakedNZ");near(x[0],.6f);near(y[1],-.6f);near(z[2],.8f);near(x[3],-.6f);
   for(String normals:new String[]{"[[0,0,0]]","[[\"NaN\",0,1]]","[[\"Infinity\",0,1]]","[]"}){JsonObject bad=mesh();bad.addProperty("tml_normal_mode","authored");bad.add("normals",JsonParser.parseString(normals));PolyMesh b=bake(bad);for(float nz:(float[])field(b,"bakedNZ"))near(nz,1);}
   JsonObject huge=mesh();huge.addProperty("tml_normal_mode","authored");huge.add("normals",JsonParser.parseString("[[3e38,0,0],[0,3e38,0],[0,0,3e38]]"));PolyMesh h=bake(huge);near(((float[])field(h,"bakedNX"))[0],1);near(((float[])field(h,"bakedNY"))[1],-1);
   JsonObject missing=mesh();missing.remove("normals");missing.addProperty("tml_normal_mode","authored");for(float nz:(float[])field(bake(missing),"bakedNZ"))near(nz,1);
   for(String mode:new String[]{"\"typo\"","true","null","[]"}){JsonObject bad=mesh();bad.add("tml_normal_mode",JsonParser.parseString(mode));try{bake(bad);throw new AssertionError("invalid mode accepted");}catch(IllegalArgumentException expected){}}
   req(((Map<?,?>)field(p,"vboCache")).isEmpty(),"GPU state");System.out.println("PASS authored, default-flat, missing/zero/nonfinite/out-of-range normals, large finite normalization, invalid-mode rejection and no GPU cache tests");
  }
  MessageDigest digest=MessageDigest.getInstance("SHA-256");JsonArray bones=JsonParser.parseString(Files.readString(Path.of(args[0]))).getAsJsonObject().getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject().getAsJsonArray("bones");int count=0;
  for(JsonElement be:bones){JsonObject b=be.getAsJsonObject();if(!b.has("poly_mesh"))continue;PolyMesh p=bake(b.getAsJsonObject("poly_mesh"));for(String f:new String[]{"bakedX","bakedY","bakedZ","bakedU","bakedV","bakedNX","bakedNY","bakedNZ"})for(float v:(float[])field(p,f)){digest.update(ByteBuffer.allocate(4).putInt(Float.floatToRawIntBits(v)).array());count++;}}
  System.out.println("DEFAULT_ARRAY_DIGEST "+HexFormat.of().formatHex(digest.digest())+" values="+count);
 }
}
