import com.google.gson.*;import com.example.taczmeshloader.core.PolyMesh;import java.nio.file.*;
public class AuthoredFixtureCheck{
 public static void main(String[] args)throws Exception{
  JsonArray bones=JsonParser.parseString(Files.readString(Path.of(args[0]))).getAsJsonObject().getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject().getAsJsonArray("bones");int corners=0;double maxError=0;
  for(JsonElement be:bones){JsonObject b=be.getAsJsonObject();if(!b.has("poly_mesh"))continue;JsonObject m=b.getAsJsonObject("poly_mesh");m.addProperty("tml_normal_mode","authored");PolyMesh p=new PolyMesh(m,2048,2048,new float[]{0,0,0});float[] x=(float[])CandidateCheck.field(p,"bakedNX"),y=(float[])CandidateCheck.field(p,"bakedNY"),z=(float[])CandidateCheck.field(p,"bakedNZ");int offset=0;
   for(JsonElement pe:m.getAsJsonArray("polys")){JsonArray poly=pe.getAsJsonArray();CandidateCheck.req(poly.size()==3,"triangle fixture");for(int k=0;k<4;k++){int src=Math.min(k,2);JsonArray n=m.getAsJsonArray("normals").get(poly.get(src).getAsJsonArray().get(1).getAsInt()).getAsJsonArray();double nx=n.get(0).getAsFloat(),ny=-n.get(1).getAsFloat(),nz=n.get(2).getAsFloat();double len=Math.sqrt(nx*nx+ny*ny+nz*nz);double err=Math.max(Math.max(Math.abs(x[offset+k]-nx/len),Math.abs(y[offset+k]-ny/len)),Math.abs(z[offset+k]-nz/len));maxError=Math.max(maxError,err);CandidateCheck.req(err<1e-6,"source normal lost");corners++;}offset+=4;}
  }System.out.println("PASS full authored-normal fixture: "+corners+" expanded corners, max component error="+maxError+". Source-build data test only; no GPU lighting or animation acceptance.");
 }
}
