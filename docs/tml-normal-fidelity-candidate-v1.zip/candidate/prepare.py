from pathlib import Path
import hashlib,difflib,argparse
R=Path(__file__).resolve().parent;parser=argparse.ArgumentParser();parser.add_argument('--upstream-source',type=Path,default=R.parent/'tml-normal-fidelity-study/PolyMesh-upstream.java');args=parser.parse_args();src=args.upstream_source.read_text();assert hashlib.sha256(src.encode()).hexdigest()=='d38e5b86e87e580bfa0eae208ced2d009af386136f7d3731543f15a746852c92','Unexpected upstream source';R.joinpath('baseline').mkdir(exist_ok=True);R.joinpath('candidate').mkdir(exist_ok=True)
p=Path('com/example/taczmeshloader/core/PolyMesh.java')
for folder in ['baseline','candidate']:(R/folder/p).parent.mkdir(parents=True,exist_ok=True)
(R/'baseline'/p).write_text(src)
old='        float[][] normals   = parse2DArray(meshObj.getAsJsonArray("normals"), 3);'
new=old+'''
        // Proposed opt-in; old meshes retain the existing flat default.
        boolean authoredNormals = false;
        if (meshObj.has("tml_normal_mode")) {
            var mode = meshObj.get("tml_normal_mode");
            if (!mode.isJsonPrimitive() || !mode.getAsJsonPrimitive().isString())
                throw new IllegalArgumentException("tml_normal_mode must be flat or authored");
            String value = mode.getAsString();
            if (!value.equals("flat") && !value.equals("authored"))
                throw new IllegalArgumentException("Unknown tml_normal_mode: " + value);
            authoredNormals = value.equals("authored");
        }
        boolean[] validNormals = authoredNormals ? new boolean[normals.length] : null;
        if (authoredNormals) {
            // Model-load-only normalization, once per unique normal, never per frame.
            for (int ni = 0; ni < normals.length; ni++) {
                float[] n = normals[ni];
                double length = Math.sqrt((double)n[0]*n[0] + (double)n[1]*n[1] + (double)n[2]*n[2]);
                if (Double.isFinite(length) && length > 1e-12) {
                    validNormals[ni] = true;
                    n[0] /= length; n[1] /= length; n[2] /= length;
                }
            }
        }'''
assert src.count(old)==1;out=src.replace(old,new)
# Geometric fallback must exist even when an authored normal is invalid.
out=out.replace('            if (FORCE_FLAT_SHADING) {','            {',1)
old2='                if (FORCE_FLAT_SHADING) {';assert out.count(old2)==1
out=out.replace(old2,'                if (!authoredNormals || vi[1] < 0 || vi[1] >= normals.length || !validNormals[vi[1]]) {')
(R/'candidate'/p).write_text(out);(R/'authored-normal-opt-in.patch').write_text(''.join(difflib.unified_diff(src.splitlines(True),out.splitlines(True),fromfile='a/src/main/java/'+str(p),tofile='b/src/main/java/'+str(p))))
print('Prepared default-preserving source candidate; upstream SHA256',hashlib.sha256(src.encode()).hexdigest())
