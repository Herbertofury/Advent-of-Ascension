from pathlib import Path
import subprocess,os,json,tempfile,argparse,hashlib
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--jdk17',type=Path,default=R.parent/'toolchains/amazon-corretto-17.0.20.12.1-linux-x64/bin');p.add_argument('--java21',type=Path,default=Path('/usr/bin/java'));p.add_argument('--lib',type=Path,default=R.parent/'released-tacz-parser-study/lib');p.add_argument('--geometry',type=Path,default=R.parent/'soul-storm-metal-transport-v33/soul_storm_metal.geo.json');a=p.parse_args();J=a.jdk17;lib=a.lib;geo=a.geometry;results=[]
pins=json.loads((R/'library-hashes.json').read_text());libfiles=[lib.resolve()/e['file']for e in pins]
for e,f in zip(pins,libfiles):assert hashlib.sha256(f.read_bytes()).hexdigest()==e['sha256'],'Unexpected dependency '+str(f)
libcp=os.pathsep.join(map(str,libfiles))
with tempfile.TemporaryDirectory()as td:
 for mode in ['baseline','candidate']:
  classes=Path(td)/mode;classes.mkdir();src=list((R/mode).rglob('*.java'))+list((R/'standins').rglob('*.java'))+[R/'CandidateCheck.java',R/'AuthoredFixtureCheck.java'];subprocess.run([str(J/'javac'),'--release','17','-cp',libcp,'-d',str(classes),*map(str,src)],check=True)
  for runtime,java in [('17',J/'java'),('21',a.java21)]:
   run=subprocess.run([str(java),'-Xverify:all','-cp',str(classes)+os.pathsep+libcp,'CandidateCheck',str(geo),str(mode=='candidate').lower()],capture_output=True,text=True,check=True);text=run.stdout
   if mode=='candidate':text+=subprocess.run([str(java),'-Xverify:all','-cp',str(classes)+os.pathsep+libcp,'AuthoredFixtureCheck',str(geo)],capture_output=True,text=True,check=True).stdout
   results.append({'mode':mode,'runtime':runtime,'stdout':text});print(mode,runtime,text)
assert len({next(l for l in r['stdout'].splitlines()if l.startswith('DEFAULT_ARRAY_DIGEST'))for r in results})==1
(R/'checks.json').write_text(json.dumps({'scope':'Actual upstream source versus local opt-in patch compiled with explicit fail-closed rendering stand-ins; no native Minecraft execution','default_arrays_bit_identical':True,'results':results,'native_tested':False},indent=2))
