# Authored-normal opt-in: local source candidate

This is a proposed patch and offline test bundle for VellEagle/TacZMeshLoader commit a3faaaf45ed956351278a5b6f86b4140f48439ea. It is not an installed mod, released loader feature or native-tested fix. No upstream PR was sent. Upstream attribution and GPL-3.0 terms apply to the patch; LICENSE.txt is included. Original upstream source and dependency jars are not bundled.

## Proposed contract

A mesh may explicitly request `"tml_normal_mode":"authored"`. Missing mode or `"flat"` retains the current flat behavior. Other modes/types fail clearly. Merely adding this field to stock TML0.1.8 does not activate the proposal; that release ignores it.

The candidate normalizes each unique finite, nonzero normal once when loading the model. Missing, zero, nonfinite and out-of-range normals fall back to the existing geometric face normal. Normal calculations are not added to rendering/frame loops. Existing draw methods and their sign convention are unchanged; the separate fallback/VBO parity question remains open.

## Bounded evidence

Both unmodified official source and the local candidate were compiled with Java17 target and run under Java17/21, using explicit fail-closed graphics stand-ins. All 879,104 baked float values for the default Soul Storm metal fixture have the same SHA256 digest in all four runs. Opt-in authored normals match all 109,888 expanded corners within 2.981e-8 component error. Invalid mode, missing/zero/nonfinite/out-of-range normals, huge finite vectors and GPU-cache-empty cases are covered.

These are source-build/data tests. They do not prove a native loader build, runtime linkage, shader correctness, hand fit, visual parity, mod compatibility or performance. Default-array equality is not a claim of zero startup/frame-time regression.

## Reproduce

1. Obtain PolyMesh.java from the exact upstream commit, path src/main/java/com/example/taczmeshloader/core/PolyMesh.java. The prepare script checks its SHA256.
2. Run `python prepare.py --upstream-source /path/PolyMesh.java` and `python make_standins.py`.
3. Obtain the five official dependency jars listed in library-hashes.json; the runner verifies every SHA256 and uses only those paths.
4. Run `python run_checks.py --jdk17 /path/jdk17/bin --java21 /path/java21 --lib /path/jars --geometry ../fixtures/soul_storm_metal.geo.json`.

The geometry is a metal-only test fixture. It omits the grip, flame, effects, hands and gameplay bindings, and is not a functional gunpack. Its 136 parts belong to five neutral-pose groups. See the adjacent released-bytecode diagnostics for the stock behavior.

## Before adoption

Build the real mod against the pinned loader, verify old packs, validate source/flat normal choices through actual VBO and fallback rendering, exercise shader toggles and resource reload, test mirrors/nonuniform transforms and animated owners, and measure equivalent-work load time/memory/frame times. Preserve a safe original-renderer path. Do not flip all normals globally or patch installed binaries based only on this study.
