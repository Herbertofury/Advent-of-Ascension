import com.google.gson.*;
import com.example.taczmeshloader.core.PolyMesh;
import java.nio.file.*;
import java.util.*;
public class TransportCheck {
 public static void main(String[] args) throws Exception {
  JsonObject g=JsonParser.parseString(Files.readString(Path.of(args[0]))).getAsJsonObject().getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject();
  int total=0,bones=0,shortNormals=0; float minNormal=Float.POSITIVE_INFINITY;
  for(JsonElement e:g.getAsJsonArray("bones")) {
   JsonObject b=e.getAsJsonObject();if(!b.has("poly_mesh"))continue;
   JsonObject m=b.getAsJsonObject("poly_mesh");float[] pivot={0,0,0};
   if(b.has("pivot"))for(int j=0;j<3;j++)pivot[j]=b.getAsJsonArray("pivot").get(j).getAsFloat();
   PolyMesh p=new PolyMesh(m,2048,2048,pivot);int n=(int)BakerCheck.field(p,"vertexCount");
   BakerCheck.req(n==m.getAsJsonArray("polys").size()*4,"expanded count");
   String[] fields={"bakedX","bakedY","bakedZ","bakedU","bakedV","bakedNX","bakedNY","bakedNZ"};
   for(String f:fields){float[] a=(float[])BakerCheck.field(p,f);BakerCheck.req(a.length==n,"array size");for(float v:a){BakerCheck.req(Float.isFinite(v),"nonfinite "+f);if(f.equals("bakedU")||f.equals("bakedV"))BakerCheck.req(v>=0&&v<=1,"UV bounds");}}
   float[] nx=(float[])BakerCheck.field(p,"bakedNX"),ny=(float[])BakerCheck.field(p,"bakedNY"),nz=(float[])BakerCheck.field(p,"bakedNZ");
   for(int i=0;i<n;i+=4){float len=(float)Math.sqrt(nx[i]*nx[i]+ny[i]*ny[i]+nz[i]*nz[i]);minNormal=Math.min(minNormal,len);if(len<.99f)shortNormals++;}
   BakerCheck.req(((Map<?,?>)BakerCheck.field(p,"vboCache")).isEmpty(),"GPU cache touched");total+=n;bones++;
  }
  System.out.println("Normal diagnostic: minimum length="+minNormal+", faces below 0.99="+shortNormals);
  BakerCheck.req(bones==Integer.parseInt(args[1])&&total==Integer.parseInt(args[2]),"unexpected transport count");
  System.out.println("PASS actual released TML baker: "+bones+" Soul Storm mesh bones, "+total+" baked vertices, finite geometry/normals, bounded UVs, empty GPU caches. Static geometry only; no rendering or game acceptance.");
 }
}
