import com.google.gson.*;import com.example.taczmeshloader.core.PolyMesh;import java.nio.file.*;import java.util.*;
/** Quantify normal-direction loss on triangle-only export; no native rendering claim. */
public class NormalLossCheck{
 public static void main(String[] args)throws Exception{
  JsonObject root=JsonParser.parseString(Files.readString(Path.of(args[0]))).getAsJsonObject();JsonObject geo=root.getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject();List<Double> errors=new ArrayList<>();int over5=0,over20=0;double max=0,flatControlMax=0;
  for(JsonElement be:geo.getAsJsonArray("bones")){
   JsonObject bone=be.getAsJsonObject();if(!bone.has("poly_mesh"))continue;JsonObject m=bone.getAsJsonObject("poly_mesh");PolyMesh baked=new PolyMesh(m,2048,2048,new float[]{0,0,0});float[] nx=(float[])BakerCheck.field(baked,"bakedNX"),ny=(float[])BakerCheck.field(baked,"bakedNY"),nz=(float[])BakerCheck.field(baked,"bakedNZ");int offset=0;
   for(JsonElement pe:m.getAsJsonArray("polys")){
    JsonArray poly=pe.getAsJsonArray();BakerCheck.req(poly.size()==3,"triangle-only diagnostic");
    double[][] pv=new double[3][3];for(int k=0;k<3;k++){JsonArray vv=m.getAsJsonArray("positions").get(poly.get(k).getAsJsonArray().get(0).getAsInt()).getAsJsonArray();for(int j=0;j<3;j++)pv[k][j]=vv.get(j).getAsDouble();}
    double ax=pv[1][0]-pv[0][0],ay=pv[1][1]-pv[0][1],az=pv[1][2]-pv[0][2],bx=pv[2][0]-pv[0][0],by=pv[2][1]-pv[0][1],bz=pv[2][2]-pv[0][2];double fx=ay*bz-az*by,fy=-(az*bx-ax*bz),fz=ax*by-ay*bx;double fl=Math.sqrt(fx*fx+fy*fy+fz*fz);double bn=Math.sqrt(nx[offset]*nx[offset]+ny[offset]*ny[offset]+nz[offset]*nz[offset]);double fd=(fx*nx[offset]+fy*ny[offset]+fz*nz[offset])/(fl*bn);double fa=Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,fd))));flatControlMax=Math.max(flatControlMax,fa);
    for(int i=0;i<3;i++){
     int ni=poly.get(i).getAsJsonArray().get(1).getAsInt();JsonArray n=m.getAsJsonArray("normals").get(ni).getAsJsonArray();double x=n.get(0).getAsDouble(),y=-n.get(1).getAsDouble(),z=n.get(2).getAsDouble();double len=Math.sqrt(x*x+y*y+z*z);double bl=Math.sqrt(nx[offset+i]*nx[offset+i]+ny[offset+i]*ny[offset+i]+nz[offset+i]*nz[offset+i]);double dot=(x*nx[offset+i]+y*ny[offset+i]+z*nz[offset+i])/(len*bl);double angle=Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,dot))));errors.add(angle);max=Math.max(max,angle);if(angle>5)over5++;if(angle>20)over20++;
    }offset+=4;
   }BakerCheck.req(offset==nx.length,"baked corner expansion");
  }
  BakerCheck.req(flatControlMax<.1,"Flat orientation control failed: "+flatControlMax);Collections.sort(errors);System.out.println("NORMAL_LOSS "+new Gson().toJson(Map.of("corners",errors.size(),"flat_control_max_degrees",flatControlMax,"max_degrees",max,"median_degrees",errors.get(errors.size()/2),"p95_degrees",errors.get((int)(errors.size()*.95)),"over_5_degrees",over5,"over_20_degrees",over20,"scope","Authored normals compared to actual baked arrays using input Y-normal inversion; no GPU/native visual acceptance")));
 }
}
