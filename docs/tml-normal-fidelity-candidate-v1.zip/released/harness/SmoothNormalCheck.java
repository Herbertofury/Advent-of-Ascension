import com.google.gson.*;
import com.example.taczmeshloader.core.PolyMesh;
import java.util.*;
/** Negative-control test: parsing normals is not proof the released baker preserves them. */
public class SmoothNormalCheck {
 public static void main(String[] args)throws Exception{
  JsonObject flat=BakerCheck.mesh("[[[0,0,0],[1,0,1],[2,0,2]]]",true);
  JsonObject smooth=flat.deepCopy();
  smooth.add("normals",JsonParser.parseString("[[0.6,0,0.8],[0,0.6,0.8],[-0.6,0,0.8]]"));
  smooth.add("polys",JsonParser.parseString("[[[0,0,0],[1,1,1],[2,2,2]]]"));
  PolyMesh a=new PolyMesh(flat,16,16,new float[]{0,0,0});
  PolyMesh b=new PolyMesh(smooth,16,16,new float[]{0,0,0});
  int compared=0;
  for(String name:new String[]{"bakedNX","bakedNY","bakedNZ"}){
   float[] x=(float[])BakerCheck.field(a,name),y=(float[])BakerCheck.field(b,name);
   BakerCheck.req(Arrays.equals(x,y),"Released normal behavior changed: review expected limitation");compared+=x.length;
  }
  float[] x=(float[])BakerCheck.field(b,"bakedNX");
  BakerCheck.req(Math.abs(x[0]-.6f)>.1f,"Negative control failed: source X normal unexpectedly preserved");
  System.out.println("PASS negative-control evidence: distinct authored corner normals produce identical released baked normals ("+compared+" components). Authored smooth-normal preservation is NOT established; native lighting remains open.");
 }
}
