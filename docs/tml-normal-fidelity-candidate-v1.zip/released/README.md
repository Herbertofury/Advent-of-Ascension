# Released mesh normal-fidelity regression

This is an offline regression harness, not a patched loader or gunpack. It executes pinned, unmodified PolyMesh bytecode from official Forge 1.20.1 TaCZ Mesh Loader 0.1.8, with explicit graphics/logging stand-ins. No GPU draw or Minecraft entrypoint runs.

Source inspected: VellEagle/TacZMeshLoader commit a3faaaf45ed956351278a5b6f86b4140f48439ea, src/main/java/com/example/taczmeshloader/core/PolyMesh.java. The official 1.20.1 branch and Modrinth versions page were rechecked on 2026-10-19. FORCE_FLAT_SHADING is a private static final true constant in this source. An authored normals array alone cannot turn it off.

## Results

- A negative control changes three authored corner normals while keeping positions/UVs fixed. The actual released baker returns identical normal arrays in both cases.
- On the Soul Storm metal-only fixture, 82,416 original triangle corners were compared with the released baked arrays using the source's explicit Y-normal inversion.
- A geometric face-normal control agrees within 0.019717 degrees, checking the diagnostic's coordinate convention.
- Authored-versus-baked median difference: 14.954608 degrees; p95: 22.255623; maximum: 82.226989. 48,716 corners differ by more than 5 degrees and 8,758 by more than 20.
- The same diagnostics pass on Java 17 and 21. This establishes a data-fidelity limit, not the exact visible result under game lighting.
- Existing fallback/VBO sign-path evidence remains a separate native lighting question. Do not label an installed pack broken based only on the offline test.

## Reproduce

Python 3, JDK17 and optionally Java21. Obtain the exact official TML0.1.8 jar and Gson2.10, JOML1.10.5 and fastutil8.5.9 from their official sources. Artifacts and released class hashes are verified by the runner. Upstream code, classes and dependency jars are not redistributed here.

python run_check.py --jar /path/tacz-mesh-loader-forge-1.20.1-0.1.8.jar --lib /path/dependency-jars --jdk /path/jdk17/bin --geometry /path/soul_storm_metal.geo.json --expected-bones 5 --expected-vertices 109888

Add --java /path/java21 to run the same Java17-targeted classes on Java21. The geometry argument is a triangle-only research fixture, not a complete weapon model.

## Candidate implementation requirements

An optional authored-normal path should preserve the existing flat default for old packs, validate and normalize finite nonzero per-corner normals, define behavior for missing/invalid indices, and use the existing documented axis convention. Invalid imported data needs a deliberate safe fallback or clear rejection. Do not simply flip all normals or add a JSON field that the released loader silently ignores.

Acceptance must include both VBO and fallback draws, winding/culling, mirrors/nonuniform scales, animated owners, hands, shader packs, resource reloads, old packs and measured load/frame-time cost. Compute and cache at model load; do not repair normals per frame. Any source modification must retain upstream attribution and satisfy its GPL license. No third-party issue or pull request has been sent.
