public final class ParticleEmissionClockTest {
    private static int checks;
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    private static void rejects(Runnable fn) {
        boolean rejected = false;
        try { fn.run(); } catch (IllegalArgumentException expected) { rejected = true; }
        check(rejected, "Expected invalid input rejection");
    }
    public static void main(String[] args) {
        // 480/s is only an illustrative 8 requests * 60 render calls reference, not a final visual budget.
        for (int hz : new int[]{10, 20, 30, 60, 90, 144, 240}) {
            ParticleEmissionClock clock = new ParticleEmissionClock(480, 0.25, 64);
            int total = 0;
            for (int i = 0; i < hz * 10; i++) {
                int count = clock.advance(1.0 / hz, true);
                check(count >= 0 && count <= 64, "Burst bounded");
                total += count;
            }
            check(Math.abs(total - 4800) <= 1, "Steady-rate drift at " + hz + " Hz: " + total);
        }
        ParticleEmissionClock clock = new ParticleEmissionClock(480, 0.25, 64);
        check(clock.advance(0, true) == 0, "No elapsed time, no emission");
        check(clock.advance(120, false) == 0, "Inactive does not accumulate");
        check(clock.advance(0, true) == 0, "No visibility catch-up");
        check(clock.advance(10, true) == 64, "Hitch bounded by explicit policy");
        check(clock.advance(0, true) == 0, "No unbounded deferred debt");
        clock.advance(0.001, true);
        clock.reset();
        check(clock.advance(0.001, true) == 0, "Reset clears fractional debt");
        ParticleEmissionClock zero = new ParticleEmissionClock(0, .25, 64);
        check(zero.advance(1, true) == 0, "Zero-rate disabled");
        rejects(() -> clock.advance(Double.NaN, true));
        rejects(() -> clock.advance(Double.POSITIVE_INFINITY, true));
        rejects(() -> clock.advance(-1, true));
        rejects(() -> new ParticleEmissionClock(-1, .25, 64));
        rejects(() -> new ParticleEmissionClock(480, 0, 64));
        rejects(() -> new ParticleEmissionClock(480, .25, 0));
        rejects(() -> new ParticleEmissionClock(Double.MAX_VALUE, .25, 64));
        System.out.println("PASS " + checks + " headless scheduling checks; no Minecraft, GPU, visuals or FPS acceptance");
    }
}
