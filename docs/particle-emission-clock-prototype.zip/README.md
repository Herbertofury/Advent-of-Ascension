# Render-independent particle scheduling prototype

Original headless Java source. This is not an installed Minecraft component and not a measured FPS improvement.

Compile with Java 17 or newer:

    javac --release 17 ParticleEmissionClock.java ParticleEmissionClockTest.java
    java ParticleEmissionClockTest

Tests pass on the checked Java 17 and Java 21 runtimes. They exercise steady scheduling at 10, 20, 30, 60, 90, 144 and 240 calls/second; pause/inactive/reset behavior; bounded hitch catch-up; zero rates; and invalid input rejection. The test count includes per-call bounds assertions, not thousands of independent native test scenarios.

## Integration contract

- Supply elapsed GAME time, not one fixed allowance per render callback. Avoid feeding both render and tick callbacks into the same clock for the same interval.
- Keep separate clock state per emitting entity/effect. Reset time origin/state on world or entity lifecycle changes.
- The caller owns pause and visibility policy. Inactive resets fractional state and creates no deferred burst. Do not secretly change offscreen simulation or gameplay events.
- The returned integer is a request budget; the particle engine still decides what is rendered.
- `480/s` in tests is only an illustrative eight requests times sixty render calls reference. It is not a selected production setting or proof of visual equivalence.
- The maximum burst and catch-up window deliberately discard excess hitch debt. That is a quality/performance policy tradeoff which must be exposed, tuned and visually tested. It is not lossless under arbitrary long stalls.
- Keep projectile damage, healing, impact authority and sounds separate from this visual scheduler.

## Still required

Integrate in a real client update path, audit world reload and entity removal, test multiple passes/cameras, compare source trail appearance, profile many projectiles, and test graphics/particle settings plus accessibility modes. Do not enable a source-behavior change without documenting it.
