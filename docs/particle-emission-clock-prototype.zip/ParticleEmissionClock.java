/** Original headless prototype. Caller supplies elapsed GAME time, not render count. */
public final class ParticleEmissionClock {
    private final double particlesPerSecond;
    private final double maxCatchUpSeconds;
    private final int maxBurst;
    private double fraction;

    public ParticleEmissionClock(double particlesPerSecond, double maxCatchUpSeconds, int maxBurst) {
        if (!Double.isFinite(particlesPerSecond) || particlesPerSecond < 0 || particlesPerSecond > 1_000_000
                || !Double.isFinite(maxCatchUpSeconds) || maxCatchUpSeconds <= 0 || maxCatchUpSeconds > 1
                || maxBurst <= 0 || maxBurst > 1_000_000) {
            throw new IllegalArgumentException("Invalid emission budget");
        }
        this.particlesPerSecond = particlesPerSecond;
        this.maxCatchUpSeconds = maxCatchUpSeconds;
        this.maxBurst = maxBurst;
    }

    /** Returns requests, not guaranteed rendered particles. Excess hitch debt is discarded deliberately. */
    public int advance(double elapsedGameSeconds, boolean active) {
        if (!Double.isFinite(elapsedGameSeconds) || elapsedGameSeconds < 0) {
            throw new IllegalArgumentException("Elapsed game time must be finite and nonnegative");
        }
        if (!active) {
            reset();
            return 0;
        }
        double due = fraction + Math.min(elapsedGameSeconds, maxCatchUpSeconds) * particlesPerSecond;
        double whole = Math.floor(due);
        fraction = due - whole;
        return (int)Math.min(whole, maxBurst);
    }

    /** Call on world/entity lifecycle changes and visibility-policy transitions. */
    public void reset() {
        fraction = 0;
    }
}
