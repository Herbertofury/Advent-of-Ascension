import bpy
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'shyre-prop-study-v8.blend'));s=bpy.context.scene;s.render.resolution_x=640;s.render.resolution_y=452;s.render.resolution_percentage=100;s.render.fps=24;s.cycles.samples=16;s.cycles.seed=0;s.cycles.use_denoising=False;s.render.image_settings.file_format='PNG';(R/'inspect-v8-frames').mkdir(exist_ok=True)
for frame in range(1,71):
 s.frame_set(frame);s.render.filepath=str(R/'inspect-v8-frames'/f'{frame:04d}.png');bpy.ops.render.render(write_still=True)
