"""Bound one cosmetic gem's swept volume against this static authored prop."""
import bpy,json,math,numpy as np
from pathlib import Path
from mathutils import Vector
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from precise_surface import nearest_triangle_distance
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'shyre-prop-study-v8.blend'));s=bpy.context.scene;s.frame_set(20);bpy.context.view_layer.update();gem=bpy.data.objects['Inspection floating gem'];assert gem.parent is None and not gem.constraints and not gem.modifiers
curves=list(gem.animation_data.action.fcurves);assert all(c.data_path in ('scale','rotation_euler')for c in curves);assert all(not c.modifiers for c in curves)
max_scale=0
for c in curves:
 if c.data_path!='scale':continue
  # Every segment is bounded by its Bezier control polygon.
 for k in c.keyframe_points:
  assert k.interpolation=='BEZIER';assert k.co.x in (1,20,45,70)
  vals=[k.co.y,k.handle_left.y,k.handle_right.y];assert min(vals)>=-1e-8;max_scale=max(max_scale,*vals)
dg=bpy.context.evaluated_depsgraph_get();actors=[gem,*gem.children_recursive];inverse=gem.matrix_world.inverted();radii=[]
for actor in actors:
 assert not actor.constraints and not actor.modifiers
 if actor!=gem:assert actor.animation_data is None
 assert actor.data.animation_data is None
 if actor.type=='MESH':assert actor.data.shape_keys is None
 e=actor.evaluated_get(dg);m=e.to_mesh()
 radii.extend((inverse@(actor.matrix_world@v.co)).length for v in m.vertices);e.to_mesh_clear()
radius=max(radii)*max_scale;center=np.array(gem.location);assert np.isfinite(radius)
mesh_data=[];line_data=[]
for o in bpy.data.objects:
 if o in actors or o.type not in ('MESH','CURVE') or o.hide_render:continue
 assert o.animation_data is None and not o.constraints,(o.name,'not static')
 if o.type=='MESH':
  e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();tri=np.array([[tuple(o.matrix_world@m.vertices[i].co)for i in t.vertices]for t in m.loop_triangles],dtype=np.float64);mesh_data.append((o.name,tri));e.to_mesh_clear()
 else:
  stretch=float(np.linalg.svd(np.array(o.matrix_world.to_3x3()),compute_uv=False).max())
  for curve in o.data.splines:
   assert curve.type=='POLY';pts=np.array([tuple(o.matrix_world@p.co.xyz)for p in curve.points]);r=o.data.bevel_depth*max(p.radius for p in curve.points)*stretch
   segments=list(zip(pts[:-1],pts[1:]));
   if curve.use_cyclic_u:segments.append((pts[-1],pts[0]))
   line_data.append((o.name,segments,r))
def measure(point,rad):
 rows=[]
 for name,t in mesh_data:
  dist,_=nearest_triangle_distance(point,t);a,b,c=t[:,0]-point,t[:,1]-point,t[:,2]-point;la,lb,lc=[np.linalg.norm(x,axis=1)for x in (a,b,c)];num=np.einsum('ij,ij->i',a,np.cross(b,c));den=la*lb*lc+np.einsum('ij,ij->i',a,b)*lc+np.einsum('ij,ij->i',b,c)*la+np.einsum('ij,ij->i',c,a)*lb;solid=float(np.sum(2*np.arctan2(num,den)));inside=abs(solid)>2*math.pi;rows.append({'name':name,'clearance_bound':(-dist if inside else dist)-rad,'center_inside':inside})
 for name,segments,r in line_data:
  ds=[]
  for a,b in segments:
   d=b-a;l=float(np.dot(d,d));u=np.clip(np.dot(point-a,d)/l,0,1)if l else 0;ds.append(float(np.linalg.norm(point-(a+u*d))))
  rows.append({'name':name,'clearance_bound':min(ds)-r-rad,'capsule_bound':True})
 return rows
rows=measure(center,radius);bad_fixture=measure(np.array((.25,.74,.55)),radius);assert min(x['clearance_bound']for x in bad_fixture)<0,'bad fixture did not fail';passed=all(x['clearance_bound']>0 for x in rows)
result={'scope':'Conservative sphere envelope over frames1–70 for the crystal and two root-owned orbit curves; static authored mesh surfaces and polyline capsules only','actor_count':len(actors),'radius_bound':radius,'scale_control_bound':max_scale,'center':list(center),'minimum_clearance_bound':min(x['clearance_bound']for x in rows),'nearest_objects':sorted(rows,key=lambda x:x['clearance_bound'])[:5],'bad_fixture_rejected':True,'passed':passed,'native_accepted':False,'hands_attachment_variants_and_game_transforms_not_tested':True};(R/'inspect-group-envelope-qa.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if not passed:raise SystemExit(1)
