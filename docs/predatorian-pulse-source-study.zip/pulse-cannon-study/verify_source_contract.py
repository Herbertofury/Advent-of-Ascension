"""Read-only source contracts, never native gameplay acceptance."""
from pathlib import Path
import argparse,hashlib,zipfile,subprocess,json,re
p=argparse.ArgumentParser();p.add_argument('jar',type=Path);p.add_argument('--javap',required=True);a=p.parse_args();assert hashlib.sha256(a.jar.read_bytes()).hexdigest()=='f417ecb337d4a3b2aebec559a9262d8a86cc93ee7910f4eea64108bff063193a'
def read(c):return subprocess.check_output([a.javap,'-classpath',str(a.jar),'-p','-c',c],text=True)
prefix='net.tslat.aoa3.content.item.weapon.cannon.';reg=read('net.tslat.aoa3.common.registration.item.AoAWeapons');base=read(prefix+'BaseCannon');checks=[]
for cls,damage,durability,delay,recoil in [('PredatorianBlaster',23.5,845,28,.175),('PulseCannon',26,510,42,.15)]:
 c=prefix+cls;part=next(t for t in reg.split('private static')if '// class '+c.replace('.','/')in t)
 for marker in [rf'float {float(damage)}f',rf'sipush\s+{durability}',rf'bipush\s+{delay}',rf'float {recoil}f']:assert re.search(marker,part),(cls,marker)
 checks.append(cls+' constructor inputs')
s=read(prefix+'PredatorianBlaster');assert 'HeavyBoneCannonballEntity'in s and 'WITHERS_TARGETS'in s;assert re.search(r'bipush\s+100',s)and re.search(r'iconst_2\s+\d+: invokevirtual.*EffectBuilder.level',s);checks.append('Predatorian projectile and effect inputs')
s=read(prefix+'PulseCannon');assert 'createProjectileEntity'not in s;assert 'CannonballEntity'in base and 'AoAItems.CANNONBALL'in base;checks.append('Pulse inherited cannonball path')
assert s.index('BaseCannon.doFiringEffects')<s.index('double 2.5d')<s.index('HOSTILE_MOB')<s.index('float 0.75f')<s.index('pushEntityAway');checks.append('Pulse firing hook and shooter query markers')
with zipfile.ZipFile(a.jar)as z:
 recipe=json.loads(z.read('data/aoa3/recipes/upgrade_kit_predatorian_blaster.json'));assert recipe['input']['item']=='aoa3:ghast_blaster'and recipe['upgrade_kit']['item']=='aoa3:predator_upgrade_kit';checks.append('Predatorian lineage')
 recipe=json.loads(z.read('data/aoa3/recipes/infusion_pulse_cannon.json'));assert recipe['type']=='aoa3:infusion'and len(recipe['ingredients'])==6 and sum(x.get('tag')=='forge:ingots/iron'for x in recipe['ingredients'])==2;checks.append('Pulse infusion structure')
print(json.dumps({'status':'PASS','checks':checks,'scope':'Pinned bytecode markers and recipe structure; no native behavior, visual or performance acceptance','native_accepted':False},indent=2))
