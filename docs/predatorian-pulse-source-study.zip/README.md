# Predatorian and Pulse source studies

Run verify_source_contract.py with your own pinned AoA3-1.20.1-3.7.1-all.jar and javap path. The script checks its SHA256 before inspecting narrow bytecode markers and recipes. No native engine tests are implied. Concepts were created using the built-in image tool from actual extracted original sprites. Source game binaries and class dumps are not redistributed in this archive.
