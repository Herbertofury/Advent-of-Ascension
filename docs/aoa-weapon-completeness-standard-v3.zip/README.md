# Complete AoA weapon checklist and evidence validator

Read GUIDELINE.md, then feature-catalog.json. Copy weapon-manifest-template.json for an actual registry ID and reconcile existing work feature by feature. Every feature gets separate concept/design, implementation and QA status. Visual rows need art/storyboards; nonvisual systems need a concrete design specification. Never infer implementation from art or native acceptance from a parser result.

python validate_manifest.py my-weapon.json --root /path/to/evidence
python validate_manifest.py my-weapon.json --root /path/to/evidence --release
python test_validator.py

Normal validation reports structural defects and incomplete work. Strict release mode also fails on incomplete work or an undeclared release. Evidence files must remain beneath the supplied root and match SHA-256. The tests deliberately reject a missing feature, unapproved omission, false completion flag, unsupported passed claim, absent visual comparison, escaped path, wrong hash and incomplete native evidence.

The validator checks structure, declarations and hashes only. It cannot determine whether a picture matches a concept, whether a capture is genuinely in-game, whether a reviewer is correct, or whether a weapon is fun. Human/owner feedback and actual runtime review remain independent gates.

coverage.json assigns the complete contract to all 228 first-target registry IDs. Its new per-feature review status does not erase prior work or claim that previously completed research was absent. Legacy-only/version-exclusive weapons require additional entries. The coverage register claims zero newly accepted weapons.

SKILL.md and companion files are provided as a reusable project skill package. This publication does not claim that any existing installed personal skill was replaced.

## v2: both owner-approved visual treatments are mandatory

The 31 feature groups remain. Each weapon additionally needs concept/implementation/QA evidence and an actual visual review for minecraft_fit and concept_faithful. Profile QA cannot pass without a native test log and capture tagged for that exact profile. Missing profiles keep legacy manifests incomplete; they never silently pass. A profile toggle is not implemented by this bookkeeping tool.

The new template has 109 incomplete phase/review obligations. Fifteen synthetic regression cases test structural/evidence rules, including wrong-profile evidence. Synthetic fixtures are not acceptance of any weapon. Regeneration preserves existing coverage entries instead of dropping updated links/statuses.

## v3: lore and provenance review

An additional lore_provenance gate requires source evidence, review notes and classified claims. Confirmed facts need source references; interpretations, new proposals and unknowns are kept separate. Unknown creator intent is a valid finding, never a reason to invent lore. The template has 110 incomplete obligations; nineteen synthetic regressions pass. This validator checks records/evidence, not factual truth by itself.
