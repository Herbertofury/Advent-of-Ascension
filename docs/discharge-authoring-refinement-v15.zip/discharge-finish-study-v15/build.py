import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'discharge-energy-study-v14/discharge-energy-study.blend'))
for o in bpy.data.objects:
 if o.name.startswith('Owned white muzzle housing'):
  o.data.materials.append(bpy.data.materials['Discharge bright edges']);edge_index=len(o.data.materials)-1
  for face in o.data.polygons:face.material_index=1
  for mod in o.modifiers:
   if mod.type=='BEVEL':mod.material=edge_index;mod.width=.008
m=bpy.data.materials['Discharge patterned core']
for node in m.node_tree.nodes:
 if node.type=='VALTORGB':node.color_ramp.elements[0].color=(.85,.001,.007,1);node.color_ramp.elements[1].color=(.065,.0001,.001,1)
m.node_tree.nodes.get('Principled BSDF').inputs['Emission Strength'].default_value=2.8
s=bpy.context.scene;s.cycles.samples=64;s.render.filepath=str(R/'hero.png');bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-finish-study.blend'));bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'unaccepted authoring finish study','changes':['Dark muzzle faces with narrow metallic bevel edges instead of broad white rings','Red chamber energy replaces orange-looking v14 veins'],'native_tested':False,'original_projectile_count':4,'visual_channels':3},indent=2)+'\n')
