import bpy,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'discharge-finish-study.blend'));dg=bpy.context.evaluated_depsgraph_get();rows=[]
for z in [.2,.68,1.16]:
 for side in [-1,1]:
  for xoff in [-.07,0,.07]:
   for zoff in [-.015,0,.015]:
    hit,loc,normal,index,obj,matrix=bpy.context.scene.ray_cast(dg,Vector((3.30+xoff,side*2,z+zoff)),Vector((0,-side,0)),distance=4)
    rows.append({'z':z,'side':side,'xoff':xoff,'zoff':zoff,'first_hit':obj.name if hit else None,'y':loc.y if hit else None,'blocked':bool(hit and loc.y*side>.37)})
bad=[r for r in rows if r['blocked']];(R/'side-vent-check.json').write_text(json.dumps({'samples':len(rows),'blocked_count':len(bad),'scope':'Sparse normal-ray samples through six exterior vent interiors; not a continuous or animated clearance proof','rows':rows},indent=2)+'\n');print(len(rows),'samples',len(bad),'blocked');print(bad[:3]);assert not bad
