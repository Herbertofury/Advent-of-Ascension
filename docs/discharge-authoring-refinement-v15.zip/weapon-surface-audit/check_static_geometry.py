import bpy,bmesh,json,sys,argparse,hashlib,math
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);bpy.ops.wm.open_mainfile(filepath=str(a.source.resolve()));dg=bpy.context.evaluated_depsgraph_get();rows=[];bad=[]
for o in bpy.data.objects:
 if o.type not in {'MESH','CURVE'}or o.hide_render or o.get('aoa_reference_only'):continue
 e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();pts=[o.matrix_world@v.co for v in m.vertices];nonfinite=sum(not all(math.isfinite(x)for x in p)for p in pts);small=0
 for t in m.loop_triangles:
  x,y,z=(pts[i]for i in t.vertices)
  if (y-x).cross(z-x).length*.5<=1e-12:small+=1
 bm=bmesh.new();bm.from_mesh(m);bm.transform(o.matrix_world);closed=bool(bm.edges)and all(edge.is_manifold for edge in bm.edges);volume=bm.calc_volume(signed=True)if closed else None;bm.free();rows.append({'object':o.name,'triangles':len(m.loop_triangles),'near_zero_area_triangles':small,'nonfinite_vertices':nonfinite,'closed_manifold':closed,'signed_world_volume':volume});e.to_mesh_clear()
 if small or nonfinite or(closed and volume<-1e-9):bad.append(o.name)
r={'source_sha256':hashlib.sha256(a.source.read_bytes()).hexdigest(),'triangles':sum(x['triangles']for x in rows),'problem_objects':bad,'objects':rows,'scope':'Neutral-pose evaluated geometry only. Open surfaces, overlaps, hands, animations, UVs, native export and art fidelity need independent review.'};a.out.write_text(json.dumps(r,indent=2)+'\n');print({'triangles':r['triangles'],'problem_objects':bad});assert not bad
