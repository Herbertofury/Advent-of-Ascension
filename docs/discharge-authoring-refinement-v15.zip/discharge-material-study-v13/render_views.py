import bpy
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'discharge-material-study.blend'));s=bpy.context.scene;cam=s.camera;s.cycles.samples=24;s.render.resolution_x=1100;s.render.resolution_y=750;target=Vector((-.2,0,.4))
bpy.ops.object.light_add(type='AREA',location=(0,0,0));light=bpy.context.object;light.data.energy=900;light.data.size=8
for name,loc in [('left',(0,18,1)),('right',(0,-18,1)),('front',(18,0,1)),('rear',(-18,0,1)),('top',(0,0,18)),('bottom',(0,0,-18))]:
 cam.location=loc;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=13.5 if name in ['top','bottom'] else (5.5 if name in ['front','rear'] else 11.5);light.location=loc;light.rotation_euler=cam.rotation_euler;s.render.filepath=str(R/(name+'.png'));bpy.ops.render.render(write_still=True)
