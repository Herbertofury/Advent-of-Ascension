"""Original editable procedural enamel study. Native baked materials remain open."""
import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'discharge-authored-muzzles-v12/discharge-muzzle-study.blend'))
root=bpy.data.objects['Discharge_Root']
for name,color in [('Discharge ceramic-white worn armor',(.65,.67,.65)),('Discharge crimson worn enamel',(.28,.003,.006))]:
 m=bpy.data.materials[name];n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF')
 for link in list(l):
  if link.to_node==p and link.to_socket.name=='Base Color':l.remove(link)
 coord=n.new('ShaderNodeTexCoord');coord.object=root
 noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=18;noise.inputs['Detail'].default_value=2;noise.inputs['Roughness'].default_value=.7;l.new(coord.outputs['Object'],noise.inputs['Vector'])
 ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.65;ramp.color_ramp.elements[0].color=(*color,1);ramp.color_ramp.elements[1].position=.70;ramp.color_ramp.elements[1].color=(.065,.07,.075,1);l.new(noise.outputs['Fac'],ramp.inputs[0]);l.new(ramp.outputs[0],p.inputs['Base Color'])
 rough=n.new('ShaderNodeMapRange');rough.inputs['From Min'].default_value=.25;rough.inputs['From Max'].default_value=.75;rough.inputs['To Min'].default_value=.25;rough.inputs['To Max'].default_value=.48;l.new(noise.outputs['Fac'],rough.inputs[0]);l.new(rough.outputs[0],p.inputs['Roughness'])
 micro=n.new('ShaderNodeTexNoise');micro.inputs['Scale'].default_value=80;micro.inputs['Detail'].default_value=2;l.new(coord.outputs['Object'],micro.inputs['Vector'])
 bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.12;bump.inputs['Distance'].default_value=.012;l.new(micro.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs['Normal'],p.inputs['Normal'])
s=bpy.context.scene;s.cycles.samples=96;s.render.filepath=str(R/'hero.png');bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-material-study.blend'));bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'unaccepted procedural authoring materials','changes':['Shared root-space enamel chips','Varied roughness','Subtle enamel microtexture'],'native_baked_maps':False,'geometry_source':'discharge-authored-muzzles-v12','limits':['Not a validated native material set','Needs close-range and gameplay-distance visual review','Minecraft-fit and concept-faithful choices still require separate native QA']},indent=2)+'\n')
