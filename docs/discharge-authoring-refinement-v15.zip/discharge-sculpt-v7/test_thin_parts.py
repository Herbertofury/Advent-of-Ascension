"""Exercise the actual generator's constructor definitions, without running its scene/render body."""
import bpy,bmesh,ast,math,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);root=bpy.data.objects.new('FixtureRoot',None);bpy.context.collection.objects.link(root);made=[];mat=bpy.data.materials.new('Fixture');scope={'bpy':bpy,'bmesh':bmesh,'math':math,'Vector':Vector,'root':root,'made':made}
tree=ast.parse((R/'build.py').read_text());defs=[node for node in tree.body if isinstance(node,ast.FunctionDef)and node.name in {'finish','cyl','prism'}];exec(compile(ast.Module(body=defs,type_ignores=[]),'actual_constructor_definitions','exec'),scope)
objects=[]
for depth in [.01,.02,.035,.055,.1]:
 for radius in [.073,.115,.14]:objects.append(scope['cyl']('thin-cylinder',(len(objects),0,0),radius,depth,mat))
 outline=[(0,0),(.4,0),(.4,.3),(.2,.2),(0,.3)];objects.append(scope['prism']('thin-concave-inset',outline,len(objects),depth,mat))
bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();failures=[];triangles=0
for o in objects:
 e=o.evaluated_get(dg);me=e.to_mesh();me.calc_loop_triangles();triangles+=len(me.loop_triangles)
 bad=0
 for t in me.loop_triangles:
  v=[o.matrix_world@me.vertices[i].co for i in t.vertices]
  if (v[1]-v[0]).cross(v[2]-v[0]).length_squared<1e-20:bad+=1
 bm=bmesh.new();bm.from_mesh(me);volume=bm.calc_volume(signed=True);bm.free();e.to_mesh_clear()
 if bad or volume<=0:failures.append({'object':o.name,'degenerate':bad,'volume':volume})
report={'fixtures':len(objects),'triangles':triangles,'failures':failures,'scope':'Actual cylinder/prism factory thickness fixtures; not arbitrary shape/hand/native certification'};(R/'thin-part-regression.json').write_text(json.dumps(report,indent=2)+'\n');print(report);assert not failures
