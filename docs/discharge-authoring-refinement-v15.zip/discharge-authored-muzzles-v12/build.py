"""Original exterior vent refinement; no gameplay or firing mechanism changes."""
import bpy,json,math
from pathlib import Path
R=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(R.parent/'discharge-authored-muzzles-v9/discharge-muzzle-study.blend'))
# New closed housings replace these old overlapping side-wall pieces.
for old in list(bpy.data.objects):
 if old.name.startswith('Muzzle side segment'):bpy.data.objects.remove(old,do_unlink=True)
for i,z in enumerate([.2,.68,1.16]):
 housing=bpy.data.objects['Owned white muzzle housing '+str(i)]
 for side in [-1,1]:
  bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,location=(3.30,side*.56,z))
  cutter=bpy.context.object;cutter.name='Temporary exterior vent cutter';cutter.scale=(.19,.20,.055)
  bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
  cutter.data.materials.append(bpy.data.materials['Discharge ceramic-white worn armor'])
  cutter.data.materials.append(bpy.data.materials['Discharge dark machined steel'])
  for face in cutter.data.polygons:face.material_index=1
  bpy.ops.object.select_all(action='DESELECT');housing.select_set(True);bpy.context.view_layer.objects.active=housing
  mod=housing.modifiers.new('Recessed exterior capsule vent','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cutter
  bpy.ops.object.modifier_move_to_index(modifier=mod.name,index=0)
  bpy.ops.object.modifier_apply(modifier=mod.name)
  bpy.data.objects.remove(cutter,do_unlink=True)
scene=bpy.context.scene;scene.cycles.samples=64;scene.render.filepath=str(R/'hero.png')
bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-muzzle-study.blend'))
bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'unaccepted authoring study','changes':['Six actual capsule-shaped side openings in three separately owned muzzle housings'],'original_projectile_count':4,'visual_channels':3,'native_tested':False,'texture_rebake_required':True},indent=2)+'\n')
