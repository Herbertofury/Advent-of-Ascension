"""Editable fictional energy-chamber appearance; no weapon resource rules changed."""
import bpy,math,json
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'discharge-material-study-v13/discharge-material-study.blend'));root=bpy.data.objects['Discharge_Root']
for o in list(bpy.data.objects):
 if o.name.startswith('Capacitor bright pulse helix'):bpy.data.objects.remove(o,do_unlink=True)
def path(name,pts,radius,material):
 curve=bpy.data.curves.new(name,'CURVE');curve.dimensions='3D';curve.resolution_u=2;curve.bevel_depth=radius;curve.bevel_resolution=2
 spline=curve.splines.new('POLY');spline.points.add(len(pts)-1)
 for p,co in zip(spline.points,pts):p.co=(*co,1)
 o=bpy.data.objects.new(name,curve);bpy.context.collection.objects.link(o);o.parent=root;curve.materials.append(bpy.data.materials[material]);return o
for side in [-1,1]:
 yc=side*.72
 for zoff in [-.245,.245]:
  path('Chamber protective longitudinal rail',[(-.66,yc,.65+zoff),(-.50,yc+side*.035,.65+zoff),(.98,yc+side*.035,.65+zoff),(1.17,yc,.65+zoff)],.024,'Discharge dark machined steel')
m=bpy.data.materials['Discharge patterned core'];n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF')
for node in list(n):
 if node not in [p,n.get('Material Output')]:n.remove(node)
coord=n.new('ShaderNodeTexCoord');noise=n.new('ShaderNodeTexNoise');noise.noise_dimensions='4D';noise.inputs['Scale'].default_value=3.7;noise.inputs['Detail'].default_value=2;noise.inputs['Roughness'].default_value=.65;l.new(coord.outputs['Generated'],noise.inputs['Vector'])
warp=n.new('ShaderNodeVectorMath');warp.operation='SCALE';warp.inputs[3].default_value=.16;l.new(noise.outputs['Color'],warp.inputs[0]);add=n.new('ShaderNodeVectorMath');add.operation='ADD';l.new(coord.outputs['Generated'],add.inputs[0]);l.new(warp.outputs[0],add.inputs[1])
vor=n.new('ShaderNodeTexVoronoi');vor.feature='DISTANCE_TO_EDGE';vor.inputs['Scale'].default_value=3.2;l.new(add.outputs[0],vor.inputs['Vector'])
ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.007;ramp.color_ramp.elements[0].color=(1,.08,.02,1);ramp.color_ramp.elements[1].position=.026;ramp.color_ramp.elements[1].color=(.018,.0001,.0003,1);l.new(vor.outputs['Distance'],ramp.inputs[0]);l.new(ramp.outputs[0],p.inputs['Base Color']);l.new(ramp.outputs[0],p.inputs['Emission Color']);p.inputs['Emission Strength'].default_value=2.5;p.inputs['Roughness'].default_value=.19;p.inputs['Metallic'].default_value=.1
# Authoring-only seamless parameter excursion: equal endpoints. Native time mapping remains open.
for frame,value in [(1,0),(31,.65),(61,0)]:noise.inputs['W'].default_value=value;noise.inputs['W'].keyframe_insert('default_value',frame=frame)
s=bpy.context.scene;s.frame_start=1;s.frame_end=61;s.frame_set(1);s.cycles.samples=64;s.render.filepath=str(R/'hero.png');bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-energy-study.blend'));bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'unaccepted authoring energy study','changes':['Removed distracting bright metallic helices','Four seated dark longitudinal protection rails','Warped sparse red energy veins with authored shader-time variation'],'native_animation':False,'resource_damage_behavior_changed':False,'limits':['Shader keyframes are not exported gameplay animation','Requires baked/animated native material implementation and visual QA','No projectile, resource or damage change']},indent=2)+'\n')
