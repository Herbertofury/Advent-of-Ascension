# v9 visual review

Status: unaccepted authoring study. Hero inspected against the owner-selected Discharge A concept.

The three discrete dark housings with lighter front rims read more clearly than v8's broad white walls. Their frontal interior rectangle passes 297 sampled parallel rays (99 per channel); this is not continuous/all-angle/native collision proof.

Remaining defects: slab-like housing sides lack the concept's inset vents and surface treatment. Rear assembly, grip ornamentation, material finish and shaped armor remain substantially simpler than the concept. Authoring light and emission do not establish native appearance. No animation, hand-clearance, full particle package or in-game acceptance.

Next: add actual recessed side vent geometry to these owned housings, inspect oblique views, and rerun neutral geometry/aperture tests. Existing texture bakes must be regenerated for changed geometry.
