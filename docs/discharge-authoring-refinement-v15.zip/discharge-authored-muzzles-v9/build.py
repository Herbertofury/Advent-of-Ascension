"""Concept-directed external muzzle housing study; original projectile count unchanged."""
import bpy,bmesh,json
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'discharge-sculpt-v7/discharge-v7.blend'));root=bpy.data.objects['Discharge_Root'];old=bpy.data.objects.get('Open elliptical muzzle housing')
if old:bpy.data.objects.remove(old,do_unlink=True)
def ring(name,xc,zc,outer,inner,depth,mat):
 n=len(outer);v=[(xc+dx,y,zc+z)for dx in [-depth/2,depth/2]for loop in [outer,inner]for y,z in loop];f=[]
 for i in range(n):j=(i+1)%n;f.extend([(i,j,n+j,n+i),(2*n+i,3*n+i,3*n+j,2*n+j),(i,2*n+i,2*n+j,j),(n+i,n+j,3*n+j,3*n+i)])
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);o.parent=root;me.materials.append(bpy.data.materials[mat]);me.materials.append(bpy.data.materials['Discharge dark machined steel'])
 for poly in me.polygons:poly.material_index=1 if poly.index%4 in (2,3) else 0
 b=o.modifiers.new('Housing edge bevel','BEVEL');b.width=.012;b.segments=3;o.modifiers.new('Housing weighted normals','WEIGHTED_NORMAL');return o
outer=[(-.58,-.14),(-.49,-.225),(.49,-.225),(.58,-.14),(.58,.14),(.49,.225),(-.49,.225),(-.58,.14)]
inner=[(-.39,-.075),(-.35,-.115),(.35,-.115),(.39,-.075),(.39,.075),(.35,.115),(-.35,.115),(-.39,.075)]
for i,z in enumerate([.2,.68,1.16]):
 ring('Owned white muzzle housing '+str(i),3.30,z,outer,inner,.70,'Discharge ceramic-white worn armor')
 lip_outer=[(y*1.025,zz*1.025)for y,zz in inner];lip_inner=[(y*.85,zz*.80)for y,zz in inner]
 ring('Owned dark muzzle liner '+str(i),3.675,z,lip_outer,lip_inner,.045,'Discharge dark machined steel')
for o in bpy.data.objects:
 if o.name.startswith('Muzzle inner red edge'):
  for sp in o.data.splines:
   zc=sum(p.co.z for p in sp.points)/len(sp.points)
   for p in sp.points:p.co.y=.28 if p.co.y>0 else-.28;p.co.z=zc+(p.co.z-zc)*.75
from mathutils import Vector
bpy.context.view_layer.update();checks=[]
for z in [.2,.68,1.16]:
 hit,loc,normal,index,obj,matrix=bpy.context.scene.ray_cast(bpy.context.evaluated_depsgraph_get(),Vector((10,0,z)),Vector((-1,0,0)),distance=20)
 checks.append({'channel_center_z':z,'first_hit':obj.name if hit else None,'first_hit_x':loc.x if hit else None});assert not hit or loc.x<3.25,checks[-1]
(R/'aperture-center-check.json').write_text(json.dumps({'scope':'One center ray per visible port confirms an open front region; not all-angle or projectile collision testing','rays':checks},indent=2)+'\n')
s=bpy.context.scene;s.cycles.samples=48;s.render.filepath=str(R/'hero.png');bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-muzzle-study.blend'));bpy.ops.render.render(write_still=True);(R/'manifest.json').write_text(json.dumps({'status':'unaccepted external art study','visible_channels':3,'original_projectile_burst_count':4,'behavior_changed':False,'native_tested':False,'changes':['Replaced broad elliptical outer housing with three separately owned chamfered housings','Preserved actual open ports and recessed light strips'],'limits':['No animation or gameplay integration','Three visible channels do not redefine original projectile count','Full concept and mesh QA remain required']},indent=2)+'\n')
