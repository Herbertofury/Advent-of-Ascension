"""Frontal presentation-opening samples, not projectile or animation collision QA."""
import bpy,json,hashlib
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent
source=R/'discharge-muzzle-study.blend'
bpy.ops.wm.open_mainfile(filepath=str(source))
bpy.context.view_layer.update(); dg=bpy.context.evaluated_depsgraph_get()
rows=[]
for channel,zc in enumerate([.2,.68,1.16]):
 for yi in range(11):
  for zi in range(9):
   y=-.25+.5*yi/10; z=zc-.055+.11*zi/8
   hit,loc,normal,index,obj,matrix=bpy.context.scene.ray_cast(dg,Vector((4,y,z)),Vector((-1,0,0)),distance=2)
   rows.append({'channel':channel,'y':y,'z':z,'first_hit':obj.name if hit else None,'first_hit_x':loc.x if hit else None,'front_obstruction':bool(hit and loc.x>=3.25)})
blocked=[r for r in rows if r['front_obstruction']]
report={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'sample_count':len(rows),'blocked_count':len(blocked),'scope':'99 frontal parallel rays through a conservative rectangular interior per channel. Does not prove continuous clearance, oblique opening, animated collision, hand clearance, gameplay or native rendering.','rows':rows}
(R/'aperture-grid-check.json').write_text(json.dumps(report,indent=2)+'\n')
print('Frontal samples',len(rows),'blocked',len(blocked));print(blocked[:3]);assert not blocked
