# Rejected v10 vent visibility

The hero render reveals shallow-looking oval outlines rather than clear side openings. The Boolean removed material from the new housing, but old overlapping muzzle-side pieces remained behind it. Static triangle validity and frontal port sampling did not catch this semantic/occlusion defect. v11 removes the replaced old side-wall objects and adds a separate side-vent ray check. This version is preserved as a failed iteration; no visual or native acceptance.
