# Native hand-axis source study

Read-only audit of an independently obtained official TaCZ source checkout at the recorded commit. Place it at tacz-source next to the script, install NumPy from its standard package source if needed, and run Python audit_source_axis.py. No upstream source or game binaries are included. Seven synthetic math checks are not native game acceptance.
