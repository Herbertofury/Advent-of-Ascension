# Discharge receiver-contour authoring patch v32

Cosmetic Blender study, not an installable mod or an accepted weapon.

Requires the exact discharge-authoring-study.blend from the published v31 authoring archive, SHA-256 81e2a42d29e4f690ba83ed62f67202af47c28e5f6c9e950c8e5b0cbd15b19cc5. Original archive: https://github.com/Herbertofury/Advent-of-Ascension/raw/refs/heads/main/docs/discharge-exterior-authoring-study-v31.zip

Use Blender 4.3.2. The patch adds fourteen exterior objects without replacing the old scene. It refuses a different source hash. The output is a new file in the selected output directory.

blender -b -t 2 --python-exit-code 1 --python build.py -- --source /path/discharge-authoring-study.blend --output /path/new-output
blender -b -t 2 --python-exit-code 1 --python check_geometry.py -- --source /path/discharge-authoring-study.blend --scene /path/new-output/discharge-rear-contour.blend --report /path/new-output/geometry-qa.json

Add --render to the build command for the side review. Cycles denoising is disabled for portable rendering; high-quality native materials remain open. Existing camera/render settings are changed for the review scene, while all 164 original mesh coordinates, polygon indices, matrices, material-slot names and render visibility remain unchanged in the scoped comparison. Curves, animations, driver state and material node internals are not covered by this preservation test.

The 14 new objects are closed positive-volume meshes with no degenerate evaluated triangles under the recorded test threshold. These tests do not establish collision-free hand motion, intersections with every existing surface, TaCZ export, exact concept fidelity or performance. Actual hands, native captures, textures and full animation/effect coverage remain open.

## Root ownership correction (r2)

The fourteen added objects now explicitly inherit Discharge_Root. The previous static study did not establish this ownership. Tests exercise 21 root transforms and 10,752 vertex positions, with maximum observed error below 1e-6 scene units. This checks whole-asset transform following, not native animation or hands. Existing v31 mesh geometry remains unchanged.

## Dependency-graph correction (r3)

An actual combined-scene render exposed oversized cosmetic fasteners in r2: their scale had been assigned immediately before reading a stale world matrix during parenting. The build now updates the Blender dependency graph before capturing those matrices. Six explicit fastener-dimension checks prevent that regression. A separate comparison checks all 512 added vertices against the pre-parenting v1 scene: zero world-space drift. The side render has been repeated after correction. Use r3 rather than r2.
