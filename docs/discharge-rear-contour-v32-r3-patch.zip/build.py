import bpy,bmesh,json,hashlib,math,argparse,sys
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--render',action='store_true');a=p.parse_args(sys.argv[sys.argv.index('--')+1:]if '--'in sys.argv else[]);R=a.output;R.mkdir(parents=True,exist_ok=True);src=a.source
assert hashlib.sha256(src.read_bytes()).hexdigest()=='81e2a42d29e4f690ba83ed62f67202af47c28e5f6c9e950c8e5b0cbd15b19cc5','Source scene differs from pinned v31'
bpy.ops.wm.open_mainfile(filepath=str(src));added=[]
def plate(name,points,y,depth,mat,bevel=.025):
 n=len(points);vs=[(x,y-depth/2,z)for x,z in points]+[(x,y+depth/2,z)for x,z in points];fs=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n)for i in range(n)];m=bpy.data.meshes.new(name);m.from_pydata(vs,[],fs);m.update();o=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(o);bm=bmesh.new();bm.from_mesh(m);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(m);bm.free();m.materials.append(bpy.data.materials[mat]);b=o.modifiers.new('Small authored edge bevel','BEVEL');b.width=bevel;b.segments=3;b.affect='EDGES';o.modifiers.new('Weighted surface normals','WEIGHTED_NORMAL');added.append(o.name);return o
silver='Discharge bright edges';dark='Discharge dark machined steel';red='Discharge crimson worn enamel'
# Layered cosmetic exterior only: no changes to trigger, guard, grip or gameplay.
for sign in [-1,1]:
 y=sign*.555
 plate('V32 swept rear lower brace', [(-2.82,.38),(-2.64,.50),(-2.41,.59),(-2.15,.56),(-1.87,.42),(-1.54,.33),(-1.59,.23),(-1.96,.29),(-2.22,.41),(-2.46,.44),(-2.71,.32)],y,.065,silver,.018)
 plate('V32 layered upper receiver armor',[(-2.80,.96),(-2.65,1.16),(-2.35,1.23),(-2.10,1.16),(-1.87,.98),(-1.55,.88),(-1.61,.72),(-1.98,.78),(-2.25,.94),(-2.48,1.00)],y,.075,silver,.025)
 plate('V32 inset rear graphite panel',[(-2.63,.93),(-2.44,1.07),(-2.25,1.02),(-2.02,.86),(-1.80,.80),(-1.85,.76),(-2.13,.82),(-2.35,.95),(-2.51,.95)],sign*.608,.025,dark,.012)
 plate('V32 rear crimson accent',[(-2.64,1.13),(-2.36,1.19),(-2.15,1.13),(-2.33,1.08),(-2.52,1.08)],sign*.606,.023,red,.008)
 for x,z in [(-2.64,.43),(-1.76,.33),(-2.56,1.11)]:
  bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=6,radius=1,location=(x,sign*.625,z));o=bpy.context.object;o.name='V32 recessed-style cosmetic fastener';o.scale=(.034,.018,.034);o.data.materials.append(bpy.data.materials[dark]);added.append(o.name)
bpy.context.view_layer.update()
root=bpy.data.objects['Discharge_Root']
for name in added:
 o=bpy.data.objects[name];world=o.matrix_world.copy();o.parent=root;o.matrix_world=world
bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.samples=64;bpy.context.scene.cycles.use_denoising=False
bpy.context.scene.render.resolution_x=1200;bpy.context.scene.render.resolution_y=850;bpy.context.scene.render.resolution_percentage=100
bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-rear-contour.blend'))
(R/'manifest.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'added_objects':added,'parent':'Discharge_Root','scope':'Layered external receiver cosmetics only; source geometry retained','native_accepted':False,'art_accepted':False},indent=2))
if a.render:
 c=bpy.context.scene.camera;c.location=(0,17,3.2);c.rotation_euler=(Vector((-.2,0,.3))-c.location).to_track_quat('-Z','Y').to_euler();c.data.type='ORTHO';c.data.ortho_scale=9.8;bpy.context.scene.render.filepath=str(R/'side.png');bpy.ops.render.render(write_still=True)
