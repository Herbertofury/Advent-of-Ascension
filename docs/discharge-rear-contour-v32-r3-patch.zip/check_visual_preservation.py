import bpy,json,sys,argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--before',required=True);p.add_argument('--after',required=True);p.add_argument('--report',required=True);args=p.parse_args(sys.argv[sys.argv.index('--')+1:]);bpy.ops.wm.open_mainfile(filepath=args.before);base={o.name:[o.matrix_world@v.co for v in o.data.vertices]for o in bpy.context.scene.objects if o.type=='MESH' and o.name.startswith('V32 ')}
bpy.ops.wm.open_mainfile(filepath=args.after);samples=0;maximum=0
for name,verts in base.items():
 o=bpy.data.objects[name];assert o.parent.name=='Discharge_Root';assert len(verts)==len(o.data.vertices)
 for a,v in zip(verts,o.data.vertices):maximum=max(maximum,(a-o.matrix_world@v.co).length);samples+=1
assert maximum<1e-6,maximum
r={'scope':'World-space new-part vertex preservation before and after root parenting','vertices_compared':samples,'maximum_position_error':maximum,'native_accepted':False};Path(args.report).write_text(json.dumps(r,indent=2));print(r)
