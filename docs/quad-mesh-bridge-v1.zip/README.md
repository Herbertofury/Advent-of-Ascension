# Immutable quad bridge candidate

Original Java 17 source implementing the actual released TaCZ BedrockCube interface. The harness invokes the unmodified released BedrockPart.compile method and records its calls through our implementation. This is a more concrete extension-seam test, not a finished native renderer or installable mod.

Run with a full JDK 17+:
python run_check.py --jar PATH_TO_TACZ_HOTFIX2_JAR --lib-dir HASHED_JOML_FASTUTIL_DIRECTORY --java-extra PATH_TO_SECOND_JAVA
Without local inputs, the runner downloads the pinned official Modrinth TaCZ file and two pinned libraries from libraries.minecraft.net. Every file is hash checked. Only two TaCZ classes are extracted into the runtime classpath; the complete mod JAR never enters it. The archive contains original source and manifests, not upstream binaries.

Source vertex layout: four vertices per planar convex quad; each vertex contains model-unit XYZ, normalized atlas UV, unit XYZ normal. Model units divide by 16, matching the inspected native cube path. Input arrays are copied, bounds are fixed and there are no per-vertex Vector allocations in our compile loop. Sink/game allocations and actual frame-time effects are unmeasured.

Guards reject empty/oversize buffers, nonfinite values, out-of-range atlas UVs, invalid normals, degenerate/nonconvex/nonplanar quads, unreasonable local-coordinate bounds, non-affine/nonfinite transforms and possible transform overflow before submitting geometry. The 4096-quad cap is an engineering guardrail, not an accepted performance budget.

Minecraft PoseStack/VertexConsumer and otherwise-unused rendering types are narrow harness stand-ins. Real JOML math and fastutil are used. The compiler currently reports the absent Forge Dist.CLIENT annotation type; that unused annotation warning is retained in results. Neither Forge nor its mixins are active. No runtime cache, shader, resource reload, actual buffer, hand, native render or GPU claim follows.

The candidate uses the inspected 1.20.1 SRG method names. A production adapter needs the correct mapped build, version checks, lifecycle registration restricted to our own model parts, texture/material handling, topology/LOD integration and actual native acceptance. Never mutate vertex/UV arrays inside an already-cached accelerated-renderer part. Keep previous source/model versions and a native-format fallback.
