package aoa.armory.geometry;
import com.tacz.guns.client.model.bedrock.BedrockCube;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Matrix4f;
import org.joml.Matrix3f;
/** Candidate 1.20.1 SRG-bound bridge. No loader registration or native acceptance. */
public final class ImmutableQuadMesh implements BedrockCube {
  public static final int MAX_QUADS=4096;
  private final float[] vertices;
  private final float maxX,maxY,maxZ;
  /** Four vertices per quad; each vertex is model-unit XYZ, normalized atlas UV, unit XYZ normal. */
  public ImmutableQuadMesh(float[] input) {
    if(input==null||input.length==0||input.length%32!=0||input.length/32>MAX_QUADS)throw new IllegalArgumentException("quad budget/layout");
    vertices=input.clone();
    float boundX=0,boundY=0,boundZ=0;
    for(int i=0;i<vertices.length;i+=8){
      for(int j=0;j<8;j++)if(!Float.isFinite(vertices[i+j]))throw new IllegalArgumentException("nonfinite vertex");
      if(Math.abs(vertices[i])>65536||Math.abs(vertices[i+1])>65536||Math.abs(vertices[i+2])>65536)throw new IllegalArgumentException("model coordinate budget");
      boundX=Math.max(boundX,Math.abs(vertices[i]));boundY=Math.max(boundY,Math.abs(vertices[i+1]));boundZ=Math.max(boundZ,Math.abs(vertices[i+2]));
      if(vertices[i+3]<0||vertices[i+3]>1||vertices[i+4]<0||vertices[i+4]>1)throw new IllegalArgumentException("UV outside normalized atlas");
      double n=vertices[i+5]*vertices[i+5]+vertices[i+6]*vertices[i+6]+vertices[i+7]*vertices[i+7];
      if(Math.abs(n-1)>0.001)throw new IllegalArgumentException("normal must be unit length");
    }
    maxX=boundX;maxY=boundY;maxZ=boundZ;
    for(int i=0;i<vertices.length;i+=32)validateQuad(i);
  }
  private void validateQuad(int i){
    double ax=vertices[i+8]-vertices[i],ay=vertices[i+9]-vertices[i+1],az=vertices[i+10]-vertices[i+2];
    double bx=vertices[i+16]-vertices[i],by=vertices[i+17]-vertices[i+1],bz=vertices[i+18]-vertices[i+2];
    double cx=vertices[i+24]-vertices[i],cy=vertices[i+25]-vertices[i+1],cz=vertices[i+26]-vertices[i+2];
    double nx=ay*bz-az*by,ny=az*bx-ax*bz,nz=ax*by-ay*bx;
    double mx=by*cz-bz*cy,my=bz*cx-bx*cz,mz=bx*cy-by*cx;
    double n2=nx*nx+ny*ny+nz*nz,m2=mx*mx+my*my+mz*mz;
    if(n2<1e-12||m2<1e-12||nx*mx+ny*my+nz*mz<=0)throw new IllegalArgumentException("degenerate or inconsistent quad winding");
    for(int corner=0;corner<4;corner++){
      int a=i+8*corner,b=i+8*((corner+1)%4),c=i+8*((corner+2)%4);
      double ux=vertices[b]-vertices[a],uy=vertices[b+1]-vertices[a+1],uz=vertices[b+2]-vertices[a+2];
      double vx=vertices[c]-vertices[b],vy=vertices[c+1]-vertices[b+1],vz=vertices[c+2]-vertices[b+2];
      if((uy*vz-uz*vy)*nx+(uz*vx-ux*vz)*ny+(ux*vy-uy*vx)*nz<=0)throw new IllegalArgumentException("nonconvex quad");
    }
    if(Math.abs(nx*cx+ny*cy+nz*cz)>1e-5*Math.sqrt(n2)*Math.max(1,Math.sqrt(cx*cx+cy*cy+cz*cz)))throw new IllegalArgumentException("nonplanar quad");
  }
  public int quadCount(){return vertices.length/32;}
  @Override public void compile(PoseStack.Pose pose,VertexConsumer sink,int light,int overlay,float red,float green,float blue,float alpha){
    if(pose==null||sink==null)throw new IllegalArgumentException("missing render context");
    if(!Float.isFinite(red)||!Float.isFinite(green)||!Float.isFinite(blue)||!Float.isFinite(alpha))throw new IllegalArgumentException("nonfinite tint");
    Matrix4f p=pose.m_252922_();Matrix3f n=pose.m_252943_();
    if(!p.isFinite()||!n.isFinite())throw new IllegalArgumentException("nonfinite transform");
    if(p.m03()!=0||p.m13()!=0||p.m23()!=0||p.m33()!=1)throw new IllegalArgumentException("expected affine model pose");
    double xBound=maxX/16.0,yBound=maxY/16.0,zBound=maxZ/16.0,limit=Float.MAX_VALUE/4.0;
    if(Math.abs((double)p.m00())*xBound+Math.abs((double)p.m10())*yBound+Math.abs((double)p.m20())*zBound+Math.abs((double)p.m30())>limit
      ||Math.abs((double)p.m01())*xBound+Math.abs((double)p.m11())*yBound+Math.abs((double)p.m21())*zBound+Math.abs((double)p.m31())>limit
      ||Math.abs((double)p.m02())*xBound+Math.abs((double)p.m12())*yBound+Math.abs((double)p.m22())*zBound+Math.abs((double)p.m32())>limit
      ||Math.abs((double)n.m00())+Math.abs((double)n.m10())+Math.abs((double)n.m20())>limit
      ||Math.abs((double)n.m01())+Math.abs((double)n.m11())+Math.abs((double)n.m21())>limit
      ||Math.abs((double)n.m02())+Math.abs((double)n.m12())+Math.abs((double)n.m22())>limit)throw new IllegalArgumentException("transform overflow budget");
    // Source model units are sixteenths, matching the inspected native cuboid path.
    // Scalar math creates no per-vertex Vector objects. Native allocations/performance remain unmeasured.
    for(int i=0;i<vertices.length;i+=8){
      float x=vertices[i]/16f,y=vertices[i+1]/16f,z=vertices[i+2]/16f;
      float nx=vertices[i+5],ny=vertices[i+6],nz=vertices[i+7];
      sink.m_5954_(p.m00()*x+p.m10()*y+p.m20()*z+p.m30(),p.m01()*x+p.m11()*y+p.m21()*z+p.m31(),p.m02()*x+p.m12()*y+p.m22()*z+p.m32(),red,green,blue,alpha,vertices[i+3],vertices[i+4],overlay,light,n.m00()*nx+n.m10()*ny+n.m20()*nz,n.m01()*nx+n.m11()*ny+n.m21()*nz,n.m02()*nx+n.m12()*ny+n.m22()*nz);
    }
  }
}
