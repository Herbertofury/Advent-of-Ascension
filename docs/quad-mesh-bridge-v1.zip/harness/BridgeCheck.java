import aoa.armory.geometry.ImmutableQuadMesh;
import com.tacz.guns.client.model.bedrock.BedrockPart;
import com.mojang.blaze3d.vertex.*;
import org.joml.*;
import java.util.*;
public class BridgeCheck {
 static float[] quad(){return new float[]{0,0,0,0,0,0,0,1, 16,0,0,1,0,0,0,1, 16,16,0,1,1,0,0,1, 0,16,0,0,1,0,0,1};}
 static void require(boolean x,String s){if(!x)throw new AssertionError(s);}static void near(float x,float y){require(java.lang.Math.abs(x-y)<1e-5,x+" != "+y);}
 static void reject(Runnable r){try{r.run();throw new AssertionError("invalid input accepted");}catch(IllegalArgumentException expected){}}
 static final class Sink implements VertexConsumer {final List<float[]> rows=new ArrayList<>();public void m_5954_(float x,float y,float z,float r,float g,float b,float a,float u,float v,int overlay,int light,float nx,float ny,float nz){rows.add(new float[]{x,y,z,r,g,b,a,u,v,overlay,light,nx,ny,nz});}}
 public static void main(String[]args){
  float[] source=quad();var mesh=new ImmutableQuadMesh(source);source[0]=999;require(mesh.quadCount()==1,"quad count");
  var part=new BedrockPart("aoa_test_quad");part.cubes.add(mesh);var sink=new Sink();part.compile(new PoseStack.Pose(new Matrix4f().translation(3,4,5),new Matrix3f()),sink,123,456,.2f,.3f,.4f,.5f);
  require(sink.rows.size()==4,"native part interface dispatch");float[] p=sink.rows.get(0);near(p[0],3);near(p[1],4);near(p[2],5);near(p[3],.2f);near(p[6],.5f);near(p[9],456);near(p[10],123);near(p[13],1);
  near(sink.rows.get(2)[0],4);near(sink.rows.get(2)[1],5);near(sink.rows.get(2)[7],1);near(sink.rows.get(2)[8],1);
  sink.rows.clear();Matrix4f rotation=new Matrix4f().rotateY((float)java.lang.Math.PI/2);Matrix3f normal=new Matrix3f().rotateY((float)java.lang.Math.PI/2);part.compile(new PoseStack.Pose(rotation,normal),sink,1,2,1,1,1,1);near(sink.rows.get(1)[0],0);near(sink.rows.get(1)[2],-1);near(sink.rows.get(1)[11],1);
  sink.rows.clear();part.cubes.add(mesh);part.compile(new PoseStack.Pose(new Matrix4f(),new Matrix3f()),sink,0,0,1,1,1,1);require(sink.rows.size()==8,"multiple entries dispatch");
  reject(()->new ImmutableQuadMesh(null));reject(()->new ImmutableQuadMesh(new float[0]));reject(()->new ImmutableQuadMesh(new float[31]));reject(()->new ImmutableQuadMesh(new float[(ImmutableQuadMesh.MAX_QUADS+1)*32]));
  float[] bad=quad();bad[0]=Float.NaN;reject(()->new ImmutableQuadMesh(bad));float[] uv=quad();uv[3]=2;reject(()->new ImmutableQuadMesh(uv));float[] norm=quad();norm[7]=0;reject(()->new ImmutableQuadMesh(norm));float[] deg=quad();deg[8]=0;reject(()->new ImmutableQuadMesh(deg));float[] planar=quad();planar[26]=1;reject(()->new ImmutableQuadMesh(planar));
  sink.rows.clear();reject(()->mesh.compile(new PoseStack.Pose(new Matrix4f().m00(Float.NaN),new Matrix3f()),sink,0,0,1,1,1,1));require(sink.rows.isEmpty(),"invalid matrix emitted partial geometry");
  float[] concave=quad();concave[16]=4;concave[17]=4;reject(()->new ImmutableQuadMesh(concave));float[] huge=quad();huge[8]=Float.MAX_VALUE;reject(()->new ImmutableQuadMesh(huge));
  sink.rows.clear();reject(()->mesh.compile(new PoseStack.Pose(new Matrix4f().m00(Float.MAX_VALUE),new Matrix3f()),sink,0,0,1,1,1,1));require(sink.rows.isEmpty(),"overflow emitted geometry");
  reject(()->mesh.compile(new PoseStack.Pose(new Matrix4f().m03(.5f),new Matrix3f()),sink,0,0,1,1,1,1));
  System.out.println("PASS actual released BedrockPart.compile dispatch to immutable custom BedrockCube: quad vertices, model-unit scaling, transform/normal/UV/tint/light order, input-copy isolation and malformed-input gates. PoseStack/VertexConsumer and unused Minecraft types are test stand-ins; no GPU/native renderer acceptance.");
 }
}
