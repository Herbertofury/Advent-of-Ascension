package net.minecraft.client.renderer;public class LightTexture {public static int m_109885_(int a,int b){throw new UnsupportedOperationException("unused native render path");}}
