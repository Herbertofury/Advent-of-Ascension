package com.mojang.math;import org.joml.Quaternionf;public interface Axis {Axis f_252529_=null,f_252436_=null,f_252403_=null;Quaternionf m_252961_(float angle);}
