package com.mojang.blaze3d.vertex;
/** Test recording sink; no GPU or actual Minecraft buffer. */
public interface VertexConsumer {void m_5954_(float x,float y,float z,float r,float g,float b,float a,float u,float v,int overlay,int light,float nx,float ny,float nz);}
