package com.mojang.blaze3d.vertex;
import org.joml.*;
/** Narrow test stand-in, NOT Minecraft PoseStack. Only Pose is used in tests. */
public class PoseStack {
 public static class Pose {private final Matrix4f p;private final Matrix3f n;public Pose(Matrix4f p,Matrix3f n){this.p=p;this.n=n;}public Matrix4f m_252922_(){return p;}public Matrix3f m_252943_(){return n;}}
 public void m_85836_(){throw new UnsupportedOperationException();}public void m_85849_(){throw new UnsupportedOperationException();}public Pose m_85850_(){throw new UnsupportedOperationException();}
 public void m_252880_(float x,float y,float z){throw new UnsupportedOperationException();}public void m_252781_(Quaternionf q){throw new UnsupportedOperationException();}public void m_85841_(float x,float y,float z){throw new UnsupportedOperationException();}
}
