import argparse,pathlib,json,hashlib,zipfile,subprocess,os,shutil,urllib.request
p=argparse.ArgumentParser();p.add_argument('--jar',type=pathlib.Path);p.add_argument('--lib-dir',type=pathlib.Path);p.add_argument('--java-extra',type=pathlib.Path);p.add_argument('--out',type=pathlib.Path);a=p.parse_args();R=pathlib.Path(__file__).resolve().parent;m=json.loads((R/'manifest.json').read_text());C=R/'cache';C.mkdir(exist_ok=True)
def fetch(url,p,expected,algorithm='sha256'):
 if p.exists()and hashlib.new(algorithm,p.read_bytes()).hexdigest()==expected:return
 b=urllib.request.urlopen(url,timeout=90).read();assert hashlib.new(algorithm,b).hexdigest()==expected;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
jar=a.jar or C/m['download']['filename']
if a.jar:assert hashlib.sha512(jar.read_bytes()).hexdigest()==m['download']['hashes']['sha512'],'Wrong pinned release'
else:fetch(m['download']['url'],jar,m['download']['hashes']['sha512'],'sha512')
existing={str(p.relative_to(C/'released'))for p in (C/'released').rglob('*.class')};assert existing<=set(m['class_files']),'Unlisted cache class'
with zipfile.ZipFile(jar)as z:
 for path,h in m['class_files'].items():
  b=z.read(path);assert hashlib.sha256(b).hexdigest()==h;out=C/'released'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
urls={'fastutil-8.5.9.jar':'https://libraries.minecraft.net/it/unimi/dsi/fastutil/8.5.9/fastutil-8.5.9.jar','joml-1.10.5.jar':'https://libraries.minecraft.net/org/joml/joml/1.10.5/joml-1.10.5.jar'};libs=[]
for f in m['libraries']:
 path=(a.lib_dir or C/'lib')/f['file']
 if a.lib_dir:assert hashlib.sha256(path.read_bytes()).hexdigest()==f['sha256']
 else:fetch(urls[f['file']],path,f['sha256'])
 libs.append(str(path))
home=os.getenv('JAVA_HOME');javac=str(pathlib.Path(home)/'bin/javac')if home else shutil.which('javac');java=str(pathlib.Path(home)/'bin/java')if home else shutil.which('java');assert javac and java
classes=C/'classes';classes.mkdir(exist_ok=True);cp=os.pathsep.join([str(C/'released'),*libs]);sources=sorted([*R.joinpath('src').rglob('*.java'),*R.joinpath('harness').rglob('*.java')]);compile=subprocess.run([javac,'--release','17','-cp',cp,'-d',str(classes),*map(str,sources)],capture_output=True,text=True,check=True);results=[]
for runtime in [java]+([str(a.java_extra)]if a.java_extra else[]):
 version=subprocess.run([runtime,'-version'],capture_output=True,text=True,check=True).stderr.strip();run=subprocess.run([runtime,'-Xverify:all','-cp',str(classes)+os.pathsep+cp,'BridgeCheck'],capture_output=True,text=True,check=True);print(run.stdout,end='');results.append({'java':version,'stdout':run.stdout,'stderr':run.stderr})
report={'release':m['release'],'jar_sha512':m['download']['hashes']['sha512'],'actual_released_classes':m['class_files'],'source_sha256':{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sources},'compiler_warnings':compile.stderr,'results':results,'limits':['Actual BedrockPart.compile dispatch only; not full render method','PoseStack/VertexConsumer and unused MC types are narrow stand-ins','No Forge boot, GPU, AR mixins, native game, resource reload, shader or performance acceptance','No native registration, model injection or asset importer in this prototype','4096-quad budget is a guardrail, not a proven frame-time limit']};(a.out or R/'results.json').write_text(json.dumps(report,indent=2)+'\n')
