"""Lossless cell packing and root alignment; source RGBA pixels are not repainted/resampled."""
from PIL import Image
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;src=Image.open(R/'soul-flame-atlas-candidate-v4.png').convert('RGBA');w,h=src.size;out=Image.new('RGBA',(2048,2048));rows=[]
for j in range(4):
 for i in range(4):
  cell=src.crop((i*w//4,j*h//4,(i+1)*w//4,(j+1)*h//4));cw,ch=cell.size;weighted=[]
  for y in range(int(ch*.75),ch):
   for x in range(cw):
    r,g,b,a=cell.getpixel((x,y));weight=(r/255)**4*(g/255)*(a/255)
    if weight>.02:weighted.append((x,y,weight))
  total=sum(z[2]for z in weighted);assert total>0
  ax=round(sum(x*k for x,y,k in weighted)/total);ay=round(sum(y*k for x,y,k in weighted)/total);dx=256-ax;dy=460-ay
  assert dx>0 and dy>0 and dx+cw<512 and dy+ch<512
  x0=i*512+dx;y0=j*512+dy;out.paste(cell,(x0,y0));assert out.crop((x0,y0,x0+cw,y0+ch)).tobytes()==cell.tobytes()
  rows.append({'frame':j*4+i,'source_rect':[i*w//4,j*h//4,cw,ch],'source_bright_root':[ax,ay],'destination_rect':[x0,y0,cw,ch],'tile_root':[256,460]})
out.save(R/'soul-flame-atlas-v4-padded.png');a=out.getchannel('A')
for j in range(4):
 for i in range(4):
  c=a.crop((i*512,j*512,(i+1)*512,(j+1)*512));assert not any(c.crop((0,0,512,1)).get_flattened_data());assert not any(c.crop((0,511,512,512)).get_flattened_data());assert not any(c.crop((0,0,1,512)).get_flattened_data());assert not any(c.crop((511,0,512,512)).get_flattened_data())
(R/'atlas-pack-qa.json').write_text(json.dumps({'source_sha256':hashlib.sha256((R/'soul-flame-atlas-candidate-v4.png').read_bytes()).hexdigest(),'frames':rows,'source_pixels_unchanged':True,'resampled':False,'all_tile_borders_zero_alpha':True,'root_method':'Integer alignment of bright-core weighted centroid in bottom quarter; visual anchor still requires review','native_acceptance':False},indent=2)+'\n');print('PASS 16 source cells preserved pixel-for-pixel; roots aligned; all padded tile borders zero alpha')
