import bpy
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-v16.blend'));s=bpy.context.scene;c=s.camera;c.location=(-8,0,4.1);c.rotation_euler=(Vector((-2.4,0,4.12))-c.location).to_track_quat('-Z','Y').to_euler();c.data.ortho_scale=1.8;s.render.resolution_x=640;s.render.resolution_y=640;s.cycles.samples=24;s.cycles.use_denoising=False
out=R/'focus-frames';out.mkdir(exist_ok=True)
for f in [0,10,15,20,25,30,35,45,60,70,75,80,85,100]:s.frame_set(f);s.render.filepath=str(out/f'{f:03d}.png');bpy.ops.render.render(write_still=True)
