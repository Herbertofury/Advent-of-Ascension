import bpy,math,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;B=R.parent;bpy.ops.wm.open_mainfile(filepath=str(B/'soul-storm-sculpt-v15/soul-storm-v15.blend'));s=bpy.context.scene;s.frame_set(0);root=bpy.data.objects['SoulStorm_Root'];new=[]
steel=bpy.data.materials['Brushed silver'];indigo=bpy.data.materials['Anodized indigo'];cyan=bpy.data.materials['Spirit cyan'];rubber=bpy.data.materials['Grip inset'];dark=bpy.data.materials['Obsidian violet']
def finish(o,n,m,p=root):o.name=n;o.parent=p;o.data.materials.append(m);new.append(o.name);return o
def mesh_obj(n,vs,fs,m,p=root,smooth=False):
 me=bpy.data.meshes.new(n);me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(o);finish(o,n,m,p)
 for f in me.polygons:f.use_smooth=smooth
 return o
def tube(n,pts,r,m,p=root):
 c=bpy.data.curves.new(n,'CURVE');c.dimensions='3D';c.resolution_u=1;c.bevel_depth=r;c.bevel_resolution=2;sp=c.splines.new('POLY');sp.points.add(len(pts)-1)
 for dst,pt in zip(sp.points,pts):dst.co=(*pt,1)
 o=bpy.data.objects.new(n,c);bpy.context.collection.objects.link(o);return finish(o,n,m,p)
def box(n,loc,size,m):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);finish(o,n,m);mod=o.modifiers.new('Rounded','BEVEL');mod.width=min(size)*.18;mod.segments=3;return o
# Rebalance toward concept: longer body, less tower-like four-emitter spacing.
E=sorted((o for o in bpy.data.objects if o.name.startswith('Emitter_')and o.name.endswith('_top_to_bottom')),key=lambda o:o.name);assert len(E)==4
old=[next(c for c in e.children if c.name.startswith('Rear energy coupler')).location.z for e in E];levels=[1.605+(1.5-i)*.72 for i in range(4)]
bpy.context.view_layer.update()
for i,e in enumerate(E):
 dz=levels[i]-old[i]
 for o in list(e.children):
  if o.type not in {'MESH','CURVE'}:continue
  world=o.matrix_world.copy();inv=world.inverted();longer=not o.name.startswith(('Moving energy connector','Rear energy coupler'))
  def change(co):
   v=world@co;v.z+=dz
   if longer:v.x=.15+(v.x-.15)*1.25
   return inv@v
  if o.type=='MESH':
   for v in o.data.vertices:v.co=change(v.co)
   o.data.update()
  else:
   for sp in o.data.splines:
    for v in sp.points:v.co=(*change(Vector(v.co[:3])),1)
for o in bpy.data.objects:
 if o.name.startswith(('Emitter structural saddle','Saddle indigo face','Saddle cyan rune')):
  world=o.matrix_world.copy();inv=world.inverted()
  for v in o.data.vertices:
   p=world@v.co;p.x=.15+(p.x-.15)*1.25;p.z=1.605+(p.z-1.605)*(.72/.83);v.co=inv@p
  o.data.update()
 if o.name.startswith(('Spirit distribution manifold','Manifold energy seam','Fixed telescoping sleeve'))and o.type=='MESH':
  world=o.matrix_world.copy();inv=world.inverted()
  for v in o.data.vertices:
   p=world@v.co;p.z=1.605+(p.z-1.605)*(.72/.83);v.co=inv@p
  o.data.update()
 if o.name.startswith('Authoring_disc_')and o.animation_data:
  idx=int(o.name.split('_')[-1])-1
  for fc in o.animation_data.action.fcurves:
   if fc.data_path=='location':
    for k in fc.keyframe_points:
     if fc.array_index==0:k.co.y=.15+(k.co.y-.15)*1.25
     if fc.array_index==2:k.co.y+=levels[idx]-old[idx]
# Replace the flat ribbed block/large shoe heel with a continuous rounded grip.
for o in bpy.data.objects:
 if o.name.startswith(('Ergonomic main grip','Grip rib','Grip silver heel','Touch activation inset','V15 heel spirit crest')):o.hide_render=True
N=24
def section(t,inflate=0):
 x=-3.08-.55*t-.10*math.sin(math.pi*t);z=.12-1.74*t;rx=.43+.04*math.sin(math.pi*t)+inflate;ry=.49-.035*t+inflate
 return [(x+rx*math.cos(2*math.pi*k/N),ry*math.sin(2*math.pi*k/N),z)for k in range(N)]
def grip_band(n,t0,t1,mat,inflate):
 vs=section(t0,inflate)+section(t1,inflate);fs=[tuple(range(N-1,-1,-1)),tuple(range(N,2*N))]+[(i,(i+1)%N,(i+1)%N+N,i+N)for i in range(N)];return mesh_obj(n,vs,fs,mat,smooth=True)
vs=[]
for j in range(15):vs+=section(j/14)
fs=[tuple(range(N-1,-1,-1)),tuple(range(14*N,15*N))]
for j in range(14):
 for i in range(N):a=j*N+i;b=j*N+(i+1)%N;fs.append((a,b,b+N,a+N))
mesh_obj('V16 continuous curved grip',vs,fs,rubber,smooth=True)
for j in range(5):grip_band('V16 flush grip wrap',.13+j*.15,.19+j*.15,dark,.012)
grip_band('V16 fitted heel cap',.93,1.02,steel,.018);grip_band('V16 grip root collar',-.03,.07,indigo,.025)
# Rooted flame socket; preserve prior alternatives as hidden history.
for o in bpy.data.objects:
 if o.name.startswith(('Soul flame atlas','Sight socket')) or (o.type=='MESH' and any(m and m.name=='Soul flame atlas surface'for m in o.data.materials)):o.hide_render=True
cx=-2.4;anchor=3.64
bpy.ops.mesh.primitive_cylinder_add(vertices=40,radius=.32,depth=.16,location=(cx,0,3.55));finish(bpy.context.object,'V16 rounded brazier base',dark)
bpy.ops.mesh.primitive_torus_add(major_radius=.29,minor_radius=.035,major_segments=40,minor_segments=8,location=(cx,0,anchor));finish(bpy.context.object,'V16 circular brazier lip',steel)
for k in range(4):
 a=math.pi/4+k*math.pi/2;u=Vector((math.cos(a),math.sin(a),0));v=Vector((-math.sin(a),math.cos(a),0));vs=[]
 for z,r,w,d in [(3.56,.29,.065,.035),(3.93,.35,.025,.018)]:
  c=Vector((cx,0,z))+u*r
  for side,depth in [(-1,-1),(1,-1),(1,1),(-1,1)]:vs.append(tuple(c+v*w*side+u*d*depth))
 mesh_obj('V16 tapered brazier prong',vs,[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],steel)
s['focus']=0.0
for f,v in [(0,0),(15,0),(35,1),(65,1),(85,0),(100,0)]:s['focus']=float(v);s.keyframe_insert(data_path='["focus"]',frame=f)
def focus_driver(socket,expression):
 fc=socket.driver_add('default_value');fc.driver.expression=expression;v=fc.driver.variables.new();v.name='focus';v.type='SINGLE_PROP';v.targets[0].id_type='SCENE';v.targets[0].id=s;v.targets[0].data_path='["focus"]'
fire=bpy.data.materials.new('V16 living soul fire');fire.use_nodes=True;n=fire.node_tree.nodes;n.clear();l=fire.node_tree.links;uv=n.new('ShaderNodeTexCoord');mul=n.new('ShaderNodeVectorMath');mul.operation='MULTIPLY';mul.inputs[1].default_value=(.25,.25,0);add=n.new('ShaderNodeVectorMath');add.operation='ADD';tex=n.new('ShaderNodeTexImage');atlas_path=B/'soul-storm-design-v16/soul-flame-atlas-v4-padded.png';atlas_path=atlas_path if atlas_path.exists()else R/'assets/soul-flame-atlas-v4-padded.png';tex.image=bpy.data.images.load(str(atlas_path));l.new(uv.outputs['UV'],mul.inputs[0]);l.new(mul.outputs[0],add.inputs[0]);l.new(add.outputs[0],tex.inputs['Vector'])
for f in range(0,101):idx=(f//4)%16;add.inputs[1].default_value=((idx%4)/4,1-(idx//4+1)/4,0);add.inputs[1].keyframe_insert('default_value',frame=f)
if fire.node_tree.animation_data:
 for fc in fire.node_tree.animation_data.action.fcurves:
  for k in fc.keyframe_points:k.interpolation='CONSTANT'
alpha=n.new('ShaderNodeMath');alpha.operation='MULTIPLY';l.new(tex.outputs['Alpha'],alpha.inputs[0]);focus_driver(alpha.inputs[1],'.70*(1-.85*focus)')
# Keep the exact aiming center clear at full focus while retaining rooted wisps.
sub=n.new('ShaderNodeVectorMath');sub.operation='SUBTRACT';sub.inputs[1].default_value=(.5,1-460/512+.62/1.85,0);l.new(uv.outputs['UV'],sub.inputs[0]);metric=n.new('ShaderNodeVectorMath');metric.operation='MULTIPLY';metric.inputs[1].default_value=(1.4,1.85,0);l.new(sub.outputs[0],metric.inputs[0]);dist=n.new('ShaderNodeVectorMath');dist.operation='LENGTH';l.new(metric.outputs[0],dist.inputs[0]);inside=n.new('ShaderNodeMapRange');inside.interpolation_type='SMOOTHERSTEP';inside.clamp=True;inside.inputs['From Min'].default_value=.035;inside.inputs['From Max'].default_value=.12;inside.inputs['To Min'].default_value=1;inside.inputs['To Max'].default_value=0;l.new(dist.outputs['Value'],inside.inputs['Value']);focused=n.new('ShaderNodeMath');focused.operation='MULTIPLY';l.new(inside.outputs[0],focused.inputs[0]);focus_driver(focused.inputs[1],'focus');clear=n.new('ShaderNodeMath');clear.operation='SUBTRACT';clear.inputs[0].default_value=1;l.new(focused.outputs[0],clear.inputs[1]);visible_alpha=n.new('ShaderNodeMath');visible_alpha.operation='MULTIPLY';l.new(alpha.outputs[0],visible_alpha.inputs[0]);l.new(clear.outputs[0],visible_alpha.inputs[1])
em=n.new('ShaderNodeEmission');em.inputs['Strength'].default_value=2.8;l.new(tex.outputs['Color'],em.inputs[0]);tr=n.new('ShaderNodeBsdfTransparent');mix=n.new('ShaderNodeMixShader');l.new(visible_alpha.outputs[0],mix.inputs[0]);l.new(tr.outputs[0],mix.inputs[1]);l.new(em.outputs[0],mix.inputs[2]);out=n.new('ShaderNodeOutputMaterial');l.new(mix.outputs[0],out.inputs[0])
for plane in [0,1]:
 w,h=1.40,1.85;bottom=anchor-h*(1-460/512);vs=[]
 for u,v in [(0,0),(1,0),(1,1),(0,1)]:vs.append((cx+(u-.5)*w if plane else cx,(u-.5)*w if not plane else 0,bottom+v*h))
 o=mesh_obj('V16 rooted fire layer',vs,[(0,1,2,3)],fire);uvl=o.data.uv_layers.new(name='Fire atlas UV')
 for dst,co in zip(uvl.data,[(0,0),(1,0),(1,1),(0,1)]):dst.uv=co
# Soft-edged emissive ribbons; avoid opaque leaf/metal-strip appearance.
reticle=bpy.data.materials.new('V16 soft reticle energy');reticle.use_nodes=True;rn=reticle.node_tree.nodes;rn.clear();rl=reticle.node_tree.links;tc=rn.new('ShaderNodeTexCoord');sep=rn.new('ShaderNodeSeparateXYZ');rl.new(tc.outputs['UV'],sep.inputs[0]);scale=rn.new('ShaderNodeMath');scale.operation='MULTIPLY_ADD';scale.inputs[1].default_value=2;scale.inputs[2].default_value=-1;rl.new(sep.outputs['X'],scale.inputs[0]);ab=rn.new('ShaderNodeMath');ab.operation='ABSOLUTE';rl.new(scale.outputs[0],ab.inputs[0]);inv=rn.new('ShaderNodeMath');inv.operation='SUBTRACT';inv.inputs[0].default_value=1;rl.new(ab.outputs[0],inv.inputs[1]);pow=rn.new('ShaderNodeMath');pow.operation='POWER';pow.inputs[1].default_value=2;rl.new(inv.outputs[0],pow.inputs[0]);fac=rn.new('ShaderNodeMath');fac.operation='MULTIPLY';rl.new(pow.outputs[0],fac.inputs[0]);focus_driver(fac.inputs[1],'.15+.85*focus');emr=rn.new('ShaderNodeEmission');emr.inputs[0].default_value=(.015,.5,1,1);emr.inputs[1].default_value=4;trr=rn.new('ShaderNodeBsdfTransparent');mx=rn.new('ShaderNodeMixShader');rl.new(fac.outputs[0],mx.inputs[0]);rl.new(trr.outputs[0],mx.inputs[1]);rl.new(emr.outputs[0],mx.inputs[2]);oo=rn.new('ShaderNodeOutputMaterial');rl.new(mx.outputs[0],oo.inputs[0])
# Four actual morphing luminous filaments become clear reticle prongs in the YZ sight plane.
for k in range(4):
 angle=k*math.pi/2;orientation=-1 if -math.sin(angle)<-1e-6 else 1;vs=[];target=[]
 for j in range(13):
  t=j/12;half=.003+.006*math.sin(math.pi*t)
  idle=Vector((cx+.08*math.sin(t*6+k),.12*math.sin(t*7+k)*(1-t),anchor+t*.95));focused=Vector((cx,math.cos(angle)*(.075+t*.30),anchor+.62+math.sin(angle)*(.075+t*.30)))
  for side in [-1,1]:vs.append(tuple(idle+Vector((0,side*half,0))));target.append(tuple(focused+Vector((0,-math.sin(angle)*side*half*orientation,math.cos(angle)*side*half*orientation))))
 fs=[(j*2,j*2+1,j*2+3,j*2+2)for j in range(12)];o=mesh_obj('V16 flame reticle filament',vs,fs,reticle);uvl=o.data.uv_layers.new(name='Soft ribbon UV')
 for poly in o.data.polygons:
  for li in poly.loop_indices:
   vi=o.data.loops[li].vertex_index;uvl.data[li].uv=(vi%2,(vi//2)/12)
 o.shape_key_add(name='Idle flame');key=o.shape_key_add(name='Focused reticle')
 for v,co in zip(key.data,target):v.co=co
 fc=key.driver_add('value');fc.driver.expression='focus';v=fc.driver.variables.new();v.name='focus';v.type='SINGLE_PROP';v.targets[0].id_type='SCENE';v.targets[0].id=s;v.targets[0].data_path='["focus"]'
assert not any(o.type=='MESH'and not o.hide_render and any(m and m.name=='Soul flame atlas surface'for m in o.data.materials)for o in bpy.data.objects),'Old leaf-like flame material remains visible'
s.frame_end=100;s.frame_set(0);s.cycles.samples=40;s.cycles.use_denoising=False;s.camera.data.ortho_scale=13.5;bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'soul-storm-v16.blend'))
for name,f in [('idle',0),('focused',50)]:s.frame_set(f);s.render.filepath=str(R/(name+'.png'));bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'Unaccepted authoring prototype; native integration and complete QA open','new_objects':new,'launcher_length_multiplier_from_v15':1.25,'emitter_pitch':.72,'grip_centerline_height':1.74,'flame_frames':16,'focus':'Four geometric filaments morph into prongs; anchored fire fades but stays rooted','limits':['No first-person aim alignment acceptance','No native flame shader or gameplay binding','New grip and rebalance require spatial/hand QA','No claim of matching concept yet']},indent=2)+'\n')
