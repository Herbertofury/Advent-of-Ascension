# Soul Storm v16: unaccepted authoring prototype

Open soul-storm-v16.blend in Blender 4.3.2. It contains packed images. This is an authoring scene, not a playable TaCZ pack.

## Implemented in this scene
- Four-emitter proportion adjustment and a continuous curved grip.
- Rooted 16-frame fire atlas in a rounded brazier.
- Four geometric filaments that morph toward a focused reticle, with smooth intermediate focus values and a softly cleared center.
- Older rejected source geometry remains hidden for history.

## Evidence and limits
- 101 focus samples, 21 unique focus values, midpoint 0.5.
- All active visible evaluated geometry checked across 101 frames: 4,552,768 triangle samples; zero degenerate active triangles.
- 776 object/frame records were explicit zero-scale authoring projectiles and are listed separately. The unfiltered check flagged these intentionally inactive shapes; this is not proof of native projectile visibility.
- No continuous collision, hand fit, native aiming, GPU renderer, gameplay or artistic acceptance is implied.
- visual-review.json lists remaining concept-fidelity defects. The source is still too plain in several areas and is not approved as matching the target.

## Rebuilding
build.py expects sibling soul-storm-sculpt-v15/soul-storm-v15.blend and sibling soul-storm-design-v16/soul-flame-atlas-v4-padded.png. The published v15 source package provides the prior scene; the new packed scene can be inspected independently. Run with Blender --python-exit-code 1. check_morph.py and check_full_geometry.py work on the included v16 blend. render_focus.py and render_views.py generate evidence views.

The new fire has 16 frames. The existing 15-frame native sight helper is not compatible without an explicit adapter update and testing. Blender nodes/shape keys do not establish native renderer support.
