import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-v16.blend'));s=bpy.context.scene;rows=[];focus_values=[]
for frame in range(101):
 s.frame_set(frame);focus_values.append(float(s['focus']));dg=bpy.context.evaluated_depsgraph_get();bad=[]
 for o in bpy.data.objects:
  if not o.name.startswith('V16 ')or o.type not in {'MESH','CURVE'}or o.hide_render:continue
  e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles()
  for idx,t in enumerate(m.loop_triangles):
   pts=[o.matrix_world@m.vertices[v].co for v in t.vertices]
   if (pts[1]-pts[0]).cross(pts[2]-pts[0]).length_squared<1e-20:bad.append([o.name,idx])
  e.to_mesh_clear()
 if bad:rows.append({'frame':frame,'focus':s['focus'],'bad':bad})
assert len(set(round(v,6)for v in focus_values))>=15,'Focus snapped between states instead of morphing';assert abs(focus_values[25]-.5)<.01,'Midpoint morph missing'
(R/'focus-progress-qa.json').write_text(json.dumps({'samples':101,'unique_focus_values':len(set(round(v,6)for v in focus_values)),'midpoint':focus_values[25],'range':[min(focus_values),max(focus_values)],'native_acceptance':False},indent=2)+'\n')
(R/'morph-degeneracy.json').write_text(json.dumps(rows,indent=2)+'\n');print('Frames with degenerate new geometry:',len(rows));assert not rows,rows[:1]
