"""Compile the original engine-independent presentation core and run its tests."""
from pathlib import Path
import os,shutil,subprocess,tempfile
root=Path(__file__).resolve().parent
suffix='.exe'if os.name=='nt'else''
def tool(name):
 home=os.environ.get('JAVA_HOME');result=str(Path(home)/'bin'/(name+suffix))if home else shutil.which(name)
 if not result or not Path(result).is_file():raise SystemExit('Set JAVA_HOME to a full JDK')
 return result
javac,java=tool('javac'),tool('java');subprocess.run([javac,'-version'],check=True);subprocess.run([java,'-version'],check=True)
with tempfile.TemporaryDirectory(prefix='aoa-presentation-core-')as classes:
 subprocess.run([javac,'--release','17','-d',classes,*map(str,sorted((root/'src').rglob('*.java')))],check=True)
 runtimes=[java]
 extra=os.environ.get('SECONDARY_JAVA')
 if extra:
  if not Path(extra).is_file():raise SystemExit('SECONDARY_JAVA must name an existing Java executable')
  runtimes.append(extra)
 for runtime in runtimes:
  subprocess.run([runtime,'-version'],check=True)
  for name in ['AtlasLayoutTest','SoulSightFrameTest','ImpactVisualLedgerTest','EmissionClockTest','FrameVisibilitySetTest']:
   subprocess.run([runtime,'-cp',classes,'dev.herbertofury.armory.presentation.'+name],check=True)
