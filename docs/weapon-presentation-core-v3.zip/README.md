# Weapon presentation core — engine-independent source study

One original Java 17 source package containing the tested Soul Sight frame sampler, branch-aware cosmetic event ledger a per-emitter game-time emission clock and a pre-bound discrete-frame visibility selector. This consolidates the reusable primitives; earlier standalone source studies remain available for provenance.

**Not a Forge/NeoForge mod, TaCZ gunpack, native adapter or performance benchmark.** There are no game dependencies or hooks. Do not put this source ZIP in a Mods folder.

## Components and boundaries

### SoulSightFrame

Preserves the legacy 15-frame/two-second default and adds an explicit immutable Atlas contract. ROOTED_FIRE_16 selects all sixteen cells of the padded 2048×2048 four-by-four atlas at six frames/second, with a half-texel UV inset. Coordinates use a top-origin image convention; a native renderer must explicitly convert orientation if needed. Do not infer the layout from a filename or silently change Candle to the new flame atlas. Sampling uses caller-supplied paused game time. Explicit sight/pass gates suppress the flame for Gem/shadow views and require GUI opt-in. A caller-owned output is cleared before sampling. Reduced motion selects a stable frame. Bone offsets, textures, buffers, blending and native pause/camera integration remain the adapter's job.

### ImpactVisualLedger

Keeps a finite cosmetic identity window keyed by world generation, actor, weapon instance, burst, pellet, impact ordinal and weapon/projectile branch. This preserves distinct intended branches while rejecting a repeated logical visual event inside the window. Evicted keys can be accepted again: it is not permanent replay prevention, authentication or gameplay damage validation.

Invoke it once at a logical-event dispatch boundary, then fan out to all configured cosmetic channels. Do not call separately for every camera, particle or shader pass. Caller-supplied identities and world-reset generations must be valid. Use it only on its owning presentation thread.

### EmissionClock

Schedules bounded cosmetic requests from paused game/presentation time. Repeated timestamps emit nothing. Each emitter owns its state; there is no shared-renderer color/timer state or inventory scan. Hidden/disabled periods clear fractional carry, and returning to visibility rebases time without a catch-up burst. The adapter must notify the clock when emission stops; invisibility cannot be inferred from silence alone.

Large stalls are clamped to a configured elapsed-time allowance and per-update cap. Excess whole emissions are deliberately discarded, not stored as an ever-growing backlog. This is a visual quality/performance policy to evaluate, not a promise of unchanged appearance at every frame rate. Never use it to schedule gameplay projectiles or damage.

The 40-requests/second rate in tests is a mathematical fixture, not a chosen production particle budget for Hive Blaster or any other weapon. All original colors, silhouette, trail richness and target readability still need native visual review.

### FrameVisibilitySet

Owns a pre-bound collection of discrete frame parts. Validate actual native-part identities before touching any target; duplicate identities are rejected even if wrapped by different callbacks. Initialization hides the set once. A repeated frame performs no visibility writes; changing frames hides the previous part and shows the next. Invalid indices hide the current frame and fail; close hides it and rejects further selection. No bone search or normal-path allocation occurs in select/hide.

Bind once per resource generation on one presentation thread, and use the actual part object as each Binding identity. Callbacks must be nonthrowing cosmetic visibility assignments. Nobody else may mutate this owned set's visibility. The adapter is responsible for asset reloads, correct per-pass selection and not accidentally hiding unrelated model parts. This helper does not implement native bone lookup or rendering.

It selects one discrete frame and does not blend the SoulSightFrame output's next/mix values. A crossfading design needs a different explicitly tested material/visibility policy. Do not silently replace an accepted blended effect with this discrete fallback.

## Reproduce

Set JAVA_HOME to a full JDK and run `python run_tests.py`. It compiles all source/tests with `--release 17` in a disposable directory and runs the five standalone test mains. Set SECONDARY_JAVA to another existing Java executable to test the same compiled classes on another runtime. Only the selected Java tools run; game classes are not loaded.

Recorded verification used a full Corretto 17 compiler/runtime and the installed OpenJDK 21 runtime. This tests the pure core on those JVMs, not Minecraft 1.20.1/1.21.1 API compatibility.

Coverage includes:
- Sight/pass/GUI combinations, 100,000 atlas samples, loop/paused-time/invalid-input cases and separate outputs.
- Four pellets × two cosmetic branches, repeated events, actor/weapon/world separation and 10,000 events in a bounded ledger.
- Simulated 20, 30, 60, 144, 240, 1000 and 2000 Hz updates producing the same 400 scheduled requests over ten game-time seconds, with duplicate timestamps, pauses, hidden/resume transitions, stalls, resets and invalid inputs.

## Native work remaining

Resolve the authoritative item/attachment state; supply the correct game clock and identities; integrate the renderer/particle pool with resource reload and visibility lifecycle; preserve per-pass drawing without re-emitting effects; implement LOD/material fallbacks; test real hands, target visibility, shaders/Vulkan and multiplayer. Measure actual allocations, particle counts, frame times and memory in game before making performance claims. Authoritative damage and resources stay outside this presentation package.

## v3 layout regression coverage

The explicit-layout test exercises 100,000 samples, all sixteen frames, last-to-first wrapping, the exact cycle boundary and its preceding representable double, reduced motion, repeated paused timestamps, hidden Gem pass, null/invalid layouts and very large finite time. The blend factor is clamped below one to prevent float rounding from producing an out-of-contract endpoint. The older sight, ledger, scheduler and visibility tests are retained.

A 16-frame layout removes one source-level mismatch with the new authoring atlas. It does not implement the native focus morph, shader, crossfade, mesh parts, alignment, materials or game hooks. Native integration remains open.
