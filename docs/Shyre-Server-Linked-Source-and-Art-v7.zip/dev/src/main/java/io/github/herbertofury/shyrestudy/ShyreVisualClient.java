package io.github.herbertofury.shyrestudy;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.GsonBuilder;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.logging.LogUtils;
import com.mojang.math.Axis;
import com.tacz.guns.api.client.animation.AnimationController;
import com.tacz.guns.api.client.animation.Animations;
import com.tacz.guns.api.client.animation.ObjectAnimation;
import com.tacz.guns.client.model.BedrockAnimatedModel;
import com.tacz.guns.client.model.functional.LeftHandRender;
import com.tacz.guns.client.model.functional.RightHandRender;
import com.tacz.guns.client.resource.pojo.animation.bedrock.AnimationKeyframes;
import com.tacz.guns.client.resource.pojo.animation.bedrock.BedrockAnimationFile;
import com.tacz.guns.client.resource.pojo.model.BedrockModelPOJO;
import com.tacz.guns.client.resource.pojo.model.BedrockVersion;
import com.tacz.guns.client.resource.pojo.model.CubesItem;
import com.tacz.guns.client.resource.serialize.AnimationKeyframesSerializer;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.io.InputStreamReader;
import java.util.List;

/** Client-only visual probe. F8 is a manual motion test, never a firing command. */
@Mod.EventBusSubscriber(modid = ShyreStudy.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ShyreVisualClient {
    private static final Logger LOG = LogUtils.getLogger();
    private static final ResourceLocation SHYRE = new ResourceLocation("aoa3", "shyre_blaster");
    private static final ResourceLocation TEXTURE = id("textures/shyre_basecolor.png");
    private static final String CLIP = "animation.ascension_armory.shyre_fire_candidate";
    private static final KeyMapping PREVIEW = new KeyMapping("key.shyre_study.motion", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F8, "key.categories.shyre_study");
    private static final KeyMapping TOGGLE = new KeyMapping("key.shyre_study.toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F7, "key.categories.shyre_study");
    private static final Gson GSON = new GsonBuilder()
        .registerTypeAdapter(CubesItem.class, new CubesItem.Deserializer())
        .registerTypeAdapter(AnimationKeyframes.class, new AnimationKeyframesSerializer()).create();
    private static VisualModel model;
    private static AnimationController animation;
    private static ShyreMeshBridge mesh;
    private static boolean shapeLogged;
    private static ViewFit view;
    private static boolean enabled = true;
    private static final PreviewLifecycle lifecycle = new PreviewLifecycle();
    private static boolean paused;
    private static final ShotSignalGate shotSignals = new ShotSignalGate();
    private static Object signalLevel;

    public static void confirmedShot(ShyreShotCosmetics.Shot shot) {
        Minecraft mc = Minecraft.getInstance();
        if (signalLevel != mc.level) { shotSignals.clear(); signalLevel = mc.level; }
        boolean valid = mc.player != null && mc.level != null && eligible(mc)
            && SHYRE.equals(BuiltInRegistries.ITEM.getKey(mc.player.getMainHandItem().getItem()))
            && mc.player.getUUID().equals(shot.player()) && mc.level.dimension().location().equals(shot.dimension())
            && shot.slot() == mc.player.getInventory().selected && mc.screen == null
            && !mc.isPaused() && model != null && animation != null;
        if (shotSignals.accept(shot.sequence(), shot.tick(), mc.level == null ? -1 : mc.level.getGameTime(), valid)) {
            try { animation.runAnimation(0, CLIP, ObjectAnimation.PlayType.PLAY_ONCE_STOP, 0f); }
            catch (RuntimeException | LinkageError failure) {
                LOG.error("Shyre cosmetic motion failed; original item behavior is unchanged", failure);
                return;
            }
            LOG.info("SHYRE_COSMETIC accepted_server_return sequence={} tick={} slot={}", shot.sequence(), shot.tick(), shot.slot());
        }
    }

    private static ResourceLocation id(String path) { return new ResourceLocation(ShyreStudy.MOD_ID, path); }
    private static boolean target(ItemStack stack) {
        return stack.is(ShyreStudy.PREVIEW.get()) || SHYRE.equals(BuiltInRegistries.ITEM.getKey(stack.getItem()));
    }
    private static boolean eligible(Minecraft mc) {
        return enabled && mc.player != null && mc.player.getMainArm() == HumanoidArm.RIGHT
            && mc.player.getOffhandItem().isEmpty() && target(mc.player.getMainHandItem());
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        while (TOGGLE.consumeClick()) enabled = !enabled;
        if (signalLevel != mc.level) { shotSignals.clear(); signalLevel = mc.level; }
        boolean held = eligible(mc);
        boolean reset = lifecycle.update(held, mc.level, mc.player == null ? -1 : mc.player.getInventory().selected,
            mc.player == null ? "" : BuiltInRegistries.ITEM.getKey(mc.player.getMainHandItem().getItem()).toString());
        if (animation != null && reset) {
            animation.removeAnimation(0);
            model.cleanAnimationTransform();
        }
        if (animation != null) {
            var runner = animation.getAnimation(0);
            if (runner != null && mc.isPaused() != paused) {
                if (mc.isPaused()) runner.pause(); else if (paused && runner.isPausing()) runner.run();
            }
        }
        paused = mc.isPaused();
        while (PREVIEW.consumeClick()) {
            if (held && enabled && !paused && mc.screen == null && animation != null) {
                animation.runAnimation(0, CLIP, ObjectAnimation.PlayType.PLAY_ONCE_STOP, 0f);
            }
        }
    }

    @SubscribeEvent
    public static void render(RenderHandEvent event) {
        Minecraft mc = Minecraft.getInstance();
        // Left-main-arm and offhand placement remain intentionally on the original renderer.
        if (!eligible(mc) || model == null || animation == null
                || event.getHand() != InteractionHand.MAIN_HAND || !target(event.getItemStack())) return;
        var pose = event.getPoseStack();
        pose.pushPose();
        boolean completed = false;
        try {
            pose.translate(view.x(), view.y(), view.z());
            pose.mulPose(Axis.ZP.rotationDegrees(view.roll()));
            pose.mulPose(Axis.YP.rotationDegrees(view.yaw()));
            pose.mulPose(Axis.XP.rotationDegrees(view.pitch()));
            pose.scale(view.scale(), view.scale(), view.scale());
            model.cleanAnimationTransform();
            animation.update();
            model.applyPlayerShape("slim".equals(mc.player.getModelName()));
            mesh.render(pose, mc.renderBuffers().bufferSource(), TEXTURE, event.getPackedLight(), OverlayTexture.NO_OVERLAY);
            model.render(pose, ItemDisplayContext.FIRST_PERSON_RIGHT_HAND,
                RenderType.entityCutout(TEXTURE), event.getPackedLight(), OverlayTexture.NO_OVERLAY);
            if (!shapeLogged) {
                LOG.info("Shyre native visual probe rendered with player model {}", mc.player.getModelName());
                shapeLogged = true;
            }
            completed = true;
        } catch (RuntimeException | LinkageError failure) {
            LOG.error("Shyre visual probe disabled after render failure; original item behavior is unchanged", failure);
            if (mesh != null) mesh.close();
            mesh = null;
            model = null;
            animation = null;
        } finally {
            pose.popPose();
        }
        if (completed) event.setCanceled(true);
    }

    private static final class VisualModel extends BedrockAnimatedModel {
        private final JsonObject armFit;
        VisualModel(BedrockModelPOJO data, JsonObject armFit) {
            super(data, BedrockVersion.NEW);
            this.armFit = armFit;
            setFunctionalRenderer("lefthand_pos", part -> new LeftHandRender(this));
            setFunctionalRenderer("righthand_pos", part -> new RightHandRender(this));
        }
        void applyPlayerShape(boolean slim) {
            for (String name : List.of("lefthand_pos", "righthand_pos")) {
                var point = getNode(name);
                var values = armFit.getAsJsonArray(name);
                point.setPos(slim ? values.get(0).getAsFloat() : 0,
                    slim ? values.get(1).getAsFloat() : 0, slim ? values.get(2).getAsFloat() : 0);
            }
        }
        @Override public boolean getRenderHand() { return true; }
    }

    private record Prepared(JsonObject geometry, BedrockAnimationFile motion, JsonObject armFit, JsonObject viewFit) {}
    private static final class Reload extends SimplePreparableReloadListener<Prepared> {
        private <T> T read(ResourceManager resources, String path, Class<T> type) throws Exception {
            try (Reader reader = new InputStreamReader(resources.getResourceOrThrow(id(path)).open(), StandardCharsets.UTF_8)) {
                return GSON.fromJson(reader, type);
            }
        }
        @Override protected Prepared prepare(ResourceManager resources, ProfilerFiller profiler) {
            try {
                return new Prepared(read(resources, "geo_models/shyre.geo.json", JsonObject.class),
                    read(resources, "animations/shyre.animation.json", BedrockAnimationFile.class),
                    read(resources, "arm_fit.json", JsonObject.class), read(resources, "view_fit.json", JsonObject.class));
            } catch (Exception failure) {
                LOG.error("Shyre visual resources unavailable; original renderer will remain active", failure);
                return null;
            }
        }
        @Override protected void apply(Prepared data, ResourceManager resources, ProfilerFiller profiler) {
            if (mesh != null) mesh.close();
            mesh = null;
            model = null;
            animation = null;
            shapeLogged = false;
            lifecycle.clear();
            paused = false;
            if (data == null) return;
            try {
                ViewFit candidateView = ViewFit.parse(data.viewFit());
                VisualModel candidate = new VisualModel(GSON.fromJson(data.geometry(), BedrockModelPOJO.class), data.armFit());
                AnimationController controller = Animations.createControllerFromBedrock(data.motion(), candidate);
                if (!controller.containPrototype(CLIP)) throw new IllegalArgumentException("Missing original motion clip");
                controller.setUpdatingTrackArray(List.of(0));
                ShyreMeshBridge candidateMesh = new ShyreMeshBridge(candidate, data.geometry());
                view = candidateView;
                mesh = candidateMesh;
                model = candidate;
                animation = controller;
                LOG.info("Loaded Shyre original visuals with server-return cosmetic motion; no full gameplay or art acceptance");
            } catch (RuntimeException | LinkageError failure) {
                LOG.error("Shyre probe setup failed; original renderer will remain active", failure);
            }
        }
    }

    @Mod.EventBusSubscriber(modid = ShyreStudy.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class Registration {
        @SubscribeEvent public static void keys(RegisterKeyMappingsEvent event) {
            event.register(PREVIEW);
            event.register(TOGGLE);
        }
        @SubscribeEvent public static void resources(RegisterClientReloadListenersEvent event) {
            event.registerReloadListener(new Reload());
        }
    }
}
