#!/usr/bin/env python3
"""Compile small original state/configuration tests with the same verified Java 17."""
from pathlib import Path
import json
import subprocess
import hashlib
import os
import shutil

root = Path(__file__).resolve().parent
tools = root.parent / "toolchains"
java = Path(os.environ["JAVA_HOME"]) / "bin" if os.environ.get("JAVA_HOME") else tools / "amazon-corretto-17.0.20.12.1-linux-x64/bin"
gson = tools / "gradle-home/caches/forge_gradle/maven_downloader/com/google/code/gson/gson/2.10/gson-2.10.jar"
gson = Path(os.environ.get("GSON_JAR", str(gson)))
sources = root / "dev/src/main/java/io/github/herbertofury/shyrestudy"
out = root / "tests/classes"
out.mkdir(exist_ok=True)
files = [sources / "PreviewLifecycle.java", sources / "ViewFit.java", sources / "ShotSignalGate.java", root / "tests/ShotSignalGateTest.java",
         root / "tests/PreviewLifecycleTest.java", root / "tests/ViewFitTest.java"]
subprocess.run([str(java / "javac"), "-cp", str(gson), "-d", str(out), *map(str, files)], check=True)
results = []
for name in ("PreviewLifecycleTest", "ViewFitTest", "ShotSignalGateTest"):
    result = subprocess.run([str(java / "java"), "-cp", f"{out}:{gson}",
                             "io.github.herbertofury.shyrestudy." + name],
                            check=True, text=True, capture_output=True)
    print(result.stdout.strip())
    results.append({"test": name, "stdout": result.stdout.strip()})
(root / "unit-checks.json").write_text(json.dumps({
    "scope": "Pure state/configuration tests, not native gameplay acceptance",
    "results": results,
    "source_sha256": {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
}, indent=2) + "\n")
