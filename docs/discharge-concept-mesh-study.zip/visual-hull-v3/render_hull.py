import bpy,bmesh,math,json
import numpy as np
from pathlib import Path
from mathutils import Matrix,Vector
R=Path(__file__).resolve().parent;d=np.load(R/'hull.npz');bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);v=d['vertices'];f=d['faces'];origins=d['camera_origins'];rotations=d['camera_rotations'];fx=.5/math.tan(math.radians(36)/2)
me=bpy.data.meshes.new('Local visual hull');me.from_pydata(v.tolist(),[],f.tolist());me.update();obj=bpy.data.objects.new('Discharge_preview_visual_hull_NOT_original_mesh',me);bpy.context.collection.objects.link(obj)
for p in me.polygons:p.use_smooth=True
for i in range(8):
 m=bpy.data.materials.new('Projected preview view '+str(i));m.use_nodes=True;n=m.node_tree.nodes;n.clear();tex=n.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(R.parent/'preview-views'/f'basecolor-{i:02}.jpg'));tex.interpolation='Linear';em=n.new('ShaderNodeEmission');out=n.new('ShaderNodeOutputMaterial');m.node_tree.links.new(tex.outputs['Color'],em.inputs['Color']);m.node_tree.links.new(em.outputs[0],out.inputs['Surface']);me.materials.append(m)
centers=v[f].mean(axis=1);norm=np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]]);norm/=np.maximum(np.linalg.norm(norm,axis=1,keepdims=True),1e-9);scores=[]
for origin in origins:
 to=origin-centers;to/=np.linalg.norm(to,axis=1,keepdims=True);scores.append(np.einsum('ij,ij->i',norm,to))
smooth=d['normals'][f].mean(axis=1);choice=np.where(centers[:,1]>=0,0,4);choice[(centers[:,0]>.40)&(smooth[:,0]>.5)]=2;choice[(centers[:,0]<-.40)&(smooth[:,0]<-.5)]=6;uv=me.uv_layers.new(name='PreviewProjection')
for p,i in zip(me.polygons,choice):
 p.material_index=int(i);q=(v[f[p.index]]-origins[i])@rotations[i].T;coords=q[:,:2]/q[:,2:3]*fx+.5
 for li,co in zip(p.loop_indices,coords):uv.data[li].uv=(float(co[0]),float(1-co[1]))
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=16;s.cycles.use_denoising=False;s.render.resolution_x=s.render.resolution_y=1024;s.render.film_transparent=True;s.view_settings.view_transform='Standard';s.view_settings.look='Medium High Contrast'if 'Medium High Contrast'in [] else'None';s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs['Strength'].default_value=0
bpy.ops.object.camera_add();cam=bpy.context.object;cam.data.type='PERSP';cam.data.angle=math.radians(36);cam.data.clip_start=.1;cam.data.clip_end=10;s.camera=cam
for i in range(8):
 mat=np.eye(4);mat[:3,:3]=np.stack([rotations[i][0],-rotations[i][1],-rotations[i][2]],axis=1);mat[:3,3]=origins[i];cam.matrix_world=Matrix(mat.tolist());s.render.filepath=str(R/f'projection-{i:02}.png');bpy.ops.render.render(write_still=True)
mat=np.eye(4);mat[:3,:3]=np.stack([rotations[0][0],-rotations[0][1],-rotations[0][2]],axis=1);mat[:3,3]=origins[0];cam.matrix_world=Matrix(mat.tolist());bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'local-preview-hull.blend'))
bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj;bpy.ops.export_scene.gltf(filepath=str(R/'local-preview-hull.glb'),export_format='GLB',use_selection=True)
