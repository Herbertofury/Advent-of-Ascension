"""Local silhouette reconstruction from authorized preview images, NOT the original TRELLIS mesh."""
import sys,json,math,time
from pathlib import Path
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parents[1]/'toolchains/geometry-science'))
import numpy as np
from PIL import Image
from scipy import ndimage
from skimage.measure import marching_cubes
N=256;bound=.55;step=2*bound/(N-1);axis=np.linspace(-bound,bound,N,dtype=np.float32);points=np.stack(np.meshgrid(axis,axis,axis,indexing='ij'),axis=-1).reshape(-1,3);occupied=np.ones(len(points),bool);cameras=[];masks=[];colors=[];normal_images=[];fx=.5/math.tan(math.radians(36)/2);start=time.time()
for i in range(8):
 yaw=2*math.pi*i/8-math.radians(16);pitch=math.radians(20);origin=2*np.array([math.sin(yaw)*math.cos(pitch),math.cos(yaw)*math.cos(pitch),math.sin(pitch)],np.float32);forward=-origin/np.linalg.norm(origin);right=np.cross(forward,[0,0,1]);right/=np.linalg.norm(right);down=np.cross(forward,right);rotation=np.array([right,down,forward],np.float32);cameras.append((origin,rotation))
 normal=np.array(Image.open(R.parent/'preview-views'/f'normal-{i:02}.jpg').convert('RGB'));mask=np.max(np.abs(normal.astype(np.int16)-127),axis=2)>20;mask=ndimage.binary_dilation(mask,iterations=1);masks.append(mask);normal_images.append(normal);colors.append(np.array(Image.open(R.parent/'preview-views'/f'basecolor-{i:02}.jpg').convert('RGB')));h,w=mask.shape
 q=(points-origin)@rotation.T;uv=(q[:,:2]/q[:,2:3]*fx+.5)*[w,h]-.5;pix=np.rint(uv).astype(np.int32);valid=(q[:,2]>0)&(pix[:,0]>=0)&(pix[:,0]<w)&(pix[:,1]>=0)&(pix[:,1]<h);keep=np.zeros(len(points),bool);keep[valid]=mask[pix[valid,1],pix[valid,0]];occupied&=keep;print('view',i,'remaining',int(occupied.sum()),flush=True)
assert occupied.any(),'Camera calibration produced an empty hull'
field=occupied.reshape(N,N,N);field[[0,-1],:,:]=False;field[:,[0,-1],:]=False;field[:,:,[0,-1]]=False
verts,faces,_,_=marching_cubes(ndimage.gaussian_filter(field.astype(np.float32),sigma=.5),level=.5,spacing=(step,step,step),allow_degenerate=False);verts-=bound
volume=np.sum(np.einsum('ij,ij->i',verts[faces[:,0]],np.cross(verts[faces[:,1]],verts[faces[:,2]])))/6
if volume<0:faces=faces[:,[0,2,1]]
face_normals=np.cross(verts[faces[:,1]]-verts[faces[:,0]],verts[faces[:,2]]-verts[faces[:,0]]);normals=np.zeros_like(verts)
for k in range(3):np.add.at(normals,faces[:,k],face_normals)
normals/=np.maximum(np.linalg.norm(normals,axis=1,keepdims=True),1e-12);color_sum=np.zeros_like(verts);weight_sum=np.zeros(len(verts),np.float32);best=np.full(len(verts),-1,np.float32);fallback=np.zeros_like(verts);transfer=np.zeros_like(verts)
for i,(origin,rotation)in enumerate(cameras):
 q=(verts-origin)@rotation.T;h,w=masks[i].shape;uv=(q[:,:2]/q[:,2:3]*fx+.5)*[w,h]-.5;xx=np.clip(np.rint(uv[:,0]).astype(int),0,w-1);yy=np.clip(np.rint(uv[:,1]).astype(int),0,h-1);view=origin-verts;view/=np.linalg.norm(view,axis=1,keepdims=True);facing=np.maximum(np.einsum('ij,ij->i',normals,view),0)
 _,nearest=ndimage.distance_transform_edt(~masks[i],return_indices=True);inside=masks[i][yy,xx];sx=np.where(inside,xx,nearest[1,yy,xx]);sy=np.where(inside,yy,nearest[0,yy,xx]);rgb=colors[i][sy,sx]/255.0
 depth=np.full((h,w),np.inf,np.float32);np.minimum.at(depth,(yy,xx),q[:,2]);depth=ndimage.minimum_filter(depth,size=9);visible=q[:,2]<=depth[yy,xx]+step*3;weight=facing**6*visible
 color_sum+=rgb*weight[:,None];weight_sum+=weight
 choose=facing>best;best[choose]=facing[choose];fallback[choose]=rgb[choose]
 nc=1-2*normal_images[i][sy,sx].astype(np.float32)/255;wn=nc@rotation;wn/=np.maximum(np.linalg.norm(wn,axis=1,keepdims=True),1e-12);transfer[choose]=wn[choose]
color=np.where((weight_sum>1e-8)[:,None],color_sum/np.maximum(weight_sum[:,None],1e-8),fallback);transfer=np.where((np.einsum('ij,ij->i',transfer,normals)>.15)[:,None],transfer,normals)
np.savez_compressed(R/'hull.npz',vertices=verts,faces=faces,normals=normals,preview_normals=transfer,colors=color,camera_origins=np.array([x[0]for x in cameras]),camera_rotations=np.array([x[1]for x in cameras]))
report={'method':'Original local visual-hull approximation from eight authorized preview silhouettes','not_original_trellis_mesh':True,'grid':N,'vertices':len(verts),'triangles':len(faces),'occupied_voxels':int(occupied.sum()),'seconds':time.time()-start,'camera_assumption':{'yaw_offset_degrees':-16,'pitch_degrees':20,'radius':2,'fov_degrees':36,'source':'https://raw.githubusercontent.com/microsoft/TRELLIS.2/main/trellis2/utils/render_utils.py'},'limits':['Concavities not constrained by silhouettes are missing','JPEG previews do not recover original PBR maps or original topology','Camera calibration still needs reprojection verification','No rig, native export or gameplay acceptance']};(R/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
