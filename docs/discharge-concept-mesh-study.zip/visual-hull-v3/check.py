import sys,json
from pathlib import Path
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R.parents[1]/'toolchains/geometry-science'))
import numpy as np
from PIL import Image
rows=[]
for i in range(8):
 normal=np.asarray(Image.open(R.parent/'preview-views'/f'normal-{i:02}.jpg').convert('RGB')).astype(np.int16)
 target=np.max(abs(normal-127),axis=2)>20
 actual=np.asarray(Image.open(R/f'projection-{i:02}.png'))[:,:,3]>127
 rows.append({'view':i,'silhouette_iou':float((target&actual).sum()/(target|actual).sum()),'extra_pixels':int((actual&~target).sum()),'missing_pixels':int((target&~actual).sum())})
d=np.load(R/'hull.npz');v=d['vertices'];f=d['faces'];area=np.linalg.norm(np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]]),axis=1)/2
edges=np.sort(np.concatenate([f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]]),axis=1);_,counts=np.unique(edges,axis=0,return_counts=True)
report={'scope':'Observed camera silhouette and geometric validity only. High overlap does not prove texture, concept or gameplay quality.','views':rows,'vertices':len(v),'triangles':len(f),'nonfinite_vertices':int((~np.isfinite(v)).sum()),'degenerate_triangles':int((area<1e-12).sum()),'boundary_edges':int((counts==1).sum()),'nonmanifold_edges':int((counts>2).sum()),'accepted':False,'visual_defects':['Projected texture tears and doubled details on front/oblique views','Silhouette intersection cannot reconstruct internal cavities','Missing authored component separation and rigging','No independent PBR textures, native implementation or playtest'],'decision':'Retain as reference volume only; do not ship as a finished weapon.'}
(R/'reprojection-qa.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
