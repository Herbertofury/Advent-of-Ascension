# Concept-to-mesh trial

The original owner-selected Discharge concept remains canonical and unchanged. These derived cutouts are reconstruction inputs, not replacement concepts or in-game captures. Both were prepared with the built-in image tool.

- discharge-isolated-v1.png: rejected for clipped/tight upper and lower framing.
- discharge-isolated-v2.png: complete weapon in a wider-height frame; alpha is present but includes a soft glow. Suitable only for an initial reconstruction trial, not automatically accepted as exact canonical art.
- Trial service: Microsoft's official TRELLIS.2 Space, https://huggingface.co/spaces/microsoft/TRELLIS.2 . The visible service notice says uploads are temporarily cached on Hugging Face and deleted after the session; no sensitive material was supplied.

## First extraction prompt

Use case: background-extraction. Asset type: isolated reference input for 3D reconstruction of a fictional game weapon. Edit target: the attached Discharge Shotgun concept sheet. Extract ONLY the large main weapon in row A, labeled Core Discharge Scattercaster, from the upper-left/center portion of the sheet. Preserve that exact weapon's silhouette, proportions, camera angle, red/white/black palette, intricate shaped ceramic armor, two raised capacitor fins, exposed red energy chamber, black curved grip, trigger guard, rear assembly, three-front-channel muzzle and all small ornamental details. Do not redesign or simplify it. Remove all text, sheet borders, labels, inset illustrations, other guns, projectiles, smoke and background. Produce one clean high-detail isolated weapon with a genuine transparent background and transparent negative spaces through its trigger guard and open cutouts. Keep the full muzzle and grip inside the frame with modest clear margins. No floor shadow, no added effects, no new components. This is preparation of the chosen concept, not a new concept or an in-game screenshot.

## Framing correction prompt

Use case: background-extraction. Edit image 1 (the isolated Discharge weapon). Image 2 is the original approved concept sheet for restoring any clipped extremities. Keep the exact isolated row-A weapon design, colors, shapes, materials, camera angle and detail unchanged. Correct only framing: use a 3:2 landscape transparent canvas, with the COMPLETE weapon centered at no more than 80 percent of canvas width. Give at least 10 percent transparent margin at the left and right and ample transparent space above and below. The upper tips of BOTH capacitor fins and the entire bottom of the grip must be fully visible and not touch the canvas. Restore any tiny clipped fin tips from row A of image 2. Preserve genuine alpha transparency including all cutouts. No text, no floor, no shadow, no additional effects, no other weapon, no new design. This is a clean reference cutout for image-to-3D reconstruction, not a redesign.

Any resulting mesh requires concept comparison, cleanup, topology/UV/normal checks, separation and rigging, LOD work, compatible material export and actual native testing. Generated appearance is not acceptance.
