import json,hashlib
from pathlib import Path
from huggingface_hub import hf_hub_download,model_info
R=Path(__file__).resolve().parent;meta=json.loads((R/'model-metadata.json').read_text());revision=meta['sha'];info=model_info('stabilityai/TripoSR',revision=revision,files_metadata=True,token=False);records=[]
for name in ['config.yaml','model.ckpt']:
 path=Path(hf_hub_download('stabilityai/TripoSR',filename=name,revision=revision,local_dir=R/'model',token=False));h=hashlib.sha256(path.read_bytes()).hexdigest();entry=next(x for x in info.siblings if x.rfilename==name);lfs=getattr(entry,'lfs',None);expected=lfs.get('sha256')if isinstance(lfs,dict)else getattr(lfs,'sha256',None)
 if expected:assert h==expected,name
 records.append({'file':name,'bytes':path.stat().st_size,'sha256':h,'verified_lfs_sha256':expected});print(name,path.stat().st_size,h,flush=True)
(R/'download-receipt.json').write_text(json.dumps({'model':'stabilityai/TripoSR','revision':revision,'files':records},indent=2)+'\n')
