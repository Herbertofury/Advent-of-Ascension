"""Explicit CPU extraction adapter using scikit-image; this is not torchmcubes."""
import torch
from skimage.measure import marching_cubes as skimage_marching_cubes

def marching_cubes(field,level):
    vertices,faces,_,_=skimage_marching_cubes(field.detach().cpu().numpy(),level=level,gradient_direction='ascent',allow_degenerate=False)
    # TripoSR flips the native extractor's z/y/x positions back to x/y/z.
    # Supply that expected order; the wrapper's second flip restores scikit-image coordinates.
    return torch.from_numpy(vertices[:,[2,1,0]].copy()),torch.from_numpy(faces.astype('int64').copy())
