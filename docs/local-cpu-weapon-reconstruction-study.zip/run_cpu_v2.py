"""One controlled CPU reconstruction study. Output is unaccepted reference geometry."""
from pathlib import Path
import sys,types,time,json,hashlib,argparse
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'source'))
import cpu_surface_adapter
adapter=types.ModuleType('torchmcubes');adapter.marching_cubes=cpu_surface_adapter.marching_cubes;sys.modules['torchmcubes']=adapter
import torch,numpy as np
from PIL import Image
import rembg
from tsr.system import TSR
from tsr.utils import resize_foreground
start=time.monotonic();torch.set_num_threads(4)
parser=argparse.ArgumentParser();parser.add_argument('--input',type=Path,required=True);parser.add_argument('--out',type=Path,required=True);parser.add_argument('--name',required=True);args=parser.parse_args();source=args.input;O=args.out;O.mkdir(parents=True,exist_ok=True)
print('Preprocess source input',flush=True)
rgba=Image.open(source).convert('RGBA')
if rgba.getchannel('A').getextrema()[0]==255:
 session=rembg.new_session('u2net',providers=['CPUExecutionProvider']);rgba=rembg.remove(rgba,session=session)
rgba.save(O/'segmented-input.png');rgba=resize_foreground(rgba,.85);pixels=np.asarray(rgba).astype(np.float32)/255;rgb=pixels[:,:,:3]*pixels[:,:,3:4]+.5*(1-pixels[:,:,3:4]);im=Image.fromarray(np.clip(rgb*255,0,255).astype(np.uint8));im.save(O/'model-input.png')
print('Load pinned model; PyTorch safe weight loading default remains enabled',flush=True)
model=TSR.from_pretrained(str(R/'model'),config_name='config.yaml',weight_name='model.ckpt');model.renderer.set_chunk_size(2048);model.eval()
print('CPU inference',flush=True)
with torch.inference_mode():codes=model([im],device='cpu')
torch.save(codes.cpu(),O/'scene-codes.pt')
print('Extract 128-grid reference mesh with documented CPU adapter',flush=True)
mesh=model.extract_mesh(codes,has_vertex_color=True,resolution=128)[0]
mesh.export(O/(args.name+'-reference.glb'));mesh.export(O/(args.name+'-reference.ply'))
report={'status':'unaccepted reconstruction reference','source_image_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'model_revision':json.loads((R/'model-metadata.json').read_text())['sha'],'backend':'CPU; scikit-image extraction adapter instead of torchmcubes','grid_resolution':128,'vertices':len(mesh.vertices),'triangles':len(mesh.faces),'watertight':bool(mesh.is_watertight),'signed_volume':float(mesh.volume),'degenerate_faces':int(np.sum(mesh.area_faces<=1e-12)),'bounds':mesh.bounds.tolist(),'elapsed_seconds':time.monotonic()-start,'native_tested':False,'limits':['Single-image reconstruction can invent hidden geometry','No part ownership, hand fit, rig, animations or native export acceptance','Vertex colors are not a finished material/texture set','Visual and topology review required before any use']};(O/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
