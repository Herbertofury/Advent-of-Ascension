"""Reuse saved scene code to compare extraction resolution without another image inference."""
from pathlib import Path
import sys,types,time,json,hashlib
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'source'));import cpu_surface_adapter
adapter=types.ModuleType('torchmcubes');adapter.marching_cubes=cpu_surface_adapter.marching_cubes;sys.modules['torchmcubes']=adapter
import torch,numpy as np
from tsr.system import TSR
O=R/'apoco-run-256';O.mkdir(exist_ok=True);torch.set_num_threads(4);start=time.monotonic();codes_file=R/'apoco-run-v1/scene-codes.pt';codes=torch.load(codes_file,map_location='cpu',weights_only=True);print('Load pinned model and reuse existing scene code',flush=True);model=TSR.from_pretrained(str(R/'model'),config_name='config.yaml',weight_name='model.ckpt');model.renderer.set_chunk_size(2048);model.eval();print('Extract 256 grid',flush=True)
with torch.inference_mode():mesh=model.extract_mesh(codes,has_vertex_color=True,resolution=256)[0]
mesh.export(O/'apoco-reference.glb');mesh.export(O/'apoco-reference.ply');out={'status':'unaccepted extraction-resolution comparison','scene_code_sha256':hashlib.sha256(codes_file.read_bytes()).hexdigest(),'image_inference_repeated':False,'grid_resolution':256,'vertices':len(mesh.vertices),'triangles':len(mesh.faces),'watertight':bool(mesh.is_watertight),'signed_volume':float(mesh.volume),'degenerate_faces':int(np.sum(mesh.area_faces<=1e-12)),'elapsed_seconds':time.monotonic()-start,'native_tested':False};(O/'result.json').write_text(json.dumps(out,indent=2)+'\n');print(out,flush=True)
