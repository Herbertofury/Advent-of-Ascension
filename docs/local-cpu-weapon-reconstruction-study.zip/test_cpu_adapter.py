from pathlib import Path
import torch,numpy as np,trimesh,json
from cpu_surface_adapter import marching_cubes
r=Path(__file__).resolve().parent;n=48;x,y,z=np.meshgrid(np.linspace(-1,1,n),np.linspace(-1,1,n),np.linspace(-1,1,n),indexing='ij');field=1-((x/.7)**2+(y/.5)**2+(z/.3)**2)
v,f=marching_cubes(torch.tensor(field,dtype=torch.float32),0);v=v[:,[2,1,0]].numpy();m=trimesh.Trimesh(vertices=v,faces=f.numpy(),process=False)
assert m.is_watertight and np.all(m.area_faces>0)
assert m.extents[0]>m.extents[1]>m.extents[2],m.extents
out={'watertight':bool(m.is_watertight),'signed_volume':float(m.volume),'extents':m.extents.tolist(),'faces':len(m.faces),'scope':'Positive-inside field matching the actual TSR helper; anisotropic analytic level-set orientation/topology fixture only; no learned model quality or native rendering acceptance'};(r/'adapter-fixture.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
assert m.volume>0,'Winding does not match expected outward orientation'
