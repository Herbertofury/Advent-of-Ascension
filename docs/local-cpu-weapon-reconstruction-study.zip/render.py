import bpy,json,math
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.wm.ply_import(filepath=str(R/'discharge-reference.ply'));obj=bpy.context.object
center=sum((obj.matrix_world@Vector(c)for c in obj.bound_box),Vector())/8;obj.location-=center
m=bpy.data.materials.new('Reference vertex color');m.use_nodes=True;n=m.node_tree.nodes;l=m.node_tree.links;bs=n.get('Principled BSDF');bs.inputs['Roughness'].default_value=.7
attrs=list(obj.data.color_attributes)
if attrs:
 attr=n.new('ShaderNodeVertexColor');attr.layer_name=attrs[0].name;l.new(attr.outputs['Color'],bs.inputs['Base Color'])
obj.data.materials.append(m)
for p in obj.data.polygons:p.use_smooth=True
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=24;s.cycles.use_denoising=False;s.render.resolution_x=1000;s.render.resolution_y=700;s.render.resolution_percentage=100;s.world=bpy.data.worlds.new('Neutral');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.08,.08,.08,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.5;s.view_settings.view_transform='AgX'
bpy.ops.object.camera_add();cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=1.25;s.camera=cam
for loc,power in [((2,-2,3),120),((-2,1,2),80)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.size=3;o.rotation_euler=(-o.location).to_track_quat('-Z','Y').to_euler()
for name,loc in [('side-a',(2,0,.25)),('side-b',(-2,0,.25)),('end-a',(0,2,.15)),('end-b',(0,-2,.15)),('top',(0,0,2))]:
 cam.data.ortho_scale=1.6 if name=='top' else 1.25;cam.location=loc;cam.rotation_euler=(-cam.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/(name+'.png'));bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(R/'reference-study.blend'));(R/'render-receipt.json').write_text(json.dumps({'color_attributes':[a.name for a in attrs],'source':'discharge-reference.ply','status':'unaccepted reconstruction review','views':['side-a','side-b','end-a','end-b','top']},indent=2)+'\n')
