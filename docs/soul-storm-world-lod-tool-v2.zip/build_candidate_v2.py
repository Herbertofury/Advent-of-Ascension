import bpy,json,sys,argparse,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--render',action='store_true');args=p.parse_args(sys.argv[sys.argv.index('--')+1:]if '--'in sys.argv else[])
bpy.ops.wm.open_mainfile(filepath=str(Path(args.source).resolve()));scene=bpy.context.scene;scene.frame_set(0)
emitter_count=sum(o.name.startswith('Emitter_') and o.name.endswith('_top_to_bottom') for o in bpy.data.objects);assert emitter_count==4,'This candidate is reviewed for four emitters only'
def inventory():
 dg=bpy.context.evaluated_depsgraph_get();rows=[]
 for o in bpy.data.objects:
  if o.type not in {'MESH','CURVE','SURFACE','FONT'} or o.hide_render:continue
  e=o.evaluated_get(dg);mesh=e.to_mesh();mesh.calc_loop_triangles();bad=sum(t.area<=1e-12 for t in mesh.loop_triangles);world_bad=0
  ancestor=o;cue=False
  while ancestor is not None:
   cue=cue or ancestor.name.startswith('Authoring_disc_');ancestor=ancestor.parent
  inactive_cue=cue and abs(o.matrix_world.to_3x3().determinant())<1e-20
  for t in mesh.loop_triangles:
   if inactive_cue:continue
   ps=[o.matrix_world@mesh.vertices[i].co for i in t.vertices]
   if (ps[1]-ps[0]).cross(ps[2]-ps[0]).length_squared<1e-20:world_bad+=1
  rows.append({'name':o.name,'source_type':o.type,'vertices':len(mesh.vertices),'triangles':len(mesh.loop_triangles),'zero_area_triangles':bad,'world_collapsed_triangles':world_bad,'inactive_projectile_triangles':len(mesh.loop_triangles)if inactive_cue else 0});e.to_mesh_clear()
 return {'objects':len(rows),'vertices':sum(x['vertices']for x in rows),'triangles':sum(x['triangles']for x in rows),'zero_area_triangles':sum(x['zero_area_triangles']for x in rows),'world_collapsed_triangles':sum(x['world_collapsed_triangles']for x in rows),'inactive_projectile_triangles':sum(x['inactive_projectile_triangles']for x in rows),'rows':rows}
def animation_digest():
 records=[]
 for action in bpy.data.actions:
  records.append([action.name,[[f.data_path,f.array_index,[[list(k.co),list(k.handle_left),list(k.handle_right),k.interpolation]for k in f.keyframe_points]]for f in action.fcurves]])
 return hashlib.sha256(json.dumps(records,sort_keys=True).encode()).hexdigest()
def core_uv_digest():
 rows=[]
 for o in bpy.data.objects:
  if o.name.startswith('Animated soul vortex surface') and o.type=='MESH':rows.append([o.name,[[tuple(v.uv)for v in layer.data]for layer in o.data.uv_layers]])
 return hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest()
actions_before=animation_digest();uv_before=core_uv_digest();before=inventory();changes=[]
for o in bpy.data.objects:
 if o.hide_render:continue
 for mod in o.modifiers:
  if mod.type=='BEVEL' and o.type=='MESH':
   extents=[max(v.co[i]for v in o.data.vertices)-min(v.co[i]for v in o.data.vertices)for i in range(3)]
   if min(extents)>0 and mod.width>min(extents)*.25:
    safe=min(extents)*.25;changes.append({'object':o.name,'change':'bevel_width_clearance','from':mod.width,'to':safe});mod.width=safe
  if mod.type=='BEVEL' and mod.segments>1:changes.append({'object':o.name,'change':'bevel_segments','from':mod.segments,'to':1});mod.segments=1
 if o.type=='CURVE' and o.data.bevel_resolution>1:changes.append({'object':o.name,'change':'curve_bevel_resolution','from':o.data.bevel_resolution,'to':1});o.data.bevel_resolution=1
# Preserve core surface topology and texture UVs; only analytic torus meshes get a modest reduction.
for o in bpy.data.objects:
 if o.hide_render or o.type!='MESH':continue
 if o.name.startswith(('Core armor hoop','Core silver rim','Core luminous seal')):
  mod=o.modifiers.new('World LOD torus reduction','DECIMATE');mod.ratio=.5;mod.use_collapse_triangulate=True;changes.append({'object':o.name,'change':'torus_decimation_ratio','to':.5})
after=inventory();(R/'world-gate-debug-v2.json').write_text(json.dumps({'before':before,'after':after},indent=2));assert after['world_collapsed_triangles']==0,'World-space collapsed triangles remain';assert animation_digest()==actions_before,'Animation data changed';assert core_uv_digest()==uv_before,'Core UV data changed';assert after['triangles']<before['triangles'];assert after['zero_area_triangles']<=before['zero_area_triangles'],'New evaluated zero-area triangles'
report={'animation_data_unchanged':True,'animation_sha256':actions_before,'core_uv_data_unchanged':True,'core_uv_sha256':uv_before,'source_sha256':hashlib.sha256(Path(args.source).read_bytes()).hexdigest(),'emitter_count':emitter_count,'scope':'World-LOD authoring candidate only; includes hidden-by-scale VFX meshes, not native draw counts/FPS','before':before,'after':after,'triangle_reduction_fraction':1-after['triangles']/before['triangles'],'changes':changes,'native_acceptance':False,'limits':['No accepted visual equivalence','No native TML/AR/shader/Vulkan tests','No full surface/hand collision acceptance','Source animations and UV mappings preserved; first-person default not replaced']};(R/'geometry-budget-v2.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['scope','triangle_reduction_fraction']}));print('Triangles',before['triangles'],'->',after['triangles'])
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'soul-storm-world-lod-candidate-v2.blend'))
if args.render:
 scene.cycles.samples=24;scene.cycles.use_denoising=False;scene.render.filepath=str(R/'candidate-v2.png');bpy.ops.render.render(write_still=True)
