# Soul Storm world-LOD authoring candidate

Original Blender 4.3.2 script. Reuses the preserved v14 source instead of publishing another duplicate packed Blender backup.

1. Obtain the v14 archive from https://github.com/Herbertofury/Advent-of-Ascension/blob/main/docs/soul-storm-sculpt-v14.zip (SHA-256 65a996ac906c51c79cd81044d219bd92553fae731b035a3a99e43531ed816b0e).
2. Regenerate its four-emitter scene with blender -b -t 4 --python-exit-code 1 --python build.py -- --emitters 4 --skip-render.
3. Run Blender on this script with --source pointing to emitters-4/soul-storm-sculpt-v14.blend. Add --render for a comparison preview.

The candidate reduces bevel segmentation, curve bevel resolution and selected torus topology. It preserves the high-resolution original, core surface UV topology and animation data. Its 185 evaluated mesh-convertible objects (including curves and hidden-by-scale VFX geometry) change from 53,952 to 25,664 triangles, with no evaluated zero-area triangles in this neutral-pose check. These are geometry inventory counts, not native draw calls or FPS measurements.

The inspected view preserves the broad silhouette and component layout, but edge highlights and grip rib appearance change. This is a world-LOD candidate, not accepted visual equivalence or a replacement first-person default. Native TML materials, shading, distance transitions, reloads, hands and performance remain untested.

## v2 correction: world-space degeneracy

The v1 gate checked local evaluated triangle areas only. A stronger check after object transforms found 264 collapsed triangles in the original v14 body and 144 in the v1 reduced candidate. v2 caps oversized bevel widths on eight thin cyan rune pieces and the touch inset while retaining their raw dimensions. The corrected four-emitter candidate has zero collapsed body triangles at the checked neutral pose. Its 5,376 intentionally zero-scaled authoring-projectile triangles are counted separately, not passed as body geometry. No claim of all-pose or full collision acceptance is made.

Run build_candidate_v2.py using the same v14 four-emitter source and --render if desired. Counts remain 53,952 to 25,664; animation and core UV digests remain unchanged. Old v1 assets are preserved for provenance and superseded for geometry export.
