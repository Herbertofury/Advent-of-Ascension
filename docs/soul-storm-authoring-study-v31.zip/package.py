from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib,zipfile,shutil
R=Path(__file__).resolve().parent;D=R.parents[1]/'aoa-recovery-repo/docs';im=Image.new('RGB',(1500,550),'#101825');draw=ImageDraw.Draw(im)
for i,n in enumerate(['relaxed','transition','focused']):
 s=Image.open(R/('sight-'+n+'.png')).convert('RGBA');s.thumbnail((500,500));im.paste(s,(i*500,35),s);draw.text((i*500+18,12),n,fill='white')
im.save(R/'focus-review.jpg',quality=93)
for a,b in [('hero.png','soul-storm-v31-hero.png'),('six-view-review.jpg','soul-storm-v31-six-views.jpg'),('focus-review.jpg','soul-storm-v31-focus.jpg')]:shutil.copyfile(R/a,D/b)
g=json.loads((R/'full-active-geometry-qa.json').read_text());q=json.loads((R/'qa.json').read_text());packed=json.loads((R/'packed-winding-qa.json').read_text());report={'revision':'v31','native_accepted':False,'art_accepted':False,'source_scene_sha256':hashlib.sha256((R/'soul-storm-ornament-study.blend').read_bytes()).hexdigest(),'active_geometry':{'frame_samples':g['samples'],'triangle_samples':g['active_triangles_checked'],'degenerate_active_frames':g['degenerate_active_frames']},'saddle_surface_check':{'pairs':q['sampled_pairs'],'intersections':q['surface_intersections'],'flame_anchor_max_error':q['flame_anchor_max_error'],'limits':q['scope']},'packed_and_winding':packed,'visual_review':json.loads((R.parent/'soul-storm-channel-v30/visual-review.json').read_text()),'changes':['Baked leather material retained from v25','Broader six-solid saddle with four-prong crest','Anchored relaxed flame and broader four-prong focused sight with open central ring','Actual disc channel widened to .22 authoring units; render-only field .20 high','Symmetric oval heel settings; grip/trigger/guard sizes unchanged'],'remaining':['Unaccepted boxy emitter stack and plain underside/rear','Native effects/export and actual hand fit','Original projectile/impact capture','Full gameplay, multiplayer, save and frame-time tests']}
(D/'soul-storm-v31-evidence.json').write_text(json.dumps(report,indent=2)+'\n')
(R/'README.md').write_text('''# Soul Storm v31 authoring study

Open soul-storm-ornament-study.blend with Blender 4.3.2. Five file-backed images are packed. This is an editable authoring scene, not an installable TaCZ weapon. Native acceptance and art acceptance remain false.

The final scene carries the v25 grip bake plus v26–v31 saddle, flame, sight, slot and ornament refinements. Prior studies remain preserved. Included QA scripts run against this scene; rendering uses CPU with denoising disabled. The build script documents the v31 change and expects the previous v30 scene when rebuilding that single step; the packaged final scene can be inspected without earlier work directories.

Geometry sampling and saddle surface tests have narrow scopes. They do not certify solid containment, continuous contacts, arm fit, native shader support or gameplay. Oval heel setting layers intentionally overlap. Keep four cosmetic emitter lanes and verify source gameplay independently.
''')
with zipfile.ZipFile(D/'soul-storm-authoring-study-v31.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in [R/'soul-storm-ornament-study.blend',R/'README.md']+list(R.glob('*.py'))+[R/n for n in ['manifest.json','full-active-geometry-qa.json','full-focus-progress-qa.json','qa.json','packed-winding-qa.json']]:z.write(p,p.name)
with zipfile.ZipFile(D/'soul-storm-authoring-study-v31.zip')as z:assert z.testzip()is None
before=(R/'wiki-before.md').read_text();addition='''

## v31: flame focus, disc channels and heel detailing

![Soul Storm v31 authoring render](https://raw.githubusercontent.com/Herbertofury/Advent-of-Ascension/main/docs/soul-storm-v31-hero.png)

This combined authoring revision retains the baked grip and adds a broader side saddle, a more visible rooted flame, four tapered focused sight prongs with an open center, wider actual disc channels and symmetric oval heel settings. Grip, trigger and guard dimensions were not shrunk to make decoration fit. Prior concepts and studies remain preserved.

![Relaxed, transitional and focused sight states](https://raw.githubusercontent.com/Herbertofury/Advent-of-Ascension/main/docs/soul-storm-v31-focus.jpg)

The aperture field is an authoring-only transparent/emissive surface, not a physical wall. Its native material support, aim alignment and effect cost are unproven. The sight remains an authoring effect; these renders do not certify a working in-game crosshair.

![Six actual views of the v31 model](https://raw.githubusercontent.com/Herbertofury/Advent-of-Ascension/main/docs/soul-storm-v31-six-views.jpg)

### What the checks establish

- 101 sampled frames, 5,258,960 active triangle samples; declared inactive zero-scale projectiles are recorded separately.
- 132,660 scoped saddle/mechanical surface pairs with no reported intersections. This excludes plasma parts and does not prove containment or continuous-time clearance.
- Frame-zero mesh winding check found no negative-volume closed meshes. All five file-backed images are packed.
- The v25 leather maps and grip GLB were separately regenerated byte-for-byte from their published source archive; this does not certify the full v31 native material pipeline.

### Still below the final art bar

The emitter stack remains too boxy, the underside/rear too plain and the grip still reads rubber-like in some lighting. The circular core dominates the silhouette. These are open art defects, not waived QA gates. Actual arm fit, native animation/export, source projectile captures, multiplayer and measured performance remain unaccepted.

[Editable scene and scoped check scripts](https://github.com/Herbertofury/Advent-of-Ascension/blob/main/docs/soul-storm-authoring-study-v31.zip) · [Evidence and limitations](https://github.com/Herbertofury/Advent-of-Ascension/blob/main/docs/soul-storm-v31-evidence.json)
''';(D/'Soul-Storm-Sculpt-Study.md').write_text(before+addition)
ns=['Soul-Storm-Sculpt-Study.md','soul-storm-v31-hero.png','soul-storm-v31-six-views.jpg','soul-storm-v31-focus.jpg','soul-storm-v31-evidence.json','soul-storm-authoring-study-v31.zip'];(R/'upload-paths.json').write_text(json.dumps([str((D/n).resolve())for n in ns]));print('6 assets prepared; archive', (D/'soul-storm-authoring-study-v31.zip').stat().st_size)
