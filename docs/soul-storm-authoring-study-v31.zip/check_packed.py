import bpy,json,bmesh
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-ornament-study.blend'));s=bpy.context.scene;s.frame_set(0);rows=[]
for o in s.objects:
 if o.type!='MESH'or o.hide_render:continue
 dg=bpy.context.evaluated_depsgraph_get();e=o.evaluated_get(dg);me=e.to_mesh();bm=bmesh.new();bm.from_mesh(me);closed=all(x.is_manifold for x in bm.edges);vol=bm.calc_volume(signed=True)if closed else None;rows.append({'name':o.name,'closed':closed,'signed_volume':vol});bm.free();e.to_mesh_clear()
images=[{'name':i.name,'source':i.source,'packed':bool(i.packed_file),'filepath':i.filepath}for i in bpy.data.images if i.type!='RENDER_RESULT'and i.source=='FILE'];bad=[r for r in rows if r['closed']and r['signed_volume']<-1e-10];report={'active_meshes':len(rows),'closed_meshes':sum(r['closed']for r in rows),'negative_volume_meshes':bad,'file_images':images,'missing_packed_images':[x for x in images if not x['packed']],'native_accepted':False,'scope':'Frame-zero mesh winding and packed image availability; not continuous collision or hand-fit proof'};(R/'packed-winding-qa.json').write_text(json.dumps(report,indent=2));assert not bad and not report['missing_packed_images'];print('PACKED/WINDING PASS')
