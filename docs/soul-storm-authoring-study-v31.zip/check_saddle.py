import bpy,json,bmesh
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-ornament-study.blend'));s=bpy.context.scene;plates=[o for o in s.objects if o.name.startswith('V26 ')and not o.hide_render];assert len(plates)==6
fire=[o for o in s.objects if o.name.startswith('V16 rooted fire layer')and not o.hide_render];assert len(fire)==2;anchor=Vector((-2.4,0,3.64));max_anchor_error=0;focus_values=[];bad_volume=[]
for o in plates:
 eo=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=eo.to_mesh();bm=bmesh.new();bm.from_mesh(me);bm.transform(eo.matrix_world);assert all(e.is_manifold for e in bm.edges);vol=bm.calc_volume(signed=True);assert vol>0;bm.free();eo.to_mesh_clear()
def tree(o,dg):
 eo=o.evaluated_get(dg);me=eo.to_mesh();t=BVHTree.FromPolygons([eo.matrix_world@v.co for v in me.vertices],[tuple(p.vertices)for p in me.polygons]);eo.to_mesh_clear();return t
moving=[];excluded=[]
for o in s.objects:
 if o.hide_render or o.type not in {'MESH','CURVE'}:continue
 p=o.parent;under=False
 while p:
  if p.name.startswith('Emitter_'):under=True
  p=p.parent
 if not under:continue
 if any(m and any(x in m.name.lower()for x in ['plasma','energy','fire'])for m in o.data.materials):excluded.append(o.name);continue
 moving.append(o)
s.frame_set(0);dg=bpy.context.evaluated_depsgraph_get();static={o.name:tree(o,dg)for o in plates};collisions=[];pairs=0
for q in range(201):
 f=q/2;s.frame_set(int(f),subframe=f-int(f));bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();focus_values.append(float(s['focus']))
 for o in fire:
  eo=o.evaluated_get(dg);me=eo.to_mesh();v=[eo.matrix_world@x.co for x in me.vertices];t=1-460/512;point=(v[0]+v[1])*.5*(1-t)+(v[2]+v[3])*.5*t;max_anchor_error=max(max_anchor_error,(point-anchor).length);eo.to_mesh_clear()
 for o in moving:
  t=tree(o,dg)
  for name,st in static.items():
   pairs+=1
   if t.overlap(st):collisions.append({'frame':f,'moving':o.name,'saddle':name})
r={'scope':'Six new saddle solids and half-frame mechanical emitter/saddle surface checks; plasma materials excluded. Does not prove solid containment, native hand fit or arbitrary attachments.','plate_count':len(plates),'mechanical_moving_parts':len(moving),'excluded_plasma_parts':excluded,'sampled_pairs':pairs,'surface_intersections':collisions,'flame_anchor_max_error':max_anchor_error,'focus_samples':len(focus_values),'native_accepted':False};(R/'qa.json').write_text(json.dumps(r,indent=2));print('pairs',pairs,'intersections',len(collisions),'anchor',max_anchor_error);assert max_anchor_error<1e-5 and not collisions
