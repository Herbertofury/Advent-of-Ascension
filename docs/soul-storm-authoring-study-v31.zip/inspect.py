import bpy,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'soul-storm-channel-v30/soul-storm-channel-study.blend'));bpy.context.scene.frame_set(0);out=[]
for o in bpy.context.scene.objects:
 if not o.hide_render and any(w in o.name.lower()for w in ['heel','collar','pommel','grip']):
  bb=[o.matrix_world@Vector(v)for v in o.bound_box];out.append({'name':o.name,'material':[m.name for m in o.data.materials]if o.type=='MESH'else[],'min':[min(v[i]for v in bb)for i in range(3)],'max':[max(v[i]for v in bb)for i in range(3)]})
(R/'parts.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
