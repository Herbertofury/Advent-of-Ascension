import bpy,bmesh,json,math
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'soul-storm-channel-v30/soul-storm-channel-study.blend'));s=bpy.context.scene;s.frame_set(0);root=bpy.data.objects['SoulStorm_Root'];made=[]
for o in bpy.data.objects:
 if o.name.startswith(('V17 heel crest setting','V17 heel cyan crest')):o.hide_render=True
# Closed, low-poly oval cabochon ornament replaces the tiny diamond marks.
# It is an external decoration, not an invented moving mechanism.
def ellipsoid(name,loc,scale,mat):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=10,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);world=o.matrix_world.copy();o.parent=root;o.matrix_world=world;o.data.materials.append(bpy.data.materials[mat]);made.append(o.name)
 for f in o.data.polygons:f.use_smooth=True
 return o
for side in [-1,1]:
 ellipsoid('V31 heel silver oval setting '+str(side),(-3.62,side*.554,-1.505),(.195,.030,.125),'Brushed silver')
 ellipsoid('V31 heel dark inset '+str(side),(-3.62,side*.579,-1.505),(.154,.015,.096),'Obsidian violet')
 ellipsoid('V31 heel soul cabochon '+str(side),(-3.62,side*.594,-1.505),(.118,.035,.076),'Spirit cyan')
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'soul-storm-ornament-study.blend'));(R/'manifest.json').write_text(json.dumps({'native_accepted':False,'art_accepted':False,'new_parts':made,'scope':'Symmetric oval heel settings inspired by concept. Grip, collar, trigger and guard dimensions unchanged. Overlapping setting layers are intentional; hand fit remains untested.'},indent=2));s.cycles.samples=40;s.cycles.use_denoising=False;s.render.resolution_x=1200;s.render.resolution_y=800;s.render.resolution_percentage=100;s.render.filepath=str(R/'hero.png');bpy.ops.render.render(write_still=True)
