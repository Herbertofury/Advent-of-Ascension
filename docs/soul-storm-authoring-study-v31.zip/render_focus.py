import bpy
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-ornament-study.blend'));s=bpy.context.scene;c=s.camera;c.location=(-8,0,4.26);c.rotation_euler=(Vector((-2.4,0,4.26))-c.location).to_track_quat('-Z','Y').to_euler();c.data.type='ORTHO';c.data.ortho_scale=3.1;s.render.resolution_x=700;s.render.resolution_y=700;s.render.resolution_percentage=100;s.cycles.samples=24;s.cycles.use_denoising=False
for name,frame in [('relaxed',0),('transition',25),('focused',35)]:
 s.frame_set(frame);s.render.filepath=str(R/('sight-'+name+'.png'));bpy.ops.render.render(write_still=True)
