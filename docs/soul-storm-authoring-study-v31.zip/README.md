# Soul Storm v31 authoring study

Open soul-storm-ornament-study.blend with Blender 4.3.2. Five file-backed images are packed. This is an editable authoring scene, not an installable TaCZ weapon. Native acceptance and art acceptance remain false.

The final scene carries the v25 grip bake plus v26–v31 saddle, flame, sight, slot and ornament refinements. Prior studies remain preserved. Included QA scripts run against this scene; rendering uses CPU with denoising disabled. The build script documents the v31 change and expects the previous v30 scene when rebuilding that single step; the packaged final scene can be inspected without earlier work directories.

Geometry sampling and saddle surface tests have narrow scopes. They do not certify solid containment, continuous contacts, arm fit, native shader support or gameplay. Oval heel setting layers intentionally overlap. Keep four cosmetic emitter lanes and verify source gameplay independently.
