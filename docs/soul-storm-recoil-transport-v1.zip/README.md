# Soul Storm cosmetic recoil transport

Four separate clips sampled from the v14 four-emitter Blender curves. Each addresses only its matching exported emitter body + illuminated bone pair. This is not a gameplay binding and must not play all four clips for one confirmed shot. The native adapter must select the next emitter from authoritative successful-shot events, deduplicate repeats, and preserve authoritative costs/cadence.

Each nonlooping clip lasts 5/60 seconds, contains 21 position keys per bone, starts/ends at zero, and peaks at 1.12 model units along +Z. Source Blender -X recoil becomes +Z under the transport coordinate mapping. The numeric linear approximation error is under 0.012 model units across 201 comparison samples per clip. The authored timing is a presentation fixture, not an accepted firing rate.

Actual released TaCZ1.1.8-hotfix2 animation parser classes accept all 4 clips /168 keys on Java17 and21 with the previously documented narrow helper stand-ins. Parser acceptance is not native interpolation, attachment, shader, audio, hands or gameplay acceptance. Only the four-emitter transport currently has matching geometry; five/six-emitter exports remain work.

Reproduce using Blender4.3.2, corrected four-emitter LODv2 source:
blender -b -t 4 --python-exit-code 1 --python export_recoil.py -- --source /path/to/soul-storm-world-lod-candidate-v2.blend

Original high-detail sources and v14 archives remain preserved. No imported proprietary game animations or upstream binary classes are included.
