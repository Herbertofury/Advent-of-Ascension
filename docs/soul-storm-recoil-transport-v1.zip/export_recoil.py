"""Source-sampled cosmetic recoil clips; no gameplay/cadence binding."""
import bpy,json,sys,argparse,math
from pathlib import Path
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--source',required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);bpy.ops.wm.open_mainfile(filepath=str(Path(a.source).resolve()));scene=bpy.context.scene
emitters=sorted((o for o in bpy.data.objects if o.name.startswith('Emitter_')and o.name.endswith('_top_to_bottom')),key=lambda o:o.name)
assert len(emitters)==4,'Transport skeleton currently four emitters';fps=scene.render.fps/scene.render.fps_base;animations={};qa=[]
for i,o in enumerate(emitters):
 fc=next(f for f in o.animation_data.action.fcurves if f.data_path=='location'and f.array_index==0);start=1+i*6;duration=5/fps;times=[k/4 for k in range(21)];values=[-4*fc.evaluate(start+t)for t in times];keys={format(t/fps,'.9f'):[0,0,v]for t,v in zip(times,values)}
 bones={o.name.lower():{'position':keys},o.name.lower()+'_illuminated':{'position':keys}}
 animations['shoot_emitter_'+str(i+1)]={'animation_length':duration,'loop':False,'bones':bones}
 errors=[]
 for k in range(201):
  frame=k/40;slot=min(19,int(frame*4));frac=(frame-times[slot])/.25;linear=values[slot]*(1-frac)+values[slot+1]*frac;errors.append(abs(linear+4*fc.evaluate(start+frame)))
 assert abs(values[0])<1e-6 and abs(values[-1])<1e-6;assert all(math.isfinite(v)for v in values)
 qa.append({'emitter':i+1,'duration_seconds':duration,'keys_per_channel':len(keys),'max_linear_approximation_error_model_units':max(errors),'peak_recoil_model_units':max(values)})
(R/'soul_storm_recoil.animation.json').write_text(json.dumps({'format_version':'1.8.0','animations':animations},indent=2)+'\n');(R/'recoil-qa.json').write_text(json.dumps({'clips':qa,'scope':'Authoring source sampling and numeric interpolation approximation only; no native playback or shot cadence/selection binding'},indent=2)+'\n');print(json.dumps(qa))
