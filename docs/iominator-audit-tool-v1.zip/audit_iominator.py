"""Bounded released-file checks. Does not run Minecraft or claim native acceptance."""
import argparse,hashlib,json,os,pathlib,re,shutil,subprocess,zipfile
p=argparse.ArgumentParser();p.add_argument('jar');p.add_argument('evidence');a=p.parse_args();d=json.load(open(a.evidence));z=zipfile.ZipFile(a.jar)
for n,h in d['class_sha256'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h,n
assert json.loads(z.read('data/aoa3/recipes/upgrade_kit_iominator.json'))==d['recipe']
tool=str(pathlib.Path(os.environ['JAVA_HOME'])/'bin/javap') if os.getenv('JAVA_HOME') else shutil.which('javap');assert tool,'Need full JDK javap'
def dis(n):return subprocess.check_output([tool,'-c','-p','-classpath',a.jar,n],text=True)
w=dis('net.tslat.aoa3.content.item.weapon.gun.Iominator');assert 'ToxicBulletEntity' in w and 'bipush        120' in w and 'ITEM_GUN_GENERIC_FIRE_1' in w
b=dis('net.tslat.aoa3.content.entity.projectile.gun.ToxicBulletEntity');assert 'doEntityImpact' not in b and 'doBlockImpact' not in b
r=dis('net.tslat.aoa3.client.render.entity.projectile.bullets.ToxicBulletRenderer');assert re.search(r'bipush\s+8\b',r) and 'ColourUtil.GREEN' in r and 'FLICKERING_SPARKLER' in r
base=dis('net.tslat.aoa3.content.item.weapon.gun.BaseGun');assert re.search(r'boolean isFullAutomatic\(\);\s+Code:\s+0: iconst_1\s+1: ireturn',base);assert 'AoAItems.LIMONITE_BULLET' in base
print('PASS 7 class hashes, recipe, projectile, renderer and inherited ammo/automatic checks. Native acceptance remains open.')
