import bpy
from pathlib import Path
R=Path(__file__).resolve().parent
for label,source in [('source',R.parent/'discharge-sculpt-v7/discharge-v7.blend'),('baked',R/'discharge-baked-study.blend')]:
 bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene;s.cycles.samples=64;s.cycles.seed=17;s.cycles.use_animated_seed=False;s.cycles.use_adaptive_sampling=False;s.cycles.use_denoising=False;s.render.filepath=str(R/('matched-'+label+'.png'));bpy.ops.render.render(write_still=True)
