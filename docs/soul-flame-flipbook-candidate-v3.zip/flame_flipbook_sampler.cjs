'use strict';
// Original renderer-independent UV/time helper. Caller owns the output object.
const FRAME_COUNT=15, LOOP_SECONDS=2;
const RECTS=Object.freeze(Array.from({length:FRAME_COUNT},(_,i)=>Object.freeze({u0:(i%4)/4,v0:Math.floor(i/4)/4,u1:(i%4+1)/4,v1:(Math.floor(i/4)+1)/4})));
function sampleFlame(gameSeconds,out){
 if(!Number.isFinite(gameSeconds)||gameSeconds<0)throw Error('Invalid game time');
 if(!out||typeof out!=='object')throw Error('Reusable output object required');
 const position=(gameSeconds%LOOP_SECONDS)*FRAME_COUNT/LOOP_SECONDS;
 const frame=Math.min(FRAME_COUNT-1,Math.floor(position));
 out.frame=frame;out.next=(frame+1)%FRAME_COUNT;out.mix=position-frame;
 out.currentUV=RECTS[out.frame];out.nextUV=RECTS[out.next];
 return out;
}
module.exports={sampleFlame,RECTS,FRAME_COUNT,LOOP_SECONDS};
