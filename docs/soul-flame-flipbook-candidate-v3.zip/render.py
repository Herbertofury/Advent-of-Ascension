"""Run with Blender 4.3: blender -b -t 4 --python render.py
Regenerates original RGBA frames from the adjacent editable source.
"""
from pathlib import Path
import bpy,math
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'rendered-frames';OUT.mkdir(exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'flame-asset-source.blend'))
scene=bpy.context.scene
for i,frame in enumerate(range(1,61,4)):
 scene.frame_set(frame)
 for material in bpy.data.materials:
  if material.name.startswith('Original translucent soul flame'):
   for node in material.node_tree.nodes:
    if node.type=='TEX_NOISE':node.inputs['W'].default_value=.7*math.sin((frame-1)/60*2*math.pi)
 scene.render.filepath=str(OUT/f'frame-{i:02}.png');bpy.ops.render.render(write_still=True)
