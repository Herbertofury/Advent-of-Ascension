'use strict';
const assert=require('node:assert/strict');const {sampleFlame:s,RECTS}=require('./flame_flipbook_sampler.cjs');
const out={};assert.equal(s(0,out),out);assert.equal(out.frame,0);assert.equal(s(2,out).frame,0);assert.equal(s(1.999999,out).frame,14);assert.equal(out.next,0);
const seen=new Set();for(let i=0;i<10000;i++){s(i/997,out);seen.add(out.frame);assert(out.frame>=0&&out.frame<15);assert(out.next>=0&&out.next<15);assert(out.mix>=0&&out.mix<1);assert.equal(out.currentUV,RECTS[out.frame]);}
assert.equal(seen.size,15);assert(Object.isFrozen(RECTS));assert(RECTS.every(Object.isFrozen));
for(const t of [NaN,Infinity,-1])assert.throws(()=>s(t,out),/time/);
assert.throws(()=>s(0,null),/output/);
for(const t of [.1,.3,.7,1.1]){const a={},b={};s(t,a);s(t+2,b);assert.equal(a.frame,b.frame);assert(Math.abs(a.mix-b.mix)<1e-12);}
assert.equal(s(.5,out).currentUV,RECTS[3]);
console.log(JSON.stringify({status:'pass',samples:10000,usedFrames:seen.size,unusedAtlasCell:15,scope:'UV/time helper only; native render blending and aim calibration untested'}));
