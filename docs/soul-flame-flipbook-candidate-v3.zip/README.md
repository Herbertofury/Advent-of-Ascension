# Original Soul Flame flipbook candidate

Authoring asset, not an installable Minecraft mod. 15 RGBA frames in a 4x4 atlas; cell15 is unused. Two-second loop. Source created in Blender4.3.2. Run node test_flame_flipbook_sampler.cjs for UV/time tests. Run blender -b -t 4 --python render.py to regenerate frames. The source is original procedural mesh/shading. Native integration, shader blending, hand/aim alignment and final art acceptance remain open. Earlier concept and authoring iterations remain preserved in the project.
