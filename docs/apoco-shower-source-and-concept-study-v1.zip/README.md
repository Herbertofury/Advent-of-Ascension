# Apoco Shower source and concept study

Run `audit.py PATH_TO_PINNED_JAR --javap PATH_TO_JDK_JAVAP` to inspect the released classes and assets without executing game code. The input is the exact AoA3.7.1 / Minecraft1.20.1 archive whose SHA-256 is recorded in the evidence.

Ten classes and the renderer bootstrap association are checked. The source distinguishes Spirit consumption, three projectile classes/gravity parameters, the entity-impact condition and per-render particle requests. These are source observations, not native test results.

Concept v1 was generated with the built-in image tool from the actual enlarged source sprite. Its fungal/root-like construction, alternate shrouds, dramatic effects and inspection mechanisms are proposed art, not original lore or an implemented feature. See concept-review.json before authoring. The original concept image remains a separate published asset rather than being duplicated in this small source archive.

Original AoA identity and sprite: Tslat and contributors. Audit and concept prompt/review: original project work. No game JAR or decompiled source is bundled.
