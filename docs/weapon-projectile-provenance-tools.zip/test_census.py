import json
from pathlib import Path
R=Path(__file__).resolve().parent;d=json.loads((R/'projectile-provenance.json').read_text());b={r['id']:r for r in d['records']};assert len(b)==len(d['records'])==228
for r in b.values():
 decl=r['firing_declarations_by_signature'];assert len({v['signature']for v in decl})==len(decl);assert all(len(v['class_sha256'])==64 for v in decl)
 assert all(v['inheritance_path'][0]==r['class'].replace('/','.')for v in decl)
def allocation(id,suffix):return any(any(c.endswith('/'+suffix)for c in x['declaration']['allocations'])for x in b[id]['firing_declarations_by_signature'])
assert allocation('aoa3:apoco_assault_rifle','RedBulletEntity');assert allocation('aoa3:abominator','LimoniteBulletEntity');assert allocation('aoa3:discharge_shotgun','MetalSlugEntity');assert allocation('aoa3:soul_storm','SoulStormEntity')
soul=b['aoa3:soul_storm']['firing_declarations_by_signature'];laser=b['aoa3:laser_blaster']['firing_declarations_by_signature'];assert len(soul)==len(laser)==2
assert any('boolean' in x['signature']and x['inherited']for x in soul)
assert any('boolean' in x['signature']and not x['inherited']for x in laser)
print('PASS228 unique rows; signature-separated inheritance; four reviewed allocation fixtures; SoulStorm/LaserBlaster overload distinction. Static navigation only, no runtime acceptance.')
