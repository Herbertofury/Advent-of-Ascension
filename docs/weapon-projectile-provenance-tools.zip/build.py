"""Static released-code navigation census, never a gameplay behavior simulation."""
import json,hashlib,zipfile,subprocess,re,concurrent.futures,argparse
from pathlib import Path
R=Path(__file__).resolve().parent;W=R.parent;J=W/'references/AoA3-1.20.1-3.7.1-all.jar';javap=W/'toolchains/amazon-corretto-17.0.20.12.1-linux-x64/bin/javap';docs=W.parent/'aoa-recovery-repo/docs'
p=argparse.ArgumentParser();p.add_argument('--jar',type=Path,default=J);p.add_argument('--javap',type=Path,default=javap);p.add_argument('--baseline-dir',type=Path,default=docs);a=p.parse_args();J=a.jar;javap=a.javap;docs=a.baseline_dir
rows=[]
for name in ['conventional-weapon-baselines-1.20.1.json','blaster-baselines-1.20.1.json']:
 d=json.loads((docs/name).read_text());assert hashlib.sha512(J.read_bytes()).hexdigest()==d['jar_sha512'];rows+=d['records']
assert len(rows)==len({x['id']for x in rows})==228
with zipfile.ZipFile(J)as z:
 for r in rows:assert hashlib.sha256(z.read(r['constructor_class']+'.class')).hexdigest()==r['class_sha256']
def inspect(r):
 cache=R/'cache';cache.mkdir(exist_ok=True);cached=cache/(r['class_sha256']+'.txt')
 text=cached.read_text()if cached.exists()else subprocess.check_output([str(javap),'-c','-p','-classpath',str(J),r['constructor_class'].replace('/','.')],text=True)
 if not cached.exists():cached.write_text(text)
 sections=re.split(r'(?=^  (?:public|protected|private) [^\n]+;)',text,flags=re.M)
 allocations=[]
 for section in sections:
  header=section.splitlines()[0]if section.splitlines()else''
  for cls in re.findall(r'\d+: new\s+#\d+\s+// class (net/tslat/aoa3/content/entity/projectile/[\w/$]+)',section):allocations.append({'method_declaration':header.strip(),'class':cls})
 declared=re.findall(r'^  (?:public|protected|private) .*? ([\w$]+)\([^\n]*\);',text,re.M)
 refs=sorted(set(re.findall(r'// class (net/tslat/aoa3/content/entity/projectile/[\w/$]+)',text)))
 sounds=sorted(set(re.findall(r'AoASounds\.([A-Z_0-9]+):',text)))
 header=re.search(r'^public class .+? extends ([\w.]+)',text,re.M)
 return {'id':r['id'],'name':r['name'],'family':r.get('family','blaster'),'class':r['constructor_class'],'class_sha256':r['class_sha256'],'superclass':header.group(1)if header else None,'declared_methods':declared,'direct_projectile_allocations':allocations,'direct_projectile_class_references':refs,'direct_sound_fields':sounds,'status':'direct_references_found'if refs else'inherited_or_nonprojectile_path_requires_review','warning':'References alone do not prove spawn count, hit behavior, runtime damage, lifetime or renderer appearance.'}
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:out=list(pool.map(inspect,rows))
result={'schema':1,'release':'AoA 3.7.1 / Minecraft 1.20.1','jar_sha256':hashlib.sha256(J.read_bytes()).hexdigest(),'scope':'Static code-navigation index for all 228 pinned first-target registrations; not completed weapon profiles or all-version coverage','count':len(out),'direct_reference_rows':sum(bool(r['direct_projectile_class_references'])for r in out),'manual_review_rows':sum(not r['direct_projectile_class_references']for r in out),'records':out,'native_acceptance':False};(R/'projectile-provenance.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items()if k!='records'})
