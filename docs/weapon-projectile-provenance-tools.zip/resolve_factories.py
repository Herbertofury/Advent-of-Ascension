"""Resolve the declaring class for projectile factories; not control-flow or hit simulation."""
import json,hashlib,zipfile,subprocess,re,argparse
from pathlib import Path
R=Path(__file__).resolve().parent;W=R.parent;J=W/'references/AoA3-1.20.1-3.7.1-all.jar';javap=W/'toolchains/amazon-corretto-17.0.20.12.1-linux-x64/bin/javap';d=json.loads((R/'projectile-provenance.json').read_text());cache=R/'cache';classes={}
p=argparse.ArgumentParser();p.add_argument('--jar',type=Path,default=J);p.add_argument('--javap',type=Path,default=javap);a=p.parse_args();J=a.jar;javap=a.javap;assert hashlib.sha256(J.read_bytes()).hexdigest()==d['jar_sha256'],'Wrong released artifact'
def inspect(cls):
 cls=cls.replace('/','.');key=cls.replace('.','/')+'.class'
 with zipfile.ZipFile(J)as z:data=z.read(key)
 sha=hashlib.sha256(data).hexdigest();p=cache/(sha+'.txt')
 text=p.read_text()if p.exists()else subprocess.check_output([str(javap),'-c','-p','-classpath',str(J),cls],text=True)
 if not p.exists():p.write_text(text)
 ext=re.search(r'^public (?:abstract )?class .+? extends ([\w.]+)',text,re.M);methods={}
 for sec in re.split(r'(?=^  (?:public|protected|private) [^\n]+;)',text,flags=re.M):
  header=sec.splitlines()[0]if sec.splitlines()else'';m=re.search(r' ([\w$]+)\(',header)
  if m:methods.setdefault(m.group(1),[]).append({'declaration':header.strip(),'allocations':sorted(set(re.findall(r'\d+: new\s+#\d+\s+// class (net/tslat/aoa3/content/entity/projectile/[\w/$]+)',sec)))})
 return {'class':cls,'sha256':sha,'parent':ext.group(1)if ext else None,'methods':methods}
def get(cls):
 if cls not in classes:classes[cls]=inspect(cls)
 return classes[cls]
for row in d['records']:
 method='fireBlaster'if row['family']=='blaster'else'createProjectileEntity';current=row['class'].replace('/','.');visited=[];found=[];seen=set()
 while current and current.startswith('net.tslat.aoa3.'):
  assert current not in visited,'Inheritance cycle';visited.append(current);info=get(current)
  for declaration in info['methods'].get(method,[]):
   signature=method+'('+declaration['declaration'].split('(',1)[1]
   if signature in seen:continue
   seen.add(signature);found.append({'method':method,'signature':signature,'declared_in':current,'class_sha256':info['sha256'],'inherited':len(visited)>1,'abstract':' abstract 'in declaration['declaration'],'declaration':declaration,'inheritance_path':list(visited)})
  current=info['parent']
 row.pop('factory_declaration',None);row['firing_declarations_by_signature']=found;row['other_firing_overrides']=[m for m in row['declared_methods']if m in ['fireGun','doImpactEffect','doEntityImpact','doBlockImpact','getFiringDelay','getProjectileCount']]
d['factory_resolution']={'rows_with_declarations':sum(bool(r['firing_declarations_by_signature'])for r in d['records']),'rows_without_declarations':sum(not r['firing_declarations_by_signature']for r in d['records']),'limits':'Overload signatures are kept distinct. This index does not prove which overload executes or follows dispatch, projectile count, chance branches, impact behavior or final stats. Abstract declarations are explicitly marked.'};(R/'projectile-provenance.json').write_text(json.dumps(d,indent=2)+'\n');print(d['factory_resolution'])
