"""Pack source-derived previews into page-sized atlases; originals remain unchanged."""
from pathlib import Path
from PIL import Image
import json,hashlib,math,sys
R=Path(sys.argv[1] if len(sys.argv)>1 else 'docs');records=json.loads((R/'weapon-ammo-resolution-1.20.1.json').read_text())['records'];icons=json.loads((R/'recipe-data-1.20.1.json').read_text())['icons'];cols=6;tile=100;size=96;sheets={};mapping={};sources={};outputs=[]
for start in range(0,len(records),24):
 batch=records[start:start+24];atlas=Image.new('RGBA',(cols*tile,math.ceil(len(batch)/cols)*tile));name=f'weapon-ammo-thumbnails-1.20.1-{start//24+1}.webp'
 for i,r in enumerate(batch):
  s=icons[r['id']];p=R/s['sheet']
  if s['sheet']not in sheets:sheets[s['sheet']]=Image.open(p).convert('RGBA');sources[s['sheet']]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
  im=sheets[s['sheet']];assert im.width==s['sheet_width'];x,y,w,h=[s[k]for k in ['x','y','w','h']];assert 0<=x<x+w<=im.width and 0<=y<y+h<=im.height;thumb=im.crop((x,y,x+w,y+h)).resize((size,size),Image.Resampling.LANCZOS);assert thumb.getbbox();xx=i%cols*tile+2;yy=i//cols*tile+2;atlas.paste(thumb,(xx,yy));mapping[r['id']]={'name':r['name'],'sheet':name,'x':xx,'y':yy,'w':size,'h':size,'sheet_width':atlas.width}
 out=R/name;atlas.save(out,lossless=True,method=6);outputs.append({'file':name,'bytes':out.stat().st_size,'pixels':list(atlas.size),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
first={icons[r['id']]['sheet']for r in records[:24]};proof={'scope':'Static asset transfer-size comparison, not measured page startup or game FPS. Full source sheets remain unchanged.','thumbnail_count':len(records),'display_pixels':[96,96],'page_size':24,'atlas_files':outputs,'all_atlas_bytes':sum(x['bytes']for x in outputs),'first24_new_atlas_bytes':outputs[0]['bytes'],'first24_previous_unique_sheet_bytes':sum(sources[n]['bytes']for n in first),'all172_previous_unique_sheet_bytes':sum(x['bytes']for x in sources.values()),'source_sheets':sources};(R/'weapon-ammo-thumbnail-metadata.json').write_text(json.dumps(mapping,separators=(',',':'))+'\n');(R/'weapon-ammo-thumbnail-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print('first page bytes',outputs[0]['bytes'],'previous',proof['first24_previous_unique_sheet_bytes'],'all8',proof['all_atlas_bytes'])
