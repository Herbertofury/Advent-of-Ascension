# Released ammo identity audit

Run: python reproduce.py PATH_TO_AOA3_1.20.1_3.7.1_JAR PATH_TO_released-weapon-behavior-map-1.20.1.json OUTPUT.json. Use a full JDK17 with JAVA_HOME. The map is published in the repository docs folder. The script pins its SHA256 and the original JAR SHA512, runs javap on40 relevant methods and two registries with a four-worker pool, and reads five named source comparisons from the official pinned AoA repository. It does not execute mod classes.

Only recognized constant-return getAmmoItem shapes are accepted. This is not a complete resource-consumption test. Reproduction cache is scoped by class hash; use a fresh --cache directory to recheck from scratch.

Run node test_explorer.cjs PATH_TO_weapon-ammo-explorer.html to check the browser's pure DOM logic with simulated elements. This is separate from a live browser or game test. The public HTML embeds the resolved data and existing image references.

Source code and reference JAR are acquired separately; this archive contains our analysis/test tooling only.

Thumbnail/browser rebuild: python build_thumbnail_atlas.py PATH_TO_REPOSITORY_DOCS, then python build_explorer.py PATH_TO_REPOSITORY_DOCS. Requires Pillow and the existing committed source sheets, recipe-data, queue and ammo JSON. The atlas conversion repacks existing previews at their displayed96px size; it does not recreate original art or certify native visuals.
