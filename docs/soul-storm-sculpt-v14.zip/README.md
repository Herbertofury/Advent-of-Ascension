# Soul Storm v14: four, five and six emitter authoring variants

Original Blender geometry/animation study, not an installable mod or native TaCZ export. Shared source supports exactly the three currently checked layouts. More emitters remain future layout/performance scope.

Run `python run_variants.py` to regenerate and check all three without rendering. Add `--render` for idle/action stills. Run `blender -b -t 4 --python-exit-code 1 --python render_motion.py -- --emitters 6` for the six-emitter two-second sampled preview. Blender4.3.2 is the tested version.

The source archive includes the six-emitter .blend with packed textures, shared texture assets, builders, per-variant QA and manifests. Four/five scenes can be regenerated without duplicating all packed Blender files in the archive. Earlier v5-v13 archives remain separate history.

Each emitter has a horizontal plasma-disc aperture and a moving energy coupler. A common Spirit bus distributes to telescoping sleeves. The selected rod/sleeve overlap is intentional; a sampled test checks centerline engagement and endpoints within the rear coupler box envelope. It is not exact beveled-surface, full-weapon, hand or continuous collision proof.

Recoil events remain top-to-bottom. Burst endpoints scale with emitter count so the last emitter is not truncated. Display cadence is an authoring fixture, not AoA's native cadence or an implemented damage multiplier. Gameplay resource/cadence/volley upgrades need the authoritative adapter and effective-stat UI.

The runner uses Blender --python-exit-code 1: ordinary Blender exit status alone can hide Python errors. A discarded local variable collision between emitter count and armor-arc segments was fixed before these receipts; future failures stop rather than allowing stale QA to count as a pass.

Open quality gates: richer ornament/materials, atmospheric trails, original-versus-upgraded native footage, real hands/aim, texture alpha masking, native mesh/export/shader performance and gameplay compatibility. Original AoA identity credit Tslat and contributors.
