"""Regenerate and strictly check selected authoring variants; not native game QA."""
import argparse,subprocess,pathlib,json
p=argparse.ArgumentParser();p.add_argument('--emitters',type=int,nargs='+',choices=[4,5,6],default=[4,5,6]);p.add_argument('--render',action='store_true');p.add_argument('--blender',default='blender');a=p.parse_args();R=pathlib.Path(__file__).resolve().parent
for n in a.emitters:
 for script in ['build.py','check.py']:
  command=[a.blender,'-b','-t','4','--python-exit-code','1','--python',str(R/script),'--','--emitters',str(n)]
  if script=='build.py' and not a.render:command+=['--skip-render']
  run=subprocess.run(command,capture_output=True,text=True);(R/(script[:-3]+'-'+str(n)+'.log')).write_text(run.stdout+run.stderr)
  if run.returncode:raise RuntimeError(f'{script} failed for {n} emitters; see log')
 q=json.loads((R/f'emitters-{n}'/'qa.json').read_text());assert q['emitter_count']==n and q['energy_feed_envelope']['rod_samples']>0 and q['emitter_stack']['count']==n
 print('PASS',n,'emitters; scoped authoring envelope checks only')
