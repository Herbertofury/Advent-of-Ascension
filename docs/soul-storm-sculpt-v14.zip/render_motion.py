import bpy
from pathlib import Path
ROOT=Path(__file__).resolve().parent
import argparse,sys
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
parser=argparse.ArgumentParser();parser.add_argument('--emitters',type=int,choices=[4,5,6],default=4);parser.add_argument('--skip-render',action='store_true');config=parser.parse_args(args);count=config.emitters;burst_end=max(30,6*count+1)
R=ROOT/f'emitters-{count}';R.mkdir(exist_ok=True)
pitch={4:.83,5:.765,6:.72}[count]
levels=[1.605+((count-1)/2-i)*pitch for i in range(count)]

bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-sculpt-v14.blend'));scene=bpy.context.scene;scene.render.resolution_x=840;scene.render.resolution_y=540;scene.cycles.samples=12;scene.cycles.use_denoising=False
(R/'motion').mkdir(exist_ok=True)
for frame in range(0,120,4):
 scene.frame_set(frame);scene.render.filepath=str(R/'motion'/f'{frame:03d}.png');bpy.ops.render.render(write_still=True)
