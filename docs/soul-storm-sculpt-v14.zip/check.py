import bpy,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parent
import argparse,sys
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
parser=argparse.ArgumentParser();parser.add_argument('--emitters',type=int,choices=[4,5,6],default=4);parser.add_argument('--skip-render',action='store_true');config=parser.parse_args(args);count=config.emitters;burst_end=max(30,6*count+1)
R=ROOT/f'emitters-{count}';R.mkdir(exist_ok=True)
pitch={4:.83,5:.765,6:.72}[count]
levels=[1.605+((count-1)/2-i)*pitch for i in range(count)]

bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-sculpt-v14.blend'))
emitters=[bpy.data.objects[f'Emitter_{i+1}_top_to_bottom'] for i in range(count)];scene=bpy.context.scene;violations=[]
for frame in range(4*burst_end+1):
 scene.frame_set(frame//4,subframe=(frame%4)/4)
 moving=[]
 for i,e in enumerate(emitters):
  if not all(math.isfinite(x) for x in e.matrix_world.translation):violations.append('nonfinite pose')
  if not -.28001<=e.location.x<=.00001:violations.append(f'overshoot {i} {frame/4} {e.location.x}')
  if e.location.x<-.001:moving.append(i)
 if len(moving)>1:violations.append(f'overlapping recoil events at {frame/4}: {moving}')
scene.frame_set(0)
meshes=[o for o in bpy.data.objects if o.type=='MESH' and not o.hide_render]
zero=[];duplicate=[]
for o in meshes:
 bad=sum(p.area<1e-10 for p in o.data.polygons)
 if bad:zero.append([o.name,bad])
 coords=[tuple(round(x,7) for x in v.co)for v in o.data.vertices]
 if len(set(coords))<len(coords):duplicate.append([o.name,len(coords)-len(set(coords))])
report={'scope':'Blender authoring geometry/keyframe smoke test; no native hands or continuous collision proof','emitter_count':len(emitters),'samples':4*burst_end+1,'recoil_violations':violations,'zero_area_polygons':zero,'duplicate_position_vertices':duplicate,'visible_meshes':len(meshes)}
(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
assert not violations, 'Recoil motion gate failed'
assert not zero, 'Zero-area polygon gate failed'
assert not any(name=='Default soul flame' for name,count in duplicate), 'Flame pole weld gate failed'
# Check all 15 atlas cells in the real animated material; unused cell15 is never sampled.
material=bpy.data.materials['Soul flame atlas surface'];add=next(n for n in material.node_tree.nodes if n.type=='VECT_MATH' and n.operation=='ADD')
observed=[]
for frame in range(0,121):
 scene.frame_set(frame);offset=add.inputs[1].default_value;expected=(frame//8)%15
 actual=int(round(offset[0]*4))+4*int(round((1-offset[1])*4-1));assert actual==expected,(frame,actual,expected);observed.append(actual)
assert set(observed)==set(range(15))
report['atlas_frames_seen']=sorted(set(observed));report['atlas_samples']=121;report['limitations']=['Not native renderer acceptance','Core texture has low nonzero border alpha; final asset cleanup/masking pending','No actual hands, shader-pass or continuous collision proof']
(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS bounded recoil/topology and 15-cell atlas sampling; native/visual acceptance open')
# v14 aperture envelope check. Bounds are conservative mesh-coordinate envelopes,
# not a full weapon/hand continuous collision proof.
from mathutils import Vector
scene.frame_set(0)
disc_checks=[]
for i,z in enumerate(levels):
 g=bpy.data.objects[f'Authoring_disc_{i+1}']
 children=[o for o in g.children if o.type=='MESH' and not o.hide_render]
 assert len(children)==2,(i,[o.name for o in children])
 # Evaluate at full scale, independent of hidden/flight animation samples.
 for o in children:
  local=[o.matrix_basis @ v.co for v in o.data.vertices]
  y=max(abs(v.y)for v in local);zz=max(abs(v.z)for v in local)
  assert y<=.730001,(o.name,y,'side-wall intersection')
  assert zz<=.080001,(o.name,zz,'upper/lower aperture intersection')
  disc_checks.append({'part':o.name,'half_width':y,'half_thickness':zz,'side_clearance':.73-y,'vertical_clearance':.08-zz})
 face=bpy.data.objects[f'Horizontal soul-disc face {i+1}']
 assert all(abs(v.co.z)<1e-8 for v in face.data.vertices)
 assert max(v.co.x for v in face.data.vertices)-min(v.co.x for v in face.data.vertices)>1.27
report['disc_aperture_envelopes']=disc_checks
report['disc_plane']='XY plane; firing travels +X, matching thin horizontal slot'
report['limits']='Static disc cross-section envelope only; not full moving assembly/hand or native collision proof'
(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS horizontal disc plane and conservative aperture cross-section envelopes')
# Inspect the actual rod/sleeve object transforms across recoil samples.
# This measures declared bounding envelopes and rod centerlines, not beveled surface collision.
scene.frame_set(0)
sleeves=[o for o in bpy.data.objects if o.name.startswith('Fixed telescoping sleeve')]
rods=[o for o in bpy.data.objects if o.name.startswith('Moving energy connector')]
assert len(sleeves)==len(rods)==2*count
pairs=[]
for rod in rods:
 p=rod.matrix_world @ Vector(rod.data.splines[0].points[0].co[:3])
 choices=[s for s in sleeves if abs(s.location.y-p.y)<1e-5 and abs(s.location.z-p.z)<1e-5]
 assert len(choices)==1
 couplers=[o for o in rod.parent.children if o.name.startswith('Rear energy coupler')];assert len(couplers)==1
 pairs.append((rod,choices[0],couplers[0]))
min_engagement=1e9;rod_samples=0
for frame in range(4*burst_end+1):
 scene.frame_set(frame//4,subframe=(frame%4)/4)
 for rod,sleeve,coupler in pairs:
  ends=[rod.matrix_world @ Vector(p.co[:3]) for p in rod.data.splines[0].points]
  bounds=[sleeve.matrix_world @ Vector(p)for p in sleeve.bound_box]
  overlap=min(max(p.x for p in ends),max(p.x for p in bounds))-max(min(p.x for p in ends),min(p.x for p in bounds))
  assert overlap>=.39999,(rod.name,frame/4,overlap)
  tip=coupler.matrix_world.inverted() @ ends[-1]
  for axis in range(3):assert min(p[axis]for p in coupler.bound_box)-1e-5<=tip[axis]<=max(p[axis]for p in coupler.bound_box)+1e-5
  min_engagement=min(min_engagement,overlap);rod_samples+=1
report['energy_feed_envelope']={'rod_samples':rod_samples,'minimum_centerline_sleeve_engagement':min_engagement,'coupler_endpoints_inside_box_envelopes':True,'scope':'Selected sampled rod centerline/sleeve and endpoint envelopes; intentional telescoping overlap, not complete surface/hand collision proof'}
(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS all emitter energy connectors remain engaged in sampled recoil envelopes')
scene.frame_set(0)
vertical=[]
for e in emitters:
 coords=[e2.matrix_world @ Vector(v) for e2 in e.children if e2.type in {'MESH','CURVE'} and not e2.hide_render for v in e2.bound_box]
 assert coords
 vertical.append((min(v.z for v in coords),max(v.z for v in coords)))
gaps=[vertical[i][0]-vertical[i+1][1]for i in range(len(vertical)-1)]
assert min(gaps)>=.01999,('emitter vertical envelope clearance',gaps)
report['emitter_stack']={'count':count,'pitch':pitch,'adjacent_vertical_envelope_gaps':gaps,'minimum_gap':min(gaps),'scope':'Visible emitter-child bounding envelopes at neutral pose; recoil is X-only. Not a full collision proof.'}
(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS compact emitter stack has positive selected vertical envelope clearance')
packed=[]
for name in ['soul-flame-atlas-candidate-v3.png','soul-storm-core-vfx-texture-v1.png']:
 image=bpy.data.images.get(name);assert image is not None and image.packed_file is not None,('missing packed texture',name);packed.append(name)
report['packed_textures']=packed
(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS both required texture assets packed into Blender file')
