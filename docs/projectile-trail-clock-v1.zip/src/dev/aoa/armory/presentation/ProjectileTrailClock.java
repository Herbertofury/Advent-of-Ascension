package dev.aoa.armory.presentation;

/**
 * Original client presentation scheduler, one instance per projectile lifetime.
 * Invoke from a game-time update, never from the renderer. Thread confined.
 * Counts describe requests, not actual particles or a native performance gain.
 */
public final class ProjectileTrailClock {
    public record Emission(long tick, int requests, boolean initialized, long skippedTicks) {}
    private final int requestsPerTick;
    private boolean initialized;
    private long lastTick;
    private boolean closed;

    public ProjectileTrailClock(int requestsPerTick) {
        if (requestsPerTick < 0 || requestsPerTick > 4096)
            throw new IllegalArgumentException("Explicit finite per-projectile budget required");
        this.requestsPerTick = requestsPerTick;
    }
    /**
     * Paused, repeated, stale and removed-projectile updates produce no requests.
     * Initial update establishes a baseline, without inventing an earlier trail.
     * Gaps emit at the current position only: stale positions are not available.
     * skippedTicks makes that loss explicit; native integration may interpolate
     * from a bounded position history, but must not dump a catch-up burst.
     */
    public Emission update(long gameTick, boolean paused) {
        if (gameTick < 0) throw new IllegalArgumentException("Negative game time");
        if (closed || paused) return new Emission(gameTick, 0, initialized, 0);
        if (!initialized) {
            initialized = true; lastTick = gameTick;
            return new Emission(gameTick, 0, true, 0);
        }
        if (gameTick <= lastTick) return new Emission(gameTick, 0, true, 0);
        long elapsed = gameTick - lastTick; // Both nonnegative, strictly ordered: no overflow.
        lastTick = gameTick;
        return new Emission(gameTick, requestsPerTick, true, elapsed - 1);
    }
    /** Removal is terminal. A new projectile/world session requires a new clock. */
    public void close() { closed = true; }
}
