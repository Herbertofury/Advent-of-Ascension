package dev.aoa.armory.presentation;
public final class TrailClockTest {
    static int assertions;
    static void check(boolean c) { assertions++; if (!c) throw new AssertionError(assertions); }
    static void rejects(Runnable r) {try {r.run();throw new AssertionError("Expected rejection");}catch(IllegalArgumentException expected){assertions++;}}
    public static void main(String[] args) {
        for (int duplicateCalls : new int[]{1,2,3,8,30,100}) {
            var c = new ProjectileTrailClock(16); long total = 0;
            check(c.update(100,false).requests()==0);
            for (long tick=101;tick<=300;tick++) {
                for (int frame=0;frame<duplicateCalls;frame++) {
                    var e=c.update(tick,false);total+=e.requests();
                    check(e.requests()==(frame==0?16:0));check(e.skippedTicks()==0);
                }
            }
            check(total==3200);
            check(c.update(500,true).requests()==0);
            check(c.update(300,false).requests()==0);
            check(c.update(299,false).requests()==0);
            var gap=c.update(305,false);check(gap.requests()==16);check(gap.skippedTicks()==4);
            c.close();check(c.update(306,false).requests()==0);check(c.update(0,false).requests()==0);
        }
        var zero=new ProjectileTrailClock(0);zero.update(0,false);check(zero.update(1,false).requests()==0);
        var big=new ProjectileTrailClock(1);big.update(0,false);var e=big.update(Long.MAX_VALUE,false);check(e.skippedTicks()==Long.MAX_VALUE-1);check(e.requests()==1);
        var pauseFirst=new ProjectileTrailClock(16);check(!pauseFirst.update(0,true).initialized());check(pauseFirst.update(5,false).requests()==0);
        rejects(()->new ProjectileTrailClock(-1));rejects(()->new ProjectileTrailClock(4097));rejects(()->new ProjectileTrailClock(1).update(-1,false));
        System.out.println("PASS "+assertions+" trail-clock assertions");
    }
}
