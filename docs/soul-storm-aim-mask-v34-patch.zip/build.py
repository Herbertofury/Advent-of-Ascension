"""Keep the aiming aperture attached to the sight center during flame-card scaling."""
import bpy,json,hashlib,sys,argparse
from pathlib import Path
R=Path(__file__).resolve().parent;parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,default=R.parent/'soul-storm-metal-bake-v33-r6/soul-storm-metal-baked.blend');args=parser.parse_args(sys.argv[sys.argv.index('--')+1:]if '--'in sys.argv else[]);source=args.source;assert hashlib.sha256(source.read_bytes()).hexdigest()==json.loads((R/'input-contract.json').read_text())['source_sha256'],'Unexpected source scene';bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene;m=bpy.data.materials['V16 living soul fire'];nodes=m.node_tree.nodes
sub=next(n for n in nodes if n.type=='VECT_MATH'and n.operation=='SUBTRACT');metric=next(n for n in nodes if n.type=='VECT_MATH'and n.operation=='MULTIPLY'and any(l.from_node==sub for l in n.inputs[0].links));inside=next(n for n in nodes if n.type=='MAP_RANGE');focused=next(n for n in nodes if n.type=='MATH'and n.operation=='MULTIPLY'and any(l.from_node==inside for l in n.inputs[0].links))
def driver(socket,expr,index=None):
 fc=socket.driver_add('default_value')if index is None else socket.driver_add('default_value',index);fc.driver.expression=expr
 while fc.driver.variables:fc.driver.variables.remove(fc.driver.variables[0])
 var=fc.driver.variables.new();var.name='focus';var.type='SINGLE_PROP';var.targets[0].id_type='SCENE';var.targets[0].id=s;var.targets[0].data_path='["focus"]'
driver(sub.inputs[1],'1-460/512+.62/(1.85*(1+.45*(1-focus)))',1);driver(metric.inputs[1],'1.4*(1+.25*(1-focus))',0);driver(metric.inputs[1],'1.85*(1+.45*(1-focus))',1)
x='min(1,max(0,focus/.35))';driver(focused.inputs[1],f'({x})**2*(3-2*({x}))')
s.frame_set(0);bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'soul-storm-aim-mask.blend'));(R/'manifest.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Authoring-only aperture follows v27 flame scale; earlier smooth clearing during focus transition','geometry_changed':False,'native_accepted':False,'remaining':['Native camera and shader binding','Hand fit and visual polish','Native performance and compatibility']},indent=2))
