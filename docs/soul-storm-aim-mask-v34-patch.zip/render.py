"""Authoring sight readability setup, not a native first-person camera test."""
import bpy,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;source=R/'soul-storm-aim-mask.blend';bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene
# A tiny contrasting marker behind the sight gives a readable target reference.
def plate(name,x,half,color):
 me=bpy.data.meshes.new(name);me.from_pydata([(x,-half,4.26-half),(x,half,4.26-half),(x,half,4.26+half),(x,-half,4.26+half)],[],[(0,1,2,3)]);me.update();o=bpy.data.objects.new(name,me);s.collection.objects.link(o);m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;n.clear();em=n.new('ShaderNodeEmission');em.inputs['Color'].default_value=(*color,1);em.inputs['Strength'].default_value=.5;out=n.new('ShaderNodeOutputMaterial');m.node_tree.links.new(em.outputs[0],out.inputs['Surface']);o.data.materials.append(m)
plate('Review neutral backdrop',7,4,(.08,.08,.08));plate('Review target marker',6.9,.014,(1,.15,.7))
s.camera.location=(-9,0,4.26);s.camera.rotation_euler=(Vector((8,0,4.26))-s.camera.location).to_track_quat('-Z','Y').to_euler();s.camera.data.type='ORTHO';s.camera.data.ortho_scale=2.2;s.camera.data.shift_x=0;s.camera.data.shift_y=0;s.cycles.samples=64;s.cycles.use_denoising=False;s.render.resolution_x=900;s.render.resolution_y=900;s.render.resolution_percentage=100
rows=[]
for name,frame in [('relaxed',0),('transition',25),('focused',50)]:
 s.frame_set(frame);rows.append({'state':name,'frame':frame,'focus':float(s['focus'])});s.render.filepath=str(R/(name+'.png'));bpy.ops.render.render(write_still=True)
(R/'review-setup.json').write_text(json.dumps({'scope':'Controlled authoring orthographic sight/marker setup; not in-game first-person alignment','camera':[-9,0,4.26],'target_center':[6.9,0,4.26],'target_half_width':.014,'ortho_scale':2.2,'states':rows,'native_accepted':False},indent=2))
