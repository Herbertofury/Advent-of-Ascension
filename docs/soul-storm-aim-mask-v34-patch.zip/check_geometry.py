"""Verify the material-only patch preserves geometry and evaluated motion."""
import bpy, json, hashlib, struct, argparse, sys
from pathlib import Path
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:])
def snapshot(path):
 bpy.ops.wm.open_mainfile(filepath=str(path));s=bpy.context.scene;raw=hashlib.sha256();motion=hashlib.sha256();count=0
 def add(h,v):h.update(json.dumps(v,separators=(',',':'),sort_keys=True).encode())
 for o in sorted(bpy.data.objects,key=lambda x:x.name):
  add(raw,[o.name,o.type,o.parent.name if o.parent else None])
  if o.type!='MESH':continue
  m=o.data;count+=1
  add(raw,[[list(v.co)for v in m.vertices],[list(p.vertices)for p in m.polygons],[[list(x.uv)for x in u.data]for u in m.uv_layers]])
  if m.shape_keys:add(raw,[[k.name,[list(v.co)for v in k.data]]for k in m.shape_keys.key_blocks])
 for frame in range(101):
  s.frame_set(frame);dg=bpy.context.evaluated_depsgraph_get()
  for o in sorted(s.objects,key=lambda x:x.name):
   if o.type!='MESH':continue
   e=o.evaluated_get(dg);m=e.to_mesh();add(motion,[o.name,[list(r)for r in e.matrix_world],[list(v.co)for v in m.vertices]]);e.to_mesh_clear()
 return {'mesh_objects':count,'raw_geometry_sha256':raw.hexdigest(),'evaluated_motion_sha256':motion.hexdigest(),'frames':101}
old=snapshot(a.source);new=snapshot(R/'soul-storm-aim-mask.blend');assert old==new,(old,new)
(R/'geometry-preservation-qa.json').write_text(json.dumps({'passed':True,'source':old,'patched':new,'scope':'Exact mesh positions, topology, UVs, shape keys, parent names and 101 sampled evaluated mesh frames; shader changes intentionally excluded','native_accepted':False},indent=2));print('PASS geometry and sampled motion preserved',new)
