# Soul Storm: centered flame aperture (v34 authoring patch)

This small reproducible patch uses the published v33-R6 Blender scene. It does not contain or install a native mod. Blender 4.3.2 is the tested authoring runtime.

1. Download `soul-storm-metal-texture-study-v33.zip` from the linked repository in input-contract.json, and extract its scene.
2. Run `blender -b -t 2 --python build.py -- --source /absolute/path/soul-storm-metal-baked.blend`.
3. Run `blender -b -t 2 --python check_anchor.py`.
4. Run `blender -b -t 2 --python check_geometry.py -- --source /absolute/path/soul-storm-metal-baked.blend`.
5. Run `blender -b -t 2 --python render.py` for the controlled marker study.

The source scene SHA-256 is checked before modification. Output is saved alongside the script. Keep an untouched source. The patch updates four shader-driver expressions. It adjusts UV mask center and metric to match the changing flame-card dimensions, then smoothly opens the aperture through focus 0–0.35. It does not alter weapon gameplay or mesh geometry.

Evidence: 202 evaluated mask centers across 101 frames remain within 6.75e-7 world units of the intended center. Geometry, UVs, shape keys, parent names and sampled evaluated motion are identical for all 438 mesh objects. Controlled idle and full-focus images are pixel-identical; the halfway transition exposes the contrasting target marker. These checks cover the authoring setup, not all camera angles, continuous collision, game rendering or performance.

Open gates: native camera alignment, shader/animation binding, hand fit, gameplay readability at multiple FOVs and resolutions, accessibility, multiplayer and equivalent-work performance. Overall art approval remains open.
