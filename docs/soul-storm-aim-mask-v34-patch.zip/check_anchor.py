import bpy,json,math
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-aim-mask.blend'));s=bpy.context.scene;rows=[];maximum=0
for frame in range(101):
 s.frame_set(frame);dg=bpy.context.evaluated_depsgraph_get();focus=float(s['focus']);material=bpy.data.materials['V16 living soul fire'].evaluated_get(dg);sub=next(n for n in material.node_tree.nodes if n.type=='VECT_MATH'and n.operation=='SUBTRACT');u,v=float(sub.inputs[1].default_value[0]),float(sub.inputs[1].default_value[1]);errs=[]
 for name in ['V16 rooted fire layer','V16 rooted fire layer.001']:
  o=bpy.data.objects[name];eo=o.evaluated_get(dg);me=eo.to_mesh();assert len(me.vertices)==4;vs=[o.matrix_world@x.co for x in me.vertices];p=vs[0]*((1-u)*(1-v))+vs[1]*(u*(1-v))+vs[2]*(u*v)+vs[3]*((1-u)*v);err=(p-Vector((-2.4,0,4.26))).length;assert err<1e-5,(frame,name,p,err);errs.append(err);maximum=max(maximum,err);eo.to_mesh_clear()
 rows.append({'frame':frame,'focus':focus,'uv_center':[u,v],'card_center_errors':errs})
(R/'anchor-qa.json').write_text(json.dumps({'scope':'Evaluated flame-card geometry and shader mask-center agreement; not native camera alignment','frames':101,'card_samples':202,'maximum_world_center_error':maximum,'rows':rows,'native_accepted':False},indent=2));print('PASS 202 mask-center samples; max error',maximum)
