# Clean-extraction authoring QA

This runner verifies the exact SHA-256 inputs listed in `authoring-qa-inputs.json`, extracts seven published studies into a disposable workspace, supplies the three published HTML harness inputs, and runs every packaged Node `test*.cjs` suite. It never edits the input archives or the original repository checkout. Python 3.10+ and Node are required. No external Python packages or game files are needed.

Run from this directory, with a local public repository checkout:

    python run_authoring_qa.py --docs /path/to/Advent-of-Ascension/docs --report result.json

The runner fails if any input differs, a test fails or times out, or the suite count differs from 21. Review and explicitly regenerate the manifest after intentional source changes; never silently update expected hashes during a test run.

## Packaging correction

The original Baronator mechanism archive included an alternation test pointing to an absent `baronator-v2` directory and expecting 109 cuboids. The separate historical prototype archive contains 103 cuboids, so substituting that archive is incorrect. The revised archive's test explicitly targets its own packaged 132-cuboid mechanism study. Its 1,000 acknowledgment, duplicate/rejection/stale/bonus guards, bounded cache, recoil return, flash-location and pose-finiteness assertions remain in place. Dedicated bore-path, feed-path and hand-envelope suites remain separate and required. The old archive is retained unchanged.

The three viewer tests require the sibling `aoa-expansion` HTML inputs; the runner supplies these from the hash-verified published files. This addresses clean-extraction setup, not a visual-quality defect or proof of real rendering.

## Limits

These are source/data and simulated-DOM authoring tests. They do not run Minecraft, TaCZ, native hand rigs, a shader pack, Vulkan, network replication or actual player saves. Passing them does not approve the art or prove absence of runtime collision/performance problems.
