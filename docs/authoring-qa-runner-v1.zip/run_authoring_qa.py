"""Run original AoA authoring studies in a clean workspace. Not game acceptance."""
from pathlib import Path
import argparse, hashlib, json, shutil, subprocess, tempfile, zipfile

PACKAGES = ['ascension-armory-authoring-prototype', 'baronator-mechanism-study-qa-v2',
            'baronator-attachment-study', 'minigun-motion-study', 'soul-storm-authoring-study',
            'inspection-customization-design-study', 'soul-flame-flipbook-candidate-v3']
PAGES = ['baronator-attachment-lab.html', 'minigun-motion-lab.html', 'soul-storm-lab.html']

def extract_checked(archive, target):
    with zipfile.ZipFile(archive) as z:
        for entry in z.infolist():
            dest = (target / entry.filename).resolve()
            if not dest.is_relative_to(target.resolve()):
                raise ValueError('Unsafe archive member: ' + entry.filename)
            if (entry.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('Archive symlink rejected: ' + entry.filename)
        z.extractall(target)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--docs', type=Path, required=True, help='Published repository docs directory')
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    docs = args.docs.resolve()
    manifest = json.loads((Path(__file__).with_name('authoring-qa-inputs.json')).read_text())
    for name, expected in manifest.items():
        actual = hashlib.sha256((docs / name).read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError('Input SHA-256 mismatch: ' + name)
    results = []
    with tempfile.TemporaryDirectory(prefix='aoa-authoring-qa-') as temp:
        root = Path(temp)
        for name in PACKAGES:
            extract_checked(docs / (name + '.zip'), root / name)
        (root / 'aoa-expansion').mkdir()
        for name in PAGES:
            shutil.copy2(docs / name, root / 'aoa-expansion' / name)
        for script in sorted(root.glob('*/test*.cjs')):
            try:
                run = subprocess.run(['node', script.name], cwd=script.parent,
                                     capture_output=True, text=True, timeout=180)
                result = {'test':str(script.relative_to(root)), 'exit_code':run.returncode,
                          'stdout':run.stdout, 'stderr':run.stderr}
            except subprocess.TimeoutExpired:
                result = {'test':str(script.relative_to(root)), 'exit_code':124,
                          'stderr':'Test exceeded 180-second execution limit'}
            results.append(result)
            print(('PASS ' if result['exit_code'] == 0 else 'FAIL ') + result['test'], flush=True)
    report = {'scope':'Clean-extraction Node authoring harnesses; not native Minecraft/TaCZ tests',
              'node':subprocess.check_output(['node','--version'], text=True).strip(),
              'inputs_sha256':manifest, 'tests':results,
              'passed':sum(t['exit_code']==0 for t in results), 'total':len(results)}
    args.report.write_text(json.dumps(report, indent=2)+'\n')
    raise SystemExit(0 if report['passed']==report['total'] and report['total']==21 else 1)

if __name__ == '__main__':
    main()
