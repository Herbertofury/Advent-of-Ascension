# Soul Storm sculpt reconstruction, v5–v9

Original editable Blender authoring work, rebuilt after the execution workspace reset. These are new iterations, not recovered copies of the lost earlier sculpt drafts. The original AoA identity belongs to Tslat and contributors; the concept direction comes from this project's Soul Storm design-B and four-emitter requirements.

## Current v9

- Circular reservoir and indigo/silver/cyan silhouette; tapered hollow four-slot emitter stack.
- Four independently animated emitters, top to bottom. Flying soul discs are authoring-only visual cues.
- A default three-tongue Soul Flame ornament with a fixed-root animated primary flame and material variation. The gem concept remains an optional sight direction elsewhere.
- Reworked grip ribs, layered armor and a procedural spiral core.
- Actual editable geometry, materials, shape keys, motion curves and a build script. The PNGs are Blender renders, not native game captures.

## Reproduce

Use Blender 4.3.2. In a selected version directory:

    blender -b -t 4 --python build.py

For v9, run `blender -b -t 4 --python check.py` for the bounded topology/recoil test, and `blender -b -t 4 --python render_motion.py` for the sampled motion frames. Cycles denoising is deliberately disabled because the tested build lacks OpenImageDenoise. Original source files and exact .blend files are both included.

## Preserved experiments

v5: wire-like core and tube-like armor were visually weak.
v6: enclosed cloud core and tapered plate armor; flame poles had duplicate vertices.
v7: welded flame poles and introduced the four flying-disc cues; broad spiral read too much like a pinwheel.
v8: thinner turbulent core filaments and darker presentation lighting.
v9: tapered emitter shells, properly wrapped grip ribs and extra flame tongues.

These stages are retained for comparison, not all approved as successful designs.

## What the checks establish

The current test samples 121 authoring times over 30 frames, checks finite emitter transforms, bounded recoil and non-overlapping recoil events, tests zero-area polygon and flame-pole duplicate-position conditions, and verifies the primary flame shape-key root remains fixed. This is not continuous collision detection, hand-envelope validation or native gameplay acceptance.

## Important remaining work

Visual acceptance remains open. The design still lacks the concept's sculpted ornamental detail, stronger surface painting, convincingly energetic core depth, hand choreography, polished inspection, native aim tests and full attachment variants. The procedural surface shader/shape keys are not automatically supported by TaCZ's standard cube model loader. A real export/bake and verified native rendering path are required; this is not a gunpack to install. No FPS, shader/Vulkan, multiplayer, saved-item, resource-consumption, damage or native projectile acceptance is claimed. Timing here is an authoring preview, not a balance change to the original Soul Storm.
