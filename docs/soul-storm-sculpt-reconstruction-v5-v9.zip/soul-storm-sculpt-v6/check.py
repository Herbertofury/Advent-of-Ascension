import bpy,json,math
from pathlib import Path
R=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-sculpt-v6.blend'))
emitters=[bpy.data.objects[f'Emitter_{i+1}_top_to_bottom'] for i in range(4)];scene=bpy.context.scene;violations=[]
for frame in range(121):
 scene.frame_set(frame//4,subframe=(frame%4)/4)
 moving=[]
 for i,e in enumerate(emitters):
  if not all(math.isfinite(x) for x in e.matrix_world.translation):violations.append('nonfinite pose')
  if not -.28001<=e.location.x<=.00001:violations.append(f'overshoot {i} {frame/4} {e.location.x}')
  if e.location.x<-.001:moving.append(i)
 if len(moving)>1:violations.append(f'overlapping recoil events at {frame/4}: {moving}')
scene.frame_set(0)
meshes=[o for o in bpy.data.objects if o.type=='MESH' and not o.hide_render]
zero=[];duplicate=[]
for o in meshes:
 bad=sum(p.area<1e-10 for p in o.data.polygons)
 if bad:zero.append([o.name,bad])
 coords=[tuple(round(x,7) for x in v.co)for v in o.data.vertices]
 if len(set(coords))<len(coords):duplicate.append([o.name,len(coords)-len(set(coords))])
report={'scope':'Blender authoring geometry/keyframe smoke test; no native hands or continuous collision proof','emitter_count':len(emitters),'samples':121,'recoil_violations':violations,'zero_area_polygons':zero,'duplicate_position_vertices':duplicate,'visible_meshes':len(meshes)}
(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
