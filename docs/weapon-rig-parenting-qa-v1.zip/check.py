"""Blender-only neutral-pose preservation regression; no native engine claim."""
import bpy,json,random,math
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.read_factory_settings(use_empty=True);rng=random.Random(20261019);results=[]
def err(a,b):return max(abs(a[i][j]-b[i][j])for i in range(4)for j in range(4))
def preserve_parent(child,parent):
 bpy.context.view_layer.update();world=child.matrix_world.copy();child.parent=parent;child.matrix_parent_inverse=parent.matrix_world.inverted();child.matrix_basis=world;bpy.context.view_layer.update();return err(child.matrix_world,world)
for i in range(64):
 parent=bpy.data.objects.new('Parent_%d'%i,None);bpy.context.collection.objects.link(parent);parent.location=tuple(rng.uniform(-4,4)for _ in range(3));parent.rotation_euler=tuple(rng.uniform(-math.pi,math.pi)for _ in range(3));parent.scale=tuple(rng.uniform(.4,2)*( -1 if (i%4==0 and j==0) else 1)for j in range(3))
 bpy.ops.mesh.primitive_cube_add(size=.1,location=tuple(rng.uniform(-2,2)for _ in range(3)));child=bpy.context.object;child.rotation_euler=tuple(rng.uniform(-1,1)for _ in range(3));e=preserve_parent(child,parent);assert e<3e-6,(i,e);results.append(e)
 # Move parent after preservation; confirm child follows the actual parent delta.
 before_parent=parent.matrix_world.copy();before_child=child.matrix_world.copy();parent.location+=Vector((.1,-.2,.3));bpy.context.view_layer.update();expected=parent.matrix_world@before_parent.inverted()@before_child;movement=err(expected,child.matrix_world);assert movement<3e-6,(i,movement)
# Positive control: unpreserved nonorigin parenting must be caught by the original-world comparison.
bpy.ops.mesh.primitive_cube_add(size=.1,location=(1,2,3));child=bpy.context.object;bpy.context.view_layer.update();before=child.matrix_world.copy();parent=bpy.data.objects.new('Known bad nonorigin parent',None);bpy.context.collection.objects.link(parent);parent.location=(3,0,1);child.parent=parent;bpy.context.view_layer.update();bad=err(child.matrix_world,before);assert bad>1
out={'status':'Blender neutral parenting fixture only','cases':64,'maximum_neutral_matrix_error':max(results),'known_bad_case_matrix_error':bad,'parents':'translation, rotation, nonuniform scale and selected reflected X scale','native_tested':False,'limits':['No armature bone parenting, constraints or preexisting child shear tested','Matrix invariance does not establish outward normals, native bone pivots or hand fit']};(R/'checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
