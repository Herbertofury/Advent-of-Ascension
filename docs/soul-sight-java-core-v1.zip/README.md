# Soul Sight frame core — original Java authoring prototype

Pure Java 17 code for a future Soul Flame/Soul Candle rendering adapter. This is not a Forge mod or TaCZ gunpack and does not install a renderer, hook a bone, upload a texture, or draw a vertex.

## Contract

- The caller resolves the installed sight and passes paused game/presentation time. This core never scans inventory, queries attachment data, reads wall time or changes gameplay.
- Flame and Candle can produce atlas frames; Gem produces no flame. Each style still needs its own correctly authored bone/origin. No unverified numeric offsets are supplied.
- The shadow pass is disabled by policy; GUI animation is explicitly opt-in. First/third-person drawing still requires native compatibility and visual checks.
- Every call resets its caller-owned output, including a disabled or invalid request. A previous flame cannot survive a Gem/disabled pass through stale output fields.
- The fifteen-frame, two-second sequence wraps frame 14 to frame 0, never the empty cell 15. Reduced motion selects a stable frame without blend progression.
- No global mutable animation/weapon state, no maps keyed by players, no unbounded particle queues. Separate render owners must use separate output objects.
- The caller decides whether it supports frame blending. This core only returns UVs and a mix, so it makes no claim about translucent buffers, mipmaps, shaders or rendering speed.

Invalid inputs clear the output then throw an argument exception. Validate inputs at the native adapter boundary; do not turn repeated adapter failures into per-frame log spam. Exceptions are programming errors, not normal attachment switching.

## Reproduce

Set `JAVA_HOME` to a full JDK and run `python run_tests.py`. The runner compiles with `--release 17` in a disposable directory. The recorded run used an actual Amazon Corretto 17 JDK, not only a newer JDK targeting 17.

Tests cover 24 attachment/pass/GUI combinations; 100,000 time samples; the loop seam; reduced motion; invalid time rejection and stale-output cleanup; separate output isolation; and repeated identical paused presentation time. These are deterministic math tests, not an in-game test, native pause-hook test, shader test, benchmark or proof of complete thread safety.

## Integration still open

Connect this through the source-backed TaCZ functional leaf-bone path, use the published original flame atlas, and implement a verified render buffer/transform adapter. Verify hide/switch/cancel, actual game pause and tick interpolation, GUI/first-/third-person views, hands/FOV, resource reload, alpha/depth/filtering, multiplayer instance separation, shaders/Vulkan and frame times. The authoritative gameplay path must remain independent.
