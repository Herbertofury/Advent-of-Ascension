"""Concept-directed grip texture and contour study; no native hand-fit claim."""
import bpy,bmesh,math,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;OUT=R/'output';OUT.mkdir(exist_ok=True);bpy.ops.wm.open_mainfile(filepath=str(R/'source-v34.blend'))
for o in bpy.data.objects:
 if o.name.startswith(('V5 sculpted grip','V5 conforming grip panel','V5 grip seam','V21 ','V30 ')):o.hide_render=True
bodymat=bpy.data.materials['Discharge grip charcoal'].copy();bodymat.name='V36 matte grip rubber';p=bodymat.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.024,.027,.031,1);p.inputs['Metallic'].default_value=.03;p.inputs['Roughness'].default_value=.62
panelmat=bodymat.copy();panelmat.name='V36 patterned grip inlay';n=panelmat.node_tree.nodes;l=panelmat.node_tree.links;p=n.get('Principled BSDF');uv=n.new('ShaderNodeUVMap');uv.uv_map='GripPanel';split=n.new('ShaderNodeSeparateXYZ');l.new(uv.outputs[0],split.inputs[0])
def op(kind,a,b=0):
 o=n.new('ShaderNodeMath');o.operation=kind
 if hasattr(a,'is_output'):l.new(a,o.inputs[0])
 else:o.inputs[0].default_value=a
 if hasattr(b,'is_output'):l.new(b,o.inputs[1])
 else:o.inputs[1].default_value=b
 return o.outputs[0]
u=op('MULTIPLY',split.outputs['X'],25);v=op('MULTIPLY',split.outputs['Y'],45);a=op('SINE',op('MULTIPLY',op('ADD',u,v),math.tau));b=op('SINE',op('MULTIPLY',op('SUBTRACT',u,v),math.tau));knurl=op('MULTIPLY',a,b);mix=n.new('ShaderNodeMixRGB');l.new(op('MULTIPLY_ADD',knurl,.22),mix.inputs[0]);mix.inputs[1].default_value=(.018,.021,.026,1);mix.inputs[2].default_value=(.05,.057,.065,1);l.new(mix.outputs[0],p.inputs['Base Color']);bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.22;bump.inputs['Distance'].default_value=.005;l.new(knurl,bump.inputs['Height']);l.new(bump.outputs[0],p.inputs['Normal'])
def point(t,a,inflate=0):
 x=-2.65-.36*t;z=.37-1.67*t;rx=.39+.08*math.sin(math.pi*t);ry=.43;groove=sum(.22*math.exp(-((t-c)/.055)**2)for c in [.57,.74,.89])*max(math.cos(a),0)**1.5*min(1,max(0,(1-t)/.08))
 return(x+(rx-groove+inflate)*math.cos(a),(ry+inflate)*math.sin(a),z)
def mesh(name,vertices,faces,material,closed=False,side=0):
 me=bpy.data.meshes.new(name);me.from_pydata(vertices,[],faces);me.update();bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
 if closed:
  assert all(e.is_manifold for e in bm.edges)
  if bm.calc_volume(signed=True)<0:bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
 elif side:
  wrong=[f for f in bm.faces if f.normal.y*side<0]
  if wrong:bmesh.ops.reverse_faces(bm,faces=wrong)
 bm.to_mesh(me);bm.free();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);me.materials.append(material)
 for p in me.polygons:p.use_smooth=True
 return o
N=48;steps=48;vertices=[point(j/steps,math.tau*k/N)for j in range(steps+1)for k in range(N)];faces=[tuple(range(N)),tuple(range((steps+1)*N-1,steps*N-1,-1))]
for j in range(steps):
 for k in range(N):a=j*N+k;b=j*N+(k+1)%N;faces.append((a,a+N,b+N,b))
mesh('V36 contoured grip',vertices,faces,bodymat,closed=True)
def path(name,points,radius,material):
 d=bpy.data.curves.new(name,'CURVE');d.dimensions='3D';d.resolution_u=4;d.bevel_depth=radius;d.bevel_resolution=2;d.use_fill_caps=True;sp=d.splines.new('POLY');sp.points.add(len(points)-1)
 for p,co in zip(sp.points,points):p.co=(*co,1)
 o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);d.materials.append(material);return o
steel=bpy.data.materials['Discharge dark machined steel'];red=bpy.data.materials['Discharge crimson worn enamel']
for side in [-1,1]:
 sections=24;arc=16;vs=[point(.12+.76*j/sections,(.28+.44*k/arc)*math.pi*side,.009)for j in range(sections+1)for k in range(arc+1)];fs=[]
 for j in range(sections):
  for k in range(arc):a=j*(arc+1)+k;fs.append((a,a+1,a+arc+2,a+arc+1))
 o=mesh('V36 conforming textured inlay',vs,fs,panelmat,side=side);uv=o.data.uv_layers.new(name='GripPanel')
 for li,loop in enumerate(o.data.loops):idx=loop.vertex_index;uv.data[li].uv=((idx%(arc+1))/arc,(idx//(arc+1))/sections)
 for fraction in [.28,.72]:path('V36 fitted grip edge',[point(.12+.76*j/32,fraction*math.pi*side,.016)for j in range(33)],.009,steel)
 # Small original diamond crest with branching traces, seated into the inlay.
 emblem=[(.5,.30),(.42,.41),(.5,.53),(.58,.41),(.5,.30)]
 path('V36 inset diamond crest',[point(t,(.28+.44*u)*math.pi*side,.0115)for u,t in emblem],.005,steel)
 for sign in [-1,1]:
  branch=[(.5,.55),(.5+sign*.12,.49),(.5+sign*.17,.37)]
  path('V36 grip crest branch',[point(t,(.28+.44*u)*math.pi*side,.0115)for u,t in branch],.005,steel)
 for t in [.12,.88]:path('V36 fitted panel end',[point(t,(.28+.44*j/32)*math.pi*side,.016)for j in range(33)],.009,steel)
 for t in [.17,.82]:
  co=point(t,.5*math.pi*side,.023);bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=6,radius=.028,location=co);ob=bpy.context.object;ob.name='V36 inlay fastener';ob.data.materials.append(steel)
# Retain the established parent frame; update transforms before capturing them.
parent=bpy.data.objects['V30 contoured grip'].parent
bpy.context.view_layer.update()
if parent:
 for o in bpy.data.objects:
  if o.name.startswith('V36 '):
   world=o.matrix_world.copy();o.parent=parent;o.matrix_world=world
s=bpy.context.scene;s.frame_set(1);s.render.resolution_x=1200;s.render.resolution_y=850;s.render.resolution_percentage=100;s.cycles.samples=64;s.cycles.use_denoising=False;bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'discharge-grip-study.blend'))
(OUT/'manifest.json').write_text(json.dumps({'status':'Unaccepted grip contour and material study','changes':['Broader front-arc finger scallops; same grip endpoints and overall envelope; no hand-fit claim','Matte patterned inlays with fitted edges and an small original branching diamond crest','Explicit outward grip-panel normals'],'preserved':['Trigger and guard geometry unchanged; new finger scallops placed below the existing return instead of around it','Original concept target and earlier source scenes retained'],'native_tested':False,'limits':['Native hand clearance and gameplay feel untested','New geometry/material evidence must be rerun; old exports not automatically repaired','Still below the full concept-fidelity target']},indent=2)+'\n')
