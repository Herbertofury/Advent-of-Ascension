# Discharge v36 grip refinement study

Blender 4.3.2, procedural materials. Run `blender -b -t 2 --python-exit-code 1 --python build.py`, then the same command with `check.py`. The bundled source is the authored v34 scene, not a complete rebuild from an empty file.

This study moves the three grip contours below the existing guard return and gives the inlays finer patterned material. It retains every earlier geometry object unchanged, hidden where superseded. It does not change the trigger or guard.

QA checks old object geometry/transforms, a closed positive-volume new grip, degenerate triangles and one guard return point seated inside the grip. These are deliberately limited checks: they do not qualify hand fit, complete collisions, swept animation, native playability or visual fidelity.

The published v35 atlas, GLB, transport and animation evidence apply to v35, not this new geometry. Re-baking/export and native tests remain required. This source study is not a playable TaCZ pack. Original concepts and earlier studies remain retained.
