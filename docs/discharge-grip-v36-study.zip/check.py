import bpy,bmesh,json,hashlib
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parent;src=R/'source-v34.blend';bpy.ops.wm.open_mainfile(filepath=str(src))
def digest(o):
 if o.type=='MESH':shape={'vertices':[list(v.co)for v in o.data.vertices],'polygons':[list(p.vertices)for p in o.data.polygons]}
 elif o.type=='CURVE':shape=[{'points':[list(p.co)for p in s.points],'bezier':[{'co':list(p.co),'left':list(p.handle_left),'right':list(p.handle_right)}for p in s.bezier_points]}for s in o.data.splines]
 else:return None
 return hashlib.sha256(json.dumps({'shape':shape,'matrix':[list(r)for r in o.matrix_world]},sort_keys=True).encode()).hexdigest()
original={o.name:digest(o)for o in bpy.data.objects if o.type in {'MESH','CURVE'}};bpy.ops.wm.open_mainfile(filepath=str(R/'output/discharge-grip-study.blend'));assert all(n in bpy.data.objects and digest(bpy.data.objects[n])==d for n,d in original.items()),'Original source geometry changed';o=bpy.data.objects['V36 contoured grip'];bm=bmesh.new();bm.from_mesh(o.data);bm.transform(o.matrix_world);assert all(e.is_manifold for e in bm.edges);volume=bm.calc_volume(signed=True);assert volume>0;bm.free();o.data.calc_loop_triangles();bad=[]
for i,t in enumerate(o.data.loop_triangles):
 a,b,c=[o.matrix_world@o.data.vertices[v].co for v in t.vertices]
 if (b-a).cross(c-a).length_squared<1e-20:bad.append(i)
assert not bad;guard=bpy.data.objects['Open trigger guard'];spline=guard.data.splines[0];end=guard.matrix_world@(spline.bezier_points[-1].co if spline.bezier_points else Vector(spline.points[-1].co[:3]));tree=BVHTree.FromPolygons([o.matrix_world@v.co for v in o.data.vertices],[list(p.vertices)for p in o.data.polygons]);direction=Vector((1,.173,.081)).normalized();point=end.copy();hits=0
for _ in range(12):
 loc,normal,index,distance=tree.ray_cast(point,direction,10)
 if loc is None:break
 hits+=1;point=loc+direction*1e-5
assert hits%2==1,'Guard return is not seated inside the grip';report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'original_geometry_objects_preserved':len(original),'new_grip_triangles':len(o.data.loop_triangles),'new_grip_signed_volume':volume,'degenerate_grip_triangles':bad,'guard_return_point':list(end),'guard_return_inside_body':True,'ray_crossings':hits,'native_accepted':False,'scope':'Static source-geometry preservation, closed grip and guard endpoint seating. Not full collision, hand fit, texture/export or native acceptance'};(R/'output/qa.json').write_text(json.dumps(report,indent=2));print(report)
