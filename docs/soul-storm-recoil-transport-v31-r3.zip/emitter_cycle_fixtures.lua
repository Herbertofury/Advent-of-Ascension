local checks=0
local function check(x,msg) assert(x,msg); checks=checks+1 end
function new_context()
 local c={runs={},stops=0,ensure=0,missing={}}
 function c:hasAnimationPrototype(n)return not self.missing[n]end
 function c:ensureTrackLineSize(n)self.lines=n end
 function c:ensureTracksAmount(l,n)self.ensure=self.ensure+1;self.amount=n end
 function c:getTrack(l,i)return l*4+i end
 function c:stopAnimation(t)self.stops=self.stops+1;if self.bad_track==t then error('stop fixture')end end
 function c:runAnimation(n,t,b,m,f)
  if self.fail then error('run fixture')end
  check(b==true and m=='harness_stop'and f==0,'context call contract');self.runs[#self.runs+1]={name=n,track=t}
 end
 return c
end
local c=new_context();local x=assert(M.new(c,3,'harness_stop'))
for i=0,9999 do local ok,lane=x.present_resolved(i%4);check(ok and lane==i%4+1,'resolved lane')end
check(c.ensure==1 and c.amount==4,'bounded tracks');check(#c.runs==10000,'one clip per supplied resolved presentation')
-- A skipped server ordinal must not be replaced with a local next-lane counter.
check(x.present_resolved(0),'first lane');check(x.present_resolved(0),'same authoritative lane after gap');check(c.runs[#c.runs].name=='shoot_emitter_1','no arrival counter')
for _,bad in ipairs({-1,4,5,1.5,math.huge})do check(not x.present_resolved(bad),'invalid/unsupported index')end
check(not x.present_resolved(0/0),'NaN index')
c.missing.shoot_emitter_2=true;check(not x.present_resolved(1),'missing runtime clip');c.missing.shoot_emitter_2=nil;c.fail=true;check(not x.present_resolved(1),'run error');c.fail=false;check(x.present_resolved(1),'recovery uses supplied lane')
local before=c.stops;check(x.close(),'close success');check(c.stops==before+4,'all tracks stopped');x.close();check(c.stops==before+4,'idempotent close');check(not x.present_resolved(0),'closed')
local other=new_context();local y=assert(M.new(other,3,'harness_stop'));check(y.present_resolved(2),'independent instance');check(other.runs[1].name=='shoot_emitter_3','selected third lane')
local miss=new_context();miss.missing.shoot_emitter_3=true;check(M.new(miss,1,'harness_stop')==nil and miss.ensure==0,'check clips before allocating')
local bad=new_context();function bad:getTrack(l,i)return 0 end;check(not pcall(function()M.new(bad,3,'harness_stop')end),'duplicate track rejected')
local bad=new_context();function bad:getTrack(l,i)return -1 end;check(not pcall(function()M.new(bad,3,'harness_stop')end),'invalid track rejected')
local c=new_context();local z=assert(M.new(c,3,'harness_stop'));c.bad_track=13;local ok,err=z.close();check(not ok and #err==1 and c.stops==4,'cleanup all');c.bad_track=nil;check(z.close() and c.stops==5,'retry failed only')
print('PASS resolved-emitter Lua adapter: '..checks..' assertions; 10000-event bounded-track mock fixture. Sequence/session authority belongs to the existing Java core.')
