# Soul Storm v31 recoil presenter · R3

Status: original presentation clips and Lua presenter; not an installable gunpack. Native event identity, prediction, geometry binding, arms, effects and gameplay remain open.

## Important correction: consume the existing core's result

R1/R2 advanced a local lane counter for each received sequence. A regression fixture reproduced the flaw: authoritative ordinals 1 and 5 should both select the top emitter in a four-lane build, but R2 selected lanes 1 and 2. Those earlier adapters are superseded.

R3 removes that second counter. The existing Java `ConfirmedShotPresentation` core already handles trusted weapon/session/configuration binding, accepted-shot ordinals, gaps, stale/duplicate confirmations and projectile-count metadata. Feed its resolved zero-based `Presentation.emitterIndex()` to this presenter. Do not recreate that state machine in Lua.

## Host responsibilities

Reserve a dedicated, non-conflicting animation track line. Create `M.new(context, dedicated_line, PLAY_ONCE_STOP)` with the actual native constant. The presenter validates its four clips, allocates four reused tracks and rejects missing, invalid or duplicate track IDs. Dedicated line indices are defensively limited to 0–63 in this prototype.

Call `instance.present_resolved(emitterIndex)` exactly once for each presentation result accepted by the existing Java core. There is deliberately no raw-packet sequence API here. The four-clip presenter accepts indices 0–3; unsupported five/six-emitter variants must take the host's safe original-renderer fallback until their corresponding assets/presenter are supplied. Gameplay/resource logic must continue unchanged.

Prediction reconciliation is still a host responsibility. Do not introduce a network-round-trip delay or replay an already predicted first-person effect. Do not call from raw mouse input, each pellet, recoil magnitude or whichever weapon happens to be held when an unrelated packet arrives.

Create/dispose the presenter with its actual weapon/session lifecycle. `close()` attempts all four stops even if one fails, returns errors, and retries only failed stops on a later explicit call. It never polls or retries itself, and closed presenters reject new visual events.

## Animation contract

Four clips contain synchronized solid/illuminated sibling tracks named `emitter_1_top_to_bottom` through `emitter_4_top_to_bottom`, with `_illuminated` counterparts. Final native geometry must supply the aliases or a verified owner-parent equivalent. The old v15 transport naming convention is not proof that v31 geometry is already installed.

Blender -X maps to model +Z at four model units per authoring unit. Each recoil clip samples five authoring frames at 60fps into 41 keys per track. This is presentation timing, not a source firing scheduler. Material opacity/emission, flame focus, projectiles, sound and camera recoil are not exported by these position tracks.

## Scoped evidence

- Actual released TaCZ1.1.8-hotfix2 parser classes accept 4 clips / 8 tracks / 328 keys on Java17 and Java21 with the documented narrow helper stand-ins.
- 401 sample comparisons per clip; maximum linear approximation error about 0.003077 model units.
- Eight Python contract tests reject malformed or divergent tracks.
- Original Lua mock-context fixture: 10,000 presentations / 20,029 assertions; one initial four-track allocation.
- Existing Java core to Lua presenter: 29 bridge assertions on both Java17 and Java21, covering ordinal gaps, duplicates, wrong weapon/session, rejected attempts, rebind replay protection and unsupported variant fallback.
- The unchanged existing core's separate 80,031-assertion suite was rerun on both Java versions.
- Exact embedded LuaJ library hashes and released context API signatures were checked.

These are isolated logic/parser checks, not native Minecraft animation, packet authentication, visual acceptance or FPS results. The presenter never consumes ammo, applies damage, spawns projectiles or changes the source item.

## Reproduce the Java-to-Lua checks

Run `python run_bridge_checks.py --tacz-jar /path/to/tacz-1.20.1-1.1.8-hotfix2.jar --jdk17 /path/to/jdk17 --java21 /path/to/java21/bin/java`.

The runner checks the complete TaCZ artifact hash, extracts only the two hash-pinned embedded LuaJ libraries into a local test cache, compiles the included unchanged Java core and bridge fixture, then runs the same class files on both Java runtimes. It does not download dependencies or start Minecraft. The native context remains a mock. The older R2 gap reproduction requires the preserved R2 adapter from its earlier archive; it is diagnostic history, not the current API.
