local c={runs={}}
function c:hasAnimationPrototype(n)return true end
function c:ensureTrackLineSize(n)end
function c:ensureTracksAmount(l,n)end
function c:getTrack(l,i)return l*4+i end
function c:stopAnimation(t)end
function c:runAnimation(n,t,b,m,f)self.runs[#self.runs+1]=n end
local x=assert(M.new(c,3,'harness_stop'));assert(x.on_confirmed_shot(1));assert(x.on_confirmed_shot(5));assert(c.runs[1]=='shoot_emitter_1'and c.runs[2]=='shoot_emitter_2')
print('REPRODUCED R2 arrival-count defect: authoritative ordinals 1 and 5 should both select emitter 1 for a four-emitter build, but R2 selected 1 then 2. Superseded by resolved-index R3.')
