"""Run original core/presenter tests with hash-pinned LuaJ from the released TaCZ JAR."""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile,os
P=argparse.ArgumentParser();P.add_argument('--tacz-jar',type=Path,required=True);P.add_argument('--jdk17',type=Path,required=True);P.add_argument('--java21',type=Path,required=True);P.add_argument('--out',type=Path);A=P.parse_args();R=Path(__file__).resolve().parent;E=json.loads((R/'lua-library-evidence.json').read_text());assert hashlib.sha512(A.tacz_jar.read_bytes()).hexdigest()==E['source_jar_sha512'],'Wrong TaCZ artifact';C=R/'bridge-cache';C.mkdir(exist_ok=True)
with zipfile.ZipFile(A.tacz_jar)as Z:
 for f in E['verified_libraries']:
  b=Z.read(f['path']);assert hashlib.sha256(b).hexdigest()==f['sha256'];p=C/f['local'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
core=R/'src/dev/aoa/armory/presentation/ConfirmedShotPresentation.java';classes=C/'classes';classes.mkdir(exist_ok=True);cp=str(C/'lib/*');subprocess.run([str(A.jdk17/'bin/javac'),'--release','17','-cp',cp,'-d',str(classes),str(core),str(R/'ResolvedBridgeCheck.java')],check=True);rows=[]
for runtime in [A.jdk17/'bin/java',A.java21]:
 run=subprocess.run([str(runtime),'-Xmx128m','-cp',str(classes)+os.pathsep+cp,'ResolvedBridgeCheck',str(R/'emitter_cycle.lua'),str(R/'emitter_cycle_fixtures.lua')],check=True,capture_output=True,text=True);assert '20029 assertions' in run.stdout and '29 assertions. Mock engine context' in run.stdout;rows.append({'runtime':subprocess.run([str(runtime),'-version'],check=True,capture_output=True,text=True).stderr.strip(),'stdout':run.stdout});print(run.stdout,end='')
report={'source_core_sha256':hashlib.sha256(core.read_bytes()).hexdigest(),'lua_sha256':hashlib.sha256((R/'emitter_cycle.lua').read_bytes()).hexdigest(),'runs':rows,'native_integration_tested':False,'scope':'Actual original Java core and Lua presenter; mocked native animation context'};(A.out or R/'bridge-repro-checks.json').write_text(json.dumps(report,indent=2)+'\n')
