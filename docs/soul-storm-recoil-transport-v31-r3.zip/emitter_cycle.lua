-- Original presentation-only adapter. The host owns confirmed-shot events,
-- dedicated track-line reservation, geometry binding and all gameplay state.
local M = {}
local function integer(n)
    return type(n) == 'number' and n == n and n ~= math.huge and n ~= -math.huge and n >= 0 and n <= 9007199254740991 and n % 1 == 0
end
function M.new(context, dedicated_line, play_once_stop)
    assert(integer(dedicated_line) and dedicated_line <= 63, 'Invalid dedicated track line')
    assert(play_once_stop ~= nil, 'Host must supply native PLAY_ONCE_STOP')
    local names = {}
    for i = 1, 4 do
        names[i] = 'shoot_emitter_' .. i
        if not context:hasAnimationPrototype(names[i]) then return nil, 'missing_clip:' .. names[i] end
    end
    context:ensureTrackLineSize(dedicated_line + 1)
    context:ensureTracksAmount(dedicated_line, 4)
    local tracks, seen_tracks = {}, {}
    for i = 1, 4 do
        tracks[i] = context:getTrack(dedicated_line, i - 1)
        assert(integer(tracks[i]) and not seen_tracks[tracks[i]], 'Invalid or duplicate native track')
        seen_tracks[tracks[i]] = true
    end
    local disposed = false
    local instance = {}
    -- Consume the zero-based emitterIndex selected by ConfirmedShotPresentation.
    -- Do not count packet arrivals or duplicate its lifecycle/replay state here.
    function instance.present_resolved(emitter_index)
        if disposed then return false, 'disposed' end
        if not integer(emitter_index) or emitter_index > 3 then return false, 'unsupported_emitter_index' end
        local lane = emitter_index + 1
        if not context:hasAnimationPrototype(names[lane]) then return false, 'missing_clip:' .. names[lane] end
        local ok, err = pcall(function()
            context:stopAnimation(tracks[lane])
            context:runAnimation(names[lane], tracks[lane], true, play_once_stop, 0)
        end)
        if not ok then return false, 'animation_error:' .. tostring(err) end
        return true, lane
    end
    local cleanup_pending = {tracks[1], tracks[2], tracks[3], tracks[4]}
    function instance.close()
        disposed = true
        local failed, errors = {}, {}
        for _, track in ipairs(cleanup_pending) do
            local ok, err = pcall(function() context:stopAnimation(track) end)
            if not ok then failed[#failed + 1] = track; errors[#errors + 1] = tostring(err) end
        end
        cleanup_pending = failed
        return #failed == 0, errors
    end
    return instance
end
return M
