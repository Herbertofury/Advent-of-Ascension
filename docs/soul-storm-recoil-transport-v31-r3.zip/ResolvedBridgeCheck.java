import java.nio.file.*;
import java.util.*;
import org.luaj.vm2.*;
import org.luaj.vm2.lib.jse.JsePlatform;
import dev.aoa.armory.presentation.ConfirmedShotPresentation;
public final class ResolvedBridgeCheck {
 static int checks=0;
 static void check(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
 public static void main(String[]args)throws Exception{
  Globals g=JsePlatform.standardGlobals();
  for(String name:new String[]{"os","io","luajava","package","require","dofile","loadfile"})g.set(name,LuaValue.NIL);
  LuaValue module=g.load(Files.readString(Path.of(args[0])),"original_adapter").call();g.set("M",module);
  g.load(Files.readString(Path.of(args[1])),"mock_context_fixture").call();
  LuaValue context=g.get("new_context").call();
  LuaValue adapter=module.get("new").call(context,LuaValue.valueOf(3),LuaValue.valueOf("harness_stop"));
  UUID id=UUID.fromString("11111111-2222-3333-4444-555555555555");
  var core=new ConfirmedShotPresentation(id,7);
  check(core.bind(new ConfirmedShotPresentation.Snapshot(id,7,1,0,4)),"bind");
  long[] sequences={1,2,5,5,4,9};int[] expected={0,1,0,-1,-1,0};
  for(int i=0;i<sequences.length;i++){
   var p=core.accept(new ConfirmedShotPresentation.Confirmation(id,7,1,sequences[i],true,4));
   if(expected[i]<0){check(p==null,"duplicate/late suppressed by existing core");continue;}
   check(p!=null&&p.emitterIndex()==expected[i],"authoritative gap mapping");
   check(p.projectileCount()==4,"projectile metadata preserved");
   check(adapter.get("present_resolved").call(LuaValue.valueOf(p.emitterIndex())).toboolean(),"Lua accepts resolved lane");
  }
  LuaValue runs=context.get("runs");check(runs.length()==4,"four accepted events only");
  check(runs.get(3).get("name").tojstring().equals("shoot_emitter_1"),"ordinal 5 remains top emitter");
  check(runs.get(4).get("name").tojstring().equals("shoot_emitter_1"),"ordinal 9 remains top emitter");
  check(core.accept(new ConfirmedShotPresentation.Confirmation(new UUID(0L,0L),7,1,10,true,4))==null,"wrong weapon");
  check(core.accept(new ConfirmedShotPresentation.Confirmation(id,8,1,10,true,4))==null,"wrong session");
  check(core.accept(new ConfirmedShotPresentation.Confirmation(id,7,1,10,false,4))==null,"rejected attempt");
  core.unbind();check(core.accept(new ConfirmedShotPresentation.Confirmation(id,7,1,10,true,4))==null,"unbound");
  check(core.bind(new ConfirmedShotPresentation.Snapshot(id,7,1,0,4)),"rebind");
  check(core.accept(new ConfirmedShotPresentation.Confirmation(id,7,1,9,true,4))==null,"no replay after rebind");
  check(core.bind(new ConfirmedShotPresentation.Snapshot(id,7,2,9,6)),"six-lane configuration allowed by existing core");
  var p=core.accept(new ConfirmedShotPresentation.Confirmation(id,7,2,12,true,4));
  check(p!=null&&p.emitterIndex()==5,"six-lane index");
  check(!adapter.get("present_resolved").call(LuaValue.valueOf(p.emitterIndex())).toboolean(),"four-clip presenter rejects unsupported variant for host fallback");
  check(context.get("ensure").toint()==1&&context.get("amount").toint()==4,"bounded tracks");
  check(adapter.get("close").call().toboolean(),"cleanup");
  System.out.println("PASS existing Java core -> original Lua presenter: "+checks+" assertions. Mock engine context; no native packet or renderer integration.");
 }
}
