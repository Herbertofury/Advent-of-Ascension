"""Audit released-class presence and serialized-key evidence, without executing game code."""
import argparse,pathlib,zipfile,json,hashlib,subprocess,shutil,os
p=argparse.ArgumentParser();p.add_argument('jar');p.add_argument('out');a=p.parse_args();J=pathlib.Path(a.jar)
expected='f95109a9072946e36451daa4c25a588feeda02cf1b24ab810d2176a0635f5cfb5c9408e0345c725a96c4fe70f97251ac55aed25687ed3f4daf12082317ca0f57'
assert hashlib.sha512(J.read_bytes()).hexdigest()==expected,'Wrong release'
keys={'GunStats':['damage','ticks_between_shots','recoil_modifier','unholster_time_modifier','ammo','full_auto'],'BlasterStats':['damage','ticks_between_shots','spirit_cost','charge_up_ticks','beam_distance'],'ShotgunStats':['pellets','pellet_spread','knockback_modifier'],'SniperScope':['scope','zoomStrength'],'ItemUseSound':['sound','pitch']}
classes={};tool=str(pathlib.Path(os.environ['JAVA_HOME'])/'bin/javap')if os.getenv('JAVA_HOME')else shutil.which('javap');assert tool
with zipfile.ZipFile(J)as z:
 for name,fields in keys.items():
  path='net/tslat/aoa3/content/item/datacomponent/'+name+'.class';b=z.read(path);text=subprocess.check_output([tool,'-c','-p','-classpath',str(J),path[:-6].replace('/','.')],text=True)
  for f in fields:assert ('// String '+f+'\n') in text,(name,f)
  classes[name]={'path':path,'sha256':hashlib.sha256(b).hexdigest(),'serialized_keys_observed':fields}
 for path in ['net/tslat/aoa3/common/registration/item/AoADataComponents.class','net/tslat/aoa3/content/item/weapon/gun/AoAGun.class','net/tslat/aoa3/content/item/weapon/blaster/AoABlaster.class','net/tslat/aoa3/library/object/container/AmmoVoidPouchComponent.class']:
  classes[path.rsplit('/',1)[-1][:-6]]={'path':path,'sha256':hashlib.sha256(z.read(path)).hexdigest()}
out={'scope':'Released AoA1.21.1-3.7.16.1 class fingerprints and five codec-key observations. Does not execute codecs, serialize a live item or prove native integration.','jar_sha512':expected,'source_pin':'7919b5fe48599e6105c5740937ce36c36ef21d16','classes':classes,'native_acceptance':False}
pathlib.Path(a.out).write_text(json.dumps(out,indent=2)+'\n');print('PASS nine released class fingerprints and five serialized-key sets; native adapters pending')
