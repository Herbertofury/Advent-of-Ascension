"""Original offline authoring gate for the inspected TML0.1.8 indexed triangle/quad schema."""
import argparse,json,math,pathlib
class MeshError(ValueError):pass
def validate(document,max_vertices=200000,max_faces=100000):
 if not isinstance(document,dict):raise MeshError('Root object required')
 geometries=document.get('minecraft:geometry')
 if not isinstance(geometries,list)or len(geometries)!=1:raise MeshError('Exactly one geometry entry required by this export gate')
 geo=geometries[0]
 if not isinstance(geo,dict):raise MeshError('Geometry object required')
 desc=geo.get('description',{})
 if not isinstance(desc,dict):raise MeshError('Description object required')
 for key in ['texture_width','texture_height']:
  value=desc.get(key)
  if isinstance(value,bool)or not isinstance(value,(int,float))or not math.isfinite(value)or value<=0:raise MeshError('Positive finite texture dimensions required')
 bones=geo.get('bones');names=set();counts={'mesh_bones':0,'source_triangles':0,'source_quads':0,'render_vertices':0};warnings=[]
 if not isinstance(bones,list):raise MeshError('Missing bones')
 def vectors(value,size,label):
  if not isinstance(value,list)or len(value)>max_vertices:raise MeshError(label+' array/budget')
  for vector in value:
   if not isinstance(vector,list)or len(vector)!=size:raise MeshError(label+' tuple size')
   if any(isinstance(v,bool)or not isinstance(v,(int,float))or not math.isfinite(v)or abs(v)>3.4028234663852886e38 for v in vector):raise MeshError(label+' finite numeric components')
  return value
 for bone in bones:
  if not isinstance(bone,dict):raise MeshError('Bone object required')
  name=bone.get('name')
  if not isinstance(name,str)or not name or name in names:raise MeshError('Missing or duplicate bone name')
  names.add(name)
  if 'poly_mesh'not in bone:continue
  if 'hand' in name.lower():warnings.append(name+': keep the actual TaCZ hand rig as cuboids; review naming/role')
  if 'pivot'in bone:vectors([bone['pivot']],3,'pivot')
  mesh=bone['poly_mesh']
  if not isinstance(mesh,dict):raise MeshError('poly_mesh object required')
  positions=vectors(mesh.get('positions'),3,'positions');normals=vectors(mesh.get('normals'),3,'normals');uvs=vectors(mesh.get('uvs'),2,'uvs');polys=mesh.get('polys')
  if 'normalized_uvs'in mesh and not isinstance(mesh['normalized_uvs'],bool):raise MeshError('normalized_uvs must be Boolean')
  if not isinstance(polys,list)or not polys or len(polys)>max_faces:raise MeshError('Nonempty polygon array within budget required')
  if any(abs(c)>65536 for p in positions for c in p):raise MeshError('Authoring coordinate budget exceeded')
  counts['mesh_bones']+=1
  for poly in polys:
   if not isinstance(poly,list)or len(poly)not in(3,4):raise MeshError('Only source triangles/quads; triangulate n-gons before export')
   points=[]
   for item in poly:
    if not isinstance(item,list)or len(item)!=3:raise MeshError('Each corner needs position/normal/UV indices')
    for idx,pool in zip(item,[positions,normals,uvs]):
     if type(idx)is not int or idx<0 or idx>=len(pool):raise MeshError('Invalid geometry index')
    points.append(positions[item[0]])
    if sum(x*x for x in normals[item[1]])<1e-20:raise MeshError('Zero referenced normal')
   a,b,c=points[:3];u=[b[i]-a[i]for i in range(3)];v=[c[i]-a[i]for i in range(3)];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
   if not all(math.isfinite(x)for x in cross)or sum(x*x for x in cross)<1e-20:raise MeshError('Degenerate or overflowed first triangle')
   if len(poly)==4:
    if len({tuple(p)for p in points})<4:raise MeshError('Degenerate authored quad; source triangles should have three corners')
    for corner in range(4):
     a,b,c=points[corner],points[(corner+1)%4],points[(corner+2)%4];u=[b[i]-a[i]for i in range(3)];v=[c[i]-b[i]for i in range(3)];n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
     if sum(n[i]*cross[i]for i in range(3))<=0:raise MeshError('Concave, crossed or degenerate quad; triangulate explicitly')
    span=[points[3][i]-points[0][i]for i in range(3)]
    if abs(sum(span[i]*cross[i]for i in range(3)))>1e-5*math.sqrt(sum(x*x for x in cross))*max(1,math.sqrt(sum(x*x for x in span))):warnings.append(name+': nonplanar quad; triangulate before final shading QA')
   counts['source_triangles'if len(poly)==3 else'source_quads']+=1;counts['render_vertices']+=4
   if counts['render_vertices']>max_faces*4:raise MeshError('Combined render vertex budget')
 if counts['mesh_bones']==0:raise MeshError('No polygon mesh found')
 return {'scope':'Offline schema/index/selected degeneracy gate; not native rendering or full surface QA','counts':counts,'warnings':warnings}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('file',type=pathlib.Path);a=p.parse_args()
 if a.file.stat().st_size>32*1024*1024:raise MeshError('Input exceeds32MiB gate')
 print(json.dumps(validate(json.loads(a.file.read_text())),indent=2))
