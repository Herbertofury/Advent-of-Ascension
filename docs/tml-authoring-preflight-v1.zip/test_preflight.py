import copy,unittest
from preflight_mesh import validate,MeshError

def fixture():return {'minecraft:geometry':[{'description':{'texture_width':16,'texture_height':16},'bones':[{'name':'body','poly_mesh':{'normalized_uvs':True,'positions':[[0,0,0],[1,0,0],[1,1,0],[0,1,0]],'normals':[[0,0,1]],'uvs':[[0,0],[1,0],[1,1],[0,1]],'polys':[[[0,0,0],[1,0,1],[2,0,2]],[[0,0,0],[1,0,1],[2,0,2],[3,0,3]]]}}]}]}
class Check(unittest.TestCase):
 def test_triangle_and_quad(self):self.assertEqual(validate(fixture())['counts'],{'mesh_bones':1,'source_triangles':1,'source_quads':1,'render_vertices':8})
 def test_ngon_rejected(self):
  d=fixture();d['minecraft:geometry'][0]['bones'][0]['poly_mesh']['polys'][1].append([0,0,0])
  with self.assertRaises(MeshError):validate(d)
 def test_bad_indices(self):
  for index in [-1,999,True,1.5]:
   d=fixture();d['minecraft:geometry'][0]['bones'][0]['poly_mesh']['polys'][0][0][0]=index
   with self.assertRaises(MeshError):validate(d)
 def test_nonfinite_and_zero_texture(self):
  for value in [0,float('nan'),float('inf')]:
   d=fixture();d['minecraft:geometry'][0]['description']['texture_width']=value
   with self.assertRaises(MeshError):validate(d)
 def test_duplicate_bone_and_geometry(self):
  d=fixture();d['minecraft:geometry'][0]['bones']*=2
  with self.assertRaises(MeshError):validate(d)
  d=fixture();d['minecraft:geometry']*=2
  with self.assertRaises(MeshError):validate(d)
 def test_source_degeneracy(self):
  d=fixture();d['minecraft:geometry'][0]['bones'][0]['poly_mesh']['positions'][1]=[0,0,0]
  with self.assertRaises(MeshError):validate(d)
 def test_hand_warning(self):
  d=fixture();d['minecraft:geometry'][0]['bones'][0]['name']='left_hand';self.assertTrue(validate(d)['warnings'])
 def test_wrong_root_and_nested_types(self):
  for d in [[],{'minecraft:geometry':[None]}, {'minecraft:geometry':[{'description':None}]}]:
   with self.assertRaises(MeshError):validate(d)
 def test_float32_overflow_and_coordinate_budget(self):
  for v in [1e300,70000]:
   d=fixture();d['minecraft:geometry'][0]['bones'][0]['poly_mesh']['positions'][1][0]=v
   with self.assertRaises(MeshError):validate(d)
 def test_crossed_quad(self):
  d=fixture();mesh=d['minecraft:geometry'][0]['bones'][0]['poly_mesh'];mesh['polys']=[[[0,0,0],[2,0,2],[1,0,1],[3,0,3]]]
  with self.assertRaises(MeshError):validate(d)
if __name__=='__main__':unittest.main()
