"""Index packaged recipe/loot references without inventing lore or runtime availability."""
from pathlib import Path
import zipfile,json,hashlib,argparse
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--jar',type=Path,default=R.parent/'references/AoA3-1.20.1-3.7.1-all.jar');p.add_argument('--coverage',type=Path,default=R.parent/'weapon-completeness-standard-v3/coverage.json');a=p.parse_args();expected='f417ecb337d4a3b2aebec559a9262d8a86cc93ee7910f4eea64108bff063193a';assert hashlib.sha256(a.jar.read_bytes()).hexdigest()==expected
ids=[r['id']for r in json.loads(a.coverage.read_text())['weapons']];assert len(ids)==len(set(ids))==228;recipes={};loot={};entry_hashes={}
def item_refs(x,key='item'):
 if isinstance(x,dict):
  if isinstance(x.get(key),str):yield x[key]
  for v in x.values():yield from item_refs(v,key)
 elif isinstance(x,list):
  for v in x:yield from item_refs(v,key)
def loot_items(x):
 if isinstance(x,dict):
  if x.get('type')=='minecraft:item'and isinstance(x.get('name'),str):yield x['name']
  for v in x.values():yield from loot_items(v)
 elif isinstance(x,list):
  for v in x:yield from loot_items(v)
with zipfile.ZipFile(a.jar)as z:
 for name in z.namelist():
  if not name.endswith('.json'):continue
  if name.startswith('data/aoa3/recipes/'):
   raw=z.read(name);d=json.loads(raw);result=d.get('result');output=result.get('item')if isinstance(result,dict)else result if isinstance(result,str)else None
   if output in ids:
    inputs={k:v for k,v in d.items()if k!='result'};kit=d.get('upgrade_kit',{});record={'entry':name,'sha256':hashlib.sha256(raw).hexdigest(),'type':d.get('type'),'input_item_references':sorted(set(item_refs(inputs))),'input_tag_references':sorted(set(item_refs(inputs,'tag'))),'upgrade_kit':kit.get('item')if isinstance(kit,dict)else None,'upgrade_input':d.get('input',{}).get('item')if d.get('type')=='aoa3:upgrade_kit' and isinstance(d.get('input'),dict)else None};recipes.setdefault(output,[]).append(record)
  elif name.startswith('data/aoa3/loot_tables/'):
   raw=z.read(name);d=json.loads(raw);refs=set(loot_items(d))
   for item in refs:loot.setdefault(item,[]).append({'entry':name,'sha256':hashlib.sha256(raw).hexdigest(),'world_id_from_path':name.split('/worlds/',1)[1][:-5]if'/worlds/'in name else None})
rows=[]
for id in ids:
 rs=recipes.get(id,[]);kits=sorted({r['upgrade_kit']for r in rs if r['upgrade_kit']});rows.append({'id':id,'packaged_recipes':rs,'direct_loot_references':loot.get(id,[]),'upgrade_kit_loot_associations':{kit:loot.get(kit,[])for kit in kits},'lore_review':'not_completed','warning':'References are not a maker attribution, creator-intent statement or proof that the entry is active in this release. Ingredient alternatives and consumption rules need full recipe review.'})
report={'release':'AoA 3.7.1 / Minecraft 1.20.1','jar_sha256':expected,'rows':rows,'counts':{'weapon_ids':len(rows),'with_packaged_recipe':sum(bool(r['packaged_recipes'])for r in rows),'with_upgrade_recipe':sum(bool(r['upgrade_kit_loot_associations'])for r in rows),'with_direct_loot_reference':sum(bool(r['direct_loot_references'])for r in rows)},'native_availability_verified':False,'scope':'One-pass data reference index to seed lore research; not complete lore or completed upgrades'};(R/'origin-data-index.json').write_text(json.dumps(report,indent=2)+'\n');print(report['counts'])
byid={r['id']:r for r in rows};apoco=byid['aoa3:apoco_assault_rifle'];assert any(r['upgrade_input']=='aoa3:mechanical_assault_rifle'and r['upgrade_kit']=='aoa3:apoco_upgrade_kit'for r in apoco['packaged_recipes']);assert any(r['world_id_from_path']=='vox_ponds'for r in apoco['upgrade_kit_loot_associations']['aoa3:apoco_upgrade_kit']);assert any(r['upgrade_input']=='aoa3:discharge_rifle'for r in byid['aoa3:apoco_rifle']['packaged_recipes']);print('PASS: 228 unique IDs and distinct Apoco lineage fixtures; no native/lore acceptance')
