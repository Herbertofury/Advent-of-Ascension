# Soul Storm v15 ornamental authoring candidate

Adds sculpted silver/indigo core clasps, branching cyan emitter inscriptions, thin metal inlays, visible open muzzle-border glow and a heel crest to the corrected four-emitter full-detail source. The default Soul Flame and earlier motion remain. This is original modeled geometry, not a generated concept image or native Minecraft screenshot.

Reproduce with Blender4.3.2: run refine.py --source pointing to the targeted-corrected v14 four-emitter scene, then check.py and render_views.py. Pass Blender --python-exit-code 1. The source scene is reproduced from the published v14 archive plus targeted-clearance-v1 script. This small archive avoids another duplicate packed source scene.

The source concept remains the visual target; v15 is not final artistic acceptance. The first muzzle rail placement was buried in the face and was moved onto its border before review. The first top/bottom inspection camera cropped the body; final views use expanded framing. Six final orthographic views and the hero were reviewed. Inspection views have an extra camera-facing light and are not beauty-lighting or native footage.

Scoped QA checks new triangles in world space, sampled AABB separation of moving decorations from named stationary saddles, and new glow borders against a conservative open aperture. No complete continuous collision, hand-fit, shader, native gameplay or FPS acceptance. The single-plane flame remains an angle-dependent authoring effect, pending native presentation handling. Preserve all prior art/source versions.
