import bpy,json,math
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-v15.blend'));s=bpy.context.scene
new=[o for o in bpy.data.objects if o.name.startswith('V15 ')];mov=[o for o in new if o.parent and o.parent.name.startswith('Emitter_')];saddles=[o for o in bpy.data.objects if o.name.startswith(('Emitter structural saddle','Saddle indigo face','Saddle cyan rune')) and not o.hide_render]
def bounds(o):
 points=[o.matrix_world@Vector(v)for v in o.bound_box];return [min(v[i]for v in points)for i in range(3)],[max(v[i]for v in points)for i in range(3)]
def penetration(a,b):
 lo,hi=bounds(a);bl,bh=bounds(b);return [min(hi[i],bh[i])-max(lo[i],bl[i])for i in range(3)]
issues=[];checks=0
for frame in [i/4 for i in range(4*s.frame_end+1)]:
 s.frame_set(int(frame),subframe=frame-int(frame));bpy.context.view_layer.update()
 for a in mov:
  for b in saddles:
   d=penetration(a,b);checks+=1
   if min(d)>1e-5:issues.append({'frame':frame,'a':a.name,'b':b.name,'overlap':d})
s.frame_set(0);bpy.context.view_layer.update();aperture_checks=[]
for o in new:
 if not o.name.startswith(('V15 muzzle lip glow','V15 muzzle side glow')):continue
 e=o.parent;z=next(c for c in e.children if c.name.startswith('Rear energy coupler')).location.z;lo,hi=bounds(o)
 # Conservative open rectangular aperture, separate from surrounding seated lip accents.
 intersects=lo[1]<.73 and hi[1]>-.73 and lo[2]<z+.08 and hi[2]>z-.08
 aperture_checks.append({'object':o.name,'intrudes_open_aperture':intersects});assert not intersects,o.name
dg=bpy.context.evaluated_depsgraph_get();bad=[];triangles=0
for o in new:
 e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();triangles+=len(m.loop_triangles)
 for i,t in enumerate(m.loop_triangles):
  v=[o.matrix_world@m.vertices[x].co for x in t.vertices]
  if (v[1]-v[0]).cross(v[2]-v[0]).length_squared<1e-20:bad.append([o.name,i])
 e.to_mesh_clear()
report={'scope':'New-ornament world-space triangles at neutral pose and sampled AABB separation from named stationary saddles only','aperture_checks':aperture_checks,'new_objects':len(new),'new_triangles':triangles,'degenerate_triangles':bad,'sampled_pair_checks':checks,'collisions':issues,'limits':['Not continuous triangle collision proof','Decorative seated surface contacts not included','No full hand/grip or native engine acceptance']};(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['new_objects','new_triangles','sampled_pair_checks']}));assert not bad,bad;assert not issues,issues[:5]
