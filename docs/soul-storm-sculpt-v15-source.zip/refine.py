"""Original ornamental refinement on preserved corrected v14; not native acceptance."""
import bpy,math,json,sys,argparse
from mathutils import Vector
from pathlib import Path
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--source',required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);bpy.ops.wm.open_mainfile(filepath=str(Path(a.source).resolve()));scene=bpy.context.scene;scene.frame_set(0)
root=bpy.data.objects['SoulStorm_Root'];silver=bpy.data.materials['Brushed silver'];indigo=bpy.data.materials['Anodized indigo'];cyan=bpy.data.materials['Spirit cyan'];dark=bpy.data.materials['Obsidian violet'];new=[]
def finish(o,name,mat,parent=root):
 o.name=name;o.parent=parent;o.data.materials.append(mat);new.append(o.name);return o
def prism(name,outline,y,depth,mat,parent=root):
 vs=[(x,y+dy,z)for dy in [-depth/2,depth/2]for x,z in outline];n=len(outline);fs=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n)for i in range(n)];m=bpy.data.meshes.new(name);m.from_pydata(vs,[],fs);m.update();o=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(o);return finish(o,name,mat,parent)
def path(name,pts,width,mat,parent=root):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=1;c.bevel_depth=width;c.bevel_resolution=1;s=c.splines.new('POLY');s.points.add(len(pts)-1)
 for v,pt in zip(s.points,pts):v.co=(*pt,1)
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);return finish(o,name,mat,parent)
def gem(name,center,size,parent=root):
 x,y,z=center;w,h,d=size;vs=[(x-w,y,z),(x,y,z+h),(x+w,y,z),(x,y,z-h),(x,y-d,z),(x,y+d,z)];fs=[(i,(i+1)%4,4)for i in range(4)]+[((i+1)%4,i,5)for i in range(4)];m=bpy.data.meshes.new(name);m.from_pydata(vs,[],fs);m.update();o=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(o);return finish(o,name,cyan,parent)
# Four sculpted chevron clasps on each face, seated on the circular frame.
for o in bpy.data.objects:
 if o.name.startswith(('Radial silver clamp','Clamp spirit inset')):o.hide_render=True
cx,cz=-2.4,1.65
for side in [-1,1]:
 y=side*.88
 for k in range(4):
  angle=math.pi/4+k*math.pi/2;rx,rz=math.cos(angle),math.sin(angle);tx,tz=-rz,rx
  def pt(r,t):return(cx+rx*r+tx*t,cz+rz*r+tz*t)
  silhouette=[pt(1.18,0),pt(1.43,-.19),pt(1.73,-.12),pt(1.59,0),pt(1.73,.12),pt(1.43,.19)]
  prism('V15 sculpted silver clasp',silhouette,y,.12,silver)
  prism('V15 clasp indigo inset',[pt(1.29,0),pt(1.44,-.105),pt(1.58,0),pt(1.44,.105)],y+side*.075,.035,indigo)
  gem('V15 clasp spirit jewel',(cx+rx*1.44,y+side*.115,cz+rz*1.44),(.065,.11,.045))
# Stepped silver face accents and energy inscriptions on each independently moving emitter.
emitters=sorted((o for o in bpy.data.objects if o.name.startswith('Emitter_')and o.name.endswith('_top_to_bottom')),key=lambda o:o.name)
for i,e in enumerate(emitters):
 coupler=next(o for o in e.children if o.name.startswith('Rear energy coupler'));z=coupler.location.z
 for side in [-1,1]:
  y=side*.934
  for begin,end in[(.55,2.20),(3.12,3.68)]:
   outline=[(begin,z+.14),(begin+.14,z+.19),(end-.12,z+.19),(end,z+.12),(end-.12,z+.095),(begin+.1,z+.095)]
   prism('V15 emitter silver bevel inlay',outline,y,.018,silver,e)
  path('V15 branching soul inscription',[(.62,y+side*.018,z),(.87,y+side*.018,z+.06),(1.04,y+side*.018,z-.025),(1.25,y+side*.018,z-.025),(1.40,y+side*.018,z+.045),(1.66,y+side*.018,z+.045),(1.82,y+side*.018,z-.035),(2.06,y+side*.018,z)],.012,cyan,e)
  path('V15 inscription fork',[(1.4,y+side*.018,z+.045),(1.49,y+side*.018,z+.12),(1.68,y+side*.018,z+.12)],.009,cyan,e)
 # Glowing lip rails occupy solid border, preserving the open horizontal disc passage.
 for dz in [-.135,.135]:path('V15 muzzle lip glow',[(3.935,-.77,z+dz),(3.935,.77,z+dz)],.012,cyan,e)
 for yy in [-.77,.77]:path('V15 muzzle side glow',[(3.935,yy,z-.135),(3.935,yy,z+.135)],.012,cyan,e)
# Frame-integrated heel crest, safely clear of the hand-contact region.
gem('V15 heel spirit crest',(-3.65,-.66,-2.02),(.14,.09,.025))
scene.render.resolution_x=1400;scene.render.resolution_y=900;scene.cycles.samples=48;scene.cycles.use_denoising=False;scene.frame_set(0);bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'soul-storm-v15.blend'));scene.render.filepath=str(R/'hero.png');bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'Original ornamental authoring candidate, unaccepted','new_objects':new,'default_sight':'Soul Flame retained','limits':['No native gameplay/render acceptance','New ornaments require full mesh and sampled clearance QA','No first-person/hand acceptance','Existing source and approved motion preserved in separate prior files']},indent=2)+'\n')
