import bpy
from mathutils import Vector
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-v15.blend'));s=bpy.context.scene;s.render.resolution_x=1000;s.render.resolution_y=700;s.cycles.samples=20;s.cycles.use_denoising=False;c=s.camera;c.data.ortho_scale=11
bpy.ops.object.light_add(type='AREA',location=(0,0,0));inspection_light=bpy.context.object;inspection_light.data.energy=1800;inspection_light.data.size=6
for name,loc in [('front',(14,0,1.3)),('rear',(-14,0,1.3)),('left',(0,-16,1.3)),('right',(0,16,1.3)),('top',(0,0,18)),('bottom',(0,0,-16))]:
 c.data.ortho_scale=16 if name in ['top','bottom']else 11;c.location=loc;c.rotation_euler=(Vector((-.1,0,1.3))-c.location).to_track_quat('-Z','Y').to_euler();inspection_light.location=c.location;inspection_light.rotation_euler=c.rotation_euler;s.render.filepath=str(R/(name+'.png'));bpy.ops.render.render(write_still=True)
