"""Technical pixel-preserving atlas packing for original project assets; no repaint/resampling."""
from PIL import Image
from pathlib import Path
import json,hashlib,argparse,math
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--textures',required=True,type=Path);a=p.parse_args();m=json.loads((R/'transport-manifest.json').read_text());atlas=Image.new('RGBA',(2048,2048));checks=[]
def place(image,rect):
 x,y,w,h=rect;assert image.size==(w,h);atlas.paste(image,(x,y));g=4
 for k in range(1,g+1):
  atlas.paste(image.crop((0,0,1,h)),(x-k,y));atlas.paste(image.crop((w-1,0,w,h)),(x+w-1+k,y));atlas.paste(image.crop((0,0,w,1)),(x,y-k));atlas.paste(image.crop((0,h-1,w,h)),(x,y+h-1+k))
 for dx,dy,sx,sy in [(-g,-g,0,0),(w,-g,w-1,0),(-g,h,0,h-1),(w,h,w-1,h-1)]:atlas.paste(image.getpixel((sx,sy)),(x+dx,y+dy,x+dx+g,y+dy+g))
 checks.append((image,rect))
core=Image.open(a.textures/'soul-storm-core-vfx-texture-v1.png').convert('RGBA');flame=Image.open(a.textures/'soul-flame-atlas-candidate-v3.png').convert('RGBA');assert core.size==(1269,1239)and flame.size==(1024,1024)
place(core,m['atlas']['core_rect'])
for i,rect in enumerate(m['atlas']['flame_frame_rects']):x=(i%4)*256;y=(i//4)*256;place(flame.crop((x,y,x+256,y+256)),rect)
def srgb(v):return max(0,min(255,round((12.92*v if v<=.0031308 else 1.055*v**(1/2.4)-.055)*255)))
for i,(name,data)in enumerate(m['materials'].items()):
 rgba=tuple(srgb(v)for v in data['linear_base_rgba'][:3])+(255,);atlas.paste(rgba,(i*40,1600,i*40+40,1640))
atlas.save(R/'soul_storm_transport.png')
reopened=Image.open(R/'soul_storm_transport.png').convert('RGBA')
for im,(x,y,w,h)in checks:assert reopened.crop((x,y,x+w,y+h)).tobytes()==im.tobytes()
report={'size':[2048,2048],'pixel_preserved_image_regions':len(checks),'resampling':False,'gutter_pixels':4,'palette_encoding':'Original Blender linear base colors converted to sRGB bytes; not a native lighting/PBR equivalence claim','sha256':hashlib.sha256((R/'soul_storm_transport.png').read_bytes()).hexdigest(),'limits':['Four-pixel gutters are not native mip/bleed acceptance','Source core low border alpha remains','Static flame frame0 mapped; animation adapter pending']};(R/'atlas-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
