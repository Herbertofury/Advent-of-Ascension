# Soul Storm v15 exported geometry candidates

Not an installable gunpack. Full-detail and world-LOD static geometry share the original packed atlas. The atlas preserves the core and 15 flame cells pixel-for-pixel; only flame frame zero is mapped. Four prior recoil clips use the same emitter bone names, but native animation/gameplay binding remains unverified.

Full body: 44,264 triangles, 177,056 baked vertices. World LOD body: 20,584 triangles, 82,336 baked vertices. Authoring-scene totals include hidden-by-scale projectile cues and differ (49640→25960). Do not compare these with a different revision as if they were identical visual tiers. The selected LOD reduces eight-float-array payload from 5,665,792 to 2,634,752 bytes, excluding all object, JSON and GPU overhead. No frame-time claim.

Each variant passes the offline mesh preflight and the actual released TML0.1.8 baker under Java17/21. Compact LOD JSON yields bit-identical baked arrays; its smaller byte count is not a game-loading benchmark. Source scripts, unrounded exports, receipts and original assets are retained. Native flat shading, material translation, hand alignment, event binding and gameplay acceptance remain open.

Reproduce refinement from v15-source.zip and the published corrected v14 base. Run lod/build_candidate.py with Blender --python-exit-code 1 and --source path after --. Then run export_geometry.py against the selected .blend and pack_atlas.py against the original v14 texture directory. Run the separately published TML regression and float32 compactor tools.
