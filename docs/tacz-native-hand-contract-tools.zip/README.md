# Native hand contract audit

Supply the official matching TaCZ JAR locally, then run:

    python audit.py /path/to/tacz-1.20.1-1.1.8-hotfix2.jar --javap /path/to/jdk/bin/javap

This inspects released bytecode and JSON without running game classes. No native hand-fit acceptance is implied.
