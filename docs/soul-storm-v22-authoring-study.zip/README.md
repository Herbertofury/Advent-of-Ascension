# Soul Storm v22 authoring study

Unaccepted source study, not a gunpack. Open the packed v22 blend directly. Build scripts preserve the progression: v20 opens previously published v19; v21 opens v20; v22 opens v21. Supply their recorded sibling source paths to reconstruct. No old source was discarded.

Adds open crown geometry, varied authoring plasma and the missing physical brazier-support bridge discovered in front/rear review. 101 frame geometry checks cover 5,097,360 active triangle samples with no collapsed active triangles. Neutral closed volumes have no negatives and exact duplicate-surface test passes. These tests are narrower than animation collision, hand clearance, gameplay and art acceptance.

The shader remains Blender authoring work. Earlier v19 hardware-only transport does not contain these later changes.
