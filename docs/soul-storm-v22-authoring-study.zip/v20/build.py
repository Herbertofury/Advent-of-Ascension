import bpy,bmesh,json,math
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'soul-storm-sculpt-v19/soul-storm-v19.blend'));s=bpy.context.scene;s.frame_set(0)
source=bpy.data.objects['Tapered emitter shell.004'];parent=source.parent;source.hide_render=True;bpy.data.objects['Emitter spine inset'].hide_render=True
new=[]
def prism(name,xy,z0,z1,material):
 n=len(xy);verts=[(x,y,z)for z in [z0,z1]for x,y in xy];faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n)for i in range(n)]
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(me);bm.free();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);w=o.matrix_world.copy();o.parent=parent;o.matrix_world=w;o.data.materials.append(bpy.data.materials[material]);b=o.modifiers.new('Controlled edge chamfer','BEVEL');b.width=min(.035,(z1-z0)*.2);b.segments=2;new.append(name);return o
# A real exposed top conduit, framed by tapered armor rather than a solid slab.
for side in [-1,1]:
 xy=[(.18,side*.92),(4.85,side*.92),(4.85,side*.60),(3.62,side*.60),(3.40,side*.73),(.45,side*.73)]
 prism('V20 tapered crown rail '+str(side),xy,2.75,3.03,'Anodized indigo')
 prism('V20 crown silver edge '+str(side),[(.38,side*.92),(3.50,side*.92),(3.50,side*.88),(.38,side*.88)],3.026,3.055,'Brushed silver')
prism('V20 nose crown',[(3.64,-.72),(4.85,-.72),(4.85,.72),(3.64,.72)],2.75,3.03,'Anodized indigo')
prism('V20 rear crown collar',[(.18,-.75),(.48,-.75),(.48,.75),(.18,.75)],2.75,3.03,'Obsidian violet')
# Crown clamp segments frame the end without filling the exposed channel.
for side in [-1,1]:
 prism('V20 curved clamp '+str(side),[(3.22,side*.94),(3.68,side*.94),(3.82,side*.38),(3.58,side*.38),(3.43,side*.73),(3.22,side*.73)],3.031,3.16,'Brushed silver')
prism('V20 crown conductor',[(.52,-.04),(3.53,-.04),(3.53,.04),(.52,.04)],2.84,2.88,'Spirit cyan')
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'soul-storm-v20.blend'));s.cycles.samples=32;s.cycles.use_denoising=False;s.render.filepath=str(R/'hero.png');bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'Unaccepted concept-directed open-crown experiment','new_objects':new,'source':'v19','native_acceptance':False,'checks_pending':['All-view visual comparison','Active geometry/winding and duplicates','Moving clearances','Native materials and gameplay']},indent=2)+'\n')
