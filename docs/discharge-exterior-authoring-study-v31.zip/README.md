# Discharge unaccepted authoring study

Blender 4.3.2 editable scene, no external image dependency. Not a native TaCZ gunpack. Run the scoped check with: blender -b -t 2 --python-exit-code 1 --python check_packaged_scene.py

This checks evaluated world-space triangle area only. Hands, swept collisions, UVs, material export, animation, native gameplay and performance remain untested. Geometry/visual acceptance must not be inferred from this check.
