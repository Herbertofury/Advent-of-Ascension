"""Build a version-pinned recipe index and illustrated reference sheets. No game execution."""
import argparse,collections,hashlib,io,json,pathlib,zipfile
from PIL import Image,ImageDraw,ImageFont
p=argparse.ArgumentParser();p.add_argument('jar');p.add_argument('out');a=p.parse_args();out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
raw=pathlib.Path(a.jar).read_bytes();sha=hashlib.sha512(raw).hexdigest()
assert sha=='bdee7d12aab1903e1e74f377d4f0ae7ac948d791f46ec0368d191d86a3d5a03cfbd2e6d1295f1fe690f303b1fa709da89db980543e4d450fc0fdbbf6d9e694e6'
z=zipfile.ZipFile(io.BytesIO(raw));lang=json.loads(z.read('assets/aoa3/lang/en_us.json'));rows=[]
def title(id):return lang.get('item.'+id.replace(':','.'),id)
def sprite(id):
 ns,name=id.split(':');m=json.loads(z.read(f'assets/{ns}/models/item/{name}.json'));tex=m['textures']['layer0'];tn,tp=tex.split(':');path=f'assets/{tn}/textures/{tp}.png';b=z.read(path);im=Image.open(io.BytesIO(b)).convert('RGBA');original_size=im.size; frame=0
 if im.width!=im.height:
  meta=json.loads(z.read(path+'.mcmeta'))['animation']; frames=meta.get('frames',[0]); first=frames[0];frame=first if isinstance(first,int) else first['index'];fw=meta.get('width',im.width);fh=meta.get('height',fw);cols=im.width//fw;im=im.crop(((frame%cols)*fw,(frame//cols)*fh,(frame%cols+1)*fw,(frame//cols+1)*fh))
 return im,{'model':f'assets/{ns}/models/item/{name}.json','texture':path,'sha256':hashlib.sha256(b).hexdigest(),'source_size':original_size,'displayed_frame_index':frame}
for n in sorted(z.namelist()):
 if n.startswith('data/aoa3/recipes/') and n.endswith('.json'):
  j=json.loads(z.read(n))
  if j.get('type')=='aoa3:upgrade_kit':
   r={'id':'aoa3:'+n.split('/')[-1][:-5],'path':n,'sha256':hashlib.sha256(z.read(n)).hexdigest(),'input':j['input']['item'],'ingredient':j['upgrade_kit']['item'],'output':j['result']['item'],'count':j['result'].get('count',1)}
   r['names']={k:title(r[k]) for k in ['input','ingredient','output']};r['sprites']={k:sprite(r[k])[1] for k in ['input','ingredient','output']};rows.append(r)
rows.sort(key=lambda r:(r['names']['ingredient'],r['names']['output']));assert len(rows)==70;assert len({r['ingredient'] for r in rows})==19;assert all(r['count']==1 for r in rows)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';F=lambda s:ImageFont.truetype(font,s)
def fitted(d,s,w,size=24):
 while d.textbbox((0,0),s,font=F(size))[2]>w and size>12:size-=1
 return F(size)
for start in range(0,len(rows),7):
 batch=rows[start:start+7];im=Image.new('RGB',(1440,150+len(batch)*170),(13,18,31));d=ImageDraw.Draw(im)
 d.text((40,23),'DIVINE STATION / WEAPON UPGRADES',font=F(34),fill='#e7c779');d.text((40,75),f'AoA 3.7.1 • Minecraft 1.20.1 • Routes {start+1}–{start+len(batch)} / 70',font=F(22),fill='#b5c3d8')
 for i,r in enumerate(batch):
  y=130+i*170;d.rounded_rectangle((25,y,1415,y+150),radius=14,fill='#192338')
  for k,x,w in [('input',50,400),('ingredient',520,390),('output',990,400)]:
   s,_=sprite(r[k]);s=s.resize((84,84),Image.Resampling.NEAREST);im.paste(s,(x,y+16),s);label=r['names'][k];d.text((x,y+110),label,font=fitted(d,label,w),fill='#f1f4fb');d.text((x+100,y+25),k.upper(),font=F(16),fill='#899bb4')
  d.text((458,y+44),'+',font=F(36),fill='#e7c779');d.text((930,y+44),'→',font=F(36),fill='#e7c779')
 d.text((40,im.height-18),'Source item sprites: Tslat / AoA contributors. Reference diagram, not an in-game screenshot.',font=F(12),fill='#9aa8bf');im.save(out/f'upgrade-kit-routes-1.20.1-{start//7+1}.webp',lossless=True)
result={'minecraft':'1.20.1','aoa':'3.7.1','archive_sha512':sha,'source':'https://cdn.modrinth.com/data/9qn2AQBc/versions/ADsBtG85/AoA3-1.20.1-3.7.1-all.jar','recipe_count':len(rows),'ingredient_count':19,'routes':rows};(out/'upgrade-kit-routes-1.20.1.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: 70 unique recipes, 19 ingredients, 210 resolved sprite references, 10 illustrated sheets')
