import importlib.util,random,struct,json,math
from pathlib import Path
s=importlib.util.spec_from_file_location('c',Path(__file__).with_name('compact_float32.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=random.Random(180026);tested=0
for bits in [0,0x80000000,1,0x80000001,0x7f7fffff,0xff7fffff]+[r.getrandbits(32)for _ in range(100000)]:
 f=struct.unpack('!f',struct.pack('!I',bits))[0]
 if not math.isfinite(f):continue
 assert m.bits(float(m.encode(f,True)))==struct.pack('!I',bits);tested+=1
meta=1.2345678901234567;data={'metadata':meta,'minecraft:geometry':[{'bones':[{'poly_mesh':{'positions':[[meta,-0.0,1.0]],'normals':[[0.,0.,1.]],'uvs':[[.123456789,0.]]}}]}]};out=json.loads(m.encode(data));assert out['metadata']==meta;m.verify(data,out)
for bad in [float('nan'),float('inf'),-float('inf')]:
 try:m.encode(bad,True);raise AssertionError('nonfinite accepted')
 except ValueError:pass
print('PASS',tested,'finite float32 edge/random values including signed zero; unrelated double metadata preserved; nonfinite rejected')
