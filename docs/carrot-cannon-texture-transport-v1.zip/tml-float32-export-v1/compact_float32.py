"""TML-specific numeric encoding; preserves consumed float32 bits, not arbitrary double consumers."""
import json,math,struct,argparse,hashlib
from pathlib import Path
def bits(x):return struct.pack('!f',float(x))
def encode(value,compact=False,path=()):
 if isinstance(value,float) and compact:
  if not math.isfinite(value):raise ValueError('Nonfinite number')
  rounded=struct.unpack('!f',bits(value))[0]
  text='-0.0'if rounded==0 and math.copysign(1,rounded)<0 else format(rounded,'.9g')
  assert bits(float(text))==bits(value)
  return text
 if isinstance(value,list):return '['+','.join(encode(v,compact,path)for v in value)+']'
 if isinstance(value,dict):return '{'+','.join(json.dumps(k,ensure_ascii=False)+':'+encode(v,compact or (path and path[-1]=='poly_mesh' and k in ('positions','normals','uvs')),path+(k,))for k,v in value.items())+'}'
 return json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':'))
def verify(a,b):
 if isinstance(a,float):assert bits(a)==bits(b);return 1
 if isinstance(a,list):assert len(a)==len(b);return sum(verify(x,y)for x,y in zip(a,b))
 if isinstance(a,dict):assert list(a)==list(b);return sum(verify(a[k],b[k])for k in a)
 assert a==b;return 0
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('output',type=Path);a=p.parse_args();assert a.source.resolve()!=a.output.resolve(),'Keep original source separate';assert a.source.stat().st_size<=32*1024*1024,'Offline tool input limit:32MiB';raw=a.source.read_bytes();data=json.loads(raw);assert isinstance(data,dict)and isinstance(data.get('minecraft:geometry'),list),'Expected Bedrock geometry document';out=(encode(data)+'\n').encode();count=verify(data,json.loads(out));a.output.write_bytes(out);print(json.dumps({'source_bytes':len(raw),'output_bytes':len(out),'reduction_fraction':1-len(out)/len(raw),'verified_float32_values':count,'source_sha256':hashlib.sha256(raw).hexdigest(),'output_sha256':hashlib.sha256(out).hexdigest(),'scope':'TML consumed float32 bit equivalence; not a generic double-precision JSON rewrite or FPS claim'}))
