# Smaller TML geometry JSON without changing consumed float32 bits

This optional exporter rewrites only poly_mesh positions, normals and UV arrays to nine-significant-digit float32 decimals. Unrelated metadata retains its original JSON numeric values. Original inputs are preserved; same-path input/output is rejected. Maximum input32MiB is a local tool bound, not a TML engine limit. Run the mesh preflight before and after; this is not a schema or surface validator.

python compact_float32.py original.geo.json compact.geo.json
python test_compactor.py

For the v15 world-LOD transport: 2,258,953→1,726,063 bytes (23.59% less uncompressed JSON). 73,143 numeric values retain float32 bits. The actual released TML0.1.8 baker produces bit-identical arrays across all658,688 baked float values in13 meshes on Java17 and21. A separate test covers99,631 finite edge/random float32 values, signed zero and unchanged unrelated double metadata. These are scoped export/data-processing results, not game-loading or FPS benchmarks.

This is specifically for consumers that parse these fields as float32. Do not assume equivalence for a different double-precision engine, arbitrary JSON metadata or mathematical tools. Preserve the original source file and source authoring assets.
