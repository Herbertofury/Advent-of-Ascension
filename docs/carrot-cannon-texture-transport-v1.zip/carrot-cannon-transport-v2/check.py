from pathlib import Path
import subprocess,json,sys,shutil
R=Path(__file__).resolve().parent;W=R.parent;jdk=W/'toolchains/amazon-corretto-17.0.20.12.1-linux-x64/bin';libs=W/'released-tacz-parser-study/cache/lib';source=R/'carrot_cannon.geo.json';compact=R/'carrot_cannon_compact.geo.json';m=json.loads((R/'manifest.json').read_text());r=subprocess.run([sys.executable,str(W/'tml-float32-export-v1/compact_float32.py'),str(source),str(compact)],capture_output=True,text=True,check=True);(R/'compact-result.json').write_text(r.stdout)
for label,java in [('java17',str(jdk/'java')),('java21','/usr/bin/java')]:
 cmd=[sys.executable,str(W/'tml-export-regression-v4/run_check.py'),'--jar',str(W/'references/tacz-mesh-loader-forge-1.20.1-0.1.8.jar'),'--lib',str(libs),'--jdk',str(jdk),'--java',java,'--geometry',str(source),'--compare-geometry',str(compact),'--expected-bones',str(m['mesh_bones']),'--expected-vertices',str(m['expected_tml_baked_vertices'])];r=subprocess.run(cmd,capture_output=True,text=True);(R/(label+'.log')).write_text(r.stdout+r.stderr);print(label,r.returncode);r.check_returncode()
for n in ['carrot-shared-basecolor.png','carrot-shared-emission.png','carrot-shared-roughness.png']:shutil.copyfile(W/'carrot-cannon-shared-atlas-v17'/n,R/n)
shutil.copyfile(W/'carrot-cannon-open-faces-v12/carrot_cannon.animation.json',R/'carrot_cannon.animation.json')
