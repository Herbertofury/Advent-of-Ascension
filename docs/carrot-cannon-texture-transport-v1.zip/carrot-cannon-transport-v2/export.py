"""Original geometry transport fixture with explicit atlas and rig names; not a gunpack."""
import bpy,json,hashlib
from pathlib import Path
from mathutils import Matrix
R=Path(__file__).resolve().parent;source=R.parent/'carrot-cannon-shared-atlas-v17/carrot-shared-atlas.blend';bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene;s.frame_set(0);bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();M=Matrix(((0,-1,0),(0,0,1),(-1,0,0)));groups={};receipts=[]
def add(g,k,value):
 t=tuple(float(x)for x in value);cache=g['_'+k]
 if t not in cache:cache[t]=len(g[k]);g[k].append(list(t))
 return cache[t]
for o in bpy.data.objects:
 if not o.name.startswith('SharedAtlas_')or o.hide_render:continue
 e=o.evaluated_get(dg);mesh=e.to_mesh();mesh.calc_loop_triangles();uv=mesh.uv_layers.get('SharedAtlasUV');assert uv;normal_matrix=M@o.matrix_world.to_3x3().inverted().transposed();count=0
 for tri in mesh.loop_triangles:
  mat=mesh.materials[tri.material_index].name
  name='carrot_trigger_pivot'if o.name=='SharedAtlas_Separate trigger'else('carrot_glass_illuminated'if mat.startswith('Amber petal glass')else'carrot_weapon_root')
  if name not in groups:groups[name]={'normalized_uvs':True,'positions':[],'normals':[],'uvs':[],'polys':[],'_positions':{},'_normals':{},'_uvs':{}}
  g=groups[name];poly=[]
  for li in tri.loops:
   pos=M@(o.matrix_world@mesh.vertices[mesh.loops[li].vertex_index].co)*4;normal=(normal_matrix@mesh.corner_normals[li].vector).normalized();coord=uv.data[li].uv;assert all(0<=x<=1 for x in coord);poly.append([add(g,'positions',pos),add(g,'normals',normal),add(g,'uvs',coord)])
  g['polys'].append(poly);count+=1
 receipts.append({'object':o.name,'triangles':count});e.to_mesh_clear()
bones=[{'name':'root','pivot':[0,0,0]}]
for name in ['carrot_weapon_root','carrot_trigger_pivot','carrot_glass_illuminated']:
 g=groups[name];bones.append({'name':name,'parent':'root'if name=='carrot_weapon_root'else'carrot_weapon_root','pivot':[0,2.448,3.4]if name=='carrot_trigger_pivot'else[0,0,0],'poly_mesh':{k:v for k,v in g.items()if not k.startswith('_')}})
geometry={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.ascension_armory.carrot_cannon_study','texture_width':1024,'texture_height':1024,'visible_bounds_width':8,'visible_bounds_height':8,'visible_bounds_offset':[0,0,0]},'bones':bones}]};(R/'carrot_cannon.geo.json').write_text(json.dumps(geometry,separators=(',',':'))+'\n');total=sum(len(g['polys'])for g in groups.values());assert total==49616
manifest={'status':'Unaccepted geometry/atlas/animation transport; not an installable or functional gunpack','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'mesh_bones':len(groups),'triangles':total,'expected_tml_baked_vertices':total*4,'objects':receipts,'axes':['-Y','Z','-X'],'model_units_per_blender_unit':4,'atlas':'carrot-shared-basecolor.png,1024x1024, normalized UVs','native_tested':False,'limits':['Target normal direction, culling, pivot hierarchy, native hands and animation binding untested','Illuminated naming is an integration candidate; does not reproduce the authoring emission shader','Authoring roughness, metal response and bump shaders are not translated by this geometry','No gameplay registration, resources, projectiles, effects, sounds, recipes or native performance claim']};(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print({'triangles':total,'mesh_bones':len(groups)})
