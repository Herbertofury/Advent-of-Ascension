"""Run only two pinned released mesh-baker classes with narrow graphics stand-ins."""
from pathlib import Path
import argparse,json,hashlib,zipfile,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('--jar',required=True,type=Path);p.add_argument('--lib',required=True,type=Path);p.add_argument('--jdk',required=True,type=Path);p.add_argument('--expected-bones',type=int,default=13);p.add_argument('--expected-vertices',type=int,required=True);p.add_argument('--compare-geometry',type=Path);p.add_argument('--java',type=Path,help='Optional separate runtime executable');p.add_argument('--geometry',required=True,type=Path);a=p.parse_args();r=Path(__file__).resolve().parent
expected='4f60b62fb401d09ad3c37e8e2aa686ad6dffdcac0a97cac93df9ad190d34cb0728fe4c2127fff344be1a7116d19a10da944897401588256e564f152a8dd6c89d'
assert hashlib.sha512(a.jar.read_bytes()).hexdigest()==expected,'Unexpected TML artifact'
with tempfile.TemporaryDirectory() as td:
 d=Path(td);classes=d/'classes';released=d/'released';classes.mkdir();released.mkdir()
 with zipfile.ZipFile(a.jar)as z:
  for name,digest in json.loads((r/'class-hashes.json').read_text()).items():
   data=z.read(name);assert hashlib.sha256(data).hexdigest()==digest
   dest=released/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 cp=str(classes)+':'+str(released)+':'+str(a.lib.resolve())+'/*'
 subprocess.run([str(a.jdk/'javac'),'--release','17','-cp',cp,'-d',str(classes)]+[str(f)for f in(r/'harness').rglob('*.java')],check=True)
 for cls,extra in [('BakerCheck',[]),('ConsumerCheck',[]),('TransportCheck',[str(a.geometry.resolve()),str(a.expected_bones),str(a.expected_vertices)])]:subprocess.run([str(a.java or a.jdk/'java'),'-Xverify:all','-cp',cp,cls]+extra,check=True)
 if a.compare_geometry:subprocess.run([str(a.java or a.jdk/'java'),'-Xverify:all','-cp',cp,'EquivalenceCheck',str(a.geometry.resolve()),str(a.compare_geometry.resolve())],check=True)
 print('PASS clean isolated build; no upstream classes or dependencies redistributed')
