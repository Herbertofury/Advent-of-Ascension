import com.google.gson.*;import com.example.taczmeshloader.core.PolyMesh;import java.nio.file.*;import java.util.*;
public class EquivalenceCheck {
 static JsonArray bones(String f)throws Exception{return JsonParser.parseString(Files.readString(Path.of(f))).getAsJsonObject().getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject().getAsJsonArray("bones");}
 public static void main(String[]args)throws Exception{
  JsonArray a=bones(args[0]),b=bones(args[1]);BakerCheck.req(a.size()==b.size(),"bones");long values=0;int meshes=0;
  for(int i=0;i<a.size();i++){JsonObject x=a.get(i).getAsJsonObject(),y=b.get(i).getAsJsonObject();BakerCheck.req(x.get("name").equals(y.get("name")),"names");if(!x.has("poly_mesh"))continue;float[]pivot=new float[3];for(int k=0;k<3;k++)pivot[k]=x.getAsJsonArray("pivot").get(k).getAsFloat();PolyMesh p=new PolyMesh(x.getAsJsonObject("poly_mesh"),2048,2048,pivot),q=new PolyMesh(y.getAsJsonObject("poly_mesh"),2048,2048,pivot);
   for(String f:new String[]{"bakedX","bakedY","bakedZ","bakedU","bakedV","bakedNX","bakedNY","bakedNZ"}){float[]v=(float[])BakerCheck.field(p,f),w=(float[])BakerCheck.field(q,f);BakerCheck.req(v.length==w.length,"length");for(int k=0;k<v.length;k++){BakerCheck.req(Float.floatToRawIntBits(v[k])==Float.floatToRawIntBits(w[k]),"bit difference "+i+" "+f+" "+k);values++;}}
   BakerCheck.req(((Map<?,?>)BakerCheck.field(p,"vboCache")).isEmpty()&&((Map<?,?>)BakerCheck.field(q,"vboCache")).isEmpty(),"GPU caches");meshes++;
  }System.out.println("PASS exact released TML baker bit equivalence: "+meshes+" meshes / "+values+" baked float values. No GPU or native-game execution.");
 }
}
