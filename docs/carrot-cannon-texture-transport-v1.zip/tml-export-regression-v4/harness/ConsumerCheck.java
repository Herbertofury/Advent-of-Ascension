import com.google.gson.*;import com.example.taczmeshloader.core.PolyMesh;import com.mojang.blaze3d.vertex.*;import org.joml.*;import java.util.*;
public class ConsumerCheck {
 static class Sink implements VertexConsumer {
  ArrayList<float[]> rows=new ArrayList<>();float[] row=new float[14];int overlay,light;
  public VertexConsumer m_252986_(Matrix4f m,float x,float y,float z){Vector3f v=m.transformPosition(new Vector3f(x,y,z));row[0]=v.x;row[1]=v.y;row[2]=v.z;return this;}
  public VertexConsumer m_85950_(float r,float g,float b,float a){row[3]=r;row[4]=g;row[5]=b;row[6]=a;return this;}
  public VertexConsumer m_7421_(float u,float v){row[7]=u;row[8]=v;return this;}
  public VertexConsumer m_86008_(int v){overlay=v;return this;}public VertexConsumer m_85969_(int v){light=v;return this;}
  public VertexConsumer m_252939_(Matrix3f m,float x,float y,float z){Vector3f v=m.transform(new Vector3f(x,y,z));row[9]=v.x;row[10]=v.y;row[11]=v.z;return this;}
  public void m_5752_(){rows.add(row);row=new float[14];}
 }
 public static void main(String[]args)throws Exception{
  PolyMesh p=new PolyMesh(BakerCheck.mesh("[[[0,0,0],[1,0,1],[2,0,2]]]",true),16,16,new float[]{1,2,3});Sink s=new Sink();
  p.compileConsumer(new PoseStack.Pose(new Matrix4f().translation(2,3,4),new Matrix3f()),s,123,456,.2f,.3f,.4f,.5f);
  BakerCheck.req(s.rows.size()==4,"consumer emitted count");BakerCheck.req(s.light==123&&s.overlay==456,"light overlay");
  float[] r=s.rows.get(0);BakerCheck.near(r[0],2);BakerCheck.near(r[1],3);BakerCheck.near(r[2],4);BakerCheck.near(r[3],.2f);BakerCheck.near(r[6],.5f);BakerCheck.near(r[8],1);BakerCheck.near(r[11],-1);
  BakerCheck.near(((float[])BakerCheck.field(p,"bakedNZ"))[0],1);
  System.out.println("PASS released compileConsumer recording-sink check: positions, UVs, tint/light/overlay forwarding; fallback emits the NEGATIVE of stored baked normals. No GPU/native lighting verdict.");
 }
}
