package org.apache.logging.log4j;public interface Logger {default void info(String s,Object...args){throw new UnsupportedOperationException("Unexpected graphics-path diagnostic");}}
