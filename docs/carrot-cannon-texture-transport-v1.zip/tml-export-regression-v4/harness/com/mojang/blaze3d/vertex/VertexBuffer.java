package com.mojang.blaze3d.vertex;public class VertexBuffer {public void close(){throw new UnsupportedOperationException("GPU path must not execute");}}
