package com.mojang.blaze3d.vertex;
import org.joml.*;
/** Narrow recording-sink contract matching released method descriptors; not Minecraft. */
public interface VertexConsumer {
 VertexConsumer m_252986_(Matrix4f m,float x,float y,float z);
 VertexConsumer m_85950_(float r,float g,float b,float a);
 VertexConsumer m_7421_(float u,float v);
 VertexConsumer m_86008_(int overlay);
 VertexConsumer m_85969_(int light);
 VertexConsumer m_252939_(Matrix3f m,float x,float y,float z);
 void m_5752_();
}
