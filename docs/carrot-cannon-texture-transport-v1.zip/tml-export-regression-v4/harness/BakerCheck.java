import com.google.gson.*;import com.example.taczmeshloader.core.PolyMesh;import java.lang.reflect.*;import java.util.*;
public class BakerCheck {
 static void req(boolean b,String s){if(!b)throw new AssertionError(s);}static void near(float a,float b){req(Math.abs(a-b)<1e-6,a+" != "+b);}
 static Object field(PolyMesh mesh,String name)throws Exception{Field f=PolyMesh.class.getDeclaredField(name);f.setAccessible(true);return f.get(mesh);}
 static JsonObject mesh(String polys,boolean normalized){return JsonParser.parseString("{\"normalized_uvs\":"+normalized+",\"positions\":[[1,2,3],[17,2,3],[1,18,3]],\"normals\":[[0,0,1]],\"uvs\":[[0,0],[1,0],[0,1]],\"polys\":"+polys+"}").getAsJsonObject();}
 public static void main(String[]args)throws Exception{
  PolyMesh a=new PolyMesh(mesh("[[[0,0,0],[1,0,1],[2,0,2]]]",true),16,16,new float[]{1,2,3});req((int)field(a,"vertexCount")==4,"triangle expansion");float[]x=(float[])field(a,"bakedX"),y=(float[])field(a,"bakedY"),z=(float[])field(a,"bakedZ"),u=(float[])field(a,"bakedU"),v=(float[])field(a,"bakedV"),nz=(float[])field(a,"bakedNZ");near(x[0],0);near(x[1],1);near(y[2],-1);near(y[3],-1);near(z[0],0);near(u[1],1);near(v[0],1);near(v[2],0);near(nz[0],1);req(((Map<?,?>)field(a,"vboCache")).isEmpty(),"constructor should not create VBOs");
  PolyMesh b=new PolyMesh(mesh("[[[0,0,0],[1,0,1],[2,0,2],[0,0,0]]]",true),16,16,new float[]{1,2,3});req((int)field(b,"vertexCount")==4,"Meshy padded triangle");near(((float[])field(b,"bakedY"))[3],0);
  PolyMesh c=new PolyMesh(mesh("[[[0,0,0],[1,0,1],[2,0,2]]]",false),16,16,new float[]{1,2,3});near(((float[])field(c,"bakedU"))[1],1f/16);near(((float[])field(c,"bakedV"))[2],15f/16);
  PolyMesh d=new PolyMesh(mesh("[[[0,0,0],[1,0,1],[2,0,2],[0,0,0],[1,0,1]]]",true),16,16,new float[]{1,2,3});req((int)field(d,"vertexCount")==5,"ngon length is retained, not triangulated");
  try{new PolyMesh(mesh("[[[9,0,0],[1,0,1],[2,0,2]]]",true),16,16,new float[]{1,2,3});throw new AssertionError("bad index accepted");}catch(ArrayIndexOutOfBoundsException expected){}
  System.out.println("PASS actual TML0.1.8 constructor/baker: pivot subtraction, model-unit scaling, Y/V flips, normalized/pixel UVs, three-corner and Meshy-padded triangles, untriangulated five-corner count and bad-index rejection. No GPU/cache/render entry point executed; graphics/logging types are stand-ins.");
 }
}
