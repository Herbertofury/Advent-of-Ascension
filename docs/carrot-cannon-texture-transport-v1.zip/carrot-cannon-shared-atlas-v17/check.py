import bpy,json,math
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'carrot-shared-atlas.blend'));s=bpy.context.scene;s.frame_set(0);bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();m=json.loads((R/'manifest.json').read_text());rects=m['tiles'];roles={'Orange grown ceramic':'orange','Golden growth ridges':'orange','Leaf upper wax':'leaf','Rosid root interpretation':'wood','Dark hammered iron':'iron','Worn silver edges':'silver','Amber petal glass':'amber','Dark inner bore':'bore'};parts=[o for o in bpy.data.objects if o.name.startswith('SharedAtlas_')];position_error=0;uv_error=0;normal_error=0;loops=0;errors=[];triangles=0
for part in parts:
 owner=part.parent;assert owner and part.name=='SharedAtlas_'+owner.name;e=owner.evaluated_get(dg);source=e.to_mesh();source.calc_loop_triangles();triangles+=len(source.loop_triangles);assert len(source.vertices)==len(part.data.vertices) and len(source.polygons)==len(part.data.polygons)
 for a,b in zip(source.vertices,part.data.vertices):position_error=max(position_error,(owner.matrix_world@a.co-part.matrix_world@b.co).length)
 for a,b in zip(source.polygons,part.data.polygons):
  role=roles[source.materials[a.material_index].name];uvname={'orange':'GrownSurface','leaf':'LeafSurface','wood':'UVMap'}.get(role);layer=source.uv_layers.get(uvname)if uvname else None;x0,y0,x1,y1=rects[role]
  for al,bl in zip(a.loop_indices,b.loop_indices):
   u,v=layer.data[al].uv if layer else(.5,.5);expected=((x0+u*(x1-x0))/1024,(y0+v*(y1-y0))/1024);actual=part.data.uv_layers['SharedAtlasUV'].data[bl].uv;uv_error=max(uv_error,max(abs(actual[i]-expected[i])for i in [0,1]));normal_error=max(normal_error,(source.corner_normals[al].vector-part.data.corner_normals[bl].vector).length);loops+=1
 e.to_mesh_clear()
pose_error=0
for frame in range(49):
 s.frame_set(frame);bpy.context.view_layer.update()
 for part in parts:pose_error=max(pose_error,max(abs(part.matrix_world[i][j]-part.parent.matrix_world[i][j])for i in range(4)for j in range(4)))
result={'status':'Shared-atlas mapping and owner checks; not native acceptance','parts':len(parts),'triangles':triangles,'loops':loops,'maximum_world_position_error':position_error,'maximum_source_normal_error':normal_error,'maximum_uv_mapping_error':uv_error,'animated_owner_poses':49,'maximum_owner_matrix_error':pose_error,'native_tested':False,'limits':['Texture charts intentionally approximate per-object leaf/root noise variation','Normal-map/metal shader transfer and target texture filtering remain untested']};(R/'qa.json').write_text(json.dumps(result,indent=2)+'\n');print(result);assert len(parts)==240 and triangles==49616 and position_error<1e-6 and normal_error<1e-6 and uv_error<1e-6 and pose_error<1e-6
