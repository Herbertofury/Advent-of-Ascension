"""Material-aware atlas candidate. Shared leaf/root variation is a deliberate art change."""
import bpy,json,hashlib
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;src=R.parent/'carrot-cannon-open-faces-v12/carrot-cannon-motion.blend';bpy.ops.wm.open_mainfile(filepath=str(src));s=bpy.context.scene;s.frame_set(0);bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();originals=[o for o in bpy.data.objects if o.type in ('MESH','CURVE')and not o.hide_render]
rects={'orange':(8,8,504,504),'leaf':(520,8,1016,504),'wood':(8,520,504,1016),'iron':(520,520,632,632),'silver':(648,520,760,632),'amber':(776,520,888,632),'bore':(904,520,1016,632)}
role_by_mat={'Orange grown ceramic':'orange','Golden growth ridges':'orange','Leaf upper wax':'leaf','Rosid root interpretation':'wood','Dark hammered iron':'iron','Worn silver edges':'silver','Amber petal glass':'amber','Dark inner bore':'bore'}
source_names={'orange':'Orange grown ceramic','leaf':'Leaf upper wax','wood':'Rosid root interpretation','iron':'Dark hammered iron','silver':'Worn silver edges','amber':'Amber petal glass','bore':'Dark inner bore'}
def atlas_uv(role,u,v):
 x0,y0,x1,y1=rects[role];return ((x0+u*(x1-x0))/1024,(y0+v*(y1-y0))/1024)
# Independent simple source charts avoid fragmented smart-projection islands and projection-ray misses.
charts=[]
for role,name in source_names.items():
 me=bpy.data.meshes.new('Chart_'+role);me.from_pydata([(0,0,0),(1,0,0),(1,1,0),(0,1,0)],[],[(0,1,2,3)]);me.update();ob=bpy.data.objects.new('Chart_'+role,me);bpy.context.collection.objects.link(ob);ob.location.x=20+len(charts)*2;mat=bpy.data.materials[name].copy();me.materials.append(mat)
 x0,y0,x1,y1=rects[role];reserved=(x0-8,y0-8,x1+8,y1+8)
 for layer_name in ['GrownSurface','LeafSurface','UVMap','ChartLocalUV','SharedAtlasUV']:
  layer=me.uv_layers.new(name=layer_name)
  for li in range(4):
   u,v=[(0,0),(1,0),(1,1),(0,1)][li];px=reserved[0]+u*(reserved[2]-reserved[0]);py=reserved[1]+v*(reserved[3]-reserved[1]);layer.data[li].uv=(px/1024,py/1024)if layer_name=='SharedAtlasUV'else((px-x0)/(x1-x0),(py-y0)/(y1-y0))
 # Clamp the source chart coordinates while explicitly covering every reserved border texel.
 n=mat.node_tree.nodes;l=mat.node_tree.links;local=n.new('ShaderNodeUVMap');local.uv_map='ChartLocalUV';low=n.new('ShaderNodeVectorMath');low.operation='MAXIMUM';low.inputs[1].default_value=(0,0,0);high=n.new('ShaderNodeVectorMath');high.operation='MINIMUM';high.inputs[1].default_value=(1,1,1);l.new(local.outputs['UV'],low.inputs[0]);l.new(low.outputs[0],high.inputs[0])
 for old_node in list(n):
  if old_node==local:continue
  output=old_node.outputs.get('UV')if old_node.type=='UVMAP'else(old_node.outputs.get('Generated')if old_node.type=='TEX_COORD'else None)
  if output:
   for link in list(output.links):l.new(high.outputs[0],link.to_socket)
 me.uv_layers.active_index=me.uv_layers.find('SharedAtlasUV');charts.append(ob)
for ob in originals:ob.hide_render=True
s.render.engine='CYCLES';s.cycles.samples=8;s.render.bake.use_selected_to_active=False;s.render.bake.margin=0;s.render.bake.margin_type='EXTEND';textures={}
for kind,socket_name in [('basecolor','Base Color'),('emission','Emission Color'),('roughness','Roughness')]:
 image=bpy.data.images.new('carrot-shared-'+kind,1024,1024,alpha=True);image.colorspace_settings.name='Non-Color'if kind=='roughness'else'sRGB';image.generated_color=(0,0,0,0)
 for index,ob in enumerate(charts):
  bpy.ops.object.select_all(action='DESELECT');ob.hide_render=False;ob.select_set(True);bpy.context.view_layer.objects.active=ob;mat=ob.data.materials[0];tree=mat.node_tree;n=tree.nodes;l=tree.links;p=n.get('Principled BSDF');out=next(x for x in n if x.type=='OUTPUT_MATERIAL'and x.is_active_output);old=[x.from_socket for x in out.inputs['Surface'].links];em=n.new('ShaderNodeEmission');em.inputs['Strength'].default_value=1;inp=p.inputs[socket_name]
  if inp.is_linked:l.new(inp.links[0].from_socket,em.inputs['Color'])
  else:em.inputs['Color'].default_value=(inp.default_value,inp.default_value,inp.default_value,1)if kind=='roughness'else inp.default_value
  l.new(em.outputs[0],out.inputs['Surface']);node=n.new('ShaderNodeTexImage');node.image=image;n.active=node;s.render.bake.use_clear=index==0;bpy.ops.object.bake(type='EMIT');n.remove(em)
  for sock in old:l.new(sock,out.inputs['Surface'])
  ob.hide_render=True
 image.filepath_raw=str(R/('carrot-shared-'+kind+'.png'));image.file_format='PNG';image.save();textures[kind]=image
# Keep every owner's geometry and source UV layers; only material lookup coordinates are shared.
materials={};parts=[];violations=[]
for owner in originals:
 e=owner.evaluated_get(dg);me=bpy.data.meshes.new_from_object(e,preserve_all_data_layers=True,depsgraph=dg);part=bpy.data.objects.new('SharedAtlas_'+owner.name,me);bpy.context.collection.objects.link(part);part.parent=owner;part.matrix_parent_inverse=owner.matrix_world.inverted();part.matrix_world=owner.matrix_world.copy();parts.append(part)
 layer=me.uv_layers.new(name='SharedAtlasUV')
 for poly in me.polygons:
  name=me.materials[poly.material_index].name;role=role_by_mat[name];uvname={'orange':'GrownSurface','leaf':'LeafSurface','wood':'UVMap'}.get(role);source_uv=me.uv_layers.get(uvname)if uvname else None
  if uvname:assert source_uv,(owner.name,uvname)
  for li in poly.loop_indices:
   u,v=source_uv.data[li].uv if source_uv else(.5,.5)
   if not(-1e-6<=u<=1+1e-6 and -1e-6<=v<=1+1e-6):violations.append([owner.name,li,float(u),float(v)])
   layer.data[li].uv=atlas_uv(role,float(u),float(v))
 for i,old in enumerate(list(me.materials)):
  if old.name not in materials:
   mat=old.copy();n=mat.node_tree.nodes;l=mat.node_tree.links;p=n.get('Principled BSDF');uv=n.new('ShaderNodeUVMap');uv.uv_map='SharedAtlasUV'
   for kind,socket in [('basecolor','Base Color'),('emission','Emission Color'),('roughness','Roughness')]:
    tex=n.new('ShaderNodeTexImage');tex.image=textures[kind];l.new(uv.outputs[0],tex.inputs['Vector']);l.new(tex.outputs['Color'],p.inputs[socket])
   materials[old.name]=mat
  me.materials[i]=materials[old.name]
 me.uv_layers.active_index=me.uv_layers.find('SharedAtlasUV');owner.hide_render=True
assert not violations,violations[:10]
for ob in charts:bpy.data.objects.remove(ob,do_unlink=True)
bpy.context.view_layer.update();bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'carrot-shared-atlas.blend'));s.cycles.samples=64;s.cycles.seed=0;s.render.filepath=str(R/'hero.png');bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'Unaccepted shared material chart; deliberate variation change','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'parts':len(parts),'tiles':rects,'padding_method':'Explicit reserved rectangles with clamped local chart coordinates; no dilation overlap','reserved_border_pixels':8,'intentional_uv_sharing':'Within declared material classes only; constant-color classes use a center texel','source_uv_range_violations':violations,'native_tested':False,'limits':['Leaf and root noise variation sampled on a flat source chart instead of each original object','Authoring bump dependencies remain; no native shader or lighting acceptance','Owner motion, texture quality, filtering and native runtime require checks']},indent=2)+'\n')
