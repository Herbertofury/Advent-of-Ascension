"""Conservative software box-mip + bilinear footprint diagnostic, not GPU validation."""
from pathlib import Path
from PIL import Image
import numpy as np,json,math
R=Path(__file__).resolve().parent;m=json.loads((R/'manifest.json').read_text());rects=m['tiles'];size=1024;labels=np.zeros((size,size),np.int16);alpha=np.asarray(Image.open(R/'carrot-shared-basecolor.png').convert('RGBA'))[::-1,:,3];coverage=[]
for i,(role,(x0,y0,x1,y1))in enumerate(rects.items(),1):
 region=labels[y0-8:y1+8,x0-8:x1+8];assert not np.any(region);region[:]=i;tile_alpha=alpha[y0-8:y1+8,x0-8:x1+8];coverage.append({'class':role,'reserved_pixels':int(tile_alpha.size),'transparent_reserved_pixels':int((tile_alpha<255).sum())})
rows=[]
for i,(role,(x0,y0,x1,y1))in enumerate(rects.items(),1):
 points=[(x,y)for x in [x0,(x0+x1)/2,x1]for y in [y0,(y0+y1)/2,y1]]if role in ('orange','leaf','wood')else[((x0+x1)/2,(y0+y1)/2)]
 for wrap in ['clamp','repeat']:
  for level in range(9):
   step=2**level;n=size//step;unsafe=0;transparent=0
   for x,y in points:
    xx=x/step-.5;yy=y/step-.5;ix=math.floor(xx);iy=math.floor(yy);fx=xx-ix;fy=yy-iy;cells=[]
    for dx,wx in [(0,1-fx),(1,fx)]:
     for dy,wy in [(0,1-fy),(1,fy)]:
      if wx*wy<1e-12:continue
      u=ix+dx;v=iy+dy;u=u%n if wrap=='repeat'else min(max(u,0),n-1);v=v%n if wrap=='repeat'else min(max(v,0),n-1);cells.append((u,v))
    bad=any(np.any(labels[v*step:(v+1)*step,u*step:(u+1)*step]!=i)for u,v in cells);hole=any(np.any(alpha[v*step:(v+1)*step,u*step:(u+1)*step]<255)for u,v in cells);unsafe+=int(bad);transparent+=int(hole)
   rows.append({'class':role,'wrap':wrap,'mip_level':level,'sampled_coordinates':len(points),'coordinates_with_cross_class_footprints':unsafe,'coordinates_with_transparent_footprints':transparent})
report={'status':'Software filtering risk diagnostic only','reserved_coverage':coverage,'rows':rows,'assumptions':['Box-filtered mip texels and bilinear lookup at sampled corners/edges/center','Constant-color classes use only their actual center UV','Does not simulate anisotropy, trilinear transitions, texture compression or native shader LOD selection'],'native_tested':False};(R/'filtering-qa.json').write_text(json.dumps(report,indent=2)+'\n');print('coverage',coverage);print('first risks',[(role,wrap,min((r['mip_level']for r in rows if r['class']==role and r['wrap']==wrap and (r['coordinates_with_cross_class_footprints']or r['coordinates_with_transparent_footprints'])),default=None))for role in rects for wrap in ['clamp','repeat']]);assert all(r['transparent_reserved_pixels']==0 for r in coverage)
