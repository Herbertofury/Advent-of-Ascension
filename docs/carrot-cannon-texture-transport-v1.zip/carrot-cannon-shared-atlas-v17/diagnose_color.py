import bpy
from pathlib import Path
R=Path(__file__).resolve().parent
for label,source in [('source',R.parent/'carrot-cannon-open-faces-v12/carrot-cannon-motion.blend'),('atlas',R/'carrot-shared-atlas.blend')]:
 bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene;s.frame_set(0)
 mats={m.name:m for o in bpy.data.objects if o.type in ('MESH','CURVE')and not o.hide_render for m in o.data.materials if m}
 for m in mats.values():
  n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF');out=next(x for x in n if x.type=='OUTPUT_MATERIAL' and x.is_active_output);em=n.new('ShaderNodeEmission');em.inputs['Strength'].default_value=1
  if p.inputs['Base Color'].is_linked:l.new(p.inputs['Base Color'].links[0].from_socket,em.inputs['Color'])
  else:em.inputs['Color'].default_value=p.inputs['Base Color'].default_value
  l.new(em.outputs[0],out.inputs['Surface'])
 s.cycles.samples=32;s.cycles.seed=0;s.render.filepath=str(R/(label+'-raw-color.png'));bpy.ops.render.render(write_still=True)
