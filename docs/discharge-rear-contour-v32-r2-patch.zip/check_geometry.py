import bpy,bmesh,json,hashlib,argparse,sys,math
from mathutils import Matrix,Vector
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--scene',type=Path,required=True);p.add_argument('--report',type=Path,required=True);args=p.parse_args(sys.argv[sys.argv.index('--')+1:]);source=args.source
def sig(o):
 if o.type!='MESH':return None
 return {'vertices':[list(v.co)for v in o.data.vertices],'faces':[list(p.vertices)for p in o.data.polygons],'matrix':[list(r)for r in o.matrix_world],'hidden':o.hide_render,'materials':[m.name if m else None for m in o.data.materials]}
bpy.ops.wm.open_mainfile(filepath=str(source));old={o.name:sig(o)for o in bpy.context.scene.objects if o.type=='MESH'}
bpy.ops.wm.open_mainfile(filepath=str(args.scene));unchanged=[]
for n,s in old.items():assert sig(bpy.data.objects[n])==s,n;unchanged.append(n)
new=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.name.startswith('V32 ')];dg=bpy.context.evaluated_depsgraph_get();results=[]
for o in new:
 assert o.parent is not None and o.parent.name=='Discharge_Root',o.name+' has wrong transform owner'
 bm=bmesh.new();bm.from_mesh(o.data);nonmanifold=sum(not e.is_manifold for e in bm.edges);volume=bm.calc_volume(signed=True);bm.free();e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();bad=0
 for tri in m.loop_triangles:
  a,b,c=[o.matrix_world@m.vertices[v].co for v in tri.vertices];bad+=(b-a).cross(c-a).length_squared<1e-20
 results.append({'name':o.name,'nonmanifold_edges':nonmanifold,'signed_local_volume':volume,'parent':o.parent.name,'evaluated_triangles':len(m.loop_triangles),'degenerate_triangles':bad});e.to_mesh_clear();assert nonmanifold==0 and volume>0 and bad==0,o.name
assert len(new)==14
root=bpy.data.objects['Discharge_Root'];rest=root.matrix_world.copy();before={o.name:[o.matrix_world@v.co for v in o.data.vertices]for o in new};maximum=0;tested=0
for step in range(21):
 delta=Matrix.Translation(Vector((step*.01,-step*.006,step*.004)))@Matrix.Rotation(math.radians(step),4,'Z');root.matrix_world=delta@rest;bpy.context.view_layer.update()
 for o in new:
  for v,base in zip(o.data.vertices,before[o.name]):
   err=(o.matrix_world@v.co-delta@base).length;maximum=max(maximum,err);tested+=1
root.matrix_world=rest;bpy.context.view_layer.update();assert maximum<1e-5,maximum
out={'scope':'All existing mesh coordinates, polygons, transforms, material slots and render visibility preserved; new solid manifold/area checks only','root_transform_samples':21,'transformed_vertices_checked':tested,'max_root_follow_error':maximum,'existing_meshes_preserved':len(unchanged),'new_meshes':results,'native_accepted':False,'art_accepted':False,'limits':['No hand/animation or full intersection test','No native material/export or performance evidence']};args.report.write_text(json.dumps(out,indent=2));print('PASS',len(unchanged),'preserved meshes;',len(new),'new solids')
