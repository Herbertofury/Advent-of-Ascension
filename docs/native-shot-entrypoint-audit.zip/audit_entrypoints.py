from pathlib import Path
import json,re,subprocess,collections,hashlib,zipfile,argparse
parser=argparse.ArgumentParser();parser.add_argument('--jar',type=Path,required=True);parser.add_argument('--conventional-data',type=Path,required=True);parser.add_argument('--blaster-data',type=Path,required=True);parser.add_argument('--javap',type=Path,required=True);parser.add_argument('--out',type=Path,required=True);args=parser.parse_args();R=args.out.resolve();R.mkdir(parents=True,exist_ok=True);conventional_data=json.loads(args.conventional_data.read_text());blaster_data=json.loads(args.blaster_data.read_text());jar=args.jar.resolve();assert hashlib.sha512(jar.read_bytes()).hexdigest()==conventional_data['jar_sha512']==blaster_data['jar_sha512'],'Unexpected source artifact';conventional=conventional_data['records'];blasters=[dict(r,family='blaster')for r in blaster_data['records']];records=conventional+blasters;assert len(records)==228 and len({r['id']for r in records})==228
classes=sorted({r['constructor_class'].replace('/','.')for r in records}|{'net.tslat.aoa3.content.item.weapon.gun.BaseGun','net.tslat.aoa3.content.item.weapon.shotgun.BaseShotgun','net.tslat.aoa3.content.item.weapon.blaster.BaseBlaster','net.tslat.aoa3.content.item.weapon.cannon.BaseCannon','net.tslat.aoa3.content.item.weapon.sniper.BaseSniper'})
with zipfile.ZipFile(jar)as z:
 for r in records:assert hashlib.sha256(z.read(r['constructor_class']+'.class')).hexdigest()==r['class_sha256'],r['id']
run=subprocess.run([str(args.javap),'-p','-classpath',str(jar),*classes],check=True,capture_output=True,text=True);(R/'registry-methods.javap.txt').write_text(run.stdout);C={}
for block in run.stdout.split('Compiled from ')[1:]:
 m=re.search(r'(?:public |abstract |final )*class ([\w.$]+) extends ([\w.$]+)',block)
 if m:C[m[1]]={'parent':m[2],'use_tick_override':bool(re.search(r'\bvoid m_5929_\(',block)),'tryFireBlaster_declared':bool(re.search(r'\bboolean tryFireBlaster\(',block)),'fireGun_declared':bool(re.search(r'\bboolean fireGun\(',block))}
assert len(C)==len(classes);out=[]
for r in records:
 n=r['constructor_class'].replace('/','.');chain=[]
 while n in C:
  chain.append(n)
  if C[n]['use_tick_override']:break
  n=C[n]['parent']
 else:raise AssertionError('Unresolved use-tick owner '+r['id'])
 out.append({'id':r['id'],'family':r['family'],'registered_class':r['constructor_class'],'nearest_declared_use_tick':n,'chain':chain})
counts=dict(collections.Counter(x['nearest_declared_use_tick']for x in out));assert sum(counts.values())==228; report={'release':'AoA3.7.1 / Minecraft1.20.1','registry_items':228,'classes_inspected':len(C),'all_registered_class_hashes_verified':True,'scope':'Pinned released class hierarchy and declared use-tick methods only; runtime mixins and actual native event bridge untested','counts':counts,'declared_use_tick_owners':[n for n,c in C.items()if c['use_tick_override']],'tryFireBlaster_declared':[n for n,c in C.items()if c['tryFireBlaster_declared']],'records':out};(R/'use-tick-coverage.json').write_text(json.dumps(report,indent=2)+'\n');(R/'class-method-map.json').write_text(json.dumps(C,indent=2));print({k:v for k,v in report.items()if k!='records'})

for full in ['net.tslat.aoa3.content.item.weapon.gun.BaseGun','net.tslat.aoa3.content.item.weapon.blaster.BaseBlaster','net.tslat.aoa3.content.item.weapon.blaster.LightSpark','net.tslat.aoa3.content.item.weapon.blaster.SoulSpark','net.tslat.aoa3.common.packet.packets.GunRecoilPacket']:
 result=subprocess.run([str(args.javap),'-p','-c','-classpath',str(jar),full],check=True,capture_output=True,text=True);(R/(full.rsplit('.',1)[1]+'.javap.txt')).write_text(result.stdout)
