# Native shot-event source audit

Pinned scope: AoA 3.7.1 / Minecraft1.20.1, 228 first-target registered firearms. This is static released-class analysis, not an implemented Mixin or a native game test.

Run `python audit_entrypoints.py --jar /path/to/AoA3-1.20.1-3.7.1-all.jar --conventional-data conventional-weapon-baselines-1.20.1.json --blaster-data blaster-baselines-1.20.1.json --javap /path/to/jdk/bin/javap --out audit-output`, then `python test_entrypoint_audit.py --audit-dir audit-output`.

The two source-derived registry datasets are included. The actual AoA JAR and JDK are not. The tool verifies the complete artifact SHA-512 against both datasets and every registered constructor class SHA-256 before auditing method declarations/hierarchy. It then disassembles the selected event-path classes for inspection. It does not download or launch Minecraft.

Findings: 172 conventional items inherit BaseGun's use-tick implementation. 54 blasters inherit BaseBlaster's use-tick implementation; LightSpark and SoulSpark override it but still call inherited tryFireBlaster. Soul Storm is a blaster. BaseGun-only entry hooks miss it. A successful tryFireBlaster may have null ShotInfo and skip doFiringEffects, so effects alone are not a complete success signal.

GunRecoilPacket contains only a recoil float and firing-time integer, without weapon-instance/hand/configuration/shot-ordinal identity. Native adapter design must preserve original resource/firing semantics, provide genuine event identity, reconcile prediction and handle observer routing. Runtime mixins and native behavior remain untested.
