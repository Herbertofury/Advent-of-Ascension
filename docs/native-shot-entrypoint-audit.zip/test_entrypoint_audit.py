from pathlib import Path
import unittest,json,argparse,sys
parser=argparse.ArgumentParser();parser.add_argument('--audit-dir',type=Path,default=Path(__file__).resolve().parent);args,rest=parser.parse_known_args();sys.argv=[sys.argv[0]]+rest;R=args.audit_dir;J=json.loads((R/'use-tick-coverage.json').read_text());C=json.loads((R/'class-method-map.json').read_text());B=(R/'BaseBlaster.javap.txt').read_text()
class Audit(unittest.TestCase):
 def test_complete_registry(self):self.assertEqual(len(J['records']),228);self.assertEqual(len({r['id']for r in J['records']}),228)
 def test_hashes(self):self.assertTrue(J['all_registered_class_hashes_verified'])
 def test_counts(self):self.assertEqual(sorted(J['counts'].values()),[1,1,54,172])
 def test_soul_storm_lane(self):self.assertEqual(next(r for r in J['records']if r['id']=='aoa3:soul_storm')['nearest_declared_use_tick'],'net.tslat.aoa3.content.item.weapon.blaster.BaseBlaster')
 def test_common_blaster_gate(self):self.assertEqual(J['tryFireBlaster_declared'],['net.tslat.aoa3.content.item.weapon.blaster.BaseBlaster'])
 def test_special_ticks_reach_gate(self):
  for name in ['LightSpark','SoulSpark']:self.assertIn('Method tryFireBlaster:',(R/(name+'.javap.txt')).read_text())
 def test_null_shot_info_path(self):self.assertIn('ifnull        52',B);self.assertIn('88: iconst_1',B)
 def test_packet_fields(self):
  s=(R/'GunRecoilPacket.javap.txt').read_text();self.assertIn('private final float recoilAmount;',s);self.assertIn('private final int firingTime;',s);self.assertNotIn('private final java.util.UUID',s)
if __name__=='__main__':unittest.main()
