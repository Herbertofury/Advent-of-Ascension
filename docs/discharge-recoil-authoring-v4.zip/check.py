import bpy,json,hashlib
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;p=R/'discharge-recoil-study.blend';bpy.ops.wm.open_mainfile(filepath=str(p));m=json.loads((R/'manifest.json').read_text());s=bpy.context.scene;errors=[];samples=0;initial={}
s.frame_set(1);bpy.context.view_layer.update()
for row in m['mapping']:initial[row['object']]=bpy.data.objects[row['object']].matrix_world.copy()
max_follow_error=0;max_nonactive_translation=0;min_x=0;max_x=0
for frame in range(1,341):
 s.frame_set(frame);bpy.context.view_layer.update()
 for i,start in enumerate(m['shot_start_frames']):
  group=bpy.data.objects[f'Discharge_emitter_{i+1}_top_to_bottom'];x=group.location.x;min_x=min(min_x,x);max_x=max(max_x,x)
  if not start<=frame<=start+9:max_nonactive_translation=max(max_nonactive_translation,abs(x))
  for row in m['mapping']:
   if row['emitter_index']!=i:continue
   obj=bpy.data.objects[row['object']];expected=initial[obj.name].translation+Vector((x,0,0));max_follow_error=max(max_follow_error,(obj.matrix_world.translation-expected).length);samples+=1
  glow=bpy.data.materials[f'Discharge emitter {i+1} local glow'];strength=glow.node_tree.nodes.get('Principled BSDF').inputs['Emission Strength'].default_value
  if not start<=frame<=start+3 and abs(strength-2.0)>1e-5:errors.append(['glow outside active window',frame,i,strength])
for i in range(3):
 count=sum(row['emitter_index']==i for row in m['mapping'])
 if count!=6:errors.append(['unexpected owned part count',i,count])
if max_follow_error>1e-6:errors.append(['owner-follow error',max_follow_error])
if max_nonactive_translation>1e-6:errors.append(['inactive motion',max_nonactive_translation])
if min_x<-.075001 or max_x>.008001:errors.append(['overshoot',min_x,max_x])
r={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'frames_sampled':340,'part_transform_samples':samples,'maximum_owner_follow_error':max_follow_error,'maximum_inactive_translation':max_nonactive_translation,'recoil_x_range':[min_x,max_x],'errors':errors[:30],'scope':'Integer-frame authoring transform/glow checks only; not continuous collision, native interpolation or gameplay QA'};(R/'recoil-qa.json').write_text(json.dumps(r,indent=2)+'\n');print(r);assert not errors
