import bpy,json
from pathlib import Path
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'discharge-recoil-study.blend'));s=bpy.context.scene;m=json.loads((R/'manifest.json').read_text());owners={r['object']:r['emitter_index'] for r in m['mapping']};objects=[o for o in s.objects if not o.hide_render and o.type in {'MESH','CURVE'}]
def tree(o,dg):
 eo=o.evaluated_get(dg);mesh=eo.to_mesh();v=[eo.matrix_world@x.co for x in mesh.vertices];pol=[tuple(p.vertices)for p in mesh.polygons];b=BVHTree.FromPolygons(v,pol,all_triangles=False,epsilon=0);eo.to_mesh_clear();return b
s.frame_set(1);bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();base={o.name:tree(o,dg)for o in objects};baseline={};new=[];maxcounts={};samples=0
for name,owner in owners.items():
 for other in objects:
  if other.name==name or owners.get(other.name)==owner:continue
  pair=(name,other.name);baseline[pair]=len(base[name].overlap(base[other.name]));maxcounts[pair]=baseline[pair]
for owner,start in enumerate(m['shot_start_frames']):
 for sub in range(37):
  f=start+sub/4;s.frame_set(int(f),subframe=f-int(f));bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();moving={n:tree(bpy.data.objects[n],dg)for n,i in owners.items()if i==owner}
  for name,t in moving.items():
   for other in objects:
    if other.name==name or owners.get(other.name)==owner:continue
    pair=(name,other.name);count=len(t.overlap(base[other.name]));samples+=1;maxcounts[pair]=max(maxcounts[pair],count)
    if count and not baseline[pair]:new.append({'frame':f,'moving':name,'other':other.name,'intersecting_triangle_pairs':count})
report={'scope':'Quarter-frame triangle surface intersections against other visible scene meshes; excludes same-owner parts. Does not detect complete containment, hands, native interpolation or establish clearance tolerance. Existing baseline intersections tracked separately.','pair_samples':samples,'baseline_intersecting_pairs':[{'moving':p[0],'other':p[1],'count':c}for p,c in baseline.items()if c], 'new_intersections':new,'native_accepted':False};(R/'surface-sweep-qa.json').write_text(json.dumps(report,indent=2));print('samples',samples,'baseline pairs',len(report['baseline_intersecting_pairs']),'new intersection samples',len(new))

assert not report["baseline_intersecting_pairs"] and not report["new_intersections"], "Moving assembly intersects another visible part"
