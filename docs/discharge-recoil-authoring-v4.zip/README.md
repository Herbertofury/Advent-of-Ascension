# Discharge recoil authoring study v4

Editable Blender 4.3.2 scene based on the v31 exterior. Not an installable mod or accepted native animation.

Three top-to-bottom cosmetic channels each own six visible pieces: housing, liner, light outline, throat, and two associated horizontal segments. Receiver nose shortened locally to x=2.80 in this authoring coordinate system to provide stroke clearance. Hands, trigger and guard were not shrunk. Original four-projectile gameplay burst remains unchanged; three cosmetic channels do not define projectile count.

## Reproduce scoped authoring checks

Run each with Blender 4.3.2 from this extracted folder:

- `blender -b -t 2 --python-exit-code 1 --python check.py`
- `blender -b -t 2 --python-exit-code 1 --python check_geometry.py`
- `blender -b -t 2 --python-exit-code 1 --python check_surface_sweep.py`
- `blender -b -t 2 --python-exit-code 1 --python export_clips.py`

Transform check: 340 integer frames, 6120 part samples. Surface sweep: quarter-frame samples through each nine-frame stroke, 110556 moving-versus-other pair checks. Same-owner pieces excluded. Triangle intersections are not solid containment or a complete clearance proof; no native interpolation, hand mesh, skinning, attachment or runtime performance acceptance.

`released-parser-check.json` records a separate run against hash-checked released TaCZ animation classes with documented narrow helper stand-ins. Its external harness/dependencies are not embedded in this archive. This is parser evidence, not a runnable native integration or approval of coordinate/bone binding.

Position clips omit material glow animation and do not implement a firing scheduler. Nominal 55 ticks at20TPS is shown at60FPS for authoring only. Retain confirmed-shot networking and original gameplay behavior in a future integration.

`recoil-contact-sheet.jpg` contains sampled authoring views. Native full-motion acceptance remains open. The scene's procedural materials still need an exportable texture workflow. The previous v2 sweep found101 newly intersecting samples; v3 resolved these but retained7 baseline intersecting pairs; v4 reports0 in both categories under the scoped test. No claim of universal collision freedom.
