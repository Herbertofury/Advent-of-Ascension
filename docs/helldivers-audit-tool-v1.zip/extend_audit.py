"""Extend the generic static census with index routing and resolved LOD geometry."""
import argparse,json,zipfile,pathlib,hashlib
from jsonc_reader import loads
p=argparse.ArgumentParser();p.add_argument('zip');p.add_argument('base');p.add_argument('out');a=p.parse_args();z=zipfile.ZipFile(a.zip);j=json.loads(pathlib.Path(a.base).read_text());indices=[]
for n in sorted(z.namelist()):
 if '/index/guns/'in n and n.endswith('.json'):
  d=loads(z.read(n).decode('utf-8-sig'));indices.append({'path':n,'display':d.get('display'),'data':d.get('data')})
for row in j['records']:
 if row['lod'] and row['lod']['model']['exists']:
  g=loads(z.read(row['lod']['model']['path']).decode())['minecraft:geometry'][0];row['lod']['bones']=len(g['bones']);row['lod']['cubes']=sum(len(b.get('cubes',[]))for b in g['bones'])
j['gun_indices']=indices;j['declared_lod_pairs']=sum(bool(x['lod'])for x in j['records']);j['selected_gameplay_routing']=[]
for gun in ['railgun','quasar','plas101']:
 n=f'data/zeta/data/guns/{gun}_data.json';d=loads(z.read(n).decode());ns,script=d['script'].split(':');sp=f'data/{ns}/scripts/{script}.lua';assert sp in z.namelist();j['selected_gameplay_routing'].append({'gun':gun,'data':n,'script':sp,'sha256':hashlib.sha256(z.read(sp)).hexdigest()})
assert j['archive_sha256']=='43c0884bf721f8d746b1b8d5d4e8153153ca386cdac3878db3a182e044e7af93'
assert len(indices)==56 and len(j['records'])==57 and j['declared_lod_pairs']==49 and not j['missing_declared_lod_assets']
pathlib.Path(a.out).write_text(json.dumps(j,indent=2)+'\n');print('PASS 56 gun index records,57 displays,49 declared LOD pairs resolved; selected routing follows actual data declarations')
