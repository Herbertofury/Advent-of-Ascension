"""Exact model/texture change detection; no semantic or aesthetic automatic merge."""
import json,zipfile,hashlib,struct,io
from PIL import Image
from pathlib import Path
R=Path(__file__).resolve().parent;W=R.parent;D=W.parent/'aoa-recovery-repo/docs';rows=json.loads((D/'weapon-feature-coverage.json').read_text())['weapons'];paths={'1.20.1':W/'references/AoA3-1.20.1-3.7.1-all.jar','1.21.1':W/'references/AoA3-1.21.1-3.7.16.1.jar'};records=[];archives={v:zipfile.ZipFile(p)for v,p in paths.items()}
def pixel_hash(b):
 im=Image.open(io.BytesIO(b)).convert('RGBA');pixels=list(im.getdata());canonical=bytes(channel for pixel in pixels for channel in ((0,0,0,0) if pixel[3]==0 else pixel));return hashlib.sha256(canonical).hexdigest()
def examine(z,id):
 namespace,name=id.split(':');mp=f'assets/{namespace}/models/item/{name}.json'
 if mp not in z.namelist():return {'status':'model_missing','model_path':mp}
 raw=z.read(mp);m=json.loads(raw);textures=[]
 for slot,texture in m.get('textures',{}).items():
  if not isinstance(texture,str)or texture.startswith('#'):continue
  ns,path=texture.split(':',1)if':'in texture else('minecraft',texture);tp=f'assets/{ns}/textures/{path}.png'
  if tp in z.namelist():
   b=z.read(tp);dimensions=list(struct.unpack('>II',b[16:24]))if b.startswith(b'\x89PNG')else None;textures.append({'slot':slot,'path':tp,'sha256':hashlib.sha256(b).hexdigest(),'dimensions':dimensions,'rgba_sha256':pixel_hash(b)})
  else:textures.append({'slot':slot,'path':tp,'status':'not_in_this_archive'})
 return {'status':'model_present','model_path':mp,'model_sha256':hashlib.sha256(raw).hexdigest(),'parent':m.get('parent'),'direct_textures':textures,'scope':'Direct model texture references only; inherited, override and runtime renderer assets require separate resolution.'}
for row in rows:
 lane={v:examine(z,row['id'])for v,z in archives.items()};a,b=lane.values();sig=lambda x:[(t['slot'],t['path'],t.get('sha256'),t.get('status'))for t in x.get('direct_textures',[])]
 records.append({'id':row['id'],'lanes':lane,'model_bytes_equal':a.get('model_sha256')is not None and a.get('model_sha256')==b.get('model_sha256'),'direct_texture_refs_equal':a['status']=='model_present'and b['status']=='model_present'and sig(a)==sig(b),'decoded_texture_pixels_equal':a['status']=='model_present'and b['status']=='model_present'and [(t['slot'],t['path'],t.get('dimensions'),t.get('rgba_sha256'))for t in a.get('direct_textures',[])]==[(t['slot'],t['path'],t.get('dimensions'),t.get('rgba_sha256'))for t in b.get('direct_textures',[])],'semantic_equivalence_verified':False})
out={'archive_sha256':{v:hashlib.sha256(p.read_bytes()).hexdigest()for v,p in paths.items()},'records':records,'counts':{'ids':len(records),'same_model_bytes':sum(r['model_bytes_equal']for r in records),'same_direct_texture_refs':sum(r['direct_texture_refs_equal']for r in records),'same_decoded_texture_pixels':sum(r['decoded_texture_pixels_equal']for r in records)},'scope':'Exact asset comparison for first-target IDs in two released archives; unchanged art is not unchanged mechanics. No automatic canonical selection or native acceptance.'};(R/'comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(out['counts']);print('changed decoded pixels or references',[r['id']for r in records if not r['decoded_texture_pixels_equal']])
