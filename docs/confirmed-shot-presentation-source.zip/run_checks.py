from pathlib import Path
import subprocess,json,hashlib,argparse
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--jdk17',type=Path,default=R.parent/'toolchains/amazon-corretto-17.0.20.12.1-linux-x64');p.add_argument('--java21',type=Path,default=Path('/usr/bin/java'));a=p.parse_args();files=sorted((R/'src').rglob('*.java'));(R/'classes').mkdir(exist_ok=True)
subprocess.run([str(a.jdk17/'bin/javac'),'--release','17','-d',str(R/'classes'),*[str(f)for f in files]],check=True)
rows=[]
for executable in [a.jdk17/'bin/java',a.java21]:
 version=subprocess.run([str(executable),'--version'],check=True,text=True,capture_output=True).stdout
 result=subprocess.run([str(executable),'-cp',str(R/'classes'),'dev.aoa.armory.presentation.PresentationTest'],check=True,text=True,capture_output=True).stdout
 assert 'PASS 80031 presentation-state assertions' in result,result
 rows.append({'java_version':version.strip(),'result':result.strip()})
out={'source_sha256':{str(f.relative_to(R)):hashlib.sha256(f.read_bytes()).hexdigest()for f in files},'compile_release':17,'runs':rows,'native_integration_tested':False,'scope':'Original presentation-state logic only; authoritative event source, client prediction, actual animations and game/network integration remain untested'};(R/'checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
