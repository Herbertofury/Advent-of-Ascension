package dev.aoa.armory.presentation;

import java.util.Objects;
import java.util.UUID;

/**
 * Constant-state, event-driven alternating-emitter selection for one bound weapon.
 * This class never consumes ammo, applies damage, spawns a projectile or reads game files.
 * A native adapter must supply genuinely authoritative snapshots/confirmations.
 */
public final class ConfirmedShotPresentation {
    public record Snapshot(UUID weaponInstance, long sessionEpoch, long configurationRevision,
                           long lastConfirmedSequence, int emitterCount) {
        public Snapshot {
            Objects.requireNonNull(weaponInstance, "weaponInstance");
            if (lastConfirmedSequence < 0 || emitterCount <= 0 || configurationRevision < 0)
                throw new IllegalArgumentException("Invalid sequence or emitter count");
        }
    }
    public record Confirmation(UUID weaponInstance, long sessionEpoch, long configurationRevision,
                               long sequence, boolean accepted, int projectileCount) {}
    public record Presentation(UUID weaponInstance, long sessionEpoch, long configurationRevision,
                               long sequence, int emitterIndex, int projectileCount) {}

    private final UUID weaponInstance;
    private final long sessionEpoch;
    private Snapshot binding;
    private long lastSequence;
    private boolean active;

    /** One controller belongs to one trusted weapon/session lifecycle context. */
    public ConfirmedShotPresentation(UUID weaponInstance, long sessionEpoch) {
        this.weaponInstance = Objects.requireNonNull(weaponInstance, "weaponInstance");
        this.sessionEpoch = sessionEpoch;
    }

    /** Never rewind a replay baseline or apply an older attachment configuration. */
    public boolean bind(Snapshot snapshot) {
        Objects.requireNonNull(snapshot, "snapshot");
        if (!weaponInstance.equals(snapshot.weaponInstance()) || sessionEpoch != snapshot.sessionEpoch())
            return false;
        if (binding != null) {
            if (snapshot.configurationRevision() < binding.configurationRevision()) return false;
            if (snapshot.configurationRevision() == binding.configurationRevision()
                    && snapshot.emitterCount() != binding.emitterCount()) return false;
        }
        lastSequence = Math.max(lastSequence, snapshot.lastConfirmedSequence());
        binding = snapshot;
        active = true;
        return true;
    }

    /** Unequipping does not forget replay history. Use a new controller for a new session. */
    public void unbind() { active = false; }

    /**
     * Null means no visual firing event. Sequence gaps select by server ordinal, not arrival count.
     * This deliberately drops late confirmations; it is not a network authentication mechanism.
     */
    public Presentation accept(Confirmation confirmation) {
        if (!active || binding == null || confirmation == null || !confirmation.accepted()
                || confirmation.sequence() <= 0 || confirmation.sequence() <= lastSequence
                || confirmation.projectileCount() <= 0
                || !binding.weaponInstance().equals(confirmation.weaponInstance())
                || binding.sessionEpoch() != confirmation.sessionEpoch()
                || binding.configurationRevision() != confirmation.configurationRevision()) return null;
        lastSequence = confirmation.sequence();
        int emitter = (int) ((confirmation.sequence() - 1L) % binding.emitterCount());
        return new Presentation(binding.weaponInstance(), binding.sessionEpoch(),
                binding.configurationRevision(), confirmation.sequence(), emitter,
                confirmation.projectileCount());
    }
    public long lastConfirmedSequence() { return lastSequence; }
}
