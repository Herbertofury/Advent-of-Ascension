package dev.aoa.armory.presentation;

import java.util.UUID;
import static dev.aoa.armory.presentation.ConfirmedShotPresentation.*;

public final class PresentationTest {
    private static int checks;
    private static final UUID ID = new UUID(1, 2);
    private static Confirmation shot(long sequence, boolean accepted, int count) {
        return new Confirmation(ID, 10, 20, sequence, accepted, count);
    }
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        var state = new ConfirmedShotPresentation(ID, 10);
        check(state.accept(shot(1, true, 4)) == null, "Unbound state fired");
        state.bind(new Snapshot(ID, 10, 20, 0, 2));
        check(state.accept(shot(1, false, 4)) == null, "Rejected shot fired");
        check(state.lastConfirmedSequence() == 0, "Rejected shot advanced sequence");
        check(state.accept(shot(1, true, 4)).emitterIndex() == 0, "Top-first order");
        check(state.accept(shot(1, true, 4)) == null, "Duplicate shot replayed");
        check(state.accept(shot(2, true, 4)).emitterIndex() == 1, "Bottom-second order");
        check(state.accept(shot(5, true, 4)).emitterIndex() == 0, "Sequence gap used arrival order");
        check(state.accept(shot(4, true, 4)) == null, "Late shot replayed");
        check(state.accept(new Confirmation(new UUID(9, 9), 10, 20, 6, true, 4)) == null,
                "Wrong weapon accepted");
        check(state.accept(new Confirmation(ID, 9, 20, 6, true, 4)) == null,
                "Old session accepted");
        check(state.accept(new Confirmation(ID, 10, 19, 6, true, 4)) == null,
                "Old attachment configuration accepted");
        check(state.accept(shot(6, true, 0)) == null, "Invalid projectile count accepted");
        check(state.lastConfirmedSequence() == 5, "Invalid event mutated state");
        state = new ConfirmedShotPresentation(ID, 10);
        check(state.bind(new Snapshot(ID, 10, 20, 100, 3)), "Initial three-channel snapshot rejected");
        check(state.accept(shot(100, true, 4)) == null, "Snapshot replay baseline lost");
        var burst = state.accept(shot(101, true, 4));
        check(burst.emitterIndex() == 1 && burst.projectileCount() == 4,
                "Visible channels changed original burst metadata");
        check(state.bind(new Snapshot(ID, 10, 20, 1, 3)), "Same configuration snapshot rejected");
        check(state.accept(shot(101, true, 4)) == null, "Stale snapshot rewound replay history");
        check(!state.bind(new Snapshot(ID, 10, 19, 999, 3)), "Older configuration bound");
        check(!state.bind(new Snapshot(ID, 10, 20, 999, 4)), "Layout changed without revision");
        check(!state.bind(new Snapshot(ID, 9, 21, 999, 3)), "Wrong session bound");
        check(!state.bind(new Snapshot(new UUID(9,9), 10, 21, 999, 3)), "Wrong weapon bound");
        state.unbind();
        check(state.accept(shot(102, true, 4)) == null, "Unequipped controller fired");
        check(state.bind(new Snapshot(ID, 10, 20, 0, 3)), "Rebind failed");
        check(state.accept(shot(101, true, 4)) == null, "Reequip forgot replay history");
        check(state.bind(new Snapshot(ID, 10, 21, 10, 6)), "New configuration rejected");
        check(state.lastConfirmedSequence() == 101, "Configuration change rewound sequence");
        check(state.accept(shot(102, true, 4)) == null, "Old configuration fired after upgrade");
        var upgraded = state.accept(new Confirmation(ID, 10, 21, 102, true, 4));
        check(upgraded != null && upgraded.emitterIndex() == 5 && upgraded.projectileCount() == 4,
                "Six-emitter upgrade changed burst or ordinal");
        for (int emitters = 1; emitters <= 100; emitters++) {
            state = new ConfirmedShotPresentation(ID, 10);
            state.bind(new Snapshot(ID, 10, 20, 0, emitters));
            for (long sequence = 1; sequence <= 200; sequence++) {
                check(state.accept(shot(sequence, false, 4)) == null, "Dry/rejected event advanced");
                var event = state.accept(shot(sequence, true, 4));
                check(event.emitterIndex() == (sequence - 1) % emitters, "Emitter sequence mismatch");
                check(event.projectileCount() == 4, "Burst count changed");
                check(state.accept(shot(sequence, true, 4)) == null, "Duplicate in cycle");
            }
        }
        state = new ConfirmedShotPresentation(ID, 10);
        state.bind(new Snapshot(ID, 10, 20, Long.MAX_VALUE - 1, Integer.MAX_VALUE));
        check(state.accept(shot(Long.MAX_VALUE, true, 4)).emitterIndex() >= 0, "Ordinal overflow");
        state.unbind();
        check(state.accept(shot(Long.MAX_VALUE, true, 4)) == null, "Unbound replay");
        System.out.println("PASS " + checks + " presentation-state assertions; native integration untested");
    }
}
