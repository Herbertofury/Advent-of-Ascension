"""Original ornamental surface traces projected onto evaluated armor; unaccepted art study."""
import bpy,json,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R.parent/'discharge-grip-study-v21/discharge-grip-study.blend'))
dg=bpy.context.evaluated_depsgraph_get();records=[]
mat=bpy.data.materials['Discharge dark machined steel'].copy();mat.name='V22 dark inset ornament';p=mat.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.06,.065,.07,1);p.inputs['Metallic'].default_value=.5;p.inputs['Roughness'].default_value=.4
for side in [-1,1]:
 candidates=[o for o in bpy.data.objects if o.name.startswith('V3 sculpted forward armor') and not o.hide_render]
 target=next(o for o in candidates if sum((o.matrix_world@v.co).y for v in o.data.vertices)*side>0)
 e=target.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();bv=BVHTree.FromPolygons([target.matrix_world@v.co for v in m.vertices],[t.vertices[:]for t in m.loop_triangles],all_triangles=True)
 # These traces stay in the exposed upper silver strip; no copied external artwork.
 outlines=[[(.56,1.255),(1.0,1.315),(1.58,1.36),(2.15,1.405),(2.65,1.445)],[(1.02,1.315),(1.17,1.27),(1.35,1.29)],[(1.63,1.365),(1.79,1.31),(1.94,1.33)],[(2.19,1.405),(2.34,1.35),(2.49,1.37)]]
 for index,line in enumerate(outlines):
  points=[]
  for a,b in zip(line,line[1:]):
   for j in range(16):
    t=j/16;x=a[0]*(1-t)+b[0]*t;z=a[1]*(1-t)+b[1]*t;loc,normal,_,_=bv.ray_cast(Vector((x,side*3,z)),Vector((0,-side,0)),6)
    if loc is None:raise ValueError(('Ornament misses armor',side,index,x,z))
    points.append(loc+Vector((0,side*.002,0)))
  x,z=line[-1];loc,_,_,_=bv.ray_cast(Vector((x,side*3,z)),Vector((0,-side,0)),6);assert loc is not None;points.append(loc+Vector((0,side*.002,0)))
  d=bpy.data.curves.new('V22 seated armor trace','CURVE');d.dimensions='3D';d.bevel_depth=.005;d.bevel_resolution=1;d.use_fill_caps=True;sp=d.splines.new('POLY');sp.points.add(len(points)-1)
  for point,co in zip(sp.points,points):point.co=(*co,1)
  o=bpy.data.objects.new('V22 seated armor trace',d);bpy.context.collection.objects.link(o);d.materials.append(mat);records.append({'object':o.name,'target':target.name,'samples':len(points),'center_outward_offset':.002,'radius':.005})
 e.to_mesh_clear()
s=bpy.context.scene;s.cycles.samples=64;s.camera.location=(4,16,5);s.camera.rotation_euler=(Vector((0,0,.45))-s.camera.location).to_track_quat('-Z','Y').to_euler();s.camera.data.ortho_scale=11.5;s.render.filepath=str(R/'hero.png');bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-surface-detail.blend'));bpy.ops.render.render(write_still=True)
(R/'manifest.json').write_text(json.dumps({'status':'Unaccepted original surface ornament study','traces':records,'limits':['Surface sampling is geometric placement only, not native displacement or export acceptance','Concept fidelity remains open','Earlier export artifacts unchanged']},indent=2)+'\n')
