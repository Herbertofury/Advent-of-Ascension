import bpy,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'discharge-grip-study.blend'));dg=bpy.context.evaluated_depsgraph_get();bad=[];counts={};visible=0
for o in bpy.data.objects:
 if o.type not in {'MESH','CURVE'}or o.hide_render:continue
 visible+=1;e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();counts[o.name]=len(m.loop_triangles)
 for i,t in enumerate(m.loop_triangles):
  pts=[o.matrix_world@m.vertices[v].co for v in t.vertices]
  if (pts[1]-pts[0]).cross(pts[2]-pts[0]).length_squared<1e-20:bad.append([o.name,i])
 e.to_mesh_clear()
report={'source_sha256':hashlib.sha256((R/'discharge-grip-study.blend').read_bytes()).hexdigest(),'visible_objects':visible,'triangles':sum(counts.values()),'degenerate_triangles':bad,'scope':'Static evaluated world-space triangle area only; no hand or collision or native acceptance','native_acceptance':False}
(R/'geometry-qa.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert not bad
