import bpy,json,hashlib
from pathlib import Path
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parent
names=['Curved trigger','Open trigger guard']
def capture():
 dg=bpy.context.evaluated_depsgraph_get();out={}
 for name in names:
  o=bpy.data.objects[name];e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();out[name]={'positions':[list(o.matrix_world@v.co) for v in m.vertices],'triangles':[list(t.vertices)for t in m.loop_triangles]};e.to_mesh_clear()
 return out
bpy.ops.wm.open_mainfile(filepath=str(R.parent/'discharge-armor-relief-v19/discharge-armor-relief.blend'));before=capture()
bpy.ops.wm.open_mainfile(filepath=str(R/'discharge-grip-study.blend'));after=capture();assert before==after
trigger=after['Curved trigger'];tb=BVHTree.FromPolygons(trigger['positions'],trigger['triangles'],all_triangles=True);dg=bpy.context.evaluated_depsgraph_get();hits=[];tested=[]
for o in bpy.data.objects:
 if o.hide_render or not o.name.startswith('V21') or o.type not in {'MESH','CURVE'}:continue
 e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();vs=[o.matrix_world@v.co for v in m.vertices];ts=[t.vertices[:]for t in m.loop_triangles];bv=BVHTree.FromPolygons(vs,ts,all_triangles=True);overlaps=tb.overlap(bv);tested.append(o.name)
 if overlaps:hits.append({'part':o.name,'triangle_pairs':len(overlaps)})
 e.to_mesh_clear()
report={'source_sha256':hashlib.sha256((R/'discharge-grip-study.blend').read_bytes()).hexdigest(),'trigger_and_guard_exact_static_geometry_preserved':True,'new_parts_tested_against_static_trigger':tested,'static_trigger_surface_intersections':hits,'limits':['Static surface intersection check only; no hand, animation, containment or gameplay acceptance','Guard mounting contacts are intentionally outside this trigger-only check'],'native_acceptance':False}
(R/'fit-qa.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));assert not hits
