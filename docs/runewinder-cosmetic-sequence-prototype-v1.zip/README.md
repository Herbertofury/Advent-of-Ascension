# Runewinder cosmetic pose-target prototype

This isolated Java 17 study reuses the project's existing EmitterSequence.java unchanged from confirmed-emitter-sequence-v1.zip at AoA commit 1b324af5c184ae472aef3311bbebae8f2adb4592. It adds a RuneNecklace pose target and normalized closed-capsule bead placement, not a complete native weapon.

The caller must authenticate successful PRIMARY shot events and provide fresh epoch-bearing lifecycle keys. Contiguous accepted events advance one visual bead. Rejected, duplicate, bonus, closed and old-epoch events do not advance. Missing sequence values resynchronize the pose to the authoritative sequence; the prototype does not fabricate damage, ammo use or extra shots.

The demonstration uses 40 visual beads as an art experiment, not an accepted gameplay capacity. A one-bead loop is visually unchanged after a full step. Positions use arbitrary normalized art coordinates, not real manufacturing dimensions. This class provides target poses only: interpolation, mesh/UV/materials, glass, camera, native event binding and persistence still need implementation and validation. It is single-thread-owner code, not a thread-safe network or authority layer.

The initial shell PATH lacked javac. The existing local JDK 17.0.21 was located and used without installing another toolchain. The original 60,000-selection tests pass. New checks cover 10,000 contiguous advances, rejected/bonus/duplicate events, active capacity, lifecycle, high sequence values, sequence gaps, closed-path boundary continuity and 107,000 generated pose samples. These are offline generated checks, not gameplay footage or native acceptance.

Reproduce with JDK 17: compile the four Java files, then run EmitterSequenceTest and RuneNecklaceTest. The source-only package omits compiled classes and contains no third-party gunpack assets. No paused native task was resumed.
