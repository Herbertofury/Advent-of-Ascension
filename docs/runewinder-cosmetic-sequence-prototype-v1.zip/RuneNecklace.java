import java.util.HashMap;
import java.util.Map;
/** Isolated cosmetic pose target. Reuses the existing successful-shot sequence guard.
 * Caller authenticates events and supplies fresh lifecycle epochs. No damage/ammo logic.
 * Single-threaded owner; not a native TaCZ integration or persistence implementation.
 */
public final class RuneNecklace {
    private final EmitterSequence routing;
    private final Map<String, Integer> counts = new HashMap<>();
    private final Map<String, Integer> steps = new HashMap<>();
    public RuneNecklace(int activeCapacity) { routing = new EmitterSequence(activeCapacity); }
    public void begin(String epochKey, int visualBeads) {
        routing.begin(epochKey, visualBeads);
        counts.put(epochKey, visualBeads);
        steps.put(epochKey, 0);
    }
    /** Contiguous confirmed primary events advance one visual bead. Sequence gaps
     * resynchronize to the authoritative index rather than inventing extra shots.
     */
    public boolean confirm(String epochKey, long sequence, boolean accepted, boolean bonus) {
        int selected = routing.confirm(epochKey, sequence, accepted, bonus);
        if (selected < 0) return false;
        steps.put(epochKey, (selected + 1) % counts.get(epochKey));
        return true;
    }
    public double phase(String epochKey) {
        Integer count = counts.get(epochKey);
        if (count == null) throw new IllegalStateException("inactive epoch");
        return (double) steps.get(epochKey) / count;
    }
    public void end(String epochKey) {
        routing.end(epochKey); counts.remove(epochKey); steps.remove(epochKey);
    }
    public void reset() { routing.reset(); counts.clear(); steps.clear(); }
    public int activeCount() { return routing.activeCount(); }
    /** Normalized art-space capsule, not real dimensions. Continuous arc-length
     * placement around two straight sections and two semicircles. The final mesh,
     * crystal clearance, camera and interpolation still need authored validation.
     */
    public static double[] position(int bead, int visualBeads, double phase) {
        if (visualBeads < 1 || visualBeads > 64 || bead < 0 || bead >= visualBeads
                || !Double.isFinite(phase)) throw new IllegalArgumentException("pose input");
        double u = phase - Math.floor(phase);
        u = (u + (double) bead / visualBeads) % 1.0;
        double d = u * (4.0 + Math.PI);
        if (d < 2.0) return new double[] {-1.0 + d, 0.5};
        d -= 2.0;
        if (d < Math.PI / 2.0) {
            double angle = Math.PI / 2.0 - 2.0 * d;
            return new double[] {1.0 + 0.5 * Math.cos(angle), 0.5 * Math.sin(angle)};
        }
        d -= Math.PI / 2.0;
        if (d < 2.0) return new double[] {1.0 - d, -0.5};
        d -= 2.0;
        double angle = -Math.PI / 2.0 - 2.0 * d;
        return new double[] {-1.0 + 0.5 * Math.cos(angle), 0.5 * Math.sin(angle)};
    }
}
