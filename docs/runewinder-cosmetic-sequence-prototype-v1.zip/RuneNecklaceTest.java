public final class RuneNecklaceTest {
    static void check(boolean value) { if (!value) throw new AssertionError(); }
    static void near(double a, double b) { check(Math.abs(a-b) < 1e-9); }
    static void fails(Runnable f) { try { f.run(); throw new AssertionError(); }
        catch (IllegalArgumentException | IllegalStateException expected) {} }
    public static void main(String[] args) {
        RuneNecklace n = new RuneNecklace(2); n.begin("first:epoch1", 40);
        near(n.phase("first:epoch1"), 0);
        for (int i=0;i<10000;i++) {
            check(!n.confirm("first:epoch1",i,false,false));
            check(!n.confirm("first:epoch1",i,true,true));
            check(n.confirm("first:epoch1",i,true,false));
            near(n.phase("first:epoch1"), ((i+1)%40)/40.0);
            check(!n.confirm("first:epoch1",i,true,false));
        }
        check(n.confirm("first:epoch1",Long.MAX_VALUE,true,false));
        near(n.phase("first:epoch1"), ((Long.MAX_VALUE%40+1)%40)/40.0);
        n.begin("second:epoch1",64); near(n.phase("second:epoch1"),0);
        fails(()->n.begin("third:epoch1",40));
        n.end("first:epoch1");check(!n.confirm("first:epoch1",0,true,false));
        n.begin("first:epoch2",40); near(n.phase("first:epoch2"),0);
        check(!n.confirm("first:epoch1",1,true,false));
        // High-water sequence gaps produce deterministic resynchronization.
        check(n.confirm("first:epoch2",42,true,false)); near(n.phase("first:epoch2"),3/40.0);
        double length = 4+Math.PI;
        for(double phase:new double[]{0,2/length,(2+Math.PI/2)/length,(4+Math.PI/2)/length,1}) {
            double[] left=RuneNecklace.position(0,40,phase-1e-10);
            double[] right=RuneNecklace.position(0,40,phase+1e-10);
            check(Math.hypot(left[0]-right[0],left[1]-right[1])<1e-8);
        }
        for(int count:new int[]{1,2,40,64})for(int frame=0;frame<1000;frame++)for(int bead=0;bead<count;bead++) {
            double phase=frame/999.0;double[] p=RuneNecklace.position(bead,count,phase);
            check(Double.isFinite(p[0])&&Double.isFinite(p[1]));
            check(Math.abs(p[0])<=1.5000001&&Math.abs(p[1])<=0.5000001);
            double[] q=RuneNecklace.position(bead,count,phase+1);near(p[0],q[0]);near(p[1],q[1]);
        }
        fails(()->RuneNecklace.position(40,40,0));fails(()->RuneNecklace.position(0,0,0));
        fails(()->RuneNecklace.position(0,40,Double.NaN));fails(()->RuneNecklace.position(0,40,Double.POSITIVE_INFINITY));
        n.reset();check(n.activeCount()==0);fails(()->n.phase("first:epoch2"));
        System.out.println("PASS: 10000 confirmed advances, rejection/bonus/duplicate/lifecycle/gap guards and 107000 generated pose samples. Cosmetic prototype only; no native integration or gameplay capacity claim.");
    }
}
