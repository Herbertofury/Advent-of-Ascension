"""Read-only released-file audit. Does not execute Minecraft or game classes."""
import argparse,hashlib,json,subprocess,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('jar',type=Path);p.add_argument('--javap',required=True);p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args();a.out.mkdir(exist_ok=True)
sha=hashlib.sha256(a.jar.read_bytes()).hexdigest();assert sha=='f417ecb337d4a3b2aebec559a9262d8a86cc93ee7910f4eea64108bff063193a'
classes=['net.tslat.aoa3.common.registration.item.AoAWeapons','net.tslat.aoa3.content.item.weapon.gun.ApocoRifle','net.tslat.aoa3.content.item.weapon.gun.BaseGun','net.tslat.aoa3.content.entity.projectile.gun.BaseBullet','net.tslat.aoa3.content.entity.projectile.gun.DischargeShotEntity']
with zipfile.ZipFile(a.jar)as z:
 decoded={c.rsplit('.',1)[-1]:subprocess.check_output([a.javap,'-classpath',str(a.jar),'-p','-c','-constants',c],text=True)for c in classes}
 reg=decoded['AoAWeapons'].split('private static net.minecraft.world.item.Item lambda$static$16();')[1].split('private static')[0]
 assert all(x in reg for x in ['gun/ApocoRifle','float 2.5f','sipush        5960','bipush        6','fconst_1'])
 gun=decoded['ApocoRifle'];assert all(x in gun for x in ['DISCHARGE_CAPSULE','DischargeShotEntity','bipush        120','ITEM_GUN_PLASMA_GUN_FIRE'])
 assert 'doImpactEffect('not in gun and 'isFullAutomatic('not in gun
 assert 'float 1.8f'in decoded['DischargeShotEntity']
 assert 'protected float m_7139_();\n    Code:\n       0: fconst_0' in decoded['BaseBullet']
 entry='data/aoa3/recipes/upgrade_kit_apoco_rifle.json';recipe=json.loads(z.read(entry));assert recipe['input']['item']=='aoa3:discharge_rifle'and recipe['result']['item']=='aoa3:apoco_rifle'and recipe['upgrade_kit']['item']=='aoa3:apoco_upgrade_kit'
 assets={}
 for key,name in [('assets/aoa3/textures/item/apoco_rifle.png','apoco-rifle-original.png'),('assets/aoa3/textures/entity/projectile/bullets/discharge_shot.png','apoco-rifle-projectile-texture.png')]:
  data=z.read(key);(a.out/name).write_bytes(data);assets[key]=hashlib.sha256(data).hexdigest()
 report={'release':'AoA3.7.1 / Minecraft1.20.1','jar_sha256':sha,'item':'aoa3:apoco_rifle','distinct_from':'aoa3:apoco_assault_rifle','class_sha256':{c:hashlib.sha256(z.read(c.replace('.','/')+'.class')).hexdigest()for c in classes},'asset_sha256':assets,'inputs':{'damage':2.5,'durability':5960,'delay_ticks':6,'nominal_seconds_at_20tps':.3,'stored_recoil':1,'inherited_recoil_getter':.35,'full_automatic':True,'ammo':'aoa3:discharge_capsule','projectile':'DischargeShotEntity','projectile_age_parameter':120,'piercing_parameter':0,'projectile_multiplier':1,'projectile_gravity':0,'sound':'ITEM_GUN_PLASMA_GUN_FIRE'},'impact':'Shared gun direct-hit path then DischargeShotEntity explosion helper strength input1.8. No ApocoRifle custom impact override; do not copy DischargeShotgun extra2.5 explosion. Final damage and world-rule behavior require native tests.','recipe':{'entry':entry,'sha256':hashlib.sha256(z.read(entry)).hexdigest(),'json':recipe},'kit_loot_references':[n for n in z.namelist()if n.startswith('data/aoa3/loot_tables/')and n.endswith('.json')and b'aoa3:apoco_upgrade_kit'in z.read(n)],'lore_limit':'Packaged Vox Ponds loot-table association is not proof of current obtainability, active dimension, a named maker, or official mushroom/root construction lore.','native_accepted':False}
(a.out/'released-evidence.json').write_text(json.dumps(report,indent=2)+'\n');print('Pinned Apoco Rifle identity, five classes, two assets and upgrade recipe verified')
