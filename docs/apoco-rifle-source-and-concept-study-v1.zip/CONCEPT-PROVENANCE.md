# Apoco Rifle concept provenance

Generated with the built-in image tool using the nearest-neighbor enlarged actual AoA3.7.1 Apoco Rifle sprite as reference. The original source sprite is preserved separately. Conceptv1 has ambiguous grip/emitter orientation and is not accepted as the modeling target. Fungal and root-like materials are project interpretation; the packaged Vox Ponds loot association does not prove official construction lore.
