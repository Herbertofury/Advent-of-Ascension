# Baronator modular visual layout study

Six original external part configurations for inspection. Not a playable Minecraft mod or functional TaCZ gunpack. Optics, sound suppression, statistics, crafting and effect transfer are not implemented. No real-world weapon or suppressor engineering is represented.

Run python3 build_attachment_study.py, node test_attachment_study.cjs, then python3 build_attachment_lab.py --base-lab reference/base-mechanism-lab.html --output viewer.html. Requires Python3 and Node; optional renders require Blender. The base exported geometry is included so the attachment generator is reproducible. Known-bad mount geometry must fail the regression. Tests cover only their reported samples, not native gameplay or full artistic acceptance.
