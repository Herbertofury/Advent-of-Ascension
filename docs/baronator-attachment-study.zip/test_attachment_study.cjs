const fs=require('fs'),path=require('path'),assert=require('assert'),M=require('./animation_core'),{corners,penetration}=require('./geometry_clearance');
const file=path.join(__dirname,'attachment-study/assemblies.json'),data=JSON.parse(fs.readFileSync(file));
const clips=['static_auto','shoot_upper','shoot_lower','alternating_barrage_preview','mechanism_feed_upper','mechanism_feed_lower','mechanism_cycle_upper','mechanism_cycle_lower','mechanism_magazine_exchange'];
const bad=JSON.parse(fs.readFileSync(path.join(__dirname,'attachment-study/known-bad-prism-mount.json')));assert(penetration(bad.mount,bad.sled)>0,'Known bad mount fixture must fail');
let reports=[];
for(const [id,v]of Object.entries(data.variants)){
 const model=M.compile(v.geometry,data.animations),modules=new Set(v.module_bones);let samples=0,failures=[],boreFailures=[];
 for(const clip of clips){const c=data.animations[clip],times=new Set([0,c.animation_length]);for(let i=0;i<=Math.ceil(c.animation_length*60);i++)times.add(Math.min(c.animation_length,i/60));for(const b of Object.values(c.bones||{}))for(const ch of Object.values(b))for(const t of Object.keys(ch))times.add(+t);
 for(const t of times){const poses=M.pose(model,clip,t),items=[];for(const bone of model.geo.bones)for(const [i,cube]of (bone.cubes||[]).entries())items.push({name:bone.name+':'+i,bone:bone.name,box:corners(bone,cube,poses.get(bone.name))});samples++;
 for(const x of items.filter(x=>modules.has(x.bone)))for(const y of items){if(x.name===y.name||x.bone===y.bone)continue;const d=penetration(x.box,y.box);if(d>1e-6&&failures.length<12)failures.push({clip,t,left:x.name,right:y.name,depth:d});}
 }}
 // Straight visual projectile corridor through each chosen external housing, using exported poses.
 const pose=M.pose(model,'static_auto',0),root=model.geo.bones.find(b=>b.name==='root');
 for(const channel of ['upper','lower']){const start=model.geo.bones.find(b=>b.name==='barrel_rear_'+channel).pivot,end=model.geo.bones.find(b=>b.name==='muzzle_'+channel).pivot;assert.equal(start[0],end[0]);assert.equal(start[1],end[1]);let steps=Math.ceil((start[2]-end[2])/.05);for(let k=0;k<=steps;k++){let center=start.map((x,i)=>x+(end[i]-x)*k/steps),cube={origin:center.map((x,i)=>x-[.65,.65,1][i]/2),size:[.65,.65,1]},box=corners(root,cube,pose.get('root'));for(const b of model.geo.bones.filter(b=>modules.has(b.name)))for(const c of b.cubes||[]){if(penetration(box,corners(b,c,pose.get(b.name)))>1e-6&&boreFailures.length<8)boreFailures.push({channel,k,bone:b.name});}}}
 const r={id,samples,failures,boreFailures};reports.push(r);console.log(JSON.stringify(r));
}
fs.writeFileSync(path.join(__dirname,'attachment-study/clearance-qa.json'),JSON.stringify({scope:'Selected attachment cuboids versus other bones at 60Hz plus authored keys; static attachment bore corridor. Not continuous/native/visual certification; no blanket whole-bone collision exemptions for attachments versus base model.',reports},null,2)+'\n');assert(reports.every(x=>!x.failures.length&&!x.boreFailures.length),'Attachment collision found');
