"""Original fictional game-art attachment blockouts; no real suppressor design or runtime gameplay."""
from pathlib import Path
import copy,json
R=Path(__file__).parent;P=R/'baronator-mechanism-study/assets/ascension_armory';D=R/'attachment-study';D.mkdir(exist_ok=True)
g=json.loads((P/'geo_models/gun/baronator_geo.json').read_text())['minecraft:geometry'][0]
a=json.loads((P/'animations/baronator.animation.json').read_text())['animations']
colors={'dark':2,'metal':3,'bright':4,'gold':5,'energy':6,'shell':0}
def cube(origin,size,mat):
 i=colors[mat];return {'origin':list(origin),'size':list(size),'uv':{f:{'uv':[(i%4)*32+2,(i//4)*32+2],'uv_size':[8,8]} for f in ['north','south','east','west','up','down']}}
def prism():
 b={'name':'module_prism','parent':'root','pivot':[0,4.3,0],'cubes':[]}
 for x in [-1.35,1.0]:b['cubes'].append(cube((x,4.3,3.1),(.35,1.0,1.6),'metal'))
 for x in [-1.65,1.3]:b['cubes'].append(cube((x,5.3,-1.4),(.35,2.0,3.6),'shell'))
 for y in [5.3,6.95]:b['cubes'].append(cube((-1.3,y,-1.4),(2.6,.35,3.6),'gold'))
 # An open stylized sight window; small emissive markers, no opaque slab blocking the view.
 b['cubes'].append(cube((-.12,6.1,-1.45),(.24,.7,.12),'energy'))
 b['cubes'].append(cube((-.45,6.35,-1.45),(.33,.2,.12),'energy'))
 b['cubes'].append(cube((.12,6.35,-1.45),(.33,.2,.12),'energy'))
 # Rear anchored cantilever clears the roof sled throughout its full recoil travel.
 for c in b['cubes'][2:]:c['origin'][2]+=2.7
 return b

def damper(channel,cy,front):
 b={'name':'module_damper_'+channel,'parent':channel+'_barrel','pivot':[0,cy,front],'cubes':[]}
 # External fictional housing only: an open passage, no real baffle or functional engineering design.
 for x in [-1.6,1.35]:b['cubes'].append(cube((x,cy-1.25,front-5.5),(.25,2.5,5.5),'dark'))
 for y in [cy-1.25,cy+1.0]:b['cubes'].append(cube((-1.35,y,front-5.5),(2.7,.25,5.5),'dark'))
 for z in [front-5.5,front-1.0]:
  for x in [-1.8,1.6]:b['cubes'].append(cube((x,cy-1.45,z),(.2,2.9,.45),'gold'))
  for y in [cy-1.45,cy+1.25]:b['cubes'].append(cube((-1.6,y,z),(3.2,.2,.45),'gold'))
 return b
variants={}
for sight in ['standard','prism']:
 for muzzle in ['standard','upper_damper','dual_damper']:
  geo=copy.deepcopy(g);mods=[]
  if sight=='prism':mods.append(prism())
  channels=['upper'] if muzzle=='upper_damper' else ['upper','lower'] if muzzle=='dual_damper' else []
  for channel in channels:
   cy,front=(2,-17.2) if channel=='upper' else (-1.8,-13.2)
   mods.append(damper(channel,cy,front))
   next(b for b in geo['bones'] if b['name']=='muzzle_'+channel)['pivot'][2]=front-5.5
  geo['bones'].extend(mods)
  key=sight+'__'+muzzle;variants[key]={'label':sight.replace('_',' ')+' / '+muzzle.replace('_',' '),'geometry':geo,'module_bones':[m['name'] for m in mods],'native_gameplay_implemented':False}
out={'scope':'Original visual attachment layouts only. No native optics, sound suppression, stat changes, crafting, effects or gameplay integration.','animations':a,'variants':variants}
(D/'assemblies.json').write_text(json.dumps(out,separators=(',',':'))+'\n');print('Original visual assemblies:',len(variants),[(k,sum(len(b.get('cubes',[]))for b in v['geometry']['bones']))for k,v in variants.items()])
