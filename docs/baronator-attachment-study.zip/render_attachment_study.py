from pathlib import Path
import bpy,json,math
from mathutils import Vector,Euler
R=Path(__file__).resolve().parent;study=json.loads((R/'attachment-study/assemblies.json').read_text());out=R/'attachment-study/renders';out.mkdir(exist_ok=True)
base=(R/'render_baronator_v2.py').read_text();start="geo=json.load(open(P/'geo_models/gun/baronator_geo.json'))['minecraft:geometry'][0]";assert start in base
base=base.replace(start,'geo=selected_geometry').replace("animations=json.load(open(P/'animations/baronator.animation.json'))['animations']","animations=study['animations']").replace(';bpy.ops.render.render(write_still=True)','').replace('baronator-v2-authoring.blend','baronator-attachment-study.blend')
base=base.replace("bones[b['name']]=ob","bones[b['name']]=ob;ob.rotation_euler=(C@Euler(tuple(math.radians(v) for v in b.get('rotation',[0,0,0])),'XYZ').to_matrix()@C.inverted()).to_euler()")
for key in ['standard__standard','prism__standard','prism__dual_damper']:
 selected_geometry=study['variants'][key]['geometry'];exec(compile(base,str(R/'render_baronator_v2.py'),'exec'))
 for name in ['lefthand_pos','righthand_pos']:
  for obj in bones[name].children:obj.hide_render=True
 scene.render.resolution_x=1000;scene.render.resolution_y=650;cam.data.ortho_scale=46
 for angle,loc in [('side',(45,0,10)),('front',(-28,36,15)),('rear',(25,-35,15))]:
  cam.location=loc;cam.rotation_euler=(Vector((0,1,0))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(key+'-'+angle+'.png'));bpy.ops.render.render(write_still=True)
print('Nine original attachment-layout review renders complete; not native-game images')
