from pathlib import Path
from PIL import Image
import json,zipfile,hashlib,unittest,os
R=Path(__file__).resolve().parent;D=Path(os.environ.get('AOA_DOCS',R.parents[1]/'aoa-recovery-repo/docs'));E=json.loads((D/'divine-upgrade-atlas-data.json').read_text());Z=zipfile.ZipFile(os.environ.get('AOA_JAR',R.parent/'references/AoA3-1.20.1-3.7.1-all.jar'))
class Atlas(unittest.TestCase):
 def test_full_coverage(self):
  actual={n for n in Z.namelist()if n.startswith('data/aoa3/recipes/')and n.endswith('.json')and json.loads(Z.read(n)).get('type')=='aoa3:upgrade_kit'};self.assertEqual(actual,{r['recipe_path']for r in E['records']});self.assertEqual(len(actual),70)
 def test_no_duplicate_outputs(self):self.assertEqual(len({r['recipe']['result']['item']for r in E['records']}),70)
 def test_exact_recipe_bytes(self):
  for r in E['records']:self.assertEqual(hashlib.sha256(Z.read(r['recipe_path'])).hexdigest(),r['recipe_sha256']);self.assertEqual(json.loads(Z.read(r['recipe_path'])),r['recipe'])
 def test_all_sprites(self):
  for r in E['records']:
   self.assertEqual(len(r['sprites']),3)
   for s in r['sprites']:self.assertEqual(hashlib.sha256(Z.read(s['texture'])).hexdigest(),s['sha256'])
 def test_render_dimensions(self):
  for r in E['records']:
   with Image.open(D/r['image'])as im:self.assertEqual(im.size,(1200,500));self.assertFalse(r['native_screenshot'])
 def test_index_count(self):self.assertEqual(len(json.loads((R/'pages.json').read_text())),20)
if __name__=='__main__':unittest.main()
