# Released upgrade recipe atlas generator

Python 3 + Pillow. Requires the user-supplied exact AoA3-1.20.1-3.7.1-all.jar (SHA256 f417ecb337d4a3b2aebec559a9262d8a86cc93ee7910f4eea64108bff063193a); no game archive redistributed. DejaVuSans fonts must be installed at the paths shown in build.py.

Run `python build.py --jar /path/to/release.jar --docs /path/to/output`.
Run tests with `AOA_JAR=/path/to/release.jar AOA_DOCS=/path/to/output python test_atlas.py`.

Build writes 70 diagrams, exact recipe/sprite provenance and 20 Markdown pages. Each item uses its bundled inventory texture; animated strips use the first declared frame. These are documentation diagrams, not captured game screens or runtime certification. Every base/kit/result is checked against the original JSON. Public AoA asset attribution remains in the generated index.
