"""Generate a complete version-pinned Divine Station upgrade atlas from the release."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import zipfile,json,io,hashlib,collections,html,argparse
R=Path(__file__).resolve().parent;parser=argparse.ArgumentParser();parser.add_argument('--jar',type=Path,default=R.parent/'references/AoA3-1.20.1-3.7.1-all.jar');parser.add_argument('--docs',type=Path,default=R.parents[1]/'aoa-recovery-repo/docs');args=parser.parse_args();D=args.docs.resolve();D.mkdir(parents=True,exist_ok=True);jar=args.jar.resolve();assert hashlib.sha256(jar.read_bytes()).hexdigest()=='f417ecb337d4a3b2aebec559a9262d8a86cc93ee7910f4eea64108bff063193a','Unexpected release';z=zipfile.ZipFile(jar);lang=json.loads(z.read('assets/aoa3/lang/en_us.json'));f=lambda n,b=False:ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold'if b else'')+'.ttf',n);records=[];missing=[]
def label(id):return lang.get('item.'+id.replace(':','.'),id)
for path in sorted(z.namelist()):
 if not(path.startswith('data/aoa3/recipes/')and path.endswith('.json')):continue
 raw=z.read(path);recipe=json.loads(raw)
 if recipe.get('type')!='aoa3:upgrade_kit':continue
 assert set(recipe)=={'type','input','result','upgrade_kit'},path
 assert all(set(recipe[k])=={'item'}for k in ['input','result','upgrade_kit']),path
 ids=[recipe[k]['item']for k in ['input','upgrade_kit','result']];names=[label(x)for x in ids];sprites=[]
 for id in ids:
  ns,key=id.split(':');p=f'assets/{ns}/textures/item/{key}.png'
  if p not in z.namelist():missing.append([path,id,p]);continue
  data=z.read(p);im=Image.open(io.BytesIO(data)).convert('RGBA');frame=None
  if im.width!=im.height:
   meta=json.loads(z.read(p+'.mcmeta'))['animation'];fw=meta.get('width',im.width);fh=meta.get('height',fw);assert im.width%fw==0 and im.height%fh==0
   first=meta.get('frames',[0])[0];idx=first['index']if isinstance(first,dict)else first;cols=im.width//fw;x=(idx%cols)*fw;y=(idx//cols)*fh;assert y+fh<=im.height;frame={'index':idx,'crop':[x,y,x+fw,y+fh],'scope':'First declared animation frame only, not animated preview'};im=im.crop((x,y,x+fw,y+fh))
  sprites.append((im,{'id':id,'texture':p,'sha256':hashlib.sha256(data).hexdigest(),'animation_frame':frame}))
 if len(sprites)!=3:continue
 im=Image.new('RGB',(1200,500),'#101823');draw=ImageDraw.Draw(im);title=names[2].upper();size=34
 while draw.textlength('DIVINE STATION  /  '+title,font=f(size,True))>1120:size-=1
 draw.text((40,28),'DIVINE STATION  /  '+title,font=f(size,True),fill='#f1eee5');draw.text((40,80),'AoA 3.7.1 · Minecraft 1.20.1 · exact bundled upgrade recipe',font=f(20),fill='#aab7c9')
 for i,((sprite,proof),name,x)in enumerate(zip(sprites,names,[75,465,855])):
  draw.rounded_rectangle((x,140,x+240,380),radius=18,fill='#1b2a3b',outline='#41566c',width=3);sprite=sprite.resize((192,192),Image.Resampling.NEAREST);im.paste(sprite,(x+24,164),sprite);sz=21
  while draw.textlength(name,font=f(sz,True))>310:sz-=1
  draw.text((x+120,393),name,anchor='mt',font=f(sz,True),fill='#f3f5f8');draw.text((x+120,433),['LEFT INPUT','MIDDLE KIT','OUTPUT'][i],anchor='mt',font=f(16),fill='#8fbed2')
 draw.text((390,250),'+',anchor='mm',font=f(50,True),fill='#a9dfd0');draw.text((780,250),'→',anchor='mm',font=f(50,True),fill='#a9dfd0');draw.text((40,475),'Documentation illustration from released sprites; not a captured game UI.',font=f(14),fill='#aab7c9');fn='divine-upgrade-'+ids[2].split(':')[1]+'.webp';im.save(D/fn,'WEBP',quality=93,method=6)
 records.append({'recipe_path':path,'recipe_sha256':hashlib.sha256(raw).hexdigest(),'recipe':recipe,'names':dict(zip(['input','kit','output'],names)),'image':fn,'sprites':[p for _,p in sprites],'native_screenshot':False})
assert not missing,missing
assert len(records)==70
out={'release':'AoA3-1.20.1-3.7.1','jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'scope':'All 70 bundled upgrade_kit recipes and their released item texture illustrations; not native screenshots or arbitrary item-data transfer proof','count':len(records),'records':records};(D/'divine-upgrade-atlas-data.json').write_text(json.dumps(out,indent=2)+'\n');groups=collections.defaultdict(list)
for row in records:groups[row['names']['kit']].append(row)
index='# Divine Station: illustrated upgrade atlas\n\n**All 70 bundled upgrade-kit recipes · AoA 3.7.1 / Minecraft 1.20.1.** Each picture uses the released item textures and exact input, kit and output identifiers. These are documentation diagrams, not game screenshots. Other versions and datapacks can differ.\n\n[How to use the station](Divine-Station-Weapon-Upgrades-1.20.1) · [Recipe explorer](https://herbertofury.github.io/Advent-of-Ascension/recipe-explorer.html?v=1.20.1)\n\n## Choose your kit\n\n| Kit | Upgrade recipes | Illustrated page |\n|---|---:|---|\n';pages=[]
for kit,rs in sorted(groups.items()):
 slug='Divine-Upgrades-'+kit.replace(' Upgrade Kit','').replace(' ','-');pages.append(slug);index+=f'| {kit} | {len(rs)} | [View recipes]({slug}) |\n';body=f'# {kit}: illustrated upgrades\n\n[All kits](Divine-Station-Upgrade-Atlas) · [Station tutorial](Divine-Station-Weapon-Upgrades-1.20.1)\n\nAoA 3.7.1 / Minecraft 1.20.1. Put the pictured base item in the left input and the kit in the middle, then collect the output. Do not assume arbitrary names, enchantments or third-party attachments survive; use the tutorial’s data-transfer cautions.\n\n'
 for row in rs:
  names=row['names'];recipekey=Path(row['recipe_path']).stem;body+=f'## {names["output"]}\n\n**{names["input"]} + {names["kit"]} → {names["output"]}**\n\n![{names["input"]}, {names["kit"]} and {names["output"]}; released-texture documentation diagram](https://raw.githubusercontent.com/Herbertofury/Advent-of-Ascension/main/docs/{row["image"]})\n\n[Exact recipe](https://herbertofury.github.io/Advent-of-Ascension/recipe-explorer.html?v=1.20.1&q={recipekey}) · Bundled definition: `{row["recipe_path"]}`.\n\n'
 (D/(slug+'.md')).write_text(body)
index+='\n## Coverage and limits\n\nThe release scan found exactly 70 recipes of type `aoa3:upgrade_kit`; every one appears here once. All 210 ingredient/output illustrations resolved to actual released textures. Animated strips use their first declared frame; they are not animated previews. Recipe weights, damage, or an upgrade kit’s name are not used to invent effects or lore. This atlas includes bows, staves and melee weapons as well as firearms.\n\n[Machine-readable recipe and sprite provenance](https://github.com/Herbertofury/Advent-of-Ascension/blob/main/docs/divine-upgrade-atlas-data.json). Original AoA assets belong to their respective creators.\n';(D/'Divine-Station-Upgrade-Atlas.md').write_text(index);(R/'pages.json').write_text(json.dumps(['Divine-Station-Upgrade-Atlas']+pages,indent=2));(R/'files.json').write_text(json.dumps([str((D/row['image']).resolve())for row in records]+[str((D/(p+'.md')).resolve())for p in ['Divine-Station-Upgrade-Atlas']+pages]+[str((D/'divine-upgrade-atlas-data.json').resolve())],indent=2));print('Built',len(records),'boards and',len(pages)+1,'pages')
