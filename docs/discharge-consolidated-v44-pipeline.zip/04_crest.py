"""Restore concept crest visibility; prior ornament was buried behind later armor."""
import bpy,json,hashlib,argparse,sys
from pathlib import Path
from mathutils import Vector,Matrix
H=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);R=a.out;R.mkdir(parents=True,exist_ok=True);src=a.source;bpy.ops.wm.open_mainfile(filepath=str(src));s=bpy.context.scene;s.frame_set(1);bpy.context.view_layer.update();changes=[]
for old in list(bpy.data.objects):
 if old.hide_render or not(old.name.startswith('Capacitor heraldic silver star')or old.name.startswith('Inset red signal gem')):continue
 center=sum((old.matrix_world@Vector(p)for p in old.bound_box),Vector())/8
 if not(-1.7<center.x<-.9):continue
 side=1 if center.y>0 else-1;is_star='silver star'in old.name;scale=(.56,.55,.72)if is_star else(.48,.45,.48);target=Vector((-1.19,side*(.899 if is_star else .918),.60));obj=old.copy();obj.data=old.data.copy();obj.name='V43 visible '+old.name;bpy.context.collection.objects.link(obj)
 for v,ov in zip(obj.data.vertices,old.data.vertices):
  p=old.matrix_world@ov.co-center;v.co=target+Vector(tuple(p[i]*scale[i]for i in range(3)))
 obj.data.update();normal_matrix=old.matrix_world.to_3x3().inverted().transposed();normals=[]
 for n in old.data.corner_normals:
  world_n=normal_matrix@n.vector;normals.append(tuple(Vector(tuple(world_n[i]/scale[i]for i in range(3))).normalized()))
 obj.data.normals_split_custom_set(normals);obj.data.update();obj.matrix_world=Matrix.Identity(4);old.hide_render=True;changes.append({'old':old.name,'new':obj.name,'side':side,'scale_xyz':scale,'target_center':list(target)})
assert len(changes)==4;s.render.resolution_x=1200;s.render.resolution_y=850;s.render.resolution_percentage=100;s.cycles.samples=64;s.cycles.seed=0;s.cycles.use_denoising=False;c=s.camera;c.location=(5,15,6);c.rotation_euler=(Vector((-.2,0,.5))-c.location).to_track_quat('-Z','Y').to_euler();c.data.type='ORTHO';c.data.ortho_scale=10;s.render.filepath=str(R/'hero-r3.png');bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-crest-r3.blend'));(R/'manifest-r3.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'changes':changes,'native_accepted':False,'final_art_accepted':False,'scope':'Crest mounting/visibility correction pending geometric and render checks'},indent=2))
