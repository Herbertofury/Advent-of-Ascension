"""One bounded, non-overwriting build chain from a published authoring input."""
from pathlib import Path
import argparse,hashlib,json,subprocess
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--blender',default='blender');a=p.parse_args();R=Path(__file__).resolve().parent;source=a.source.resolve();out=a.out.resolve();expected='52b82c012a8c850c8e7cd7433594fedefc59de4b5b9344fb7fab001c44af1f70';assert source.is_file()and hashlib.sha256(source.read_bytes()).hexdigest()==expected,'Use the published v36 output scene, not an arbitrary checkpoint'
if out.exists()and any(out.iterdir()):raise SystemExit('Output directory must be empty; refusing to overwrite existing work')
if out==source.parent or out in source.parents:raise SystemExit('Output must be separate from the input source')
pins=json.loads((R/'script-hashes.json').read_text())
for name,digest in pins.items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,'Changed build stage: '+name
version=subprocess.run([a.blender,'--version'],capture_output=True,text=True,check=True).stdout.splitlines()[0]
if version!='Blender 4.3.2':raise SystemExit('This source pipeline is qualified for Blender 4.3.2; requalify other versions')
out.mkdir(parents=True,exist_ok=True);steps=[('01_collars.py','discharge-chamber-study.blend','--output'),('02_rail.py','discharge-rail-r2.blend','--out'),('03_materials.py','discharge-surface-study.blend','--out'),('04_crest.py','discharge-crest-r3.blend','--out')];receipts=[]
for i,(script,result,flag)in enumerate(steps,1):
 target=out/('step-'+str(i));target.mkdir();cmd=[a.blender,'-b','-t','2','--python-exit-code','1','--python',str(R/script),'--','--source',str(source),flag,str(target)]
 with (out/('step-'+str(i)+'.log')).open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 created=target/result;assert created.is_file();receipts.append({'step':script,'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'output':str(created.relative_to(out)),'output_sha256':hashlib.sha256(created.read_bytes()).hexdigest()});source=created
(out/'build-receipt.json').write_text(json.dumps({'source_required_sha256':expected,'steps':receipts,'final_scene':str(source.relative_to(out)),'native_accepted':False,'final_art_accepted':False,'scope':'Consolidated authoring chain only; no new atlas or native export'},indent=2));print(source)
