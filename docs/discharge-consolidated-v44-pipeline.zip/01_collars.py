"""Fictional game prop surface study: layered chamber collar appearance."""
import bpy,bmesh,math,json,hashlib,argparse,sys
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);src=a.source;OUT=a.output;OUT.mkdir(parents=True,exist_ok=True);assert hashlib.sha256(src.read_bytes()).hexdigest()=='52b82c012a8c850c8e7cd7433594fedefc59de4b5b9344fb7fab001c44af1f70','Unexpected source; requalify before applying';bpy.ops.wm.open_mainfile(filepath=str(src));s=bpy.context.scene;s.frame_set(1)
steel=bpy.data.materials['Discharge dark machined steel'];silver=bpy.data.materials['Discharge bright edges'];created=[]
# A closed lathed cosmetic shell keeps the previous collar span. No gameplay or internal mechanism changes.
profile=[(-.08,.285),(-.08,.307),(-.065,.326),(-.045,.326),(-.031,.302),(-.014,.302),(-.006,.316),(.006,.316),(.014,.302),(.031,.302),(.045,.326),(.065,.326),(.08,.307),(.08,.285)]
for owner in [o for o in bpy.data.objects if o.name.startswith('Capacitor dark collar')and not o.hide_render]:
 center=owner.matrix_world.translation.copy();owner.hide_render=True;N=48;vs=[]
 for x,r in profile:
  for k in range(N):a=math.tau*k/N;vs.append((center.x+x,center.y+r*math.cos(a),center.z+r*math.sin(a)))
 fs=[];bands=[]
 for j in range(len(profile)):
  nj=(j+1)%len(profile)
  for k in range(N):nk=(k+1)%N;fs.append((j*N+k,j*N+nk,nj*N+nk,nj*N+k));bands.append(j)
 me=bpy.data.meshes.new('V38 layered collar');me.from_pydata(vs,[],fs);me.update();bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));assert all(e.is_manifold for e in bm.edges)
 if bm.calc_volume(signed=True)<0:bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
 volume=bm.calc_volume(signed=True);bm.to_mesh(me);bm.free();o=bpy.data.objects.new('V38 layered chamber collar',me);bpy.context.collection.objects.link(o);me.materials.append(steel);me.materials.append(silver)
 for p,j in zip(me.polygons,bands):p.material_index=1 if j in [1,2,3,10,11]else 0;p.use_smooth=True
 me.set_sharp_from_angle(angle=math.radians(35))
 bpy.context.view_layer.update();world=o.matrix_world.copy();o.parent=owner.parent;o.matrix_world=world
 me.calc_loop_triangles();created.append({'name':o.name,'replaces_visible':owner.name,'triangles':len(me.loop_triangles),'volume':volume,'parent':o.parent.name if o.parent else None})
assert len(created)==4;s.render.resolution_x=1200;s.render.resolution_y=850;s.render.resolution_percentage=100;s.cycles.samples=48;s.cycles.use_denoising=False
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'discharge-chamber-study.blend'))
(OUT/'manifest.json').write_text(json.dumps({'status':'Unaccepted cosmetic chamber-collar study','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'new_parts':created,'prior_parts_retained_hidden':True,'native_accepted':False,'limits':['No native or full moving-clearance acceptance','Not the baked v37 geometry','Visual review required before publication']},indent=2)+'\n')
