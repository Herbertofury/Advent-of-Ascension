# Discharge consolidated authoring pipeline

This small source package rebuilds the current chamber collars, three-opening lower rail, paint materials and corrected visible crest from one published input. It is a partial cosmetic authoring study, not a playable/native weapon or final-art acceptance.

## Required input

Download https://github.com/Herbertofury/Advent-of-Ascension/raw/refs/heads/main/docs/discharge-grip-v36-study.zip and extract output/discharge-grip-study.blend. Its required SHA256 is 52b82c012a8c850c8e7cd7433594fedefc59de4b5b9344fb7fab001c44af1f70. The matching bytes were verified inside that published archive. No intermediate checkpoint needs to be found manually.

Use Python 3 and Blender 4.3.2. Run:

python build.py --source /path/to/output/discharge-grip-study.blend --out /path/to/new-empty-build-folder --blender /path/to/blender

The final model is step-4/discharge-crest-r3.blend under the output directory. Each stage has a log and the final build-receipt.json records inputs and outputs. The source input is never overwritten. A nonempty output directory, wrong input hash, modified stage script or unqualified Blender version is rejected.

## Why consolidate

Earlier individual patches required manually locating generated intermediate scenes; a whole-BLEND hash can vary with a rebuild location or metadata even when authored content agrees. This pipeline pins the actually published starting file, then generates and passes its own intermediate outputs. Prefer it over the standalone v42 intermediate-source workflow. Earlier art and source variants remain available.

The crest's former placement was covered by later armor at the declared test landmarks. The correction seats a smaller centered silver star and red gem on the visible plate. Its authored corner normals are transformed for the nonuniform scaling. Eight declared side-view rays hit the new crest; this is not all-angle or native-rendering acceptance.

Clean rebuild comparison matched 325 stored geometry objects, 17 materials and 7 stored actions, including geometry, normals,UVs,transforms,visibility,material-node inputs/links/ramps and action keys. Those counts include retained authoring objects and are not draw-call counts or seven accepted animation states. Native shader behavior, assembly/hand clearance, complete animations, LOD budgets and gameplay remain open.

This is separate from the older v39 baked export. A new atlas/export and native qualification are required before that evidence applies. No upstream game/mod binaries or third-party dependencies are bundled. No FPS or loading improvement is claimed.

Guard tests: python test_cli.py --source /path/to/output/discharge-grip-study.blend

The complete chain and structural comparison were tested on the cloud Linux environment with Blender 4.3.2. Other platforms still need their own execution check.
