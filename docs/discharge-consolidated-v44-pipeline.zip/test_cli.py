from pathlib import Path
import subprocess,tempfile,unittest,shutil,argparse,sys
R=Path(__file__).resolve().parent;parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True);args,rest=parser.parse_known_args();source=args.source;sys.argv=[sys.argv[0],*rest]
class Cli(unittest.TestCase):
 def test_wrong_input(self):
  with tempfile.TemporaryDirectory()as t:
   d=Path(t);bad=d/'bad.blend';bad.write_bytes(b'not the source');p=subprocess.run(['python',str(R/'build.py'),'--source',str(bad),'--out',str(d/'out')],capture_output=True,text=True);self.assertNotEqual(p.returncode,0);self.assertFalse((d/'out').exists())
 def test_nonempty_output(self):
  with tempfile.TemporaryDirectory()as t:
   d=Path(t);(d/'keep.txt').write_text('retain');p=subprocess.run(['python',str(R/'build.py'),'--source',str(source),'--out',str(d),'--blender','not-launched'],capture_output=True,text=True);self.assertNotEqual(p.returncode,0);self.assertIn('refusing to overwrite',p.stderr);self.assertEqual((d/'keep.txt').read_text(),'retain')
 def test_modified_stage(self):
  with tempfile.TemporaryDirectory()as t:
   d=Path(t);shutil.copytree(R,d/'package');p=d/'package/02_rail.py';p.write_text(p.read_text()+'\n# changed\n');run=subprocess.run(['python',str(d/'package/build.py'),'--source',str(source),'--out',str(d/'out'),'--blender','not-launched'],capture_output=True,text=True);self.assertNotEqual(run.returncode,0);self.assertIn('Changed build stage',run.stderr);self.assertFalse((d/'out').exists())
 def test_unqualified_runtime(self):
  with tempfile.TemporaryDirectory()as t:
   d=Path(t);run=subprocess.run(['python',str(R/'build.py'),'--source',str(source),'--out',str(d/'out'),'--blender',sys.executable],capture_output=True,text=True);self.assertNotEqual(run.returncode,0);self.assertIn('qualified for Blender 4.3.2',run.stderr);self.assertFalse((d/'out').exists())
if __name__=='__main__':unittest.main()
