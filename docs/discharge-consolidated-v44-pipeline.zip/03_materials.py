"""Paint-versus-metal material separation for a fictional game-prop authoring scene."""
import bpy,json,hashlib,argparse,sys
from pathlib import Path
from mathutils import Vector
H=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);R=a.out;R.mkdir(parents=True,exist_ok=True);src=a.source;bpy.ops.wm.open_mainfile(filepath=str(src));s=bpy.context.scene;s.frame_set(1);changes=[]
for oldname,metal,coat in [('Discharge ceramic-white worn armor',.08,.28),('Discharge crimson worn enamel',.12,.32)]:
 old=bpy.data.materials[oldname];m=old.copy();m.name='V42 '+oldname;t=m.node_tree;p=t.nodes.get('Principled BSDF');p.inputs['Metallic'].default_value=metal;p.inputs['Coat Weight'].default_value=coat;p.inputs['Coat Roughness'].default_value=.22
 if 'white' in oldname:
  ramp=t.nodes.get('Color Ramp.001');assert ramp
  colors=[(.20,(.68,.70,.69,1)),(.65,(.79,.80,.77,1)),(.83,(.24,.25,.25,1)),(.94,(.12,.13,.14,1))]
  while len(ramp.color_ramp.elements)>2:ramp.color_ramp.elements.remove(ramp.color_ramp.elements[-1])
  ramp.color_ramp.elements[0].position=colors[0][0];ramp.color_ramp.elements[0].color=colors[0][1];ramp.color_ramp.elements[1].position=colors[-1][0];ramp.color_ramp.elements[1].color=colors[-1][1]
  for pos,col in colors[1:-1]:ramp.color_ramp.elements.new(pos).color=col
  bump=t.nodes.get('Bump');bump.inputs['Strength'].default_value=.035;bump.inputs['Distance'].default_value=.004
  mr=t.nodes.get('Map Range');mr.inputs['To Min'].default_value=.28;mr.inputs['To Max'].default_value=.40
  mask=t.nodes.new('ShaderNodeMapRange');mask.name='V42 exposed metal only';mask.clamp=True;mask.inputs['From Min'].default_value=.78;mask.inputs['From Max'].default_value=.90;mask.inputs['To Min'].default_value=.05;mask.inputs['To Max'].default_value=.82;t.links.new(t.nodes['Noise Texture.001'].outputs['Fac'],mask.inputs['Value']);t.links.new(mask.outputs['Result'],p.inputs['Metallic'])
 changed=0
 for o in bpy.data.objects:
  if o.type not in {'MESH','CURVE'}:continue
  for slot in o.material_slots:
   if slot.material==old:slot.material=m;changed+=1
 changes.append({'source':oldname,'new':m.name,'slots':changed,'paint_metallic':metal,'coat_weight':coat})
s.render.resolution_x=1200;s.render.resolution_y=850;s.render.resolution_percentage=100;s.cycles.samples=96;s.cycles.seed=0;s.cycles.use_denoising=False;c=s.camera;c.location=(5,15,6);c.rotation_euler=(Vector((-.2,0,.5))-c.location).to_track_quat('-Z','Y').to_euler();c.data.type='ORTHO';c.data.ortho_scale=10;s.render.filepath=str(R/'hero.png');bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-surface-study.blend'));(R/'manifest.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'changes':changes,'native_accepted':False,'final_art_accepted':False,'scope':'Paint/metal differentiation authoring study; requires paired visual review and new bake/shader qualification'},indent=2))
