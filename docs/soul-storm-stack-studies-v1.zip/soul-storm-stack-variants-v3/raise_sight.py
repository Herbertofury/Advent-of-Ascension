"""Six-stack exterior sight riser; does not claim native ADS alignment."""
import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parent;src=R.parent/'soul-storm-stack-variants-v2/6/soul-stack-study.blend';bpy.ops.wm.open_mainfile(filepath=str(src));s=bpy.context.scene;s.frame_set(0);root=bpy.data.objects['SoulStorm_Root'];lift=.22;changed=[]
for o in bpy.data.objects:
 if o.hide_render:continue
 if o.name=='flame_origin' or o.name.startswith(('V16 circular brazier lip','V16 rounded brazier base','V16 tapered brazier prong','V16 flame reticle filament','V16 rooted fire layer')):
  o.location.z+=lift;changed.append(o.name)
assert len(changed)==13,changed
# The original saddle remains seated on the core. This small riser joins its upper surface to the lifted brazier base.
bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.20,depth=.25,location=(-2.4,0,3.585));o=bpy.context.object;o.name='Six-stack physical sight riser';o.parent=root;o.data.materials.append(bpy.data.materials['Anodized indigo']);b=o.modifiers.new('Riser edge radius','BEVEL');b.width=.014;b.segments=3;o.modifiers.new('Riser normals','WEIGHTED_NORMAL')
out=R/'6';out.mkdir(exist_ok=True);bpy.ops.wm.save_as_mainfile(filepath=str(out/'soul-stack-study.blend'));s.cycles.samples=48
for name,frame in [('hero',0),('focused',50)]:s.frame_set(frame);s.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True)
(out/'manifest.json').write_text(json.dumps({'status':'unaccepted static six-emitter authoring variant','sight_lift':lift,'lifted_objects':changed,'reason':'v2 focused-reticle lower bound cleared forward hardware by only0.005 authoring units; provisional extra clearance added with a physically supported riser','native_ads_tested':False,'native_gameplay_tested':False,'limits':['Provisional authoring clearance is not a universal FOV/hand/alignment guarantee','Gem and Candle variants need independent fit checks','No recoil retargeting or projectile/resource change']},indent=2)+'\n')
