import bpy,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parent
for n in [5,6]:
 folder=R.parent/'soul-storm-stack-variants-v2/5'if n==5 else R/'6';bpy.ops.wm.open_mainfile(filepath=str(folder/'soul-stack-study.blend'));bpy.context.scene.frame_set(0);dg=bpy.context.evaluated_depsgraph_get();cache={}
 def mesh(o):
  if o.name in cache:return cache[o.name]
  e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();v=[o.matrix_world@p.co for p in m.vertices];f=[tuple(t.vertices)for t in m.loop_triangles];e.to_mesh_clear();bounds=[(min(p[i]for p in v),max(p[i]for p in v))for i in range(3)];tree=BVHTree.FromPolygons(v,f,all_triangles=True);cache[o.name]=(bounds,tree);return bounds,tree
 wings=[o for o in bpy.data.objects if not o.hide_render and o.name.startswith(('V17 receiver wing','V17 swept lower receiver wing'))]
 emitters=[o for o in bpy.data.objects if not o.hide_render and o.type in {'MESH','CURVE'}and o.parent and o.parent.name.startswith('Emitter_')];pairs=[];broad=0
 for w in wings:
  a,at=mesh(w)
  for e in emitters:
   b,bt=mesh(e)
   if any(a[i][1]<b[i][0]or b[i][1]<a[i][0]for i in range(3)):continue
   broad+=1;overlaps=at.overlap(bt)
   if overlaps:pairs.append({'wing':w.name,'emitter_part':e.name,'triangle_pairs':len(overlaps)})
 report={'variant':n,'wing_objects':len(wings),'emitter_parts':len(emitters),'aabb_candidate_pairs':broad,'triangle_surface_overlap_pairs':pairs,'scope':'Neutral-pose triangle surface intersection between lower wing/borders and emitter parts only. Does not test containment, full assemblies, hands, swept animation or native collision.'};(folder/'wing-clearance.json').write_text(json.dumps(report,indent=2)+'\n');print(n,'candidate pairs',broad,'surface intersections',len(pairs));assert not pairs,pairs[:3]
