from pathlib import Path
import importlib.util,json,hashlib,copy
R=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('asset_contract',R.parent/'emitter-asset-contract/check.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);reports=[]
for n in [5,6]:
 gp=R/str(n)/'soul_storm_compact.geo.json';ap=R.parent/'soul-storm-stack-recoil-v1'/str(n)/'soul_stack_recoil.animation.json';g=json.loads(gp.read_text());a=json.loads(ap.read_text());routes=mod.validate(g,a,n)
 missing=copy.deepcopy(g);missing['minecraft:geometry'][0]['bones']=[b for b in missing['minecraft:geometry'][0]['bones']if b['name']!=f'emitter_{n}_top_to_bottom']
 try:mod.validate(missing,a,n)
 except ValueError:missing_rejected=True
 else:raise AssertionError('Missing last emitter was accepted')
 r={'count':n,'geometry_sha256':hashlib.sha256(gp.read_bytes()).hexdigest(),'animation_sha256':hashlib.sha256(ap.read_bytes()).hexdigest(),'routes':routes,'missing_last_emitter_rejected':missing_rejected,'scope':'Offline name/channel/time contract for these exact assets. No native binding, skin shader, hands, collision or performance acceptance.'};(R/str(n)/'asset-contract.json').write_text(json.dumps(r,indent=2)+'\n');reports.append(r);print(n,'matching routes',len(routes))
