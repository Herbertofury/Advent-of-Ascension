from pathlib import Path
import subprocess,json,sys
R=Path(__file__).resolve().parent;W=R.parent;jdk=W/'toolchains/amazon-corretto-17.0.20.12.1-linux-x64/bin';libs=W/'released-tacz-parser-study/cache/lib'
for n in [5,6]:
 d=R/str(n);source=d/'soul_storm_transport.geo.json';compact=d/'soul_storm_compact.geo.json';m=json.loads((d/'transport-manifest.json').read_text());r=subprocess.run([sys.executable,str(W/'tml-float32-export-v1/compact_float32.py'),str(source),str(compact)],capture_output=True,text=True,check=True);(d/'compact-result.json').write_text(r.stdout)
 for label,java in [('java17',str(jdk/'java')),('java21','/usr/bin/java')]:
  cmd=[sys.executable,str(W/'tml-export-regression-v3/run_check.py'),'--jar',str(W/'references/tacz-mesh-loader-forge-1.20.1-0.1.8.jar'),'--lib',str(libs),'--jdk',str(jdk),'--java',java,'--geometry',str(source),'--compare-geometry',str(compact),'--expected-bones',str(m['mesh_bones']),'--expected-vertices',str(m['expected_tml_baked_vertices'])]
  r=subprocess.run(cmd,capture_output=True,text=True);(d/(label+'.log')).write_text(r.stdout+r.stderr);print(n,label,r.returncode,flush=True);r.check_returncode()
