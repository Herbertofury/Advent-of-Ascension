"""Validate an explicit four-emitter presentation asset contract, offline only."""
from pathlib import Path
import json,math,hashlib,copy
R=Path(__file__).resolve().parent
G=R.parent/'soul-storm-v19-hardware-transport/soul_storm_compact.geo.json'
A=R.parent/'soul-storm-recoil-transport-v1/soul_storm_recoil.animation.json'
def validate(g,a,count=4):
 bones=g['minecraft:geometry'][0]['bones']; names=[b['name'] for b in bones]
 if len(names)!=len(set(names)):raise ValueError('Duplicate geometry bone')
 routes=[]
 for i in range(count):
  stem=f'emitter_{i+1}_top_to_bottom'; pair={stem,stem+'_illuminated'}; name=f'shoot_emitter_{i+1}'
  if not pair.issubset(names):raise ValueError('Missing emitter geometry')
  clip=a['animations'].get(name)
  if not clip or clip.get('loop') is not False:raise ValueError('Missing or looping clip')
  if set(clip['bones'])!=pair:raise ValueError('Clip drives the wrong bone set')
  duration=clip['animation_length']
  if not math.isfinite(duration) or duration<=0:raise ValueError('Invalid duration')
  for bone,tracks in clip['bones'].items():
   if set(tracks)!={'position'}:raise ValueError('Unexpected animation channel')
   keys=sorted((float(t),v)for t,v in tracks['position'].items())
   if len(keys)<2 or keys[0][0]!=0 or abs(keys[-1][0]-duration)>1e-8:raise ValueError('Invalid timeline endpoints')
   if len({t for t,v in keys})!=len(keys):raise ValueError('Duplicate numeric timestamp')
   if keys[0][1]!=[0,0,0] or keys[-1][1]!=[0,0,0]:raise ValueError('Recoil does not return neutral')
   for t,v in keys:
    if not math.isfinite(t) or not 0<=t<=duration+1e-8 or len(v)!=3 or not all(math.isfinite(x)for x in v):raise ValueError('Invalid key')
  routes.append({'emitter_index':i,'clip':name,'bones':sorted(pair)})
 return routes

def main():
 g=json.loads(G.read_text());a=json.loads(A.read_text());routes=validate(g,a);cases=[]
 def rejects(name,mutate):
  gg,aa=copy.deepcopy(g),copy.deepcopy(a);mutate(gg,aa)
  try:validate(gg,aa)
  except ValueError:cases.append({'case':name,'rejected':True})
  else:raise AssertionError(name)
 rejects('missing emitter',lambda g,a:g['minecraft:geometry'][0]['bones'].pop())
 rejects('duplicate geometry bone',lambda g,a:g['minecraft:geometry'][0]['bones'].append(copy.deepcopy(g['minecraft:geometry'][0]['bones'][1])))
 rejects('missing clip',lambda g,a:a['animations'].pop('shoot_emitter_4'))
 rejects('looping recoil',lambda g,a:a['animations']['shoot_emitter_1'].__setitem__('loop',True))
 rejects('cross-emitter animation',lambda g,a:a['animations']['shoot_emitter_1']['bones'].__setitem__('emitter_2_top_to_bottom',{}))
 rejects('nonfinite duration',lambda g,a:a['animations']['shoot_emitter_1'].__setitem__('animation_length',float('nan')))
 rejects('unknown animation track',lambda g,a:a['animations']['shoot_emitter_1']['bones']['emitter_1_top_to_bottom'].__setitem__('scale',[2,2,2]))
 def bad_end(g,a):
  keys=a['animations']['shoot_emitter_1']['bones']['emitter_1_top_to_bottom']['position'];keys[max(keys,key=float)]=[0,0,1]
 rejects('non-neutral final pose',bad_end)
 out={'status':'offline contract passes; native integration untested','geometry_sha256':hashlib.sha256(G.read_bytes()).hexdigest(),'animation_sha256':hashlib.sha256(A.read_bytes()).hexdigest(),'geometry_scope':'v19 transport fixture, not current v22 authoring scene','routes':routes,'negative_cases':cases,'limits':['No collision or hand-clearance proof','No native interpolation or prediction reconciliation','Changed geometry or clip hashes require revalidation','Five/six-emitter upgrades are not supported by these four-emitter assets']}
 (R/'contract-checks.json').write_text(json.dumps(out,indent=2)+'\n');print(len(routes),'routes validated;',len(cases),'negative cases rejected')
if __name__=='__main__':main()
