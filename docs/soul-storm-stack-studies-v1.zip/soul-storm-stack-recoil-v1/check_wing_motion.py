"""Sample lower-wing versus moving-emitter triangle surfaces, never blanket collision acceptance."""
import bpy,json,math
from pathlib import Path
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parent
for count in [5,6]:
 folder=R/str(count);bpy.ops.wm.open_mainfile(filepath=str(folder/'soul-stack-recoil.blend'));s=bpy.context.scene;s.frame_set(0);dg=bpy.context.evaluated_depsgraph_get()
 def tree(o):
  e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();v=[o.matrix_world@x.co for x in m.vertices];polys=[tuple(t.vertices)for t in m.loop_triangles];e.to_mesh_clear();bounds=[(min(p[i]for p in v),max(p[i]for p in v))for i in range(3)];return bounds,BVHTree.FromPolygons(v,polys,all_triangles=True)
 wings=[o for o in bpy.data.objects if not o.hide_render and o.name.startswith(('V17 receiver wing','V17 swept lower receiver wing'))];fixed=[(o.name,*tree(o))for o in wings];errors=[];pairs=0;samples=0
 for i in range(count):
  group=bpy.data.objects[f'Emitter_{i+1}_top_to_bottom'];parts=[o for o in bpy.data.objects if not o.hide_render and o.type in {'MESH','CURVE'}and o.parent==group];start=1+i*6
  for j in range(21):
   frame=start+5*j/20;s.frame_set(math.floor(frame),subframe=frame%1);dg=bpy.context.evaluated_depsgraph_get();samples+=1
   for o in parts:
    b,bt=tree(o)
    for name,a,at in fixed:
     if any(a[k][1]<b[k][0]or b[k][1]<a[k][0]for k in range(3)):continue
     pairs+=1;hits=at.overlap(bt)
     if hits:errors.append({'emitter':i+1,'frame':frame,'part':o.name,'wing':name,'surface_triangle_pairs':len(hits)})
 r={'emitters':count,'samples_per_clip':21,'pose_samples':samples,'aabb_candidate_pairs':pairs,'surface_intersections':errors,'scope':'Sampled lower-wing/border versus active emitter triangle surfaces only; does not establish containment, unsampled continuous motion, hands, other assembly pairs or native collision acceptance.'};(folder/'wing-motion-qa.json').write_text(json.dumps(r,indent=2)+'\n');print(count,samples,'samples',len(errors),'surface intersections',flush=True);assert not errors,errors[:3]
