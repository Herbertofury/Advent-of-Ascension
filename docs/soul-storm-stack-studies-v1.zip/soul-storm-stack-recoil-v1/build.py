"""Independent authoring recoil for five/six stacks; x-only keys preserve variant z offsets."""
import bpy,json,math,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
for count in [5,6]:
 source=R.parent/('soul-storm-stack-variants-v2'if count==5 else'soul-storm-stack-variants-v3')/str(count)/'soul-stack-study.blend';bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene;s.frame_set(0);groups=[bpy.data.objects[f'Emitter_{i+1}_top_to_bottom']for i in range(count)];offsets=[o.location.z for o in groups]
 for i,o in enumerate(groups):
  start=1+i*6
  for frame,x in [(0,0),(start,0),(start+2,-.28),(start+5,0),(count*6+5,0)]:o.location.x=x;o.keyframe_insert('location',index=0,frame=frame)
  for curve in o.animation_data.action.fcurves:
   for k in curve.keyframe_points:k.interpolation='BEZIER';k.handle_left_type='AUTO_CLAMPED';k.handle_right_type='AUTO_CLAMPED'
 s.frame_end=count*6+5;out=R/str(count);out.mkdir(exist_ok=True);s.frame_set(0);bpy.ops.wm.save_as_mainfile(filepath=str(out/'soul-stack-recoil.blend'))
 clips={};maximum_error=0;max_z_drift=0
 for i,o in enumerate(groups):
  start=1+i*6;values=[];keys={}
  for j in range(21):
   frame=start+5*j/20;s.frame_set(math.floor(frame),subframe=frame%1);z=-4*o.location.x;keys[f'{5*j/20/60:.9f}']=[0,0,z];values.append(z)
  for j in range(201):
   frame=start+5*j/200;s.frame_set(math.floor(frame),subframe=frame%1);actual=-4*o.location.x;k=min(19,int(j/10));t=j/10-k;maximum_error=max(maximum_error,abs(actual-(values[k]*(1-t)+values[k+1]*t)));max_z_drift=max(max_z_drift,max(abs(g.location.z-off)for g,off in zip(groups,offsets)))
  stem=o.name.lower();clips[f'shoot_emitter_{i+1}']={'animation_length':5/60,'loop':False,'bones':{stem:{'position':keys},stem+'_illuminated':{'position':keys}}}
 (out/'soul_stack_recoil.animation.json').write_text(json.dumps({'format_version':'1.8.0','animations':clips},indent=2)+'\n');report={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'count':count,'keys_per_bone':21,'duration_seconds':5/60,'max_linear_sample_error_model_units':maximum_error,'max_stack_z_drift':max_z_drift,'native_game_tested':False,'scope':'Authoring curves and transport keys only. Six-frame event spacing is a presentation fixture, not a validated game firing rate. Matching variant geometry/bone names and native resource/cadence integration remain required.'};(out/'recoil-qa.json').write_text(json.dumps(report,indent=2)+'\n');print(report);assert max_z_drift==0 and maximum_error<.012
