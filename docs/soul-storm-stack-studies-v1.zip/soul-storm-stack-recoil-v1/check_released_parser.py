from pathlib import Path
import hashlib,json,subprocess,os
R=Path(__file__).resolve().parent;study=R.parent/'released-tacz-parser-study';m=json.loads((study/'manifest.json').read_text());cache=study/'cache';released=cache/'released-classes'
assert {p.name for p in (cache/'lib').glob('*.jar')}=={e['file'] for e in m['libraries']}
for e in m['libraries']:assert hashlib.sha256((cache/'lib'/e['file']).read_bytes()).hexdigest()==e['sha256']
expected={x['path'] for x in m['class_files']};actual={str(p.relative_to(released))for p in released.rglob('*.class')};assert actual==expected
for e in m['class_files']:assert hashlib.sha256((released/e['path']).read_bytes()).hexdigest()==e['sha256']
java17=R.parent/'toolchains/amazon-corretto-17.0.20.12.1-linux-x64/bin';classes=R/'parser-classes';classes.mkdir(exist_ok=True);cp=str(released)+os.pathsep+str(cache/'lib/*')
subprocess.run([str(java17/'javac'),'--release','17','-cp',cp,'-d',str(classes),*map(str,sorted((study/'harness').rglob('*.java')))],check=True)
results=[]
for java in [str(java17/'java'),'/usr/bin/java']:
 run=subprocess.run([java,'-Xmx256m','-Xverify:all','-cp',str(classes)+os.pathsep+cp,'AnimationParserCheck',str(R/'5/soul_stack_recoil.animation.json'),str(R/'6/soul_stack_recoil.animation.json')],capture_output=True,text=True,check=True);results.append({'runtime_version':subprocess.run([java,'-version'],capture_output=True,text=True,check=True).stderr.splitlines()[0],'stdout':run.stdout,'stderr':run.stderr});print(run.stdout)
(R/'released-parser-check.json').write_text(json.dumps({'release':m['release'],'verified_released_class_count':len(expected),'animation_sha256':{str(n):hashlib.sha256((R/str(n)/'soul_stack_recoil.animation.json').read_bytes()).hexdigest()for n in [5,6]},'runs':results,'scope':'Actual released animation parser classes with documented narrow helper stand-ins. No native interpolation, bone binding, hands, sound, gameplay or performance acceptance.'},indent=2)+'\n')
