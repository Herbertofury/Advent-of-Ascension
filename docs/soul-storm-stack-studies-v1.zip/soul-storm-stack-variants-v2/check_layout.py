import bpy,json,sys
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;reports=[]
for count in [5,6]:
 src=R/str(count)/'soul-stack-study.blend';bpy.ops.wm.open_mainfile(filepath=str(src));s=bpy.context.scene;s.frame_set(50);dg=bpy.context.evaluated_depsgraph_get()
 def points(o):
  e=o.evaluated_get(dg);m=e.to_mesh();p=[o.matrix_world@v.co for v in m.vertices];e.to_mesh_clear();return p
 def box(o):
  p=points(o);return [(min(v[i]for v in p),max(v[i]for v in p))for i in range(3)]
 manifolds=[o for o in bpy.data.objects if o.name.startswith('Spirit distribution manifold')and not o.hide_render];sleeves=[o for o in bpy.data.objects if o.name.startswith('Fixed telescoping sleeve')and not o.hide_render];support=[]
 for o in sleeves:
  a=box(o);overlap=False
  for m in manifolds:
   b=box(m)
   if all(min(a[i][1],b[i][1])-max(a[i][0],b[i][0])>0 for i in range(3)):overlap=True
  support.append({'sleeve':o.name,'manifold_aabb_overlap':overlap})
 reticles=[o for o in bpy.data.objects if o.name.startswith('V16 flame reticle filament')and not o.hide_render];assert reticles
 reticle_low=min(v.z for o in reticles for v in points(o));forward=[]
 for o in bpy.data.objects:
  if o.type not in {'MESH','CURVE'}or o.hide_render:continue
  parent=o.parent
  if (parent and parent.name.startswith('Emitter_'))or o.name.startswith(('Emitter structural saddle','Saddle indigo face')):forward+=points(o)
 front_high=max(v.z for v in forward);r={'emitters':count,'sleeves':len(sleeves),'support_checks':support,'focused_reticle_lowest_z':reticle_low,'forward_hardware_highest_z':front_high,'vertical_bound_clearance':reticle_low-front_high,'focus_value':float(s['focus']),'scope':'Neutral static sleeve/manifold AABB overlap and focused sight vertical bounds; not exact solid contact, hand fit, animation collision or native aim alignment'};(R/str(count)/'layout-qa.json').write_text(json.dumps(r,indent=2)+'\n');reports.append(r);print(count,len(sleeves),'supported',sum(x['manifold_aabb_overlap']for x in support),'sight clearance',reticle_low-front_high);assert len(sleeves)==count*2 and all(x['manifold_aabb_overlap']for x in support);assert reticle_low>front_high
