"""Original static 5/6-emitter authoring variants. No native gameplay implementation."""
import bpy,json,math
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;source=R.parent/'soul-storm-sculpt-v22/soul-storm-v22.blend'
def shift_geometry(o,fn):
 inv=o.matrix_world.inverted()
 if o.type=='MESH':
  o.data=o.data.copy()
  for v in o.data.vertices:v.co=inv@fn(o.matrix_world@v.co)
  o.data.update()
 elif o.type=='CURVE':
  o.data=o.data.copy()
  for sp in o.data.splines:
   for p in sp.points:p.co=(*(inv@fn(o.matrix_world@Vector(p.co[:3]))),1)
def copy_object(o,name,parent,dz):
 c=o.copy();c.data=o.data.copy()if o.data else None;c.animation_data_clear();c.name=name;bpy.context.collection.objects.link(c);c.parent=parent;c.location.z+=dz;return c
for count in [5,6]:
 bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene;s.frame_set(0);bpy.context.view_layer.update();root=bpy.data.objects['SoulStorm_Root'];delta=.36*(count-4);pitch=.72;center=1.605
 # Exclude preview-only projectile objects, never represent them as gameplay spawns.
 def helper(o):
  while o:
   if o.name.startswith('Authoring_disc_'):return True
   o=o.parent
  return False
 for o in [o for o in bpy.data.objects if helper(o)]:bpy.data.objects.remove(o,do_unlink=True)
 old_groups=[bpy.data.objects[f'Emitter_{i+1}_top_to_bottom']for i in range(4)];template_parts=[o for o in bpy.data.objects if o.parent==old_groups[3]and not o.hide_render]
 for group in old_groups:group.animation_data_clear();group.location.z=delta
 for i in range(4,count):
  group=bpy.data.objects.new(f'Emitter_{i+1}_top_to_bottom',None);bpy.context.collection.objects.link(group);group.parent=root;group.location.z=delta-pitch*(i-3)
  for o in template_parts:copy_object(o,f'{o.name}_variant_emitter_{i+1}',group,0)
 # Rebuild fixed sleeves and rune markers at each new emitter center.
 for prefix in ['Fixed telescoping sleeve','Saddle cyan rune']:
  all_old=[o for o in bpy.data.objects if o.name.startswith(prefix)]
  templates={}
  for side in [-1,1]:
   candidates=[o for o in all_old if sum((o.matrix_world@Vector(c)).y for c in o.bound_box)*side>0]
   templates[side]=min(candidates,key=lambda o:sum((o.matrix_world@Vector(c)).z for c in o.bound_box))
  for side,template in templates.items():
   for i in range(count):copy_object(template,f'{prefix} variant {count} side {side} level {i+1}',root,delta+pitch*(3-i))
  for o in all_old:bpy.data.objects.remove(o,do_unlink=True)
 # Extend the side supports without scaling their width or the rune shapes.
 factor=(2.9+pitch*(count-4))/2.9
 def stretch(p):p.z=center+(p.z-center)*factor;return p
 for o in list(bpy.data.objects):
  if o.name.startswith(('Emitter structural saddle','Saddle indigo face','Spirit distribution manifold','Manifold energy seam'))and not o.hide_render:shift_geometry(o,stretch)
 # Shared deformation of the lower wing and its seated borders keeps clearance below the taller stack.
 def wing(p):
  t=max(0,min(1,(p.x+1.5)/1.2));t=t*t*(3-2*t);p.z-=delta*t;return p
 for o in list(bpy.data.objects):
  if o.name.startswith(('V17 receiver wing','V17 swept lower receiver wing'))and not o.hide_render:shift_geometry(o,wing)
 bpy.context.view_layer.update();groups=[o for o in bpy.data.objects if o.type=='EMPTY'and o.name.startswith('Emitter_')and o.name.endswith('_top_to_bottom')];assert len(groups)==count
 out=R/str(count);out.mkdir(exist_ok=True);s.cycles.samples=48;s.render.filepath=str(out/'hero.png');bpy.ops.wm.save_as_mainfile(filepath=str(out/'soul-stack-study.blend'));bpy.ops.render.render(write_still=True)
 report={'status':'unaccepted static authoring variant','emitters':count,'pitch':pitch,'centers_top_to_bottom':[2.685+delta-pitch*i for i in range(count)],'native_tested':False,'animation_retargeted':False,'source':'v22 four-emitter authoring scene','limits':['Static layout only; recoil animation deliberately cleared on emitter groups','No resource/damage/projectile increase implemented','Full collision, hand, animation, native export and visual QA still required','Four-emitter transport assets cannot be reused as matching five/six-emitter geometry']};(out/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print('VARIANT',count,flush=True)
