"""Completeness/evidence bookkeeping only: never judges artistic or native-game quality."""
import argparse,json,hashlib,re
from pathlib import Path
PHASES=('concept','implementation','qa');STATES={'not_started','in_progress','blocked','ready_for_review','passed'}
def validate(m,catalog,root):
 root=Path(root).resolve();errors=[];incomplete=[];required={x['id']for x in catalog['features']};rows=m.get('features',{})
 def err(s):errors.append(s)
 def artifact(a,where):
  if not isinstance(a,dict)or not a.get('path')or not re.fullmatch('[a-f0-9]{64}',a.get('sha256','')):err(where+': artifact needs path and SHA-256');return
  p=(root/a['path']).resolve()
  if not p.is_relative_to(root):err(where+': artifact leaves evidence root');return
  if not p.is_file():err(where+': artifact missing');return
  h=hashlib.sha256()
  with p.open('rb')as f:
   for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
  if h.hexdigest()!=a['sha256']:err(where+': artifact hash mismatch')
 def phase(p,where):
  if not isinstance(p,dict)or p.get('status')not in STATES:err(where+': invalid phase/status');return False
  if p['status']!='passed':incomplete.append(where);return False
  evidence=p.get('evidence',[])
  if not evidence:err(where+': passed without evidence')
  for e in evidence:artifact(e,where)
  return bool(evidence)
 if not isinstance(m.get('fully_accepted'),bool):err('fully_accepted must be a boolean')
 if not re.fullmatch(r'[a-z0-9_.-]+:[a-z0-9_./-]+',m.get('weapon_id','')):err('weapon_id must be an actual registry ID')
 if not isinstance(rows,dict):return ['features must be an object'],[]
 for key in sorted(required-set(rows)):err('Missing feature: '+key)
 for key in sorted(set(rows)-required):err('Unknown feature: '+key)
 for key,row in rows.items():
  if not isinstance(row,dict):err(key+': invalid record');continue
  disposition=row.get('disposition')
  if disposition=='omitted':
   omission=row.get('omission')or{}
   if not omission.get('reason')or not omission.get('owner_approval_reference'):err(key+': omission requires reason and owner approval')
   continue
  if disposition!='required':err(key+': invalid disposition');continue
  for p in PHASES:phase(row.get(p),key+'.'+p)
 for gate in ['mechanism','spatial','animation','feedback','export','runtime']:
  g=m.get('acceptance_gates',{}).get(gate);phase(g,'gate.'+gate)
  if gate=='runtime'and isinstance(g,dict)and g.get('status')=='passed':
   kinds={x.get('kind')for x in g.get('evidence',[])if isinstance(x,dict)}
   if not {'native_test_log','native_game_capture'}<=kinds:err('runtime requires native test log and native game capture evidence')
 visual=m.get('visual_fidelity_review')or{}
 if visual.get('status')=='accepted':
  if not visual.get('reviewer')or not visual.get('notes'):err('visual review needs reviewer and actual comparison notes')
  artifact(visual.get('concept_artifact'),'visual concept');artifact(visual.get('model_artifact'),'visual model')
 else:incomplete.append('visual_fidelity_review')
 concept=m.get('canonical_concept')or{}
 if concept.get('status')=='approved':
  if not concept.get('artifacts')or not concept.get('review'):err('approved canonical concept needs artifacts and review')
  for a in concept.get('artifacts',[]):artifact(a,'canonical concept')
 else:incomplete.append('canonical_concept')
 profiles=m.get('visual_profiles')
 if profiles is not None and not isinstance(profiles,dict):err('visual_profiles must be an object');profiles={}
 profiles=profiles or{}
 for name in ['minecraft_fit','concept_faithful']:
  where='visual_profile.'+name;profile=profiles.get(name)
  if profile is None:incomplete.append(where);continue
  if not isinstance(profile,dict):err(where+': invalid profile');continue
  for p in PHASES:phase(profile.get(p),where+'.'+p)
  qa=profile.get('qa')or{}
  if qa.get('status')=='passed':
   kinds={a.get('kind')for a in qa.get('evidence',[])if isinstance(a,dict)and a.get('visual_profile')==name}
   if not {'native_test_log','native_game_capture'}<=kinds:err(where+': QA requires profile-tagged native log and capture')
  review=profile.get('visual_review')or{}
  if review.get('status')=='accepted':
   if not review.get('reviewer')or not review.get('notes'):err(where+': visual review needs reviewer and comparison notes')
   artifact(review.get('concept_artifact'),where+' concept');artifact(review.get('model_artifact'),where+' model')
  else:incomplete.append(where+'.visual_review')
 if m.get('fully_accepted')and(errors or incomplete):err('fully_accepted contradicts missing, failed or incomplete evidence')
 return errors,incomplete
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('manifest',type=Path);p.add_argument('--catalog',type=Path,default=Path(__file__).with_name('feature-catalog.json'));p.add_argument('--root',type=Path,required=True);p.add_argument('--release',action='store_true');a=p.parse_args();m=json.loads(a.manifest.read_text());e,i=validate(m,json.loads(a.catalog.read_text()),a.root);complete=not e and not i and m.get('fully_accepted')is True;print(json.dumps({'structural_errors':e,'incomplete':i,'release_complete':complete,'scope':'Structure and evidence hashes only; not artistic/runtime judgment'},indent=2));raise SystemExit(1 if e else 2 if a.release and not complete else 0)
