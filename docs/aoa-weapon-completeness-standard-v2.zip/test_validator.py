import json,copy,tempfile,hashlib
from pathlib import Path
from validate_manifest import validate
R=Path(__file__).resolve().parent;c=json.loads((R/'feature-catalog.json').read_text());t=json.loads((R/'weapon-manifest-template.json').read_text());t['weapon_id']='aoa3:soul_storm'
with tempfile.TemporaryDirectory()as root:
 e,i=validate(t,c,root);assert not e and len(i)==109
 x=copy.deepcopy(t);del x['features']['tracers_and_trails'];assert any('Missing feature' in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);x['fully_accepted']=True;assert any('contradicts'in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);x['features']['death_finishers']['disposition']='omitted';assert any('owner approval'in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);x['features']['projectiles']['qa']['status']='passed';assert any('without evidence'in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);x['visual_fidelity_review']['status']='accepted';assert any('reviewer'in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);x['features']['audio']['qa']={'status':'passed','evidence':[{'path':'../escape','sha256':'0'*64}]};assert any('leaves evidence root'in e for e in validate(x,c,root)[0])
 p=Path(root)/'evidence.txt';p.write_text('Synthetic fixture, not a real weapon acceptance.');a={'path':'evidence.txt','sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 x=copy.deepcopy(t);x['features']['audio']['qa']={'status':'passed','evidence':[copy.deepcopy(a)]};assert not validate(x,c,root)[0]
 x['features']['audio']['qa']['evidence'][0]['sha256']='0'*64;assert any('hash mismatch'in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);x['acceptance_gates']['runtime']={'status':'passed','evidence':[copy.deepcopy(a)]};assert any('native test log'in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);del x['visual_profiles'];e,i=validate(x,c,root);assert not e and 'visual_profile.minecraft_fit'in i and 'visual_profile.concept_faithful'in i
 x=copy.deepcopy(t);x['visual_profiles']['minecraft_fit']['qa']={'status':'passed','evidence':[copy.deepcopy(a)]};assert any('profile-tagged'in e for e in validate(x,c,root)[0])
 x=copy.deepcopy(t);x['visual_profiles']['concept_faithful']['qa']={'status':'passed','evidence':[dict(a,kind=k,visual_profile='minecraft_fit')for k in ['native_test_log','native_game_capture']]};assert any('profile-tagged'in e for e in validate(x,c,root)[0])
 x['visual_profiles']['concept_faithful']['qa']['evidence']=[dict(a,kind=k,visual_profile='concept_faithful')for k in ['native_test_log','native_game_capture']];assert not validate(x,c,root)[0]
 x['visual_profiles']['concept_faithful']['visual_review']['status']='accepted';assert any('reviewer'in e for e in validate(x,c,root)[0])
print('PASS15 structural/evidence cases including both visual profiles and cross-profile evidence rejection. Synthetic fixture checks only, no weapon acceptance.')
