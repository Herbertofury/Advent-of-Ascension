"""Reconcile inspected version lanes without treating broad historical scope as firearm-only."""
from pathlib import Path
import json,hashlib,argparse
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--docs',type=Path,default=R.parent.parent/'aoa-recovery-repo/docs');a=p.parse_args();D=a.docs
inputs={'historical':'historical-weapon-census-1.12.2.json','first_target':'released-weapon-behavior-map-1.20.1.json'}
data={k:json.loads((D/f).read_text())for k,f in inputs.items()}
H={x['id']:x for x in data['historical']['records']};F={x['id']:x for x in data['first_target']['records']}
assert len(H)==len(data['historical']['records'])==412
assert len(F)==len(data['first_target']['records'])==228
families={x['family'] for x in F.values()};HG={k:v for k,v in H.items() if v['family'] in families}
rows=[]
for item in sorted(H.keys()|F.keys()):
 lanes=[]
 for version,source,lookup in [('1.12.2','historical',H),('1.20.1','first_target',F)]:
  if item in lookup:lanes.append({'minecraft':version,'family':lookup[item]['family'],'evidence_file':inputs[source],'native_upgrade_accepted':False})
 rows.append({'id':item,'inspected_lanes':lanes,'status':'incomplete','identity_note':'Matching IDs do not prove identical stats, acquisition, model, resource or behavior across versions.'})
out={'scope':'Reconciliation of two existing inspected lanes, not an exhaustive all-version weapon census. Historical input includes melee and other families absent from firearm-only first-target input. Missing first-target row does not prove removal.','input_sha256':{f:hashlib.sha256((D/f).read_bytes()).hexdigest()for f in inputs.values()},'counts':{'historical_all_families':len(H),'historical_matching_first_target_families':len(HG),'first_target_five_families':len(F),'shared_ids':len(H.keys()&F.keys()),'historical_ids_without_first_target_record':len(H.keys()-F.keys()),'first_target_ids_without_historical_record':len(F.keys()-H.keys()),'union_of_inspected_ids':len(rows),'fully_accepted_native_upgrades':0},'first_target_families':sorted(families),'uninspected_completion_scope':['1.7.10 and earlier renamed or removed identities','Other first-target weapon families','Later release additions and changes','Version-exclusive behaviors and alternate identities'],'records':rows}
pairs=[]
for old in sorted(H.keys()-F.keys()):
 old_class=H[old].get('class_path','').rsplit('/',1)[-1].removesuffix('.class')
 for new in sorted(F.keys()-H.keys()):
  new_classes=[v.rsplit('/',1)[-1]for v in F[new].get('constructor_classes',[])]
  if old_class and old_class in new_classes and H[old]['family']==F[new]['family']:
   pairs.append({'historical_id':old,'first_target_id':new,'matching_class_basename':old_class,'classification':'probable renamed identity; class/family evidence, not a tested save migration'})
out['possible_renamed_identities']=pairs
out['count_warning']='415 raw IDs are not 415 proven distinct weapons: three class/family-matched rename candidates are retained separately. Do not use raw union count as a completion or marketing total.'
assert len(pairs)==3
(R/'reconciliation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['counts'],indent=2))
