import json,unittest
from pathlib import Path
from literal_values import collect
class LiteralTests(unittest.TestCase):
 def test_implicit_numbers(self):
  values,missing=collect([{'offset':i,'opcode':i}for i in range(2,16)])
  self.assertEqual([x['value']for x in values],[-1,0,1,2,3,4,5,0,1,0.,1.,2.,0.,1.]);self.assertEqual(missing,[])
 def test_signed_pushes_and_unresolved_pool(self):
  v,m=collect([{'offset':0,'opcode':16,'operands':[255]},{'offset':2,'opcode':17,'operands':[128,0]},{'offset':5,'opcode':19}]);self.assertEqual([x['value']for x in v],[-1,-32768]);self.assertEqual(m,[5])
 def test_conflicting_implicit_metadata(self):
  with self.assertRaises(ValueError):collect([{'offset':0,'opcode':11,'constant':9}])
 def test_real_release_regressions(self):
  rows=json.loads(Path(__file__).with_name('registry.json').read_text())['records'];rows={r['id']:r for r in rows}
  expected={'aoa3:discharge_shotgun':[0.,4,160,55,0.,13.],'aoa3:hiver':[2.875,5960,3,1.]}
  for name,values in expected.items():
   v,m=collect(rows[name]['factories'][0]['instructions']);self.assertEqual([x['value']for x in v],values);self.assertEqual(m,[])
if __name__=='__main__':unittest.main()
