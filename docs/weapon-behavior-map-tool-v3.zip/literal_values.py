"""Recover implicit JVM constants omitted from the older registry JSON's constant field.
Specification: https://docs.oracle.com/javase/specs/jvms/se17/html/jvms-6.html
This lists pushed literals; it is not a stack evaluator or gameplay-stat resolver.
"""
def collect(instructions):
    result=[];unresolved=[]
    for i in instructions:
        op=i['opcode'];value=None;present=False
        if 2<=op<=8:value=op-3;present=True
        elif 9<=op<=10:value=op-9;present=True
        elif 11<=op<=13:value=float(op-11);present=True
        elif 14<=op<=15:value=float(op-14);present=True
        if present:
            if 'constant' in i and i['constant']!=value:raise ValueError('Contradictory implicit constant')
        elif 'constant' in i:value=i['constant'];present=True
        elif op==16 and len(i.get('operands',[]))==1:
            value=int.from_bytes(bytes(i['operands']),'big',signed=True);present=True
        elif op==17 and len(i.get('operands',[]))==2:
            value=int.from_bytes(bytes(i['operands']),'big',signed=True);present=True
        elif 16<=op<=20:unresolved.append(i['offset'])
        if present:result.append({'offset':i['offset'],'opcode':op,'value':value})
    return result,unresolved
