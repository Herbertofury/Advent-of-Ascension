"""Static released weapon implementation map; structural evidence, not gameplay QA."""
from pathlib import Path
from literal_values import collect
import argparse,concurrent.futures,hashlib,json,os,re,shutil,subprocess,zipfile
p=argparse.ArgumentParser(description=__doc__);p.add_argument('jar',type=Path);p.add_argument('output',type=Path);args=p.parse_args();R=Path(__file__).resolve().parent
registry=json.loads((R/'registry.json').read_text());families={'gun','shotgun','sniper','cannon','blaster'};rows=[r for r in registry['records'] if r['family'] in families]
home=os.environ.get('JAVA_HOME');javap=str(Path(home)/'bin'/('javap.exe' if os.name=='nt' else 'javap')) if home else shutil.which('javap')
if not javap:raise SystemExit('A full JDK with javap is required')
expected='bdee7d12aab1903e1e74f377d4f0ae7ac948d791f46ec0368d191d86a3d5a03cfbd2e6d1295f1fe690f303b1fa709da89db980543e4d450fc0fdbbf6d9e694e6'
assert hashlib.sha512(args.jar.read_bytes()).hexdigest()==expected,'Wrong release archive'
with zipfile.ZipFile(args.jar) as z:
 assert hashlib.sha256(z.read(registry['registry_class'])).hexdigest()==registry['registry_sha256'],'Registry differs from audited release'
 names=set(z.namelist());class_bytes={n:z.read(n) for n in names if n.endswith('.class') and '/content/item/weapon/' in n}
cache={};errors=[]
def inspect(name):
 out=subprocess.check_output([javap,'-c','-p','-classpath',str(args.jar),name.replace('/','.')],text=True,timeout=45)
 path=name+'.class';parent=re.search(r'^public .*?class .*? extends ([\w.$]+)',out,re.M)
 methods=[s.strip().rstrip(';') for s in out.splitlines() if re.match(r'^  (public|protected|private) .*\(',s)]
 created=sorted(set(re.findall(r'\bnew\s+#\d+\s+// class (net/tslat/aoa3/content/entity/projectile/[\w/$]+)',out)))
 return name,{'class_sha256':hashlib.sha256(class_bytes[path]).hexdigest(),'superclass':parent.group(1).replace('.','/') if parent else None,'declared_methods':methods,'directly_constructed_projectile_classes':created}
assert all(len(row['constructor_classes'])==1 for row in rows),'Ambiguous registration class'
queue={c for row in rows for c in row['constructor_classes']};assert len(rows)==228
while queue:
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for name,data in pool.map(inspect,sorted(queue)):cache[name]=data
 queue={d['superclass'] for d in cache.values() if d['superclass'] and d['superclass']+'.class' in class_bytes and d['superclass'] not in cache}
result=[]
for row in rows:
 chain=[];c=row['constructor_classes'][0]
 while c in cache:
  assert c not in chain,'Inheritance cycle';chain.append(c);c=cache[c]['superclass']
 constants=[]
 for f in row['factories']:
  decoded,unresolved=collect(f.get('instructions',[]))
  constants.append({'factory':f['name'],'literal_constants':[i['value']for i in decoded],'literal_instructions':decoded,'unresolved_literal_offsets':unresolved})
 result.append({'id':row['id'],'family':row['family'],'constructor_classes':row['constructor_classes'],'factory_literal_constants':constants,'class_chain':chain,'status':'structural source map only; effective behavior requires method/call-chain review'})
report={'release':'AoA3-1.20.1-3.7.1','scope':'228 registered first-target weapon IDs; class/override/projectile-constructor inventory, not full behavior or native acceptance','jar_sha512':hashlib.sha512(args.jar.read_bytes()).hexdigest(),'registry_sha256':registry['registry_sha256'],'records':result,'classes':cache,'fully_accepted_native_upgrades':0}
args.output.write_text(json.dumps(report,indent=2)+'\n');print(f'Mapped {len(result)} IDs through {len(cache)} unique weapon classes')
