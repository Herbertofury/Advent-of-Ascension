"""Fictional game-art transfer blockout. Not native gameplay or real firearm engineering."""
from pathlib import Path
import json,copy
R=Path(__file__).parent;src=R/'minigun-prototype/assets/ascension_armory';dst=R/'minigun-feed-study/assets/ascension_armory'
g=json.loads((src/'geo_models/gun/minigun_geo.json').read_text());bones=g['minecraft:geometry'][0]['bones'];by={b['name']:b for b in bones};a=json.loads((src/'animations/minigun.animation.json').read_text())
# Side-port art must have actual empty volume; move right motor fins away from the intake.
by['motor']['cubes']=[c for c in by['motor']['cubes'] if c['origin'][0]<2.6]
round_uv=copy.deepcopy(by['belt']['cubes'][1]['uv'])
# Replace the first solid belt link and its embedded decorative cartridge with a hollow support.
by['belt']['cubes']=by['belt']['cubes'][2:]
uv=copy.deepcopy(by['belt']['cubes'][0]['uv'])
def bone(name,pivot,parent='root'):
 b={'name':name,'parent':parent,'pivot':pivot};bones.append(b);by[name]=b;return b
def cube(name,origin,size,material=None):
 by[name].setdefault('cubes',[]).append({'origin':origin,'size':size,'uv':copy.deepcopy(material or uv)})
bone('intake_frame',[4.5,1.73,3.45])
for y in [1.15,2.03]:cube('intake_frame',[3.35,y,3.05],[2.3,.12,.8])
for z in [2.93,3.85]:cube('intake_frame',[3.35,1.3,z],[2.3,.85,.12])
bone('feed_round',[4.5,1.73,3.45]);cube('feed_round',[3.7,1.58,3.3],[1.6,.3,.3],round_uv)
bone('feed_tray',[4.5,1.73,3.45]);cube('feed_tray',[3.6,1.46,3.22],[1.8,.12,.46])
# Carriage movement is a readable inspection abstraction. It is not a timed game shot.
position={'0':[0,0,0],'.6':[-4.5,0,0],'1.1':[-4.5,0,0],'1.7':[-4.5,1.27,0],'2.5':[-4.5,1.27,-7.8],'3.1':[-4.5,1.27,-7.8],'3.8':[-4.5,1.27,0],'4.4':[-4.5,0,0],'4.9':[-4.5,0,0],'5.5':[0,0,0]}
rotation={'0':[0,0,0],'.6':[0,0,0],'1.1':[0,90,0],'4.4':[0,90,0],'4.9':[0,0,0],'5.5':[0,0,0]}
a['animations']['feed_inspection']={'animation_length':5.5,'loop':True,'bones':{name:{'position':position,'rotation':rotation} for name in ['feed_round','feed_tray']}}
for name,pivot in [('intake',[4.5,1.73,3.45]),('transfer',[0,1.73,3.45]),('chamber',[0,3,-4.35]),('bore_exit',[0,3,-18.6])]:bone(name,pivot)
# The carrier stops behind the barrel mouth; the cartridge projects forward.
a['animations']['feed_inspection']['bones']['feed_tray']['position']=copy.deepcopy(position)
for time in ['2.5','3.1']:
 a['animations']['feed_inspection']['bones']['feed_tray']['position'][time]=[-4.5,1.27,-7.45]
for rel,d in [('geo_models/gun/minigun_geo.json',g),('animations/minigun.animation.json',a)]:
 p=dst/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
print('Minigun feed blockout:',len(bones),'bones; QA required')
