/* Original cosmetic rotary motion. Never authorizes shots or changes native costs. */
'use strict';
class RotorMotion {
 constructor({maxSpeed=600,acceleration=1800,deceleration=900}={}) {
  for(const v of [maxSpeed,acceleration,deceleration])if(!Number.isFinite(v)||v<=0)throw new RangeError('Positive finite motion settings required');
  this.maxSpeed=maxSpeed;this.acceleration=acceleration;this.deceleration=deceleration;this.phase=0;this.speed=0;this.active=false;
 }
 setActive(active){if(typeof active!=='boolean')throw new TypeError('Boolean active state required');this.active=active;}
 step(dt){
  if(!Number.isFinite(dt)||dt<0)throw new RangeError('Finite nonnegative delta required');
  const target=this.active?this.maxSpeed:0,rate=this.active?this.acceleration:-this.deceleration;
  let distance;
  if(this.speed===target)distance=target*dt;
  else {
   const reach=(target-this.speed)/rate,t=Math.min(dt,reach);
   distance=this.speed*t+.5*rate*t*t+target*(dt-t);
   this.speed=t===reach?target:this.speed+rate*t;
  }
  this.phase=((this.phase+distance)%360+360)%360;
  return {phase:this.phase,speed:this.speed};
 }
 reset(){this.phase=0;this.speed=0;this.active=false;}
}
if(typeof module!=='undefined')module.exports={RotorMotion};
