/* Scoped fictional asset QA: six hollow visual barrels and fixed-shell clearance. */
const fs=require('fs'),path=require('path'),assert=require('assert');
const M=require('./animation_core'),{corners,penetration}=require('./geometry_clearance');
const base=path.join(__dirname,'minigun-prototype');
const geo=JSON.parse(fs.readFileSync(path.join(base,'assets/ascension_armory/geo_models/gun/minigun_geo.json')))['minecraft:geometry'][0];
const anim=JSON.parse(fs.readFileSync(path.join(base,'assets/ascension_armory/animations/minigun.animation.json'))).animations;
const model=M.compile(geo,anim),rotor=geo.bones.find(b=>b.name==='rotor');
// Retain the original blocked-mouth defect as a known-bad fixture.
const p0=M.pose(model,'rotor_spin',0),badCap={origin:[-.36,2.64,-17.8],size:[.72,.72,.08]};
assert(penetration(corners(rotor,badCap,p0.get('rotor')),corners(rotor,{origin:[-.18,2.82,-18.6],size:[.36,.36,13.65]},p0.get('rotor')))>0,'Known-bad mouth cap must be detected');
let failures=[],samples=0;
for(let step=0;step<=72;step++){
 const time=.6*step/72,pose=M.pose(model,'rotor_spin',time);
 const solids=geo.bones.flatMap(b=>(b.cubes||[]).map((c,i)=>({bone:b.name,id:`${b.name}:${i}`,box:corners(b,c,pose.get(b.name))})));
 for(let barrel=0;barrel<6;barrel++){
  const a=barrel*Math.PI/3,cx=2*Math.sin(a),cy=1+2*Math.cos(a);
  // A narrow inspection corridor, from rear barrel opening through muzzle.
  const corridor=corners(rotor,{origin:[cx-.18,cy-.18,-18.6],size:[.36,.36,13.65]},pose.get('rotor'));
  samples++;
  for(const s of solids){const d=penetration(corridor,s.box);if(d>1e-6&&failures.length<30)failures.push({step,barrel,solid:s.id,depth:d});}
 }
}
const report={scope:'Sampled visual bore corridors only. Not full feed, hand, native runtime or continuous collision certification.',samples,failures};
fs.writeFileSync(path.join(base,'bore-clearance-qa.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));assert.equal(failures.length,0,'Blocked visual barrel corridor');
