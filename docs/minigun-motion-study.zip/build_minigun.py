"""Original orange/charcoal rotary-gun study; no copied source art or animation."""
from pathlib import Path
from PIL import Image,ImageDraw
import json,math,hashlib
R=Path(__file__).parent;P=R/'minigun-prototype/assets/ascension_armory';P.mkdir(parents=True,exist_ok=True)
colors={'orange':'#dd5919','edge':'#ffa745','dark':'#18212b','metal':'#667482','bright':'#bdc9cf','brass':'#b58b45','hot':'#f8c86a','black':'#090e15'};uv={};tex=Image.new('RGBA',(128,128));d=ImageDraw.Draw(tex)
for i,(k,c) in enumerate(colors.items()):x=(i%4)*32;y=(i//4)*32;d.rectangle((x,y,x+31,y+31),fill=c);uv[k]=[x+2,y+2]
(P/'textures/gun/uv').mkdir(parents=True,exist_ok=True);tex.save(P/'textures/gun/uv/minigun.png');bones=[];by={}
def bone(n,p='root',v=(0,0,0)):
 b={'name':n,'pivot':list(v)}
 if p:b['parent']=p
 bones.append(b);by[n]=b

def cube(b,o,s,c='dark',rot=None,piv=None):
 v={'origin':list(o),'size':list(s),'uv':{f:{'uv':uv[c],'uv_size':[8,8]} for f in ['north','south','east','west','up','down']}}
 if rot:v['rotation']=list(rot);v['pivot']=list(piv or o)
 by[b].setdefault('cubes',[]).append(v)
bone('root',None)
for n,p in [('receiver',(0,0,0)),('rotor',(0,1,-6)),('motor',(0,1,4)),('feed_cover',(3,2,3)),('belt',(3,-1,4)),('top_handle',(0,4,4)),('rear_grip',(0,1,9)),('vent_left',(-3,1,2)),('vent_right',(3,1,2))]:bone(n,v=p)
for n,p in [('idle_view',(-6,9,18)),('iron_view',(0,6,12)),('thirdperson_hand',(0,2,7)),('lefthand_pos',(-1,9,4)),('righthand_pos',(0,1,10)),('ground',(0,0,0)),('fixed',(0,0,0)),('refit_view',(0,1,1))]:bone(n,v=p)
bone('muzzle_flash','rotor',(0,3,-19));bone('shell',v=(4,-1,4))
# Compact industrial orange receiver, separate drive motor and cage handle.
# Hollow fictional housing; leave internal route visible in cutaway.
cube('receiver',(-3,-2,-4),(6,.4,12),'dark');cube('receiver',(-3,3.6,-4),(6,.4,12),'dark');cube('receiver',(-3,-1.6,-4),(.4,5.2,12),'dark');cube('receiver',(2.6,-1.6,-4),(.4,5.2,6.5),'dark');cube('receiver',(2.6,-1.6,6),(.4,5.2,2),'dark');cube('receiver',(-3.3,-1.7,-3.6),(.4,5.4,10.8),'orange');cube('receiver',(2.9,-1.7,-3.6),(.4,5.4,6.1),'orange');cube('receiver',(2.9,-1.7,6),(.4,5.4,1.2),'orange');cube('receiver',(-2.9,3.8,-3.4),(5.8,.5,10.4),'orange');cube('receiver',(-3.4,-2.2,-3.8),(6.8,.5,11.5),'metal')
for x in [-3.4,3.15]:
 for z in [-3,0,3,6]:cube('receiver',(x,-1.2,z),(.25,.45,.5),'brass');cube('receiver',(x,3,z),(.25,.45,.5),'bright')
for z in [-2.8,6.6]:cube('receiver',(-3.4,3.95,z),(6.8,.35,.35),'edge')
# Six hollow barrels around the rotor. Eight rotated side walls per barrel, three segmented collars.
for barrel in range(6):
 a=barrel*math.tau/6;cx=2*math.sin(a);cy=1+2*math.cos(a)
 for seg in range(8):
  angle=seg*45;r=.52;rad=math.radians(angle);x=cx+r*math.sin(rad);y=cy+r*math.cos(rad)
  cube('rotor',(x-.24,y-.12,-18),(.48,.24,13),'metal',(0,0,-angle),(x,y,-11))
 for z in [-18.3,-12,-6.2]:
  for seg in range(8):
   angle=seg*45;rad=math.radians(angle);x=cx+.66*math.sin(rad);y=cy+.66*math.cos(rad)
   cube('rotor',(x-.31,y-.14,z),(.62,.28,.65),'bright' if z==-18.3 else 'dark',(0,0,-angle),(x,y,z))
 # Keep the bore physically open; a dark mouth cap is still a blocking solid.
# Center spindle and angular shared support rings.
cube('rotor',(-.45,.55,-16),(.9,.9,12),'black')
for z in [-15,-5.2]:
 for seg in range(12):
  a=seg*30;rad=math.radians(a);x=2.95*math.sin(rad);y=1+2.95*math.cos(rad)
  cube('rotor',(x-.48,y-.15,z),(.96,.3,.9),'metal',(0,0,-a),(x,y,z))
for x in [-3.1,2.7]:
 cube('motor',(x,-.7,1),(.4,3.4,4.5),'dark')
 for z in [1.2,2,2.8,3.6,4.4]:cube('motor',(x-.05,-.4,z),(.5,2.8,.25),'bright')
cube('motor',(-2.4,-1.3,7.5),(4.8,4.4,2),'orange');cube('motor',(-2.1,-1,9.3),(4.2,3.8,.7),'metal')
# Top carry handle and rear grip remain distinct for later authored hands.
for z in [0,6]:cube('top_handle',(-.65,4,z),(1.3,6.7,1),'metal')
cube('top_handle',(-.85,10.1,0),(1.7,1,7),'dark')
for z in [1,2,3,4,5]:cube('top_handle',(-.9,10.1,z),(1.8,1.05,.25),'metal')
for x in [-1.8,1.2]:cube('rear_grip',(x,.2,9.8),(.6,.7,3),'metal')
cube('rear_grip',(-1.8,.1,12.3),(3.6,.9,.8),'dark')
# Articulated belt links: an authoring mechanism, not native ammunition conversion.
for i in range(7):
 y=1.5-i*.7;z=3+(i%2)*.15;cube('belt',(3.4,y,z),(2.5,.5,.65),'metal');cube('belt',(3.5,y+.08,z+.1),(2.1,.3,.45),'brass')
cube('feed_cover',(3.25,2,2.5),(1.2,.8,3.5),'orange')
for n,x in [('vent_left',-3.6),('vent_right',3.3)]:
 cube(n,(x,.1,-3),(.3,2.6,3.3),'orange')
 for z in [-2.7,-1.9,-1.1]:cube(n,(x-.03,.5,z),(.36,1.7,.25),'black')
def keys(*xs):return {str(t):v for t,v in xs}
def tr(r=None,p=None):return {k:v for k,v in [('rotation',r),('position',p)] if v is not None}
clips={}
def clip(n,length,b,loop=False):clips[n]={'animation_length':length,'loop':loop,'bones':b}
clip('static_idle',2.5,{'root':tr(keys((0,[0,0,0]),(1.25,[.15,0,.15]),(2.5,[0,0,0])))},True);clip('static_auto',0,{})
clip('draw',.75,{'root':tr(keys((0,[20,5,-15]),(.35,[-2,0,2]),(.75,[0,0,0])),keys((0,[0,-9,4]),(.4,[0,.3,-.1]),(.75,[0,0,0])))})
clip('put_away',.5,{'root':tr(keys((0,[0,0,0]),(.5,[20,5,-15])),keys((0,[0,0,0]),(.5,[0,-9,4])))})
clip('shoot',.15,{'root':tr(keys((0,[0,0,0]),(.025,[-.8,0,.25]),(.08,[.2,0,-.15]),(.15,[0,0,0])),keys((0,[0,0,0]),(.025,[0,0,.5]),(.15,[0,0,0]))),'belt':tr(p=keys((0,[0,0,0]),(.075,[0,.35,0]),(.15,[0,0,0])))})
clip('rotor_spin',.6,{'rotor':tr(keys((0,[0,0,0]),(.6,[0,0,360])))},True)
clip('rotor_start',.5,{'rotor':tr(keys((0,[0,0,0]),(.15,[0,0,15]),(.3,[0,0,70]),(.5,[0,0,180])))})
clip('rotor_stop',.6,{'rotor':tr(keys((0,[0,0,0]),(.2,[0,0,100]),(.4,[0,0,160]),(.6,[0,0,180])))})
clip('inspect',3.4,{'root':tr(keys((0,[0,0,0]),(.6,[4,-18,12]),(1.2,[4,-18,12]),(2,[-4,20,-12]),(2.8,[-4,20,-12]),(3.4,[0,0,0]))),'feed_cover':tr(keys((0,[0,0,0]),(1.5,[0,0,-40]),(2.4,[0,0,-40]),(3,[0,0,0]),(3.4,[0,0,0])))})
clip('vent',1.2,{'vent_left':tr(keys((0,[0,0,0]),(.2,[0,0,28]),(.7,[0,0,28]),(1.2,[0,0,0]))),'vent_right':tr(keys((0,[0,0,0]),(.2,[0,0,-28]),(.7,[0,0,-28]),(1.2,[0,0,0])))})
clip('reload_tactical',3,{'feed_cover':tr(keys((0,[0,0,0]),(.5,[0,0,-50]),(2,[0,0,-50]),(2.5,[0,0,0]),(3,[0,0,0]))),'belt':tr(p=keys((0,[0,0,0]),(.7,[0,0,0]),(1.1,[7,-3,0]),(1.7,[7,-3,0]),(2.1,[0,0,0]),(3,[0,0,0])))})
def write(path,d):
 p=P/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
write('geo_models/gun/minigun_geo.json',{'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.ascension_armory.minigun','texture_width':128,'texture_height':128,'visible_bounds_width':4,'visible_bounds_height':3,'visible_bounds_offset':[0,0,0]},'bones':bones}]});write('animations/minigun.animation.json',{'format_version':'1.8.0','animations':clips});write('display/guns/minigun_display.json',{'model':'ascension_armory:gun/minigun_geo','texture':'ascension_armory:gun/uv/minigun','animation':'ascension_armory:minigun','third_person_animation':'default','show_crosshair':False,'iron_zoom':1.1})
manifest={'weapon':'aoa3:minigun','stage':'original authoring prototype; not game-tested','bones':len(bones),'cubes':sum(len(b.get('cubes',[])) for b in bones),'animation_records':len(clips),'native_target':{'version':'1.20.1','aoa':'3.7.1','damage_input':.625,'shot_interval_ticks':1,'durability':2680},'native_behavior_rules':['Do not add a firing delay merely to finish a cosmetic spin-up','Preserve native inventory ammunition; belt/reload clips do not consume or create items','Rotor start/stop needs phase-continuous runtime blending; these standalone clips do not prove that integration','No forced overheating or manual reload rule is implemented'],'ownership':'Original geometry/palette/keyframes; AoA identity credited to Tslat and contributors','files':[{'path':p.relative_to(R/'minigun-prototype').as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(P.rglob('*')) if p.is_file()]};(R/'minigun-prototype/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(manifest['bones'],manifest['cubes'],manifest['animation_records'])
