"""Reuse the original viewer shell with Minigun-specific data and honest scope."""
from pathlib import Path
import ast,json
R=Path(__file__).parent;P=R/'minigun-prototype/assets/ascension_armory'
g=json.loads((P/'geo_models/gun/minigun_geo.json').read_text())['minecraft:geometry'][0]
a=json.loads((P/'animations/minigun.animation.json').read_text())['animations']
tree=ast.parse((R/'build_workbench.py').read_text());assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='html' for t in n.targets));call=assignment.value
while isinstance(call,ast.Call):call=call.func.value
s=ast.literal_eval(call)
s=s.replace('Baronator','Minigun').replace('AUTHORING LAB 001','ROTARY MOTION STUDY')
s=s.replace('Alternating upper/lower barrel recoil, opening vents and a full-size trigger opening. The magazine sits in its own forward socket.','Six hollow barrels, a phase-continuous cosmetic rotor, and an orange industrial housing. Feed choreography and native hand fit remain unfinished.')
s=s.replace('and grenade mechanic','and one-tick firing interval').replace('Animated-Weapon-Prototype-Minigun','Weapon-Upgrade-Backlog')
s=s.replace('109 cuboids',f"{sum(len(b.get('cubes',[])) for b in g['bones'])} cuboids").replace('27 bones',f'{len(g["bones"])} bones').replace('15 records',f'{len(a)} records')
s=s.replace("const colors=['#b51236','#f54259','#171e2e','#667388','#b7cad4','#d99a45','#57f7e4','#080c14','#482b39'];","const colors=['#dd5919','#ffa745','#18212b','#667482','#bdc9cf','#b58b45','#f8c86a','#090e15'];")
s=s.replace("select.value='alternating_barrage_preview'","select.value='static_auto'")
s=s.replace('<h2>Motion library</h2>','<h2>Cosmetic drive</h2><button id="drive" type="button" aria-pressed="false">Start rotor</button><p class="notice" id="driveStatus">Rotor at rest. This does not authorize a shot.</p><h2>Motion library</h2>')
s=s.replace("select.appendChild(o);","if(['reload_tactical','inspect','vent'].includes(name)){o.disabled=true;o.textContent+=' — choreography pending';}select.appendChild(o);")
s=s.replace("const select=document", "const rotorMotion=new RotorMotion();let driveOn=false;const driveButton=document.getElementById('drive');driveButton.onclick=()=>{driveOn=!driveOn;rotorMotion.setActive(driveOn);driveButton.textContent=driveOn?'Coast rotor to rest':'Start rotor';driveButton.setAttribute('aria-pressed',String(driveOn));last=0;dirty=true;schedule()};const select=document")
s=s.replace("const poses=ArmoryMath.pose(model,select.value,t),polys=[];", "const poses=ArmoryMath.pose(model,select.value,t),polys=[];if(!select.value.startsWith('rotor_')){const base=poses.get('rotor');poses.set('rotor',p=>base(ArmoryMath.rotate(p,[0,0,rotorMotion.phase])));}document.getElementById('driveStatus').textContent='Cosmetic rotor: '+rotorMotion.speed.toFixed(0)+' degrees/s. Native firing has no spin-up gate.';")
s=s.replace('last=now;if(playing',"last=now;if(driveOn||rotorMotion.speed>0){rotorMotion.step(dt);dirty=true;}if(playing")
s=s.replace('if(playing&&current().animation_length>0)schedule();',"if((playing&&current().animation_length>0)||driveOn||rotorMotion.speed>0)schedule();")
s=s.replace('Original exported model loaded. All 11 records available for inspection.','Eight motion records enabled; feed-cover, vent and reload choreography await clearance review.')
s=s.replace('zoom=21','zoom=15').replace('[0,0,-2]','[0,2,-2]')
s=s.replace('ASSETDATA',json.dumps({'geometry':g,'animations':a},separators=(',',':'))).replace('CORECODE',(R/'animation_core.js').read_text()+'\n'+(R/'rotor_motion.js').read_text())
out=R.parent/'aoa-expansion/minigun-motion-lab.html';out.write_text(s);print(out,len(s.encode()))
