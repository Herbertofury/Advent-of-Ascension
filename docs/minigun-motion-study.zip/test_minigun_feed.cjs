const fs=require('fs'),path=require('path'),assert=require('assert'),M=require('./animation_core'),{corners,penetration}=require('./geometry_clearance');
const root=path.join(__dirname,'minigun-feed-study'),base=path.join(root,'assets/ascension_armory');
const g=JSON.parse(fs.readFileSync(path.join(base,'geo_models/gun/minigun_geo.json')))['minecraft:geometry'][0],a=JSON.parse(fs.readFileSync(path.join(base,'animations/minigun.animation.json'))).animations,model=M.compile(g,a);let failures=[],samples=0;
for(let f=0;f<=660;f++){
 const t=f/120,p=M.pose(model,'feed_inspection',t),solids=g.bones.flatMap(b=>(b.cubes||[]).map((c,i)=>({bone:b.name,id:b.name+':'+i,box:corners(b,c,p.get(b.name))})));samples++;
 for(const moving of solids.filter(s=>['feed_round','feed_tray'].includes(s.bone)))for(const fixed of solids){if(moving.bone===fixed.bone)continue;const d=penetration(moving.box,fixed.box);if(d>1e-6&&failures.length<40)failures.push({time:t,moving:moving.id,fixed:fixed.id,depth:d});}
}
const report={scope:'Sampled fictional cartridge and carrier versus all exported cuboids at 120 Hz for a parked-rotor inspection. Not live cyclic feed, hand choreography, native runtime or continuous collision proof.',samples,failures};fs.writeFileSync(path.join(root,'feed-clearance-qa.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));assert.equal(failures.length,0);
