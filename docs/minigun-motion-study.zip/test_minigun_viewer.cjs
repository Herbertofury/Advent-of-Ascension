/* Headless DOM harness for authored controls; real browser review remains separate. */
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/../aoa-expansion/minigun-motion-lab.html','utf8');
const assets=html.match(/<script id="assets" type="application\/json">(.*?)<\/script>/s)[1],script=html.match(/<script>(.*?)<\/script>/s)[1];
const elements={},queue=new Map();let id=0;const context={clearRect(){},beginPath(){},moveTo(){},lineTo(){},closePath(){},fill(){},stroke(){}};
function element(name){return elements[name]??=( {id:name,value:name==='speed'?'1':'',textContent:name==='assets'?assets:'',width:1000,height:600,children:[],appendChild(c){this.children.push(c)},setAttribute(k,v){this[k]=v},getContext(){return context}});}
const box={console,document:{hidden:false,getElementById:element,createElement:()=>({}),addEventListener(){}},matchMedia:()=>({matches:true}),requestAnimationFrame:f=>{queue.set(++id,f);return id},cancelAnimationFrame:i=>queue.delete(i)};
vm.createContext(box);vm.runInContext(script,box);let now=0;
function tick(dt=16){now+=dt;const jobs=[...queue.values()];queue.clear();for(const f of jobs)f(now)}
tick();assert.equal(queue.size,0,'Reduced motion static page should sleep');
element('drive').onclick();for(let i=0;i<40;i++)tick();assert.match(element('driveStatus').textContent,/600 degrees/);
element('play').onclick();tick();assert.equal(queue.size,0,'Paused rotor must stop rendering');
const held=element('driveStatus').textContent;tick(1000);assert.equal(element('driveStatus').textContent,held);
element('play').onclick();tick();assert(queue.size>0,'Resume should schedule motion');
element('drive').onclick();for(let i=0;i<60;i++)tick();assert.match(element('driveStatus').textContent,/0 degrees/);assert.equal(queue.size,0,'Stopped rotor/static pose should sleep');
assert.equal(element('clip').children.filter(x=>!x.disabled).length,8);
console.log('PASS: reduced-motion idle, start, pause, resume, coast to rest, idle scheduling and disabled unfinished clips. Node DOM harness, not native gameplay.');
