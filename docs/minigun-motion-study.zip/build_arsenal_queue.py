"""Evidence-linked target-lane work queue; no template asset counts as completed."""
from pathlib import Path
import json, hashlib, collections
R=Path(__file__).parent
src=R/'target-weapon-registry-1.20.1.json'; registry=json.loads(src.read_text())
families={'gun','shotgun','sniper','cannon','blaster'}
rows=[]
for rec in registry['records']:
    if rec['family'] not in families: continue
    entry={'id':rec['id'],'family':rec['family'],'stage':'not_started','gates':{g:'untested' for g in ['mechanism','spatial','animation','feedback','export','runtime']},'evidence':[]}
    if rec['id']=='aoa3:baronator':
        entry.update(stage='mechanism_and_modular_visual_studies',evidence=['baronator-mechanism-study/layout-contract.json','attachment-study/clearance-qa.json'])
    elif rec['id']=='aoa3:minigun':
        entry.update(stage='rotary_visual_study_under_repair',evidence=['minigun-prototype/manifest.json','minigun-prototype/bore-clearance-qa.json'],known_open=['Connected feed route and receiver clearance','Hand ownership and optional reload choreography','Native renderer and gameplay integration'])
    rows.append(entry)
assert len(rows)==228 and len({r['id'] for r in rows})==228
report={'target':{'minecraft':'1.20.1','aoa':'3.7.1'},'scope':'All 228 gun/shotgun/sniper/cannon/blaster registrations in the pinned first target release. Legacy-only and other weapon families remain additional scope; this is not an all-version completion claim.','registry_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'counts':dict(collections.Counter(r['family'] for r in rows)),'fully_accepted':0,'policy':'Continue authoring and QA across the arsenal. Milestone publication does not end the work. No gate is promoted solely from a sampled subset test.','records':rows}
(R/'arsenal-production-queue.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='records'},indent=2))
