const assert=require('assert'),{RotorMotion}=require('./rotor_motion');
const near=(a,b)=>assert(Math.abs(a-b)<1e-8,`${a} != ${b}`);
const angle=(a,b)=>{const d=Math.abs(a-b)%360;assert(Math.min(d,360-d)<1e-7)};
function run(parts){const r=new RotorMotion();r.setActive(true);for(const dt of parts)r.step(dt);return r;}
for(const seconds of [.01,.1,.333,1,4,100]){
 const a=run([seconds]),b=run(Array(100).fill(seconds/100));near(a.speed,b.speed);angle(a.phase,b.phase);
 a.setActive(false);b.setActive(false);const before=a.phase;near(before,a.phase);
 a.step(seconds);for(let i=0;i<100;i++)b.step(seconds/100);near(a.speed,b.speed);angle(a.phase,b.phase);
}
const r=run([.2]),before=r.phase;r.setActive(false);near(before,r.phase);r.step(.05);r.setActive(true);const resumed=r.phase;r.step(0);near(resumed,r.phase);r.step(2);near(r.speed,600);r.setActive(false);r.step(2);near(r.speed,0);const stop=r.phase;r.step(100);near(stop,r.phase);
for(const dt of [-1,NaN,Infinity])assert.throws(()=>r.step(dt));assert.throws(()=>r.setActive('yes'));assert.throws(()=>new RotorMotion({maxSpeed:0}));r.reset();assert.deepEqual([r.phase,r.speed,r.active],[0,0,false]);
console.log('PASS: exact ramp integration, timestep partition invariance, phase continuity, resume, rest and invalid-input checks. Cosmetic state only; no native runtime certification.');
