# Minigun original authoring studies

Not an installable mod or completed weapon. Native renderer, complete mechanism, hand interaction, audio/VFX, networking, gameplay and performance acceptance remain open.

Generate: python build_minigun.py; python build_minigun_feed_study.py.
Tests: node test_minigun_bores.cjs; node test_rotor_motion.cjs; node test_minigun_feed.cjs.
Viewers: create an aoa-expansion sibling directory, run build_minigun_lab.py and build_minigun_feed_lab.py, then node test_minigun_viewer.cjs.
Python requires Pillow; Node tests need no third-party packages.

The rotary motion study has six open visual barrel corridors and a phase-continuous cosmetic drive. The separate parked-rotor feed study is a slow cartridge/tray transfer blockout. It has no live rotary timing, discharge, ejection or native transaction. Carrier support and complete action ownership still need work. Cutaway hiding changes display only; spatial tests use all exported solids.

Original project code, geometry and palette. AoA identity credited to Tslat and contributors. No original game textures, gunpack reference assets or binaries bundled.
