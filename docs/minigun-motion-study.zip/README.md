# Minigun motion study

Original authoring geometry and cosmetic rotor control. Not an installable mod or finished weapon.

Run build_minigun.py, then node test_minigun_bores.cjs and node test_rotor_motion.cjs. Python asset generation requires Pillow. The standalone lab generator expects an aoa-expansion sibling output directory.

Six visual bore caps were removed; the scoped bore test checks 438 barrel/angle samples and retains a known-bad regression. A hollow receiver and enlarged carry-handle opening are unfinished layout improvements. Feed connection, hand rig, reload ownership, full spatial QA, audio/VFX and native integration remain open.

No original AoA art, third-party gunpack assets or game binaries are bundled. AoA identity credited to Tslat and contributors.
