"""Offline UV ownership at box-filter mip footprints; no native rendering acceptance."""
import bpy,json,hashlib,argparse,sys
import numpy as np
from pathlib import Path
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--source',required=True,type=Path);p.add_argument('--model',required=True);p.add_argument('--out',required=True,type=Path);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);bpy.ops.wm.open_mainfile(filepath=str(a.source));mesh=bpy.data.objects[a.model].data;mesh.calc_loop_triangles();uv=mesh.uv_layers.active.data;ids=mesh.attributes['SourcePartId'].data;size=1024;mask=np.zeros((size,size),dtype=np.int32);overlap=0;empty=0
for tri in mesh.loop_triangles:
 xy=np.array([list(uv[i].uv)for i in tri.loops])*size
 lo=np.maximum(0,np.floor(xy.min(axis=0)-.5).astype(int));hi=np.minimum(size-1,np.ceil(xy.max(axis=0)-.5).astype(int))
 if np.any(hi<lo):empty+=1;continue
 x,y=np.meshgrid(np.arange(lo[0],hi[0]+1)+.5,np.arange(lo[1],hi[1]+1)+.5)
 v0=xy[1]-xy[0];v1=xy[2]-xy[0];det=v0[0]*v1[1]-v0[1]*v1[0]
 if abs(det)<1e-10:empty+=1;continue
 dx=x-xy[0,0];dy=y-xy[0,1];u=(dx*v1[1]-dy*v1[0])/det;v=(v0[0]*dy-v0[1]*dx)/det;inside=(u>=-1e-8)&(v>=-1e-8)&(u+v<=1+1e-8)
 owner=ids[tri.polygon_index].value+1;tile=mask[lo[1]:hi[1]+1,lo[0]:hi[0]+1];overlap+=int(np.sum(inside&(tile!=0)&(tile!=owner)));tile[inside]=owner
rows=[]
for level in range(8):
 step=2**level;blocks=mask.reshape(size//step,step,size//step,step).transpose(0,2,1,3).reshape(-1,step*step);maximum=blocks.max(axis=1);minimum=np.where(blocks==0,2**30,blocks).min(axis=1);occupied=maximum>0;mixed=occupied&(minimum!=maximum);rows.append({'mip_level':level,'base_texel_footprint':step,'occupied_blocks':int(occupied.sum()),'blocks_with_multiple_source_owners':int(mixed.sum())})
report={'source_sha256':hashlib.sha256(a.source.read_bytes()).hexdigest(),'model':a.model,'texture_size':size,'triangles':len(mesh.loop_triangles),'base_texel_owner_overlap_samples':overlap,'degenerate_or_outside_uv_triangles':empty,'mip_footprints':rows,'interpretation':'A mixed footprint can mix source-part colors under simple box downsampling. This is a risk indicator, not measured visible bleeding. Same-owner island/material boundaries, texture dilation, bilinear/trilinear/anisotropic footprints and target shader behavior require separate checks.','native_tested':False};a.out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert overlap==0,'UV owner overlap at sampled texel centers'
