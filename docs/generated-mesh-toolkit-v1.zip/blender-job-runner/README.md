# Checked Blender job runner

This small local wrapper protects repeated authoring jobs from accepting a stale artifact after a Python error. It uses the installed Blender, explicit `--python-exit-code 1`, one rendering thread by default, a captured log, declared source hashes, and expected-output timestamps/size/hashes. It does not install software or modify the active game resources.

Example:

```sh
python run_blender_job.py --script /path/to/authoring_step.py --source /path/to/input.blend --expected-output /path/to/output.blend --expected-output /path/to/report.json --log /path/to/run.log --receipt /path/to/run-receipt.json
```

Outputs must be newly written, nonempty files. Declared sources must remain byte-identical. A nonzero Blender exit, missing/stale/empty output, or source mutation fails the execution receipt. No destructive cleanup or silent rerun is performed. A file-integrity pass is not mesh, UV, visual, rig, export or native acceptance; each of those requires its own evidence.

`python test_runner.py` uses only a temporary directory and the installed Blender. Six controlled cases cover success, Python exception, stale output, missing output, empty output and source mutation. The failing cases must fail even when Blender itself exits zero.

Timestamp checks depend on the filesystem clock and metadata. Copying a file while deliberately preserving an old timestamp will conservatively fail this runner. This is a local authoring guard, not a security sandbox or a guarantee that arbitrary scripts are safe.
