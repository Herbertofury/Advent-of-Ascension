#!/usr/bin/env python3
"""Run an installed Blender script with explicit error exits and artifact checks."""
import argparse,hashlib,json,subprocess,time,sys
from pathlib import Path

def fingerprint(path):
 if not path.is_file():return None
 with path.open('rb')as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 st=path.stat();return {'sha256':digest,'bytes':st.st_size,'mtime_ns':st.st_mtime_ns}

def run(blender,script,sources,outputs,log,receipt,threads=1):
 before_sources={str(p):fingerprint(p)for p in sources};before_outputs={str(p):fingerprint(p)for p in outputs}
 if any(v is None for v in before_sources.values()):raise ValueError('A declared source file is missing')
 command=[blender,'-b','-t',str(threads),'--python-exit-code','1','--python',str(script)]
 log.parent.mkdir(parents=True,exist_ok=True);started=time.time_ns()
 with log.open('w')as f:process=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 after_sources={str(p):fingerprint(p)for p in sources};after_outputs={str(p):fingerprint(p)for p in outputs};issues=[]
 if process.returncode:issues.append('Blender returned a nonzero exit code')
 for path,old in before_sources.items():
  new=after_sources[path]
  if new is None or new['sha256']!=old['sha256']:issues.append('Declared source was changed or removed: '+path)
 for path,new in after_outputs.items():
  if new is None:issues.append('Expected output is missing: '+path);continue
  if new['mtime_ns']<started:issues.append('Expected output is stale: '+path)
  if new['bytes']==0:issues.append('Expected output is empty: '+path)
 result={'command':command,'exit_code':process.returncode,'duration_seconds':(time.time_ns()-started)/1e9,'sources_before':before_sources,'sources_after':after_sources,'outputs_before':before_outputs,'outputs_after':after_outputs,'issues':issues,'execution_and_artifact_checks_passed':not issues,'scope':'Execution and file-integrity checks only. No mesh, UV, visual, animation or native acceptance.'}
 receipt.parent.mkdir(parents=True,exist_ok=True);receipt.write_text(json.dumps(result,indent=2)+'\n');return 0 if not issues else 1

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--blender',default='blender');p.add_argument('--script',type=Path,required=True);p.add_argument('--source',type=Path,action='append',default=[]);p.add_argument('--expected-output',type=Path,action='append',required=True);p.add_argument('--log',type=Path,required=True);p.add_argument('--receipt',type=Path,required=True);p.add_argument('--threads',type=int,default=1);a=p.parse_args()
 if a.threads<1:p.error('threads must be positive')
 return run(a.blender,a.script.resolve(),[x.resolve()for x in a.source],[x.resolve()for x in a.expected_output],a.log.resolve(),a.receipt.resolve(),a.threads)
if __name__=='__main__':sys.exit(main())
