import tempfile,json,time
from pathlib import Path
from run_blender_job import run
R=Path(__file__).resolve().parent;rows=[]
with tempfile.TemporaryDirectory(prefix='blender-job-check-')as td:
 d=Path(td);source=d/'source.txt';source.write_text('preserve source');out=d/'output.txt';script=d/'job.py'
 for name,code,expected in [('valid',f'from pathlib import Path\nPath({str(out)!r}).write_text("fresh output")\n',0),('python_exception','raise RuntimeError("intentional fixture failure")\n',1),('stale_output','pass\n',1),('missing_output',f'from pathlib import Path\nPath({str(out)!r}).unlink(missing_ok=True)\n',1),('empty_output',f'from pathlib import Path\nPath({str(out)!r}).write_bytes(b"")\n',1),('changed_source',f'from pathlib import Path\nPath({str(source)!r}).write_text("unexpected mutation")\nPath({str(out)!r}).write_text("new output")\n',1)]:
  source.write_text('preserve source');script.write_text(code);status=run('blender',script,[source],[out],d/(name+'.log'),d/(name+'.json'));receipt=json.loads((d/(name+'.json')).read_text());assert status==expected,(name,status,receipt);rows.append({'case':name,'expected_status':expected,'actual_status':status,'blender_exit':receipt['exit_code'],'issue_categories':[i.split(':')[0]for i in receipt['issues']]})
(R/'test-receipt.json').write_text(json.dumps({'tests':rows,'all_passed':True,'scope':'Controlled local execution and artifact fixtures, not game acceptance'},indent=2));print(json.dumps(rows,indent=2))
