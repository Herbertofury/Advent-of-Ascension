"""Reproduce controlled counters using an installed Blender and temporary fixtures."""
import argparse,subprocess,tempfile,sys
from pathlib import Path
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--blender',default='blender');p.add_argument('--receipt',type=Path,default=R/'test-receipt.json');args=p.parse_args();receipt=args.receipt.resolve();receipt.parent.mkdir(exist_ok=True,parents=True)
with tempfile.TemporaryDirectory(prefix='mesh-preflight-fixtures-')as td:
 d=Path(td);base=[args.blender,'-b','-t','1','--python-exit-code','1','--python'];subprocess.run(base+[str(R/'make_fixtures.py'),'--','--output-dir',str(d)],check=True)
 for name in ['closed','open-collapsed']:subprocess.run(base+[str(R/'audit_mesh.py'),'--','--input',str(d/(name+'.blend')),'--output',str(d/(name+'.json'))],check=True)
 subprocess.run([sys.executable,str(R/'test_preflight.py'),'--fixture-dir',str(d),'--receipt',str(receipt)],check=True)
