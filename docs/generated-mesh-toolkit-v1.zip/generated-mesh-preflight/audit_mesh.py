"""Read-only Blender mesh preflight. Reports evidence, never visual/native approval.
blender -b -t 1 --python audit_mesh.py -- --input asset.glb --output report.json
Also accepts .blend; hidden source originals are reported but excluded from visible totals.
"""
import argparse,bpy,bmesh,sys,json,hashlib,math
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);src=a.input.resolve()
if src.suffix.lower()=='.blend':bpy.ops.wm.open_mainfile(filepath=str(src))
elif src.suffix.lower()=='.glb':
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(src))
else:raise ValueError('Expected .blend or .glb')
reports=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 mesh=o.data;mesh.calc_loop_triangles();points=[o.matrix_world@v.co for v in mesh.vertices];finite=all(math.isfinite(c) for v in points for c in v)
 row={'name':o.name,'hidden_render':o.hide_render,'vertices':len(mesh.vertices),'triangles':len(mesh.loop_triangles),'finite_positions':finite,'material_slots':[m.name if m else None for m in mesh.materials],'uv_layers':[x.name for x in mesh.uv_layers],'parent':o.parent.name if o.parent else None,'modifiers':[{'type':m.type,'name':m.name,'render':m.show_render} for m in o.modifiers],'note':'Base mesh topology; modifiers are not evaluated.'}
 if points and finite:row['world_bounds']=[[min(v[i] for v in points) for i in range(3)],[max(v[i] for v in points) for i in range(3)]]
 bm=bmesh.new();bm.from_mesh(mesh);groups={};targets={}
 for v in bm.verts:
  key=tuple(v.co)
  if key in groups:targets[v]=groups[key]
  else:groups[key]=v
 if targets:bmesh.ops.weld_verts(bm,targetmap=targets)
 row['exact_position_weld_analysis']={'vertices':len(bm.verts),'faces':len(bm.faces),'boundary_edges':sum(e.is_boundary for e in bm.edges),'branching_edges':sum(len(e.link_faces)>2 for e in bm.edges),'wire_edges':sum(not e.link_faces for e in bm.edges),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'area_le_1e_12_faces':sum(f.calc_area()<=1e-12 for f in bm.faces)}
 todo=set(bm.verts);components=[]
 while todo:
  stack=[todo.pop()];count=0
  while stack:
   v=stack.pop();count+=1
   for e in v.link_edges:
    other=e.other_vert(v)
    if other in todo:todo.remove(other);stack.append(other)
  components.append(count)
 row['connected_components']={'count':len(components),'largest_vertex_counts':sorted(components,reverse=True)[:12]};bm.free()
 if mesh.uv_layers.active:
  uv=mesh.uv_layers.active.data;bad=0;nonfinite=0
  for tri in mesh.loop_triangles:
   q=[uv[i].uv for i in tri.loops]
   if not all(math.isfinite(c) for x in q for c in x):nonfinite+=1;continue
   cross=(q[1].x-q[0].x)*(q[2].y-q[0].y)-(q[1].y-q[0].y)*(q[2].x-q[0].x)
   bad+=abs(cross)<=1e-12
  row['uv_triangles']={'nonfinite':nonfinite,'area_twice_le_1e_12':bad,'threshold_is_not_a_visual_distortion_test':True}
 reports.append(row)
with src.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
report={'input':src.name,'sha256':digest,'blender':bpy.app.version_string,'read_only':True,'source_modified':False,'mesh_objects':reports,'images':[{'name':im.name,'dimensions':list(im.size),'packed':bool(im.packed_file),'color_space':im.colorspace_settings.name} for im in bpy.data.images],'visible_base_triangles':sum(r['triangles'] for r in reports if not r['hidden_render']),'acceptance':{'visual':False,'rig':False,'native':False},'limits':['Exact-position weld is an analytical copy, not an edit.','No self-intersection, UV overlap, distortion or continuous clearance proof.','Semantic components do not establish moving-part correctness.','No modifiers, textures or animations are exported or modified.']}
a.output.parent.mkdir(exist_ok=True,parents=True);a.output.write_text(json.dumps(report,indent=2)+'\n');print('Preflight saved:',a.output)
