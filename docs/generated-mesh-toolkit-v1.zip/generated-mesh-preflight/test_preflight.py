import json,hashlib,argparse,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--fixture-dir',type=Path,default=Path(tempfile.gettempdir())/'aoa-mesh-preflight-tests');p.add_argument('--receipt',type=Path,default=Path(__file__).resolve().parent/'test-receipt.json');args=p.parse_args();r=args.fixture_dir; a=json.loads((r/'closed.json').read_text());b=json.loads((r/'open-collapsed.json').read_text())
ao=a['mesh_objects'][0];bo=b['mesh_objects'][0]
assert ao['exact_position_weld_analysis']['nonmanifold_edges']==0
assert ao['uv_triangles']['area_twice_le_1e_12']==0
assert bo['exact_position_weld_analysis']['boundary_edges']==3
assert bo['uv_triangles']['area_twice_le_1e_12']==3
for d in [a,b]:
 with (r/d['input']).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==d['sha256']
out={'fixture_checks':6,'passed':True,'closed_boundary_edges':0,'open_boundary_edges':3,'collapsed_uv_triangles':3,'source_hashes_unchanged':True,'native_acceptance':False,'note':'Controlled fixtures validate counters only, not full mesh repair or visual quality. UV failure fixture explicitly writes collapsed coordinates; Blender initializes noncollapsed UVs by default.'}
args.receipt.write_text(json.dumps(out,indent=2)+'\n');print(out)
