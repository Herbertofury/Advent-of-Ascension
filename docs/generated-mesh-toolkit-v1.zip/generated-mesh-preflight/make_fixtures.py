import bpy,argparse,sys,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output-dir',type=Path,default=Path(tempfile.gettempdir())/'aoa-mesh-preflight-tests');a=p.parse_args(sys.argv[sys.argv.index('--')+1:]if '--'in sys.argv else []);R=a.output_dir.resolve();R.mkdir(exist_ok=True,parents=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
m=bpy.data.meshes.new('closed tetra');m.from_pydata([(0,0,0),(1,0,0),(0,1,0),(0,0,1)],[],[(0,2,1),(0,1,3),(1,2,3),(2,0,3)]);m.update();o=bpy.data.objects.new('closed tetra',m);bpy.context.collection.objects.link(o);uv=m.uv_layers.new(name='UVMap')
for poly in m.polygons:
 for i,li in enumerate(poly.loop_indices):uv.data[li].uv=[(0,0),(1,0),(0,1)][i]
bpy.ops.wm.save_as_mainfile(filepath=str(R/'closed.blend'))
# Remove one face. Collapsed UVs are independent of geometric boundary defects.
m2=bpy.data.meshes.new('open tetra');m2.from_pydata([(0,0,0),(1,0,0),(0,1,0),(0,0,1)],[],[(0,2,1),(0,1,3),(1,2,3)]);m2.update();o.data=m2;uv2=m2.uv_layers.new(name='collapsed')
for loop in uv2.data:loop.uv=(0,0)
bpy.ops.wm.save_as_mainfile(filepath=str(R/'open-collapsed.blend'))
