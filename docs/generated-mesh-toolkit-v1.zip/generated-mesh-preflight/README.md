# Generated mesh preflight

Checked with Blender 4.3.2 on 2026-10-23. This read-only diagnostic accepts a GLB or Blender source file. It does not modify the source, repair geometry or approve a weapon.

```
blender -b -t 1 --python-exit-code 1 --python audit_mesh.py -- --input asset.glb --output report.json
```

The report records the source hash, finite vertex coordinates, base triangle counts, exact-position analytical welding, boundaries/branching/wire edges, connected components, UV degeneracy, materials, image dimensions, parent ownership and unapplied modifiers. Hidden source meshes are included in the report but excluded from visible triangle totals.

## Controlled checks

Run `python run_fixture_checks.py --blender /path/to/blender --receipt test-receipt.json`. The wrapper creates temporary fixtures, runs the read-only audit on each and invokes the six assertions. It exits on a failed subprocess and does not modify user assets. Six assertions cover closed topology, noncollapsed UVs, three open boundary edges, three collapsed UV triangles and two unchanged source hashes. These fixtures do not validate every mesh condition. The optional `--output-dir` and `--fixture-dir` arguments support manual fixture runs without a hard-coded Unix path.

Blender initializes new UV layers with noncollapsed coordinates. The negative fixture therefore explicitly sets each loop to zero. Do not weaken assertions to fit an incorrectly constructed fixture.

## Interpretation

Exact-position welding can collapse coincident faces in the analytical copy. Pre-weld triangle counts and post-weld face counts are not interchangeable. Boundary counts depend on the documented welding method. Do not compare a tolerance-based historical count as though it were the same test.

A disconnected decorative part may be intentional; a connected model may still be unsuitable for animation. Modifier results, self-intersections, UV overlap/distortion, texture lighting, visual fidelity, correct hand placement and native behavior are not evaluated. Open cut surfaces must be reviewed and rebuilt, not blindly filled. This report must never be treated as a production acceptance certificate.
