Generated-mesh authoring utilities, checked 2026-10-23

Requires Python 3.11+ and an installed Blender. Tested here with Blender 4.3.2. These original project utilities do not bundle game assets or third-party mod code.

1. blender-job-runner guards script execution, declared source hashes and fresh expected outputs.
2. generated-mesh-preflight diagnoses mesh/UV counters without editing input; its portable fixture runner checks six controlled assertions.

Read each README before use. Neither tool certifies visual quality, continuous collision freedom, player hand fit, rendering, performance or native game acceptance.
