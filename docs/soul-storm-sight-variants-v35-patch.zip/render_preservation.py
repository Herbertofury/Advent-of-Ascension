import bpy,argparse,sys
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--reference',type=Path,default=R.parent/'soul-storm-aim-mask-v34/soul-storm-aim-mask.blend');args=p.parse_args(sys.argv[sys.argv.index('--')+1:]if '--'in sys.argv else[])
for name,path in [('reference-transition',args.reference),('default-transition',R/'soul-storm-sight-variants.blend')]:
 bpy.ops.wm.open_mainfile(filepath=str(path));s=bpy.context.scene
 if 'sight_variant'in s:s['sight_variant']=0;s.update_tag()
 s.frame_set(25);s.camera.location=(-7,-9,6);s.camera.rotation_euler=(Vector((-2.4,0,4.4))-s.camera.location).to_track_quat('-Z','Y').to_euler();s.camera.data.type='ORTHO';s.camera.data.ortho_scale=3.2;s.camera.data.shift_x=0;s.camera.data.shift_y=0;s.render.resolution_x=900;s.render.resolution_y=900;s.render.resolution_percentage=100;s.cycles.samples=64;s.cycles.use_denoising=False;s.render.filepath=str(R/(name+'.png'));bpy.ops.render.render(write_still=True)
