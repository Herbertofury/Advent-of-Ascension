import bpy,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-sight-variants.blend'));s=bpy.context.scene;s.camera.location=(-7,-9,6);s.camera.rotation_euler=(Vector((-2.4,0,4.4))-s.camera.location).to_track_quat('-Z','Y').to_euler();s.camera.data.type='ORTHO';s.camera.data.ortho_scale=3.2;s.camera.data.shift_x=0;s.camera.data.shift_y=0;s.render.resolution_x=900;s.render.resolution_y=900;s.render.resolution_percentage=100;s.cycles.samples=64;s.cycles.use_denoising=False;rows=[]
for mode,name in [(0,'flame'),(1,'candle'),(2,'gem')]:
 s['sight_variant']=mode;s.update_tag();s.frame_set(0);bpy.context.view_layer.update();s.render.filepath=str(R/(name+'.png'));bpy.ops.render.render(write_still=True);rows.append({'mode':mode,'name':name,'visible_optional':[o.name for o in s.objects if o.name.startswith('V35 ')and not o.hide_render]})
(R/'render-state.json').write_text(json.dumps(rows,indent=2))
