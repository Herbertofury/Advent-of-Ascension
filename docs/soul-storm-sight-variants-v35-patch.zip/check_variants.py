import bpy,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-sight-variants.blend'));s=bpy.context.scene;maximum=0;checks=0;rows=[]
for mode,names,matname in [(0,['V16 rooted fire layer','V16 rooted fire layer.001'],'V16 living soul fire'),(1,['V35 candle V16 rooted fire layer','V35 candle V16 rooted fire layer.001'],'V35 candle soul fire')]:
 s['sight_variant']=mode;s.update_tag()
 for frame in range(101):
  s.frame_set(frame);bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();m=bpy.data.materials[matname].evaluated_get(dg);sub=next(n for n in m.node_tree.nodes if n.type=='VECT_MATH'and n.operation=='SUBTRACT');u,v=map(float,sub.inputs[1].default_value[:2])
  for name in names:
   o=bpy.data.objects[name];assert not o.hide_render and not o.hide_viewport,(mode,frame,name,o.hide_render,o.hide_viewport);eo=o.evaluated_get(dg);me=eo.to_mesh();vs=[eo.matrix_world@v.co for v in me.vertices];assert len(vs)==4;p=vs[0]*(1-u)*(1-v)+vs[1]*u*(1-v)+vs[2]*u*v+vs[3]*(1-u)*v;error=(p-Vector((-2.4,0,4.26))).length;assert error<1e-5,(mode,frame,name,p,error);maximum=max(maximum,error);checks+=1;eo.to_mesh_clear()
for mode in [0,1,2,99,-1]:
 s['sight_variant']=mode;s.update_tag();s.frame_set(25);bpy.context.view_layer.update();visible=[o.name for o in s.objects if o.name.startswith('V35 ')and not o.hide_render];assert len(visible)==({0:0,1:13,2:7}.get(mode,0)),(mode,visible)
 for o in s.objects:
  if o.name.startswith('V35 '):assert o.hide_render==o.hide_viewport
 original=[bpy.data.objects[n]for n in ['V16 rooted fire layer','V16 rooted fire layer.001']];assert all(o.hide_render==(mode in [1,2])for o in original);rows.append({'mode':mode,'visible_optional':visible,'original_flame_visible':not original[0].hide_render})
s['sight_variant']=2;s.update_tag()
for frame in range(101):
 s.frame_set(frame);dg=bpy.context.evaluated_depsgraph_get();m=bpy.data.materials['V35 gem focus projection'].evaluated_get(dg);mix=next(n for n in m.node_tree.nodes if n.type=='MIX_SHADER');assert abs(mix.inputs[0].default_value-float(s['focus'])**2)<1e-6
(R/'variant-qa.json').write_text(json.dumps({'mask_center_samples':checks,'maximum_world_center_error':maximum,'gem_focus_alpha_samples':101,'visibility_modes':rows,'native_accepted':False,'art_accepted':False},indent=2));print('PASS',checks,'center samples; max error',maximum)
