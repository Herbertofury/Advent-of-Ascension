# Soul Storm v35 optional sight authoring study

Status: editable Blender prototype, visual polish and native integration unaccepted. Soul Flame remains default. Optional Soul Candle and Soul Gem share the existing brazier mount. This is not an installable TaCZ gunpack.

## Rebuild without another full-scene backup

Requires Blender 4.3.2 and the published v33-R6 source scene:
https://github.com/Herbertofury/Advent-of-Ascension/blob/main/docs/soul-storm-metal-texture-study-v33.zip

Extract soul-storm-metal-baked.blend. Its SHA-256 is checked by build.py:
cd578269eecf4d8e760cde3cdca55c9ee0f2e1f74f700745a381c01acf09ba14

Run:
blender --background -t 2 --python-exit-code 1 --python build.py -- --source /absolute/path/soul-storm-metal-baked.blend

The generated soul-storm-sight-variants.blend is saved beside the script, packed with its images. The input is not overwritten. The build includes the existing v34 aiming-mask correction before adding optional parts.

## Select a sight

Open the generated scene. Scene custom property sight_variant selects 0=Soul Flame, 1=Soul Candle, 2=Soul Gem. Both render and viewport visibility are controlled. Unsupported property values fall back to the default flame.

For scripted selection, use select_variant.py inside Blender. It validates the requested mode and explicitly tags the scene dependency graph before evaluation. Merely assigning a custom property from Python can leave stale visibility until a later update; the QA caught and corrected that workflow.

## What is new

20 optional objects: two scaled candle flame cards, 14 closed positive-volume decorative solids, and four flat gem aiming-projection planes. The candle has a wax body, wick, socket, drips and small soul-colored inlays. The gem has faceted transmission material and an inner luminous heart. Its idle view hides the default flame filaments; its focus-only projected cue keeps the central target aperture open. Native material/export support is not assumed.

## Checks

blender --background -t 2 --python-exit-code 1 --python check_variants.py
blender --background -t 2 --python-exit-code 1 --python check_solids.py

Recorded: 404 flame/candle mask-center samples over 101 frames per mode, maximum world-center error 6.7435e-7; 101 gem focus-alpha samples; valid modes and invalid fallback; viewport/render visibility agreement; 14 closed, positive-volume solids. Flat cards/projection planes are intentionally excluded from solid-volume checks.

For preservation checks, build the separately published v34 reference patch using the same v33-R6 scene:
https://github.com/Herbertofury/Advent-of-Ascension/blob/main/docs/soul-storm-aim-mask-v34-patch.zip

Then run:
blender --background -t 2 --python-exit-code 1 --python check_preservation.py -- --reference /absolute/path/soul-storm-aim-mask.blend
blender --background -t 2 --python-exit-code 1 --python render_preservation.py -- --reference /absolute/path/soul-storm-aim-mask.blend

The expected reference geometry/motion hashes are pinned in expected-reference.json. All 438 existing mesh objects preserve raw geometry, UVs, shape keys, ownership and 101 sampled evaluated geometry/render-visibility frames in default mode. The matched frame-25 default/reference renders were pixel-identical. These checks do not prove continuous collision, hand fit or native rendering.

## Render studies

render.py uses the same camera/framing for all three sights, 64 samples and no denoising.
render_aim.py uses a controlled orthographic camera and pink target marker at halfway/full focus; the marker stayed visible for both optional sights.
render_beauty.py creates individual 256-sample closeups without denoising. Its framing differs by sight and is not a scale-comparison test. The installed Blender build has no OpenImageDenoise support, so the attempted denoised pass was rejected and these renders use additional samples instead.

## Open gates

Full artistic/concept-fidelity review, first-person native camera alignment, hand fit, all transitions and FOVs, actual material/alpha/export support, configuration persistence, multiplayer behavior, optional-mod compatibility and measured equivalent-work performance. Nothing here changes ammo, damage, projectile rules or the installed game. The optional solids intentionally meet at mounting/decorative junctions; manifold checks are not a no-intersection certificate.
