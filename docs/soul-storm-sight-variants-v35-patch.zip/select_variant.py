"""Use inside Blender's Python console after opening the generated scene."""
import bpy

def select_variant(mode):
    if isinstance(mode,bool) or mode not in (0,1,2):
        raise ValueError('Use 0 (Soul Flame), 1 (Soul Candle), or 2 (Soul Gem)')
    scene=bpy.context.scene
    if 'sight_variant' not in scene:
        raise ValueError('Open the v35 optional-sight study first')
    scene['sight_variant']=mode
    scene.update_tag()
    scene.frame_set(scene.frame_current)
    bpy.context.view_layer.update()
    return mode
