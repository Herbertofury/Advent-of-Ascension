import bpy,bmesh,json
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-sight-variants.blend'));rows=[]
for o in bpy.data.objects:
 if not o.name.startswith('V35 ')or o.type!='MESH'or 'rooted fire layer'in o.name or'projected gem aim tick'in o.name:continue
 bm=bmesh.new();bm.from_mesh(o.data);bm.transform(o.matrix_world);volume=bm.calc_volume(signed=True);bad=sum(not e.is_manifold for e in bm.edges);assert volume>0 and bad==0,(o.name,volume,bad);rows.append({'name':o.name,'signed_volume':volume,'nonmanifold_edges':bad});bm.free()
assert len(rows)==14; (R/'solid-qa.json').write_text(json.dumps({'solids':rows,'scope':'Closed positive-volume optional solids; not a collision or native export certification','excluded':'Two deliberately flat flame cards and four projected aiming planes','native_accepted':False},indent=2));print('PASS14 closed positive-volume optional solids')
