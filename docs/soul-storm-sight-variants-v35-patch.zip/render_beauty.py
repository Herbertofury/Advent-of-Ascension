"""Individual authoring closeups. Framing differs; not a scale-comparison test."""
import bpy
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-sight-variants.blend'));s=bpy.context.scene;s.render.resolution_x=1000;s.render.resolution_y=1000;s.render.resolution_percentage=100;s.cycles.samples=256;s.cycles.use_denoising=False
for mode,name,scale,z in [(0,'flame-beauty',3.2,4.4),(1,'candle-beauty',2.35,4.15),(2,'gem-beauty',1.65,3.9)]:
 s['sight_variant']=mode;s.update_tag();s.frame_set(0);bpy.context.view_layer.update();s.camera.location=(-7,-9,6);s.camera.rotation_euler=(Vector((-2.4,0,z))-s.camera.location).to_track_quat('-Z','Y').to_euler();s.camera.data.type='ORTHO';s.camera.data.ortho_scale=scale;s.camera.data.shift_x=0;s.camera.data.shift_y=0;s.render.filepath=str(R/(name+'.png'));bpy.ops.render.render(write_still=True)
