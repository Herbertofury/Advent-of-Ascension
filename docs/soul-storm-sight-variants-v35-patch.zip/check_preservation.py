import bpy,json,hashlib,argparse,sys
from pathlib import Path
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--reference',type=Path,default=R.parent/'soul-storm-aim-mask-v34/soul-storm-aim-mask.blend');args=p.parse_args(sys.argv[sys.argv.index('--')+1:]if '--'in sys.argv else[])

def capture(path,names=None):
 bpy.ops.wm.open_mainfile(filepath=str(path));s=bpy.context.scene
 if 'sight_variant'in s:s['sight_variant']=0;s.update_tag()
 s.frame_set(0);bpy.context.view_layer.update();names=names or sorted(o.name for o in s.objects if o.type=='MESH');raw=hashlib.sha256();motion=hashlib.sha256()
 def add(h,x):h.update(json.dumps(x,separators=(',',':')).encode())
 for name in names:
  o=bpy.data.objects[name];m=o.data;add(raw,[name,o.parent.name if o.parent else None,[list(v.co)for v in m.vertices],[list(p.vertices)for p in m.polygons],[[list(x.uv)for x in u.data]for u in m.uv_layers]])
  if m.shape_keys:add(raw,[[k.name,[list(v.co)for v in k.data]]for k in m.shape_keys.key_blocks])
 for frame in range(101):
  s.frame_set(frame);dg=bpy.context.evaluated_depsgraph_get()
  for name in names:
   o=bpy.data.objects[name];e=o.evaluated_get(dg);m=e.to_mesh();add(motion,[name,o.hide_render,[list(row)for row in e.matrix_world],[list(v.co)for v in m.vertices]]);e.to_mesh_clear()
 return names,{'raw':raw.hexdigest(),'evaluated_motion_and_visibility':motion.hexdigest(),'mesh_objects':len(names),'frames':101}
names,old=capture(args.reference);assert old==json.loads((R/'expected-reference.json').read_text()),'Unexpected reference geometry or motion';_,new=capture(R/'soul-storm-sight-variants.blend',names);assert old==new,(old,new);(R/'preservation-qa.json').write_text(json.dumps({'passed':True,'reference':old,'candidate':new,'scope':'Existing meshes, UVs, shape keys, ownership and sampled geometry/render visibility in default mode; new optional meshes excluded','native_accepted':False},indent=2));print('PASS preserved',len(names),'existing meshes across101frames')
