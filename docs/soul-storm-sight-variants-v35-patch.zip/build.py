"""Optional sight authoring study. Keeps the corrected flame as the default."""
import bpy,math,json,hashlib,argparse,sys
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=R.parent/'soul-storm-metal-bake-v33-r6/soul-storm-metal-baked.blend');args=p.parse_args(sys.argv[sys.argv.index('--')+1:]if'--'in sys.argv else[])
assert hashlib.sha256(args.source.read_bytes()).hexdigest()=='cd578269eecf4d8e760cde3cdca55c9ee0f2e1f74f700745a381c01acf09ba14'
bpy.ops.wm.open_mainfile(filepath=str(args.source));s=bpy.context.scene;s.frame_set(0);s['sight_variant']=0;s.id_properties_ui('sight_variant').update(min=0,max=2,description='0 default Soul Flame; 1 optional Soul Candle; 2 optional Soul Gem')
def propdriver(owner,path,expr,prop,index=None):
 fc=owner.driver_add(path)if index is None else owner.driver_add(path,index);fc.driver.expression=expr
 while fc.driver.variables:fc.driver.variables.remove(fc.driver.variables[0])
 v=fc.driver.variables.new();v.name=prop;v.type='SINGLE_PROP';v.targets[0].id_type='SCENE';v.targets[0].id=s;v.targets[0].data_path='["'+prop+'"]'
def visibility(o,mode):
 expr='sight_variant==1 or sight_variant==2'if mode==0 else f'sight_variant!={mode}'
 propdriver(o,'hide_render',expr,'sight_variant');propdriver(o,'hide_viewport',expr,'sight_variant')
def fix_mask(m,anchor,height,width):
 nodes=m.node_tree.nodes;sub=next(n for n in nodes if n.type=='VECT_MATH'and n.operation=='SUBTRACT');metric=next(n for n in nodes if n.type=='VECT_MATH'and n.operation=='MULTIPLY'and any(l.from_node==sub for l in n.inputs[0].links));inside=next(n for n in nodes if n.type=='MAP_RANGE');focused=next(n for n in nodes if n.type=='MATH'and n.operation=='MULTIPLY'and any(l.from_node==inside for l in n.inputs[0].links))
 propdriver(sub.inputs[1],'default_value',f'1-460/512+{4.26-anchor}/({height}*(1+.45*(1-focus)))','focus',1);propdriver(metric.inputs[1],'default_value',f'{width}*(1+.25*(1-focus))','focus',0);propdriver(metric.inputs[1],'default_value',f'{height}*(1+.45*(1-focus))','focus',1);x='min(1,max(0,focus/.35))';propdriver(focused.inputs[1],'default_value',f'({x})**2*(3-2*({x}))','focus')
fire=bpy.data.materials['V16 living soul fire'];fix_mask(fire,3.64,1.85,1.4)
candlefire=fire.copy();candlefire.name='V35 candle soul fire';fix_mask(candlefire,4.0,1.85*.52,1.4*.5)
for n in candlefire.node_tree.nodes:
 if n.type=='EMISSION':n.inputs['Strength'].default_value=3.0
created=[]
for name in ['V16 rooted fire layer','V16 rooted fire layer.001']:
 src=bpy.data.objects[name];clone=src.copy();clone.data=src.data.copy();clone.name='V35 candle '+name;s.collection.objects.link(clone);inv=clone.matrix_world.inverted();old=Vector((-2.4,0,3.64));new=Vector((-2.4,0,4.0))
 for block in clone.data.shape_keys.key_blocks:
  for v in block.data:
   delta=clone.matrix_world@v.co-old;v.co=inv@(new+Vector((delta.x*.5,delta.y*.5,delta.z*.52)))
 clone.data.materials.clear();clone.data.materials.append(candlefire);visibility(src,0);visibility(clone,1);created.append(clone.name)
def material(name,color,metal=0,rough=.4,emission=0):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*color,1);n.inputs['Metallic'].default_value=metal;n.inputs['Roughness'].default_value=rough
 if emission:n.inputs['Emission Color'].default_value=(*color,1);n.inputs['Emission Strength'].default_value=emission
 return m
wax=material('V35 indigo soul wax',(.055,.035,.09),0,.65);silver=material('V35 optional sight silver',(.29,.35,.43),.85,.24);wick=material('V35 candle wick',(.006,.009,.014),0,.8);gem=material('V35 faceted cyan crystal',(.008,.23,.37),.35,.16,.65);core=material('V35 crystal heart',(.015,.65,.95),.1,.22,2.0)
def lathe(name,rings,mat,mode,sides=24):
 vs=[]
 for rad,z in rings:
  for i in range(sides):
   t=2*math.pi*i/sides;vs.append((-2.4+rad*math.cos(t),rad*math.sin(t),z))
 faces=[]
 for j in range(len(rings)-1):
  for i in range(sides):k=j*sides+i;n=j*sides+(i+1)%sides;faces.append((k,n,n+sides,k+sides))
 faces.extend([tuple(reversed(range(sides))),tuple((len(rings)-1)*sides+i for i in range(sides))]);me=bpy.data.meshes.new(name);me.from_pydata(vs,[],faces);me.update();o=bpy.data.objects.new(name,me);s.collection.objects.link(o);me.materials.append(mat)
 if mat==wax:
  for poly in me.polygons[:-2]:poly.use_smooth=True
 visibility(o,mode);created.append(name);return o
lathe('V35 soul candle body',[(.135,3.64),(.152,3.69),(.15,3.96),(.14,4.0),(.075,3.97)],wax,1)
lathe('V35 candle silver foot',[(.16,3.64),(.17,3.66),(.17,3.70),(.15,3.72)],silver,1)
lathe('V35 candle wick',[(.014,3.96),(.012,4.035)],wick,1,8)
# Decorative vertical wax drips, shallow and wholly outside the aiming center.
for i in range(5):
 t=i*2*math.pi/5+.3;bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,location=(-2.4+.143*math.cos(t),.143*math.sin(t),3.92-i%2*.045));o=bpy.context.object;o.name=f'V35 wax drip {i}';o.scale=(.025,.025,.055+i%2*.025);o.data.materials.append(wax)
 for poly in o.data.polygons:poly.use_smooth=True
 visibility(o,1);created.append(o.name)
for i in range(3):
 t=i*2*math.pi/3-.8;bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=1,location=(-2.4+.156*math.cos(t),.156*math.sin(t),3.835));o=bpy.context.object;o.name=f'V35 candle soul tear {i}';o.scale=(.022,.022,.045);o.data.materials.append(core);visibility(o,1);created.append(o.name)
lathe('V35 soul gem',[(.035,3.64),(.155,3.75),(.165,4.00),(.10,4.08),(.008,4.18)],gem,2,6)
lathe('V35 soul gem inner heart',[(.015,3.70),(.06,3.82),(.045,3.98),(.008,4.06)],core,2,6)
lathe('V35 gem silver setting',[(.16,3.64),(.175,3.67),(.15,3.74)],silver,2,12)
# Gem remains a crystal, with a separate focus-only projected aiming cue.
g=gem.node_tree.nodes.get('Principled BSDF');g.inputs['Metallic'].default_value=0;g.inputs['Roughness'].default_value=.1;g.inputs['Transmission Weight'].default_value=.85;g.inputs['IOR'].default_value=1.45;g.inputs['Coat Weight'].default_value=.3;g.inputs['Emission Strength'].default_value=0
for o in bpy.data.objects:
 if o.name.startswith('V16 flame reticle filament'):
  propdriver(o,'hide_render','sight_variant==2','sight_variant');propdriver(o,'hide_viewport','sight_variant==2','sight_variant')
m=bpy.data.materials.new('V35 gem focus projection');m.use_nodes=True;n=m.node_tree.nodes;n.clear();transparent=n.new('ShaderNodeBsdfTransparent');em=n.new('ShaderNodeEmission');em.inputs['Color'].default_value=(.03,.7,1,1);em.inputs['Strength'].default_value=2.0;mix=n.new('ShaderNodeMixShader');out=n.new('ShaderNodeOutputMaterial');m.node_tree.links.new(transparent.outputs[0],mix.inputs[1]);m.node_tree.links.new(em.outputs[0],mix.inputs[2]);m.node_tree.links.new(mix.outputs[0],out.inputs['Surface']);propdriver(mix.inputs[0],'default_value','focus*focus','focus')
for i in range(4):
 a=i*math.pi/2;dy,dz=math.cos(a),math.sin(a);py,pz=-dz,dy;points=[(-2.43,dy*.045,4.26+dz*.045),(-2.43,dy*.11+py*.017,4.26+dz*.11+pz*.017),(-2.43,dy*.14,4.26+dz*.14),(-2.43,dy*.11-py*.017,4.26+dz*.11-pz*.017)];me=bpy.data.meshes.new('V35 projected aim tick');me.from_pydata(points,[],[(0,1,2,3)]);me.update();o=bpy.data.objects.new(f'V35 projected gem aim tick {i}',me);s.collection.objects.link(o);me.materials.append(m);visibility(o,2);created.append(o.name)
s['sight_variant']=0;s.frame_set(0);bpy.context.view_layer.update();bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(R/'soul-storm-sight-variants.blend'))
(R/'manifest.json').write_text(json.dumps({'source_sha256':hashlib.sha256(args.source.read_bytes()).hexdigest(),'default':0,'variants':{'0':'Soul Flame with v34 aperture correction','1':'Soul Candle authoring trial','2':'Soul Gem authoring trial'},'created_objects':created,'native_accepted':False,'art_accepted':False,'remaining':['Artistic and concept fidelity acceptance','Native binding and hand fit','Material export and performance'],'checks':'See separately generated QA reports; building alone does not establish acceptance'},indent=2));print('Built optional sight trial',len(created),'new objects')
