"""Run original fixtures against a bounded set of exact released TaCZ class bytes.
No Minecraft launch, mod installation, whole-mod classpath or mod entrypoint.
"""
import argparse,pathlib,json,hashlib,urllib.request,zipfile,subprocess,os,shutil
p=argparse.ArgumentParser();p.add_argument('--jar',type=pathlib.Path);p.add_argument('--cache',type=pathlib.Path);p.add_argument('--java-extra',type=pathlib.Path);p.add_argument('--out',type=pathlib.Path);a=p.parse_args();R=pathlib.Path(__file__).resolve().parent;m=json.loads((R/'manifest.json').read_text());C=a.cache or R/'cache';C.mkdir(parents=True,exist_ok=True)
def fetch(url,path,expected,algorithm='sha256'):
 if path.exists()and hashlib.new(algorithm,path.read_bytes()).hexdigest()==expected:return
 path.parent.mkdir(parents=True,exist_ok=True)
 with urllib.request.urlopen(url,timeout=60)as r:b=r.read()
 assert hashlib.new(algorithm,b).hexdigest()==expected,'Download hash mismatch: '+url
 path.write_bytes(b)
jar=a.jar or C/m['download']['filename']
if a.jar:assert hashlib.sha512(jar.read_bytes()).hexdigest()==m['download']['hashes']['sha512'],'Wrong release'
else:fetch(m['download']['url'],jar,m['download']['hashes']['sha512'],'sha512')
# Strictly isolate the manifest-listed model/animation classes; do not load the entire mod.
allowed={f['path'] for f in m['class_files']}
existing={str(p.relative_to(C/'released-classes')) for p in (C/'released-classes').rglob('*.class')}
assert existing<=allowed,'Cache contains unlisted class files; choose a fresh --cache directory'
with zipfile.ZipFile(jar)as z:
 for f in m['class_files']:
  b=z.read(f['path']);assert hashlib.sha256(b).hexdigest()==f['sha256'];out=C/'released-classes'/f['path'];out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
urls={'gson-2.10.jar':'https://libraries.minecraft.net/com/google/code/gson/gson/2.10/gson-2.10.jar','guava-31.1-jre.jar':'https://libraries.minecraft.net/com/google/guava/guava/31.1-jre/guava-31.1-jre.jar','jsr305-3.0.2.jar':'https://repo.maven.apache.org/maven2/com/google/code/findbugs/jsr305/3.0.2/jsr305-3.0.2.jar','joml-1.10.5.jar':'https://libraries.minecraft.net/org/joml/joml/1.10.5/joml-1.10.5.jar','fastutil-8.5.9.jar':'https://libraries.minecraft.net/it/unimi/dsi/fastutil/8.5.9/fastutil-8.5.9.jar'}
for f in m['libraries']:fetch(urls[f['file']],C/'lib'/f['file'],f['sha256'])
for directory,key in [('models','model_hashes'),('inputs','animation_hashes')]:
 files=sorted((R/directory).glob('*.json'));assert len(files)==len(m[key])==8
 for f in files:assert hashlib.sha256(f.read_bytes()).hexdigest()==m[key][f.name],f
home=os.getenv('JAVA_HOME');javac=str(pathlib.Path(home)/'bin/javac')if home else shutil.which('javac');java=str(pathlib.Path(home)/'bin/java')if home else shutil.which('java');assert javac and java,'A full JDK17+ is required'
harness=C/'harness-classes';harness.mkdir(exist_ok=True);cp=str(C/'released-classes')+os.pathsep+str(C/'lib/*')
subprocess.run([javac,'--release','17','-cp',cp,'-d',str(harness),*map(str,sorted((R/'harness').rglob('*.java')))],check=True)
results=[]
for runtime in [java]+([str(a.java_extra)]if a.java_extra else[]):
 version=subprocess.run([runtime,'-version'],capture_output=True,text=True,check=True).stderr.strip()
 for check,directory in [('ModelParserCheck','models'),('AnimationParserCheck','inputs'),('MeshBoundaryCheck','models')]:
  run=subprocess.run([runtime,'-Xmx256m','-Xverify:all','-cp',str(harness)+os.pathsep+cp,check,*map(str,sorted((R/directory).glob('*.json')))],capture_output=True,text=True,check=True)
  print(run.stdout,end='');results.append({'java':version,'check':check,'stdout':run.stdout,'stderr':run.stderr})
report={'release':m['release'],'jar_sha512':m['download']['hashes']['sha512'],'released_class_count':len(m['class_files']),'model_files':8,'unique_model_hashes':len(set(m['model_hashes'].values())),'animation_files':8,'unique_animation_hashes':len(set(m['animation_hashes'].values())),'results':results,'stand_ins':['Direction: six-value enum','GsonHelper.m_13888_: numeric conversion only','GunMod and narrow Logger: diagnostic sink only','ResourceLocation: unused POJO type placeholder'],'limits':['No Forge/Minecraft boot or mod entrypoint','No real renderer, interpolation, sound effects, hand rig, gameplay or performance acceptance','Eight historical JSON variants represent four weapon identities; not eight completed weapons','Soul Storm Blender sculpt is not one of these TaCZ JSON inputs']}
(a.out or R/'results.json').write_text(json.dumps(report,indent=2)+'\n')
