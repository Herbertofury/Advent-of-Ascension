# Released TaCZ model and animation parser check

This executes 18 unmodified class files extracted from official TaCZ 1.20.1-1.1.8-hotfix2, with the artifact and every class hash pinned. It does not put the entire mod JAR on the runtime classpath or start the mod entrypoint. Only original fixtures/models and this harness are redistributed.

Run with Python3 and a full JDK17+:

`python run_check.py --jar /path/to/tacz-1.20.1-1.1.8-hotfix2.jar --out results.json`

Omit --jar to fetch the pinned official Modrinth artifact. Dependencies are fetched from Minecraft libraries/Maven Central with hash checks. Optional --java-extra /path/to/java runs the same compiled harness on another installed JVM. JAVA_HOME selects the primary full JDK. --cache selects a local cache; unlisted class files in its released-class directory cause rejection instead of being silently loaded.

Boundaries: Direction is a six-value stand-in. GsonHelper implements only the used numeric conversion signature. GunMod and a narrow Logger interface capture diagnostics only. ResourceLocation is an unused POJO placeholder. No Forge/Minecraft runtime, native renderer/interpolator, sound parsing, actual hands, gameplay or performance test is provided.

Eight model files and eight animation files are historical variants of four weapon identities, with seven unique hashes in each set. The 1,385 stored cuboids /101 clips /1,162 keys are aggregate authored-variant counts, not unique finished weapons. Soul Storm v13 Blender sculpt is not part of these TaCZ cube-JSON inputs.

Fixtures additionally cover inherited/explicit-false mirroring, six-direction getFace UV selection and scalar/unsupported-expression parser behavior. Coordinate convention is not equivalent to a rendered orientation test. The initial local attempt used a wrong inputs-folder name and failed before testing; the final package uses eight explicit hashed input files and fails closed if files are missing.

Credit: TaCZ developers for released parser implementation, Minecraft and library authors for external dependencies, original AoA identities Tslat and contributors. No upstream class files, game binary or third-party library is bundled here.

Version 2 adds MeshBoundaryCheck: actual released POJO bytecode silently ignores a poly_mesh field, including when a valid cube is present in the same bone. This proves a parsing boundary, not all possible custom rendering extensions. Successful parsing alone is insufficient native geometry acceptance.
