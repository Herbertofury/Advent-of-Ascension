package org.apache.logging.log4j;
/** Harness-only narrow interface for the one bytecode diagnostic signature exercised. */
public interface Logger {void debug(String template,Object value);}
