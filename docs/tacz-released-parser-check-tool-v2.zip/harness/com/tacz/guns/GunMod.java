package com.tacz.guns;
/** Harness-only diagnostic sink, not the mod entrypoint. */
public final class GunMod { public static int messages; public static final org.apache.logging.log4j.Logger LOGGER=(template,value)->messages++; }
