import com.google.gson.*;
import com.tacz.guns.client.resource.pojo.model.*;
import net.minecraft.core.Direction;
import java.nio.file.*;
import java.util.*;
public class ModelParserCheck {
  static final Gson GSON = new GsonBuilder().registerTypeAdapter(CubesItem.class,new CubesItem.Deserializer()).create();
  static void require(boolean b,String msg){if(!b)throw new AssertionError(msg);}
  public static void main(String[] args)throws Exception{
    int models=0,total=0;
    for(String filename:args){
      BedrockModelPOJO m=GSON.fromJson(Files.readString(Path.of(filename)),BedrockModelPOJO.class);
      require("1.12.0".equals(m.getFormatVersion()),"format");GeometryModelNew g=m.getGeometryModelNew().deco();Set<String> names=new HashSet<>();int cubes=0;
      require(g.getDescription().getTextureWidth()>0&&g.getDescription().getTextureHeight()>0,"UV dimensions");
      for(BonesItem b:g.getBones()){require(names.add(b.getName()),"duplicate bone");if(b.getParent()!=null)require(names.contains(b.getParent()),"parent ordering");
        if(b.getCubes()!=null)for(CubesItem c:b.getCubes()){cubes++;require(c.getSize().size()==3&&c.getOrigin().size()==3,"triples");require(c.getSize().stream().allMatch(v->Float.isFinite(v)&&v>0),"positive finite sizes");require(c.getOrigin().stream().allMatch(Float::isFinite),"finite origin");require(c.getFaceUv()!=null,"custom per-face UV adapter");for(Direction d:Direction.values()){FaceItem face=c.getFaceUv().getFace(d);require(face.getUv().length==2&&face.getUvSize().length==2,"face pair");for(int axis=0;axis<2;axis++){float u=face.getUv()[axis],end=u+face.getUvSize()[axis];require(Float.isFinite(u)&&Float.isFinite(end),"finite UV");float bound=axis==0?g.getDescription().getTextureWidth():g.getDescription().getTextureHeight();require(Math.min(u,end)>=0&&Math.max(u,end)<=bound,"authored UV bounds");}}}
      }
      models++;total+=cubes;System.out.println("PARSED "+Path.of(filename).getFileName()+" bones="+names.size()+" cubes="+cubes);
    }
    String fixture="{\"format_version\":\"1.12.0\",\"minecraft:geometry\":[{\"bones\":[{\"name\":\"root\",\"mirror\":true,\"cubes\":[{\"size\":[1,1,1],\"origin\":[0,0,0],\"uv\":[0,0]},{\"size\":[1,1,1],\"origin\":[0,0,0],\"uv\":[0,0],\"mirror\":false}]}]}]}";
    var cubes=GSON.fromJson(fixture,BedrockModelPOJO.class).getGeometryModelNew().deco().getBones().get(0).getCubes();require(cubes.get(0).isMirror(),"inherited mirror");require(!cubes.get(1).isMirror()&&cubes.get(1).isHasMirror(),"explicit mirror false wins");
    // Distinct UV identifiers exercise the released getFace convention, not world-space rendering.
    String faceFixture="{\"uv\":{\"down\":{\"uv\":[1,0],\"uv_size\":[1,1]},\"east\":{\"uv\":[2,0],\"uv_size\":[1,1]},\"north\":{\"uv\":[3,0],\"uv_size\":[1,1]},\"south\":{\"uv\":[4,0],\"uv_size\":[1,1]},\"up\":{\"uv\":[5,0],\"uv_size\":[1,1]},\"west\":{\"uv\":[6,0],\"uv_size\":[1,1]}}}";
    FaceUVsItem faceMap=GSON.fromJson(faceFixture,CubesItem.class).getFaceUv();
    require(faceMap.getFace(Direction.EAST).getUv()[0]==6,"EAST selects west UV");
    require(faceMap.getFace(Direction.WEST).getUv()[0]==2,"WEST selects east UV");
    require(faceMap.getFace(Direction.UP).getUv()[0]==1,"UP selects down UV");
    require(faceMap.getFace(Direction.DOWN).getUv()[0]==5,"DOWN selects up UV");
    require(faceMap.getFace(Direction.NORTH).getUv()[0]==3,"NORTH selects north UV");
    require(faceMap.getFace(Direction.SOUTH).getUv()[0]==4,"SOUTH selects south UV");
    System.out.println("PASS six-direction getFace mapping fixture; not world-space orientation proof.");
    System.out.println("PASS isolated released TaCZ POJO bytecode: "+models+" models, "+total+" cuboids, mirror fixture. Direction is a harness stand-in; no native renderer/game acceptance.");
  }
}
