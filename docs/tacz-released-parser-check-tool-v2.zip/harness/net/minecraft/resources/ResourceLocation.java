package net.minecraft.resources;
/** Unused sound type placeholder. This harness rejects sound-effect records. */
public final class ResourceLocation {}
