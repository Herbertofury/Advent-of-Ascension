import com.google.gson.*;
import com.tacz.guns.GunMod;
import com.tacz.guns.client.resource.pojo.animation.bedrock.*;
import com.tacz.guns.client.resource.serialize.AnimationKeyframesSerializer;
import java.nio.file.*;
import org.joml.Vector3f;
public class AnimationParserCheck {
 static final Gson GSON=new GsonBuilder().registerTypeAdapter(AnimationKeyframes.class,new AnimationKeyframesSerializer()).create();
 static void require(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void vector(Vector3f v){if(v!=null)require(Float.isFinite(v.x)&&Float.isFinite(v.y)&&Float.isFinite(v.z),"nonfinite vector");}
 public static void main(String[] args)throws Exception{
  int clips=0,keys=0;
  for(String file:args){String text=Files.readString(Path.of(file));JsonObject raw=JsonParser.parseString(text).getAsJsonObject().getAsJsonObject("animations");
   for(var e:raw.entrySet())require(!e.getValue().getAsJsonObject().has("sound_effects"),"Sound parsing is outside harness scope");
   BedrockAnimationFile parsed=GSON.fromJson(text,BedrockAnimationFile.class);require(parsed.getAnimations().size()==raw.size(),"clip count");
   for(var entry:parsed.getAnimations().entrySet()){clips++;BedrockAnimation clip=entry.getValue();require(Double.isFinite(clip.getAnimationLength())&&clip.getAnimationLength()>=0,"length");if(clip.getBones()==null)continue;
    for(var b:clip.getBones().values())for(AnimationKeyframes ch:new AnimationKeyframes[]{b.getPosition(),b.getRotation(),b.getScale()})if(ch!=null)for(var k:ch.getKeyframes().double2ObjectEntrySet()){
      keys++;require(Double.isFinite(k.getDoubleKey())&&k.getDoubleKey()>=0&&k.getDoubleKey()<=clip.getAnimationLength()+1e-6,"time bounds");var value=k.getValue();require(value.data()!=null||value.pre()!=null||value.post()!=null,"empty keyframe");vector(value.data());vector(value.pre());vector(value.post());
    }
   }System.out.println("PARSED "+Path.of(file).getFileName()+" clips="+raw.size());
  }
  require(GunMod.messages==0,"Unsupported expression in authored assets");
  var scalar=GSON.fromJson("2",AnimationKeyframes.class).getKeyframes().get(0.0).data();require(scalar.x==2&&scalar.y==2&&scalar.z==2,"scalar fixture");
  var string=GSON.fromJson("\"query.life_time\"",AnimationKeyframes.class);require(string.getKeyframes().isEmpty(),"expression is not evaluated");
  var arr=GSON.fromJson("[\"query.life_time\",1,2]",AnimationKeyframes.class).getKeyframes().get(0.0).data();require(arr.x==0&&arr.y==1&&arr.z==2,"string component fallback");require(GunMod.messages==2,"expected diagnostic count");
  System.out.println("PASS isolated released TaCZ animation bytecode: "+args.length+" files, "+clips+" clips, "+keys+" keyframes. Explicit helpers are stand-ins; no native interpolation/sound/game acceptance.");
 }
}
