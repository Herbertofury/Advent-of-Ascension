import com.google.gson.*;
import com.tacz.guns.client.resource.pojo.model.*;
public class MeshBoundaryCheck {
  static void require(boolean ok,String why){if(!ok)throw new AssertionError(why);}
  public static void main(String[] args){
    Gson gson=new GsonBuilder().registerTypeAdapter(CubesItem.class,new CubesItem.Deserializer()).create();
    String mesh="{\"format_version\":\"1.12.0\",\"minecraft:geometry\":[{\"bones\":[{\"name\":\"root\",\"poly_mesh\":{\"normalized_uvs\":true,\"positions\":[[0,0,0],[1,0,0],[0,1,0]],\"normals\":[[0,0,1]],\"uvs\":[[0,0],[1,0],[0,1]],\"polys\":[[[0,0,0],[1,0,1],[2,0,2]]]}}]}]}";
    BonesItem bone=gson.fromJson(mesh,BedrockModelPOJO.class).getGeometryModelNew().getBones().get(0);
    require("root".equals(bone.getName()),"bone retained");
    require(bone.getCubes()==null,"poly_mesh must not be mistaken for native cuboids");
    String roundTrip=gson.toJson(bone);require(!roundTrip.contains("poly_mesh"),"unknown mesh payload is discarded");
    String cube=mesh.replace("\"poly_mesh\":", "\"cubes\":[{\"origin\":[0,0,0],\"size\":[1,1,1],\"uv\":[0,0]}],\"poly_mesh\":");
    var result=gson.fromJson(cube,BedrockModelPOJO.class).getGeometryModelNew().getBones().get(0);
    require(result.getCubes().size()==1,"actual cube must survive mixed input");
    require(!gson.toJson(result).contains("poly_mesh"),"mixed input still discards mesh");
    System.out.println("PASS released POJO ignores poly_mesh: mesh-only bone has no cubes; mixed bone keeps exactly one cube. Successful parse is not mesh-rendering support. No native renderer executed.");
  }
}
