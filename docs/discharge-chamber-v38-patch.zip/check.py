import bpy,bmesh,json,hashlib,argparse,sys
from pathlib import Path
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--scene',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args(sys.argv[sys.argv.index('--')+1:]);src=args.source;bpy.ops.wm.open_mainfile(filepath=str(src))
def digest(o):
 if o.type=='MESH':shape={'v':[list(v.co)for v in o.data.vertices],'p':[list(p.vertices)for p in o.data.polygons]}
 elif o.type=='CURVE':shape=[{'p':[list(p.co)for p in s.points],'b':[[list(p.co),list(p.handle_left),list(p.handle_right)]for p in s.bezier_points]}for s in o.data.splines]
 else:return None
 return hashlib.sha256(json.dumps({'shape':shape,'matrix':[list(v)for v in o.matrix_world]},sort_keys=True).encode()).hexdigest()
old={o.name:digest(o)for o in bpy.data.objects if o.type in {'MESH','CURVE'}};bpy.ops.wm.open_mainfile(filepath=str(args.scene));assert all(n in bpy.data.objects and digest(bpy.data.objects[n])==h for n,h in old.items());rows=[]
for o in bpy.data.objects:
 if not o.name.startswith('V38 layered chamber collar'):continue
 bm=bmesh.new();bm.from_mesh(o.data);bm.transform(o.matrix_world);assert all(e.is_manifold for e in bm.edges);volume=bm.calc_volume(signed=True);assert volume>0;bm.free();o.data.calc_loop_triangles();bad=0
 for t in o.data.loop_triangles:
  a,b,c=[o.matrix_world@o.data.vertices[x].co for x in t.vertices];bad+=((b-a).cross(c-a).length_squared<1e-20)
 assert bad==0;rows.append({'name':o.name,'triangles':len(o.data.loop_triangles),'volume':volume,'degenerate_triangles':bad,'smooth_faces':sum(p.use_smooth for p in o.data.polygons),'sharp_edges':sum(e.use_edge_sharp for e in o.data.edges)})
assert len(rows)==4;report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'original_geometry_objects_preserved':len(old),'new_collars':rows,'native_accepted':False,'scope':'Static original geometry/transform preservation and four closed cosmetic shells. No full collision, native shading, animation or hand acceptance.'};(args.output).write_text(json.dumps(report,indent=2)+'\n');print(report)
