# Discharge v38 cosmetic chamber-collar patch

This original game-prop patch adds four layered cosmetic collar shells and hides the old simple collars without deleting them. The first flat-shaded render was refined to smooth radial shading with sharp profile transitions.

Input: the `output/discharge-grip-study.blend` in the published v36 study package. Required SHA-256: 52b82c012a8c850c8e7cd7433594fedefc59de4b5b9344fb7fab001c44af1f70. The patch intentionally stops on a different input; do not disable this check without requalification.

Using Blender 4.3.2:

`blender -b -t 2 --python-exit-code 1 --python build.py -- --source /path/to/discharge-grip-study.blend --output /path/to/output`

`blender -b -t 2 --python-exit-code 1 --python check.py -- --source /path/to/discharge-grip-study.blend --scene /path/to/output/discharge-chamber-study.blend --output /path/to/output/qa.json`

The static checks preserve 313 earlier geometry objects and verify four positive-volume shells with zero degenerate triangles. They do not prove full collisions, native hand/animation fit, final art, gameplay or performance. The v37 texture bake belongs to a different scene; no inherited atlas/export acceptance is claimed.

This small patch avoids duplicating the whole source archive. It is not a playable TaCZ pack.
