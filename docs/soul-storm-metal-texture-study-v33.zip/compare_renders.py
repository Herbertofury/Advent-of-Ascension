from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json
from scipy.ndimage import label,find_objects
R=Path(__file__).resolve().parent;a=np.array(Image.open(R/'hero-procedural.png').convert('RGB')).astype(float);b=np.array(Image.open(R/'hero-baked.png').convert('RGB')).astype(float);d=np.abs(a-b);mask=a.max(2)>25;lab,n=label(d.max(2)>32);sizes=np.bincount(lab.ravel());regions=find_objects(lab);ids=sorted(range(1,len(sizes)),key=lambda i:sizes[i],reverse=True)[:8];canvas=Image.new('RGB',(1000,800),'#17202a');draw=ImageDraw.Draw(canvas)
for j,i in enumerate(ids):
 sy,sx=regions[i-1];box=(max(0,sx.start-12),max(0,sy.start-12),min(a.shape[1],sx.stop+12),min(a.shape[0],sy.stop+12))
 for k,im in enumerate([a,b]):canvas.paste(Image.fromarray(im.astype('uint8')).crop(box).resize((210,150)),((j%2)*500+k*230,(j//2)*200+35))
 draw.text(((j%2)*500+8,(j//2)*200+8),f'Region {j+1}: {sizes[i]} px | source / baked',fill='white')
canvas.save(R/'outlier-review.png');res={'scope':'Matched 40-sample authoring renders; RGB diagnostics, not native/perceptual acceptance','foreground_pixels':int(mask.sum()),'foreground_mean_absolute_rgb8':float(d[mask].mean()),'foreground_p95_absolute_rgb8':float(np.percentile(d[mask],95)),'max_rgb8':float(d.max()),'pixels_over_32':int((d.max(2)>32).sum()),'largest_connected_outlier_region':int(max(sizes[1:],default=0)),'native_accepted':False};(R/'roundtrip-image-qa.json').write_text(json.dumps(res,indent=2));print(res)
