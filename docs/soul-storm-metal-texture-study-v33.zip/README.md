# Soul Storm: 2K metal texture-transfer study

Editable Blender 4.3.2 authoring checkpoint, not a playable mod or final art approval. The v31 source geometry and moving ownership are retained. The current source file is soul-storm-metal-baked.blend, with its image assets packed. The two loose metal maps are supplied for inspection/adapter work.

## What was tested

- 136 metal parts and 27,472 triangles; exact evaluated triangle/vertex equivalence before baking. UV repair preserved corner normals within 0.038339 degrees.
- Texel-center UV overlap checks found zero overlapping interiors at both 2048 and 4096 resolution. This is sampled coverage, not a proof of every continuous edge or mip gutter.
- Ten sampled animation times, 140,600 evaluated vertices: maximum position error 0; source parents retained.
- Direct 2K bakes showed discontinuities on narrow bright borders. Increasing padding alone did not fix them. A 4K authoring master followed by Blender image scaling to 2K reduced the largest connected >32-RGB difference region from 64 pixels to 6 in the matched render review.
- Current 2K comparison: foreground mean absolute RGB8 difference 1.265968; p95 6; largest connected >32 region 6 pixels. Remaining small differences include sampling/specular variation. These numerical checks are not final perceptual or native acceptance.
- The 4K masters were not overwritten. Their archive is not required to open this packed 2K scene.
- The metal-only geometry export is byte-identical to the fixture used in the published mesh-normal fidelity study. Source renderer/material support is a separate gate.

## Cost and scope

Two separate RGBA8 2K maps would occupy 32 MiB at base level, roughly 42.7 MiB with full mip chains. The corresponding 4K assumption is four times as large. These are format assumptions, not measured GPU residency; the actual native adapter may use different formats/compression. Do not force a 4K default without native budget evidence.

Metal base color and roughness are baked. This does not establish native PBR binding, effects, grip import, hands, normal-map parity, gameplay or frame-time performance. Overall silhouette, surface storytelling, leather quality, effects and final polish remain open.

## Review/reproduce

Open the packed scene in Blender4.3.2. render_review.py renders the hero and review angles; render_side.py reproduces the wider side view. Run render_comparison.py to regenerate matched 40-sample baked/procedural renders directly from the packed scene and its retained procedural nodes. This reproduced the earlier comparison images pixel-for-pixel. compare_renders.py uses Pillow, NumPy and SciPy to compare those regenerated images. Higher-sample hero/front/side images are for visual review, not the matched numerical comparison.

check_ownership.py requires the separately preserved v31 reference scene. Supply --reference /path/to/soul-storm-ornament-study.blend; the manifest records the expected v31 SHA256. This check compares sampled evaluated vertices and parent names, not containment, continuous collisions or hand fit.

The source scene retains prior source objects as hidden originals. Do not blindly export all scene objects; use active visible objects and the explicit ownership/material contract. The mesh-loader currently has a separate authored-normal fidelity limitation; see Mesh-Normal-Fidelity-and-Opt-In in the project wiki.
