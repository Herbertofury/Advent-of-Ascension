"""Reproduce matched renders from the packed scene and its retained procedural nodes."""
import bpy
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-metal-baked.blend'));s=bpy.context.scene;s.frame_set(0);s.cycles.samples=40;s.cycles.use_denoising=False;s.render.resolution_x=1200;s.render.resolution_y=800;s.render.resolution_percentage=100;s.render.filepath=str(R/'hero-baked.png');bpy.ops.render.render(write_still=True)
count=0
for m in bpy.data.materials:
 if not m.name.startswith('V33 edge finish '):continue
 nodes=m.node_tree.nodes;links=m.node_tree.links;bs=next(n for n in nodes if n.type=='BSDF_PRINCIPLED');ramp=nodes['V33 curvature-directed edge finish'];rough=[n for n in nodes if n.type=='MAP_RANGE'];assert len(rough)==1
 links.new(ramp.outputs['Color'],bs.inputs['Base Color']);links.new(rough[0].outputs['Result'],bs.inputs['Roughness']);count+=1
assert count==3,count
s.render.filepath=str(R/'hero-procedural.png');bpy.ops.render.render(write_still=True)
