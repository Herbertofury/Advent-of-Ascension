import bpy,json,numpy as np,hashlib,sys,argparse
from pathlib import Path
R=Path(__file__).resolve().parent;manifest=json.loads((R/'manifest.json').read_text());frames=[0,.5,2.5,5,7.5,10,15,20,25,30];parts=manifest['parts'];parser=argparse.ArgumentParser();parser.add_argument('--reference',type=Path,default=R.parent/'soul-storm-grip-ornament-v31/soul-storm-ornament-study.blend');args=parser.parse_args(sys.argv[sys.argv.index('--')+1:]if '--'in sys.argv else[]);source=args.reference;assert hashlib.sha256(source.read_bytes()).hexdigest()==manifest['source_sha256']
def vertices(o,dg):
 eo=o.evaluated_get(dg);me=eo.to_mesh();v=np.empty((len(me.vertices),3),dtype=np.float64);me.vertices.foreach_get('co',v.reshape(-1));m=np.array(o.matrix_world,dtype=np.float64);v=v@m[:3,:3].T+m[:3,3];eo.to_mesh_clear();return v
bpy.ops.wm.open_mainfile(filepath=str(source));expected={}
for f in frames:
 bpy.context.scene.frame_set(int(f),subframe=f-int(f));dg=bpy.context.evaluated_depsgraph_get();expected[f]={p['source']:vertices(bpy.data.objects[p['source']],dg)for p in parts}
bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-metal-baked.blend'));max_error=0.;samples=0
for f in frames:
 bpy.context.scene.frame_set(int(f),subframe=f-int(f));dg=bpy.context.evaluated_depsgraph_get()
 for p in parts:
  o=bpy.data.objects[p['copy']];assert (o.parent.name if o.parent else None)==p['parent'];got=vertices(o,dg);want=expected[f][p['source']];assert got.shape==want.shape,(p['source'],got.shape,want.shape);error=float(np.max(np.abs(got-want)));assert error<1e-5,(p['source'],f,error);max_error=max(max_error,error);samples+=len(got)
packed=[]
for im in bpy.data.images:
 if im.source=='FILE':packed.append({'image':im.name,'packed':bool(im.packed_file)})
assert all(x['packed']for x in packed)
result={'status':'PASS','frames':frames,'parts':len(parts),'vertex_samples':samples,'maximum_coordinate_error':max_error,'parent_ownership_preserved':True,'file_images':packed,'native_accepted':False,'limits':['Sampled evaluated vertex/parent equivalence only','No collision, native shader, arm-fit or gameplay proof']};(R/'ownership-qa.json').write_text(json.dumps(result,indent=2));print(result)
