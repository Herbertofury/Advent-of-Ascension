import bpy
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-metal-baked.blend'));s=bpy.context.scene;s.frame_set(0);s.cycles.use_denoising=False;s.cycles.samples=128;s.render.resolution_x=1200;s.render.resolution_y=800;s.render.resolution_percentage=100;s.render.filepath=str(R/'hero-review-128.png');bpy.ops.render.render(write_still=True)
for name,position,target in [('side',(.7,-18,1.5),(.7,0,1.5)),('front',(18,0,2),(1.5,0,1.5))]:
 s.camera.location=position;s.camera.rotation_euler=(Vector(target)-s.camera.location).to_track_quat('-Z','Y').to_euler();s.camera.data.type='ORTHO';s.camera.data.ortho_scale=11 if name=='side'else 8;s.camera.data.shift_x=0;s.camera.data.shift_y=0;s.cycles.samples=64;s.render.resolution_x=900;s.render.resolution_y=900;s.render.filepath=str(R/(name+'-review.png'));bpy.ops.render.render(write_still=True)
