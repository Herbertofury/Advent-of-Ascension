# Discharge lower-rail and paint authoring patch

Requires Blender 4.3.2 and the v38 chamber study source with SHA256 fd41902d367dd760bdec4b698dbc8546a7c4e3193b37fe37c8f80e3300b0fabf. The first script fails closed for a different source. Original objects remain available; four old lower-rail objects are hidden, with three rounded openings per side replacing five stair-step cuts. The existing red seam is retained. The second script copies two materials and separates painted surfaces from exposed metal.

Run Blender with --python-exit-code 1 --python build_rail.py -- --source SOURCE.blend --out output
Then --python-exit-code 1 --python build_materials.py -- --source output/discharge-rail-r2.blend --out output

These are visual authoring candidates, not final art or an installable/native weapon. They are separate from the qualified v39 baked export. A new atlas/bake, geometry transport and native shader review would be needed before those results transfer. This patch does not include upstream binaries, does not overwrite its source, and does not implement gameplay or improve measured FPS.

The v40 fine-line ornament experiment was not incorporated: its small markings did not close the concept-fidelity gap. Earlier source and variants remain intact.
