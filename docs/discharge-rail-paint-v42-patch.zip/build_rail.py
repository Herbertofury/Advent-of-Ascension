"""Three scalloped cosmetic openings following the fictional concept silhouette."""
import bpy,bmesh,json,math,hashlib,argparse,sys
from pathlib import Path
from mathutils import Vector
H=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);R=a.out;R.mkdir(parents=True,exist_ok=True);src=a.source;assert hashlib.sha256(src.read_bytes()).hexdigest()=='fd41902d367dd760bdec4b698dbc8546a7c4e3193b37fe37c8f80e3300b0fabf','Unexpected source';bpy.ops.wm.open_mainfile(filepath=str(src));s=bpy.context.scene;s.frame_set(1);bpy.context.view_layer.update();steel=bpy.data.materials['Discharge dark machined steel'];silver=bpy.data.materials['Discharge bright edges'];root=bpy.data.objects['Discharge_Root'];hidden=[];created=[]
for o in bpy.data.objects:
 if o.name.startswith(('V3 notched underbody plate','V3 underbody silver border')):o.hide_render=True;hidden.append(o.name)
# The three rounded negative spaces replace the older five staircase cuts. No receiver/hand changes.
outline=[(-1.25,.10),(-1.05,-.09),(2.58,-.11),(2.73,-.30),(2.49,-.49)]
for center in [1.85,.72,-.41]:
 outline.append((center+.32,-.49));outline.append((center+.32,-.30))
 for k in range(1,7):
  t=math.pi*.5*k/6;outline.append((center+.26+.06*math.cos(t),-.30+.06*math.sin(t)))
 outline.append((center-.26,-.24))
 for k in range(1,7):
  t=math.pi*.5+math.pi*.5*k/6;outline.append((center-.26+.06*math.cos(t),-.30+.06*math.sin(t)))
 outline.append((center-.32,-.49))
outline.extend([(-.99,-.49),(-1.20,-.32)])
for side in [-1,1]:
 N=len(outline);verts=[(x,side*.70+dy,z)for dy in [-.065,.065]for x,z in outline];faces=[tuple(range(N-1,-1,-1)),tuple(range(N,2*N))]+[(i,(i+1)%N,(i+1)%N+N,i+N)for i in range(N)];me=bpy.data.meshes.new('V41 scalloped lower rail');me.from_pydata(verts,[],faces);me.update();bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));assert all(e.is_manifold for e in bm.edges)
 if bm.calc_volume(signed=True)<0:bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
 bm.to_mesh(me);bm.free();obj=bpy.data.objects.new('V41 scalloped lower rail',me);bpy.context.collection.objects.link(obj);me.materials.append(steel);obj.parent=root;bevel=obj.modifiers.new('Soft sculpted edge','BEVEL');bevel.width=.018;bevel.segments=3;bpy.context.view_layer.objects.active=obj;obj.select_set(True);bpy.ops.object.modifier_apply(modifier=bevel.name);obj.select_set(False);created.append(obj.name)
 cu=bpy.data.curves.new('V41 continuous silver rail trim','CURVE');cu.dimensions='3D';cu.resolution_u=1;cu.bevel_depth=.021;cu.bevel_resolution=2;cu.use_fill_caps=True;sp=cu.splines.new('POLY');sp.points.add(N-1)
 for p,(x,z)in zip(sp.points,outline):p.co=(x,side*.78,z,1)
 sp.use_cyclic_u=True;ob=bpy.data.objects.new('V41 continuous silver rail trim',cu);bpy.context.collection.objects.link(ob);cu.materials.append(silver);ob.parent=root;created.append(ob.name)
s.render.resolution_x=1200;s.render.resolution_y=850;s.render.resolution_percentage=100;s.cycles.samples=64;s.cycles.use_denoising=False;c=s.camera;c.location=(5,15,6);c.rotation_euler=(Vector((-.2,0,.5))-c.location).to_track_quat('-Z','Y').to_euler();c.data.type='ORTHO';c.data.ortho_scale=10;s.render.filepath=str(R/'hero-r2.png');bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-rail-r2.blend'));(R/'manifest-r2.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'hidden_prior_parts':hidden,'new_parts':created,'openings_per_side':3,'native_accepted':False,'final_art_accepted':False,'scope':'Cosmetic lower silhouette study; geometry, moving clearance and visual review pending'},indent=2))
