"""Bounded pinned-file audit, without executing Minecraft classes."""
import argparse,hashlib,json,os,pathlib,re,shutil,subprocess,zipfile
p=argparse.ArgumentParser();p.add_argument('jar');p.add_argument('evidence');a=p.parse_args();d=json.load(open(a.evidence));z=zipfile.ZipFile(a.jar)
for n,h in d['class_sha256'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h,n
assert json.loads(z.read('data/aoa3/recipes/infusion_shoe_flinger.json'))==d['recipe']
tool=str(pathlib.Path(os.environ['JAVA_HOME'])/'bin/javap')if os.getenv('JAVA_HOME')else shutil.which('javap');assert tool
w=subprocess.check_output([tool,'-c','-p','-classpath',a.jar,'net.tslat.aoa3.content.item.weapon.gun.ShoeFlinger'],text=True)
for token in ['ShoeShotEntity','Items.f_42463_','EquipmentSlot.FEET','overworld/la_chancla','shoe_flinger_boss_kill','doScaledKnockback']:assert token in w,token
r=subprocess.check_output([tool,'-c','-p','-classpath',a.jar,'net.tslat.aoa3.client.render.entity.projectile.bullets.ShoeShotRenderer'],text=True);assert 'float 0.5f' in r and 'float 57.295776f' in r
print('PASS seven class hashes, recipe and selected weapon/renderer paths. Not native or full behavior acceptance.')
