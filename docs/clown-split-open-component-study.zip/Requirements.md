# Clown flag / ribbon sight attachment

Owner-directed gameplay requirement, 21 October 2026. Not implemented or accepted by this document or the concept artwork.

- Apply to source-verified clown-related weapons that actually have flags. Clownimator, Clowno Pulse and Clownershot are verified initial examples; inspect each additional identity before opting it in. A name containing clown is not sufficient evidence.
- Use red textile flags on black poles. All pole bases remain in one longitudinal front-to-back row along the barrel, without sideways fan-out. Pole/flag height may rise or lower during focus alignment; the old fixed-height assumption is superseded.
- The attachment is equipped by default and can be removed. Explicit removal must persist through switching, re-equipping, saving/reloading and multiplayer synchronization; a default must not overwrite an explicit off state.
- Corrected split-open mechanism: each pole owns TWO cloth flag halves attached to that same pole. Each pair splits into its own aperture; the opening motion progresses along all three poles. The three aperture planes face along the barrel and align on one sightline. No cloth stretches between adjacent poles to create one shared ring.
- Raise/lower the poles and their flags as needed to align the openings. On focus loss, each pair closes back into its normal fluttering flag and each pole returns to its source idle height. The focused first-person appearance was approved; the earlier broadside stretching transition was rejected on 22 October 2026.
- Keep the aiming center stable. Flutter remains outside the aiming aperture, and cloth motion does not steer authoritative shots. Removing the attachment must leave a usable aiming view, not a blocked or missing sight.
- Preserve each weapon's source ammunition/resource, firing event, projectile, cooldown, progression and effects unless a separate functional change is explicitly requested. This sight/cloth feature is not permission to change damage or resource costs.
- Provide reduced-motion and reduced-flash behavior. Avoid rapid brightness cycling, cloth crossing the eye line, scope obstruction, hand clipping and unintended firing effects on attachment changes.
- Resolve one build definition for UI, equipped visual, persistence and server validation. Reject incompatible IDs. Do not use a default-on fallback for malformed or unknown persisted values; preserve unknown extension fields.

## Required evidence before claiming gameplay completion

Native AoA + TaCZ stack; attach/detach/default and explicit-off persistence; idle/aim transition and interruption; first/third person; Steve/Alex hand fit; fixed-anchor and sight-alignment checks; resource reload and weapon switch; multiplayer late join and reconnect; reduced-motion option; original fire/empty-fire/resource costs; comparable frame-time and memory measurements.

Current status: revised concept panels exist. Runtime integration, persistence, UI, cloth simulation and all native acceptance gates remain open.


## Current revision status

The previous side-view and gathering panels are superseded. The corrected transition artwork is still pending after an individual generation failure; the approved focused-view appearance remains the visual target. Pure component pose tests do not prove cloth deformation, native rendering or player alignment. The existing serialized variant key `converging` is retained for compatibility and now describes paired split-open alignment rather than stretching cloth across poles.
