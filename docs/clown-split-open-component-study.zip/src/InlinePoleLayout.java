package io.github.herbertofury.ribbonstudy;
import java.util.List;

/** Weapon-local normalized authoring coordinates, not real-world construction dimensions. */
public final class InlinePoleLayout {
    public record Anchor(double lateral,double height,double longitudinal) {
        public Anchor {if(!Double.isFinite(lateral)||!Double.isFinite(height)||!Double.isFinite(longitudinal))throw new IllegalArgumentException("Non-finite anchor");}
    }
    private final List<Anchor> anchors;
    public InlinePoleLayout(List<Anchor> source){
        if(source==null||source.isEmpty())throw new IllegalArgumentException("Missing poles");
        anchors=List.copyOf(source);double x=anchors.get(0).lateral();
        for(int i=0;i<anchors.size();i++){
            Anchor a=anchors.get(i);if(Math.abs(a.lateral()-x)>1e-6)throw new IllegalArgumentException("Poles must remain longitudinal, not side-by-side");
            if(i>0&&a.longitudinal()<=anchors.get(i-1).longitudinal())throw new IllegalArgumentException("Distinct ordered inline anchors required");
        }
    }
    public List<Anchor> anchors(){return anchors;}
    /** Aim progress preserves the inline mounting bases. Moving pole tips and paired flag roots are supplied by SplitOpenSightPose; their height is not fixed. */
    public List<Anchor> anchorsAtAim(double progress){
        if(!Double.isFinite(progress)||progress<0||progress>1)throw new IllegalArgumentException("Invalid aim progress");return anchors;
    }
    public static double approachAim(double current,double target,double elapsedSeconds,double response){
        if(!Double.isFinite(current)||!Double.isFinite(target)||!Double.isFinite(elapsedSeconds)||!Double.isFinite(response)||current<0||current>1||target<0||target>1||elapsedSeconds<0||response<=0)throw new IllegalArgumentException("Invalid transition");
        return target+(current-target)*Math.exp(-response*elapsedSeconds);
    }
}
