package io.github.herbertofury.ribbonstudy;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.Set;

/** Pure attachment-state candidate. No renderer, networking, or gameplay hook is installed. */
public final class RibbonAttachmentState {
    public static final String KEY="shyre_study:ribbon_sight";
    private static final Set<String> VERIFIED_FLAGGED=Set.of("aoa3:clownimator","aoa3:clowno_pulse","aoa3:clownershot");
    public enum Status { DEFAULT, EXPLICIT, UNSUPPORTED_WEAPON, INVALID_DATA, UNKNOWN_VARIANT }
    public record Resolved(Status status, boolean enabled, String variant, int flags) {}
    private RibbonAttachmentState() {}
    public static boolean eligible(String id){return id!=null&&VERIFIED_FLAGGED.contains(id);}
    public static Resolved resolve(String id,JsonObject itemData){
        if(id==null||!eligible(id))return new Resolved(Status.UNSUPPORTED_WEAPON,false,"",0);
        if(itemData==null)throw new IllegalArgumentException("Missing item data");
        JsonElement raw=itemData.get(KEY);
        if(raw==null)return new Resolved(Status.DEFAULT,true,"converging",3);
        if(!raw.isJsonObject())return invalid(Status.INVALID_DATA);
        JsonObject state=raw.getAsJsonObject();boolean enabled=true;String variant="converging";
        if(state.has("enabled")){
            JsonElement e=state.get("enabled");
            if(!e.isJsonPrimitive()||!e.getAsJsonPrimitive().isBoolean())return invalid(Status.INVALID_DATA);
            enabled=e.getAsBoolean();
        }
        if(state.has("variant")){
            JsonElement e=state.get("variant");
            if(!e.isJsonPrimitive()||!e.getAsJsonPrimitive().isString())return invalid(Status.INVALID_DATA);
            variant=e.getAsString();
            if(!variant.equals("flags")&&!variant.equals("converging"))return invalid(Status.UNKNOWN_VARIANT);
        }
        return new Resolved(Status.EXPLICIT,enabled,variant,3);
    }
    private static Resolved invalid(Status status){return new Resolved(status,false,"",3);}
    public static JsonObject withEnabled(String id,JsonObject original,boolean enabled){
        Resolved old=resolve(id,original);
        if(old.status()!=Status.DEFAULT&&old.status()!=Status.EXPLICIT)throw new IllegalArgumentException("Cannot overwrite unresolved attachment data");
        JsonObject copy=original.deepCopy();JsonObject state=copy.has(KEY)?copy.getAsJsonObject(KEY):new JsonObject();
        state.addProperty("enabled",enabled);copy.add(KEY,state);return copy;
    }
    public static JsonObject withVariant(String id,JsonObject original,String variant){
        if(!"flags".equals(variant)&&!"converging".equals(variant))throw new IllegalArgumentException("Unknown variant");
        Resolved old=resolve(id,original);JsonObject copy=withEnabled(id,original,old.enabled());
        copy.getAsJsonObject(KEY).addProperty("variant",variant);return copy;
    }
}
