package io.github.herbertofury.ribbonstudy;
import java.util.List;
public final class SplitOpenSightPoseTest {
    static int checks;
    static void check(boolean v){checks++;if(!v)throw new AssertionError("check "+checks);}
    static void near(double a,double b){check(Math.abs(a-b)<1e-10);}
    static void rejects(Runnable r){boolean bad=false;try{r.run();}catch(IllegalArgumentException e){bad=true;}check(bad);}
    static InlinePoleLayout layout(){return new InlinePoleLayout(List.of(new InlinePoleLayout.Anchor(0,0,0),new InlinePoleLayout.Anchor(0,0.05,0.5),new InlinePoleLayout.Anchor(0,0,1)));}
    public static void main(String[]args){
        List<Double> idle=List.of(0.35,0.65,0.45);
        for(var dir:SplitOpenSightPose.WaveDirection.values()){
            var model=new SplitOpenSightPose(layout(),idle,0.8,0.15,0.2,0.15,dir);
            var start=model.at(0,true);var end=model.at(1,true);
            for(int i=0;i<3;i++){near(start.get(i).tip().height(),idle.get(i));near(start.get(i).opening(),0);near(end.get(i).opening(),1);near(end.get(i).apertureCenter().height(),0.8);near(end.get(i).tip().height(),0.6);}
            // Same lateral coordinate and height, separate ordered longitudinal planes.
            for(int step=0;step<=100;step++){
                double p=step/100.0;var poses=model.at(p,true);check(poses.size()==3);var hidden=model.at(p,false);for(int j=0;j<3;j++){check(!hidden.get(j).visible());check(hidden.get(j).tip().equals(start.get(j).tip()));}
                for(int i=0;i<3;i++){
                    var q=poses.get(i);check(q.visible());check(q.halves().size()==2);check(q.mount().equals(layout().anchors().get(i)));near(q.tip().lateral(),q.mount().lateral());near(q.tip().longitudinal(),q.mount().longitudinal());check(q.tip().height()>q.mount().height());check(q.opening()>=0&&q.opening()<=1);
                    for(var h:q.halves()){check(h.ownerPole()==i);near(h.bottom().longitudinal(),q.mount().longitudinal());near(h.outer().longitudinal(),q.mount().longitudinal());near(h.top().longitudinal(),q.mount().longitudinal());check(h.bottom().equals(q.tip()));}
                    check(q.halves().get(0).side()==SplitOpenSightPose.Side.LEFT);check(q.halves().get(1).side()==SplitOpenSightPose.Side.RIGHT);
                    if(step>0)check(q.opening()>=model.at((step-1)/100.0,true).get(i).opening());
                }
                // Reversing focus follows the same well-defined poses and restores idle exactly.
                near(model.at(1-(100-step)/100.0,true).get(0).opening(),poses.get(0).opening());
            }
            check(end.get(0).tip().height()>start.get(0).tip().height());check(end.get(1).tip().height()<start.get(1).tip().height());var early=model.at(0.1,true);int first=dir==SplitOpenSightPose.WaveDirection.FRONT_TO_BACK?0:2;check(early.get(first).opening()>0);check(early.get(1).opening()==0);
            rejects(()->model.at(Double.NaN,true));rejects(()->model.at(-0.1,true));rejects(()->model.at(1.1,true));
            boolean immutable=false;try{end.add(end.get(0));}catch(UnsupportedOperationException e){immutable=true;}check(immutable);
        }
        rejects(()->new SplitOpenSightPose(layout(),List.of(0.1,0.2),0.8,0.1,0.1,0.1,SplitOpenSightPose.WaveDirection.FRONT_TO_BACK));
        rejects(()->new SplitOpenSightPose(layout(),idle,0.8,0.1,0.1,0.5,SplitOpenSightPose.WaveDirection.FRONT_TO_BACK));
        rejects(()->new SplitOpenSightPose(layout(),idle,0.1,0.1,0.2,0.1,SplitOpenSightPose.WaveDirection.FRONT_TO_BACK));
        rejects(()->new SplitOpenSightPose(layout(),idle,0.8,Double.NaN,0.2,0.1,SplitOpenSightPose.WaveDirection.FRONT_TO_BACK));
        rejects(()->new SplitOpenSightPose(layout(),java.util.Arrays.asList(0.3,null,0.4),0.8,0.1,0.1,0.1,SplitOpenSightPose.WaveDirection.FRONT_TO_BACK));
        rejects(()->new SplitOpenSightPose(layout(),idle,0.8,0,0.1,0.1,SplitOpenSightPose.WaveDirection.FRONT_TO_BACK));
        rejects(()->new SplitOpenSightPose(layout(),idle,0.8,0.1,0.1,-0.1,SplitOpenSightPose.WaveDirection.FRONT_TO_BACK));
        System.out.println("Split-open pose checks PASS: "+checks+"; pure targets only, no native integration");
    }
}
