package io.github.herbertofury.ribbonstudy;
import com.google.gson.*;
import java.util.*;
public final class RibbonAttachmentStateTest {
 static int checks;static void check(boolean v){checks++;if(!v)throw new AssertionError("check "+checks);}
 static JsonObject obj(String s){return JsonParser.parseString(s).getAsJsonObject();}
 static void rejects(Runnable f){boolean rejected=false;try{f.run();}catch(IllegalArgumentException e){rejected=true;}check(rejected);}
 public static void main(String[]args){
  check(!RibbonAttachmentState.eligible(null));
  rejects(()->RibbonAttachmentState.resolve("aoa3:clownimator",null));
  for(String id:List.of("aoa3:clownimator","aoa3:clowno_pulse","aoa3:clownershot")){
   JsonObject a=obj("{\"foreign_extension\":{\"keep\":42}}");String before=a.toString();
   check(RibbonAttachmentState.resolve(id,a).enabled());
   JsonObject off=RibbonAttachmentState.withEnabled(id,a,false);check(!RibbonAttachmentState.resolve(id,off).enabled());check(a.toString().equals(before));check(off.getAsJsonObject("foreign_extension").get("keep").getAsInt()==42);
   check(!RibbonAttachmentState.resolve(id,obj(off.toString())).enabled());
   off.getAsJsonObject(RibbonAttachmentState.KEY).addProperty("future_extension","retain");
   JsonObject on=RibbonAttachmentState.withEnabled(id,off,true);check(RibbonAttachmentState.resolve(id,on).enabled());check(on.getAsJsonObject(RibbonAttachmentState.KEY).get("future_extension").getAsString().equals("retain"));
   JsonObject flags=RibbonAttachmentState.withVariant(id,off,"flags");check(!RibbonAttachmentState.resolve(id,flags).enabled());check(RibbonAttachmentState.resolve(id,flags).variant().equals("flags"));
   for(String bad:List.of("null","1","\"true\"","[]","{}")){
    JsonObject invalid=new JsonObject();JsonObject state=new JsonObject();state.add("enabled",JsonParser.parseString(bad));invalid.add(RibbonAttachmentState.KEY,state);String unchanged=invalid.toString();check(!RibbonAttachmentState.resolve(id,invalid).enabled());rejects(()->RibbonAttachmentState.withEnabled(id,invalid,true));check(unchanged.equals(invalid.toString()));
   }
   JsonObject future=new JsonObject();JsonObject state=new JsonObject();state.addProperty("variant","future_variant");future.add(RibbonAttachmentState.KEY,state);check(RibbonAttachmentState.resolve(id,future).status()==RibbonAttachmentState.Status.UNKNOWN_VARIANT);rejects(()->RibbonAttachmentState.withEnabled(id,future,true));
   rejects(()->RibbonAttachmentState.withVariant(id,a,"unknown"));
  }
  for(String id:List.of("aoa3:clown_cannon","aoa3:clown_cracker","aoa3:clownish_unverified","aoa3:discharge_shotgun","other:clownimator")){check(!RibbonAttachmentState.resolve(id,new JsonObject()).enabled());rejects(()->RibbonAttachmentState.withEnabled(id,new JsonObject(),true));}
  var roots=new ArrayList<>(List.of(new InlinePoleLayout.Anchor(0,1,-1),new InlinePoleLayout.Anchor(0,1,0),new InlinePoleLayout.Anchor(0,1,1)));var layout=new InlinePoleLayout(roots);roots.clear();check(layout.anchors().size()==3);
  for(int i=0;i<=100;i++)check(layout.anchorsAtAim(i/100.0).equals(layout.anchors()));
  rejects(()->new InlinePoleLayout(List.of(new InlinePoleLayout.Anchor(-1,1,0),new InlinePoleLayout.Anchor(0,1,0),new InlinePoleLayout.Anchor(1,1,0))));
  rejects(()->new InlinePoleLayout(List.of(new InlinePoleLayout.Anchor(0,1,0),new InlinePoleLayout.Anchor(0,1,0))));
  for(double invalid:new double[]{Double.NaN,-1,2})rejects(()->layout.anchorsAtAim(invalid));
  double a=0,b=0;for(int i=0;i<60;i++)a=InlinePoleLayout.approachAim(a,1,1.0/60,8);for(int i=0;i<144;i++)b=InlinePoleLayout.approachAim(b,1,1.0/144,8);check(Math.abs(a-b)<1e-12);check(a>0&&a<1);check(InlinePoleLayout.approachAim(a,0,.1,8)<a);
  System.out.println("PASS: "+checks+" pure state/anchor checks; no native attachment implementation or gameplay acceptance");
 }
}
