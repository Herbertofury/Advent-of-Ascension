package io.github.herbertofury.ribbonstudy;
import java.util.ArrayList;
import java.util.List;

/** Pure normalized GAME-animation targets. No renderer, physics or native hook. */
public final class SplitOpenSightPose {
    public enum WaveDirection { FRONT_TO_BACK, BACK_TO_FRONT }
    public enum Side { LEFT, RIGHT }
    public record Point(double lateral, double height, double longitudinal) {}
    public record HalfTarget(int ownerPole, Side side, Point bottom, Point outer, Point top) {}
    public record PolePose(int index, InlinePoleLayout.Anchor mount, Point tip,
                           Point apertureCenter, double opening, List<HalfTarget> halves, boolean visible) {
        public PolePose { halves=List.copyOf(halves); }
    }
    private final InlinePoleLayout layout;
    private final List<Double> idleTips;
    private final double centerHeight, halfWidth, halfHeight, stagger;
    private final WaveDirection direction;
    public SplitOpenSightPose(InlinePoleLayout layout, List<Double> idleTips,
                             double centerHeight, double halfWidth, double halfHeight,
                             double stagger, WaveDirection direction) {
        if(layout==null||idleTips==null||direction==null||layout.anchors().size()!=3||idleTips.size()!=3)
            throw new IllegalArgumentException("Exactly three inline pole specifications required");
        if(!Double.isFinite(centerHeight)||!Double.isFinite(halfWidth)||!Double.isFinite(halfHeight)
           ||!Double.isFinite(stagger)||halfWidth<=0||halfHeight<=0||stagger<0||stagger>=0.5)
            throw new IllegalArgumentException("Invalid aperture or wave parameters");
        this.layout=layout;this.centerHeight=centerHeight;
        this.halfWidth=halfWidth;this.halfHeight=halfHeight;this.stagger=stagger;this.direction=direction;
        for(int i=0;i<3;i++) {
            Double h=idleTips.get(i);
            if(h==null||!Double.isFinite(h)||h<=layout.anchors().get(i).height()
               ||centerHeight-halfHeight<=layout.anchors().get(i).height())
                throw new IllegalArgumentException("Pole tip must remain above its mount");
        }
        this.idleTips=List.copyOf(idleTips);
    }
    public List<PolePose> at(double focusProgress, boolean enabled) {
        if(!Double.isFinite(focusProgress)||focusProgress<0||focusProgress>1)
            throw new IllegalArgumentException("Invalid focus progress");
        double p=enabled?focusProgress:0;List<PolePose> out=new ArrayList<>(3);
        for(int i=0;i<3;i++) {
            int order=direction==WaveDirection.FRONT_TO_BACK?i:2-i;
            double t=Math.max(0,Math.min(1,(p-order*stagger)/(1-2*stagger)));
            double opening=t*t*(3-2*t);InlinePoleLayout.Anchor m=layout.anchors().get(i);
            double tipHeight=idleTips.get(i)+(centerHeight-halfHeight-idleTips.get(i))*opening;
            Point tip=new Point(m.lateral(),tipHeight,m.longitudinal());
            Point center=new Point(m.lateral(),tipHeight+halfHeight*opening,m.longitudinal());
            Point top=new Point(m.lateral(),center.height()+halfHeight*opening,m.longitudinal());
            List<HalfTarget> halves=List.of(
                new HalfTarget(i,Side.LEFT,tip,new Point(m.lateral()-halfWidth*opening,center.height(),m.longitudinal()),top),
                new HalfTarget(i,Side.RIGHT,tip,new Point(m.lateral()+halfWidth*opening,center.height(),m.longitudinal()),top));
            out.add(new PolePose(i,m,tip,center,opening,halves,enabled));
        }
        return List.copyOf(out);
    }
    // These are aperture guides, not cloth vertices. At opening=0 the renderer must
    // use the authored fluttering idle flag mesh, not collapse its cloth to these guides.
}
