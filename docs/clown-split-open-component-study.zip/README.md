# Pure authored component study, not an installable mod

Java 17 and Gson 2.10 required for the attachment-state test. Compile src/*.java with Gson on the classpath. Run io.github.herbertofury.ribbonstudy.RibbonAttachmentStateTest and io.github.herbertofury.ribbonstudy.SplitOpenSightPoseTest. No dependency binaries, original AoA/TaCZ code or game assets are bundled. No native integration is installed. Coordinates are normalized game-animation guides.
