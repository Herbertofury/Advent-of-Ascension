const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/../aoa-expansion/soul-storm-lab.html','utf8');
const assets=html.match(/<script id="assets" type="application\/json">(.*?)<\/script>/s)[1],script=html.match(/<script>(.*?)<\/script>/s)[1];
const elements={},queue=new Map();let id=0;const context={clearRect(){},beginPath(){},moveTo(){},lineTo(){},closePath(){},fill(){},stroke(){}};
function element(name){return elements[name]??=({id:name,value:name==='speed'?'1':'',textContent:name==='assets'?assets:'',width:1000,height:600,children:[],appendChild(c){this.children.push(c)},setAttribute(k,v){this[k]=v},getContext(){return context}});}
const box={console,document:{hidden:false,getElementById:element,createElement:()=>({}),addEventListener(){}},matchMedia:()=>({matches:true}),requestAnimationFrame:f=>{queue.set(++id,f);return id},cancelAnimationFrame:i=>queue.delete(i)};
vm.createContext(box);vm.runInContext(script,box);let now=0;function tick(dt=16){now+=dt;const jobs=[...queue.values()];queue.clear();for(const f of jobs)f(now)}
tick();assert.equal(queue.size,0);assert.equal(element('clip').children.length,7);assert.match(element('status').textContent,/Seven original/);
element('pulse').onclick();for(let i=0;i<5;i++)tick();assert(queue.size>0);element('pulse').onclick();tick();element('play').onclick();tick();assert.equal(queue.size,0);element('play').onclick();for(let i=0;i<400;i++)tick();assert.equal(queue.size,0,'Settled cosmetic response must stop rendering');
assert(!html.includes('All 15 records'));assert(!html.includes('alternating_barrage_preview'));console.log('PASS: seven correct records, static idle, pulse retrigger, pause/resume and settled idle. Authoring harness only.');
