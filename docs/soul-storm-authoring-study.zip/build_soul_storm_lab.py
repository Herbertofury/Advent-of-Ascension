"""Original Soul Storm preview, with explicit authoring-only limitations."""
from pathlib import Path
import ast,json
R=Path(__file__).parent;P=R/'soul-storm-study/assets/ascension_armory'
g=json.loads((P/'geo_models/gun/soul_storm_geo.json').read_text())['minecraft:geometry'][0];a=json.loads((P/'animations/soul_storm.animation.json').read_text())['animations']
tree=ast.parse((R/'build_workbench.py').read_text());assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='html' for t in n.targets));call=assignment.value
while isinstance(call,ast.Call):call=call.func.value
s=ast.literal_eval(call)
s=s.replace('Baronator','Soul Storm').replace('AUTHORING LAB 001','SPIRIT CHANNEL STUDY')
s=s.replace('Alternating upper/lower barrel recoil, opening vents and a full-size trigger opening. The magazine sits in its own forward socket.','An original open spirit core, clear energy channel and resonator fins. Cosmetic recovery never grants Spirit, adds a magazine or delays native firing.')
s=s.replace('and grenade mechanic','and native Spirit cost').replace('Animated-Weapon-Prototype-Soul Storm','Weapon-Upgrade-Backlog')
s=s.replace('109 cuboids',f"{sum(len(b.get('cubes',[])) for b in g['bones'])} cuboids").replace('27 bones',f'{len(g["bones"])} bones').replace('15 records',f'{len(a)} records')
s=s.replace("const colors=['#b51236','#f54259','#171e2e','#667388','#b7cad4','#d99a45','#57f7e4','#080c14','#482b39'];","const colors=['#211842','#4432ae','#6251f0','#163b70','#219cc4','#62f4ef','#bddfff','#101326'];")
s=s.replace("select.value='alternating_barrage_preview'","select.value='static_auto'")
s=s.replace('zoom=21','zoom=22')
s=s.replace('Reload clips are optional visual studies. They do not refill ammunition or impose manual reloading.','Soul Storm has no conventional reload. The recovery motion is purely cosmetic.')
s=s.replace('<h2>Motion library</h2>','<h2>Rapid-response study</h2><button id="pulse" type="button">Preview spirit pulse</button><p class="notice">Click repeatedly: the cosmetic response keeps its current pose. No gameplay shot, resource debit, sound or particle is simulated.</p><h2>Motion library</h2>')
s=s.replace('const select=document',"const recoil=new CosmeticRecoil();document.getElementById('pulse').onclick=()=>{select.value='static_auto';recoil.pulse();playing=true;last=0;update()};const select=document")
s=s.replace('poses.get(m.bone)(p),[0,0,-2]',"ArmoryMath.add(poses.get(m.bone)(p),[0,0,recoil.x]),[0,0,-2]")
s=s.replace('last=now;if(playing',"last=now;if(playing&&recoil.active){recoil.step(dt*Number(document.getElementById('speed').value));dirty=true;}if(playing")
s=s.replace('if(playing&&current().animation_length>0)schedule();',"if(playing&&(current().animation_length>0||recoil.active))schedule();")
s=s.replace('No gameplay shot, resource debit, sound or particle is simulated.','Bounded cosmetic wisps only; no gameplay shot, resource debit or sound is simulated.')
s=s.replace('<h2>Motion library</h2>','<label><input id="effects" type="checkbox"> Show cosmetic spirit wisps</label><p class="notice">Optional, non-flashing wisps; capped at 24. Off by default.</p><h2>Motion library</h2>')
s=s.replace('const recoil=new CosmeticRecoil();',"const recoil=new CosmeticRecoil(),particles=new SpiritParticles();document.getElementById('effects').onchange=()=>{if(!document.getElementById('effects').checked)particles.clear();dirty=true;schedule()};")
s=s.replace('recoil.pulse();playing=true;',"recoil.pulse();if(document.getElementById('effects').checked)particles.burst([0,1.2,-13.5]);playing=true;")
s=s.replace('last=now;if(playing&&recoil.active)',"last=now;if(playing&&particles.active){particles.step(dt*Number(document.getElementById('speed').value));dirty=true;}if(playing&&recoil.active)")
s=s.replace('current().animation_length>0||recoil.active','current().animation_length>0||recoil.active||particles.active')
s=s.replace('polys.sort((a,b)=>b.z-a.z);',"for(const p of particles.visible()){const c=ArmoryMath.rotate(ArmoryMath.sub(p.position,[0,0,-2]),[pitch,yaw,0]),r=p.size;polys.push({v:[[-r,0],[0,r],[r,0],[0,-r]].map(([x,y])=>[c[0]+x,c[1]+y,c[2]]),z:c[2],color:'#62f4ef',shade:1,alpha:p.opacity});}polys.sort((a,b)=>b.z-a.z);")
s=s.replace("for(const p of polys){let rgb","for(const p of polys){ctx.globalAlpha=p.alpha??1;let rgb")
s=s.replace('timeline.value=t;',"ctx.globalAlpha=1;timeline.value=t;")
s=s.replace('ASSETDATA',json.dumps({'geometry':g,'animations':a},separators=(',',':'))).replace('CORECODE',(R/'animation_core.js').read_text()+'\n'+(R/'cosmetic_recoil.js').read_text()+'\n'+(R/'spirit_particles.js').read_text())
s=s.replace('Original exported model loaded. All 7 records available for inspection.','Seven original motion records. Spatial and arm-proxy checks are scoped; native game, sound, VFX and full hand rig remain unqualified.')
assert 'ASSETDATA' not in s and 'CORECODE' not in s
s=s.replace('<h1>Soul Storm</h1>','<h1>Soul Storm · earlier blockout</h1><p><strong>Visual direction superseded.</strong> This is technical scaffolding, not the accepted art target. <a href="https://github.com/Herbertofury/Advent-of-Ascension/wiki/Soul-Storm-Art-Direction">See the concept-first rebuild direction.</a></p>')
out=R.parent/'aoa-expansion/soul-storm-lab.html';out.write_text(s);print(out,len(s.encode()))
