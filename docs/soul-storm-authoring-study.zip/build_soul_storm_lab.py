"""Original Soul Storm preview, with explicit authoring-only limitations."""
from pathlib import Path
import ast,json
R=Path(__file__).parent;P=R/'soul-storm-study/assets/ascension_armory'
g=json.loads((P/'geo_models/gun/soul_storm_geo.json').read_text())['minecraft:geometry'][0];a=json.loads((P/'animations/soul_storm.animation.json').read_text())['animations']
tree=ast.parse((R/'build_workbench.py').read_text());assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='html' for t in n.targets));call=assignment.value
while isinstance(call,ast.Call):call=call.func.value
s=ast.literal_eval(call)
s=s.replace('Baronator','Soul Storm').replace('AUTHORING LAB 001','SPIRIT CHANNEL STUDY')
s=s.replace('Alternating upper/lower barrel recoil, opening vents and a full-size trigger opening. The magazine sits in its own forward socket.','An original open spirit core, clear energy channel and resonator fins. Cosmetic recovery never grants Spirit, adds a magazine or delays native firing.')
s=s.replace('and grenade mechanic','and native Spirit cost').replace('Animated-Weapon-Prototype-Soul Storm','Weapon-Upgrade-Backlog')
s=s.replace('109 cuboids',f"{sum(len(b.get('cubes',[])) for b in g['bones'])} cuboids").replace('27 bones',f'{len(g["bones"])} bones').replace('15 records',f'{len(a)} records')
s=s.replace("const colors=['#b51236','#f54259','#171e2e','#667388','#b7cad4','#d99a45','#57f7e4','#080c14','#482b39'];","const colors=['#211842','#4432ae','#6251f0','#163b70','#219cc4','#62f4ef','#bddfff','#101326'];")
s=s.replace("select.value='alternating_barrage_preview'","select.value='static_auto'")
s=s.replace('zoom=21','zoom=22')
s=s.replace('Reload clips are optional visual studies. They do not refill ammunition or impose manual reloading.','Soul Storm has no conventional reload. The recovery motion is purely cosmetic.')
s=s.replace('<h2>Motion library</h2>','<h2>Rapid-response study</h2><button id="pulse" type="button">Preview spirit pulse</button><p class="notice">Click repeatedly: the cosmetic response keeps its current pose. No gameplay shot, resource debit, sound or particle is simulated.</p><h2>Motion library</h2>')
s=s.replace('const select=document',"const recoil=new CosmeticRecoil();document.getElementById('pulse').onclick=()=>{select.value='static_auto';recoil.pulse();playing=true;last=0;update()};const select=document")
s=s.replace('poses.get(m.bone)(p),[0,0,-2]',"ArmoryMath.add(poses.get(m.bone)(p),[0,0,recoil.x]),[0,0,-2]")
s=s.replace('last=now;if(playing',"last=now;if(playing&&recoil.active){recoil.step(dt*Number(document.getElementById('speed').value));dirty=true;}if(playing")
s=s.replace('if(playing&&current().animation_length>0)schedule();',"if(playing&&(current().animation_length>0||recoil.active))schedule();")
s=s.replace('ASSETDATA',json.dumps({'geometry':g,'animations':a},separators=(',',':'))).replace('CORECODE',(R/'animation_core.js').read_text()+'\n'+(R/'cosmetic_recoil.js').read_text())
s=s.replace('Original exported model loaded. All 7 records available for inspection.','Seven original motion records. Spatial and arm-proxy checks are scoped; native game, sound, VFX and full hand rig remain unqualified.')
assert 'ASSETDATA' not in s and 'CORECODE' not in s
out=R.parent/'aoa-expansion/soul-storm-lab.html';out.write_text(s);print(out,len(s.encode()))
