const assert=require('assert'),R=require('./cosmetic_recoil');
const a=new R(),b=new R();a.pulse();b.pulse();a.step(.1);for(let i=0;i<10;i++)b.step(.01);
assert(Math.abs(a.x-b.x)<1e-12);assert(Math.abs(a.v-b.v)<1e-12);
const before=a.x;a.pulse();assert.equal(a.x,before,'Retrigger must preserve current pose');
let peak=0;const fast=new R();for(let i=0;i<2400;i++){if(i%6===0)fast.pulse();fast.step(1/120);peak=Math.max(peak,fast.x);assert(Number.isFinite(fast.x));assert(fast.x<=.65);}
for(let i=0;i<1200;i++)fast.step(1/120);assert(!fast.active);
assert.throws(()=>fast.step(NaN));assert.throws(()=>fast.step(-1));assert.throws(()=>new R({frequency:0}));
for(let i=0;i<100000;i++)fast.pulse();fast.step(.01);assert(fast.x<=.65&&Number.isFinite(fast.x));fast.reset();assert(!fast.active);
console.log('PASS: exact damped integration partition, pose-continuous retrigger, 20Hz/20s sequence, bounded impulse spam, finite values, rest, invalid arguments. Cosmetic only. Peak '+peak.toFixed(4));
