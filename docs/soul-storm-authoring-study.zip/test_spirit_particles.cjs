const P=require('./spirit_particles'),assert=require('assert');
const a=new P(),b=new P();a.burst([0,1,-13]);b.burst([0,1,-13]);a.step(.1);for(let i=0;i<10;i++)b.step(.01);
for(let j=0;j<4;j++)for(let k=0;k<3;k++)assert(Math.abs(a.visible()[j].position[k]-b.visible()[j].position[k])<1e-12);
for(let i=0;i<10000;i++)a.burst([0,1,-13]);assert.equal(a.pool.length,24);assert.equal(a.visible().length,24);assert(a.visible().every(p=>p.opacity<=.55));a.step(1);assert(!a.active);assert.equal(a.visible().length,0);
assert.throws(()=>a.burst([0,NaN,0]));assert.throws(()=>a.step(-1));assert.throws(()=>new P(999));a.burst([0,0,0],99999);assert.equal(a.visible().length,24);a.clear();assert(!a.active);
console.log('PASS: deterministic trajectories, timestep partition, bounded pool under burst spam, limited opacity, finite expiry, clear, invalid input. Cosmetic preview only.');
