/* Original bounded cosmetic response. Never authorizes shots, ammo or damage. */
class CosmeticRecoil {
 constructor({frequency=28,impulse=3.6,maximum=.65}={}) {
  if(![frequency,impulse,maximum].every(x=>Number.isFinite(x)&&x>0))throw Error('Invalid cosmetic response');
  Object.assign(this,{frequency,impulse,maximum,x:0,v:0});
 }
 pulse(){this.v=Math.min(this.v+this.impulse,this.impulse*4);}
 step(dt){
  if(!Number.isFinite(dt)||dt<0)throw Error('Invalid elapsed time');
  const w=this.frequency,b=this.v+w*this.x,e=Math.exp(-w*dt);
  let x=(this.x+b*dt)*e,v=(this.v-w*b*dt)*e;
  if(x>this.maximum){x=this.maximum;v=Math.min(v,0);}
  this.x=x;this.v=v;
  if(Math.abs(x)<1e-7&&Math.abs(v)<1e-7){this.x=0;this.v=0;}
  return this.x;
 }
 get active(){return this.x!==0||this.v!==0;}
 reset(){this.x=0;this.v=0;}
}
if(typeof module!=='undefined')module.exports=CosmeticRecoil;
