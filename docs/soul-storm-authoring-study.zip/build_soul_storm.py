"""Original Soul Storm spirit-channel visual study; preserves native resource intent."""
from pathlib import Path
from PIL import Image,ImageDraw
import json,math,hashlib
R=Path(__file__).parent;P=R/'soul-storm-study/assets/ascension_armory';P.mkdir(parents=True,exist_ok=True)
colors=['211842','4432ae','6251f0','163b70','219cc4','62f4ef','bddfff','101326'];uv=[];im=Image.new('RGBA',(128,128));d=ImageDraw.Draw(im)
for i,c in enumerate(colors):
 x=i%4*32;y=i//4*32;d.rectangle((x,y,x+31,y+31),fill='#'+c);uv.append([x+2,y+2])
p=P/'textures/gun/uv/soul_storm.png';p.parent.mkdir(parents=True,exist_ok=True);im.save(p)
bones=[];by={}
def bone(n,p=(0,0,0),parent='root'):
 b={'name':n,'pivot':list(p)}
 if parent:b['parent']=parent
 bones.append(b);by[n]=b

def cube(n,o,s,c=0,rot=None,piv=None):
 q={'origin':list(o),'size':list(s),'uv':{f:{'uv':uv[c],'uv_size':[8,8]} for f in ['north','south','east','west','up','down']}}
 if rot:q.update(rotation=list(rot),pivot=list(piv or o))
 by[n].setdefault('cubes',[]).append(q)
bone('root',parent=None)
for name,pivot in [('body',(0,1,3)),('spirit_core',(0,1,3)),('conduit',(0,1,-3)),('emitter',(0,1,-10)),('grip',(0,-4,7)),('dorsal_fin',(0,4,4)),('pulse_ring',(0,1,-6))]:bone(name,pivot)
# Hollow angular shell framing a visible spirit core; no conventional magazine.
for x in [-2.9,2.5]:
 for y in [-1.4,3.0]:cube('body',(x,y,0),(.4,.8,7),0)
 for z in [0,5.8]:cube('body',(x,-.6,z),(.4,3.6,1.2),0)
for y in [-1.8,3.8]:cube('body',(-2.9,y,0),(5.8,.4,7),1)
for z in [0,6.6]:
 for x in [-3.05,2.9]:cube('body',(x,-1.8,z),(.15,6,.4),2)
# Sprite-inspired side medallions and channel marks.
for x in [-3.1,2.9]:
 for seg in range(8):
  ang=seg*45;rad=math.radians(ang);y=1+1.8*math.sin(rad);z=3.5+1.8*math.cos(rad)
  cube('body',(x,y-.4,z-.15),(.2,.8,.3),4,(ang,0,0),(x,y,z))
 for z in [.4,6]:cube('body',(x,-1,z),(.25,.6,.5),6)
cube('spirit_core',(-1.25,-.25,2.25),(2.5,2.5,2.5),5,(0,0,45),(0,1,3.5))
# Four rails leave an unobstructed central channel to the open emitter.
for x in [-1.65,1.35]:cube('conduit',(x,-.5,-8),(.3,3,8),3)
for y in [-.8,2.5]:cube('conduit',(-1.65,y,-8),(3.3,.3,8),1)
for side in [-1,1]:
 for i,z in enumerate([-2,-4,-6]):cube('conduit',(side*1.7-.1,.65,z),(.2,.7,1.1),5)
# Broad forked emitter: the native cyan/purple stripes become layered resonator fins.
for y in [-1.5,.1,1.7,3.3]:
 cube('emitter',(-2.2,y,-13),(4.4,.55,4.5),1)
 cube('emitter',(-1.8,y+.12,-13.15),(3.6,.28,.3),5)
 for x in [-2.3,1.9]:cube('emitter',(x,y,-12.7),(.4,.55,4),2)
# Two clear central lanes between the fins; no plug across the opening.
for seg in range(8):
 ang=seg*45;rad=math.radians(ang);x=3.1*math.sin(rad);y=1+3.1*math.cos(rad)
 cube('pulse_ring',(x-.65,y-.15,-7), (1.3,.3,.4),4,(0,0,-ang),(x,y,-6.8))
# Full-size ergonomic grip and touch activation plate; no hidden shrunken trigger.
cube('grip',(-1.3,-6.5,5.5),(2.6,4.8,2.4),0)
for y in [-5.8,-4.7,-3.6]:cube('grip',(-1.4,y,5.4),(2.8,.35,2.6),3)
cube('grip',(-.9,-2.9,5.22),(1.8,.8,.2),5)
cube('grip',(-1.5,-6.8,5.3),(3,.35,2.8),2)
# Dorsal spirit wick: authored geometry cue, not a gameplay energy source.
cube('dorsal_fin',(-.3,4.2,3),(.6,2.4,.6),4)
cube('dorsal_fin',(-.2,6.4,3.1),(.4,1,.4),5)
for name,p in [('idle_view',(-5,7,16)),('iron_view',(0,4.7,10)),('thirdperson_hand',(0,-2,7)),('righthand_pos',(0,-3,10)),('lefthand_pos',(-3,-1,-1)),('muzzle_flash',(0,1.2,-13.5)),('ground',(0,0,0)),('fixed',(0,0,0)),('refit_view',(0,1,0)),('spirit_supply',(0,1,3.5)),('emitter_exit',(0,1.2,-13.5))]:bone(name,p)
# Full-size right-arm locator study; native TaCZ hand transforms remain a separate gate.
by['righthand_pos']['pivot']=[6,-4.1,17.5]
by['righthand_pos']['rotation']=[-90,0,0]
def keys(*v):return {str(t):p for t,p in v}
a={}
def clip(n,l,b,loop=False):a[n]={'animation_length':l,'loop':loop,'bones':b}
clip('static_auto',0,{})
clip('idle_spirit',3,{'spirit_core':{'rotation':keys((0,[0,0,0]),(1.5,[0,0,180]),(3,[0,0,360]))}},True)
clip('shoot',.2,{'root':{'position':keys((0,[0,0,0]),(.035,[0,0,.32]),(.12,[0,0,-.05]),(.2,[0,0,0]))},'pulse_ring':{'rotation':keys((0,[0,0,0]),(.05,[0,0,18]),(.2,[0,0,0]))},'emitter':{'position':keys((0,[0,0,0]),(.04,[0,0,.25]),(.2,[0,0,0]))}})
clip('draw',.65,{'root':{'rotation':keys((0,[20,-10,-15]),(.65,[0,0,0])),'position':keys((0,[0,-7,4]),(.65,[0,0,0]))}})
clip('put_away',.45,{'root':{'rotation':keys((0,[0,0,0]),(.45,[20,-10,-15])),'position':keys((0,[0,0,0]),(.45,[0,-7,4]))}})
clip('inspect',3,{'root':{'rotation':keys((0,[0,0,0]),(.7,[0,-20,12]),(1.5,[0,-20,12]),(2.3,[0,20,-10]),(3,[0,0,0]))}})
clip('spirit_recovery_visual',2,{'spirit_core':{'rotation':keys((0,[0,0,0]),(1,[0,0,180]),(2,[0,0,360]))},'pulse_ring':{'rotation':keys((0,[0,0,0]),(1,[0,0,-45]),(2,[0,0,0]))}})
g={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.ascension_armory.soul_storm','texture_width':128,'texture_height':128,'visible_bounds_width':4,'visible_bounds_height':3,'visible_bounds_offset':[0,0,0]},'bones':bones}]}
for rel,data in [('geo_models/gun/soul_storm_geo.json',g),('animations/soul_storm.animation.json',{'format_version':'1.8.0','animations':a}),('display/guns/soul_storm_display.json',{'model':'ascension_armory:gun/soul_storm_geo','texture':'ascension_armory:gun/uv/soul_storm','animation':'ascension_armory:soul_storm','third_person_animation':'default','show_crosshair':False,'iron_zoom':1.1})]:
 p=P/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2)+'\n')
manifest={'id':'aoa3:soul_storm','stage':'original spirit-blaster blockout; unqualified','cuboids':sum(len(b.get('cubes',[])) for b in bones),'bones':len(bones),'animation_records':len(a),'native_inputs':{'minecraft':'1.20.1','aoa':'3.7.1','damage_constructor_input':1.5,'durability':3190,'delay_ticks':1,'energy_cost_constructor_input':2.0},'rules':['Native Spirit resource and effects remain authoritative','No magazine, bullet substitution or forced reload','Recovery clip is cosmetic and never grants Spirit','One-tick native cadence must not be gated by a 0.2 second visual envelope'],'open':['Hand rig and native view fit','Complete spatial QA','Spirit resource adapter','Native first/third-person rendering','Sound/VFX and measured runtime acceptance']}
(R/'soul-storm-study/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(manifest)
