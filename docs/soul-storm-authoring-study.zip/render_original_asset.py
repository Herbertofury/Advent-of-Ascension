"""Source-derived studio preview. Run in Blender; no imported third-party assets."""
import bpy,json,math,sys,argparse
from pathlib import Path
from mathutils import Vector,Euler,Matrix
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--weapon',required=True);p.add_argument('--output',required=True);a=p.parse_args(args)
base=Path(a.root)/'assets/ascension_armory';g=json.loads((base/f'geo_models/gun/{a.weapon}_geo.json').read_text())['minecraft:geometry'][0]
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
image=bpy.data.images.load(str((base/f'textures/gun/uv/{a.weapon}.png').resolve()));pixels=list(image.pixels);w,h=image.size;cache={};C=Matrix(((1,0,0),(0,0,-1),(0,1,0)))
def v(x):return Vector((x[0],-x[2],x[1]))
def mat(uv):
 key=tuple(uv)
 if key not in cache:
  x=int(uv[0]);y=h-1-int(uv[1]);color=tuple(pixels[(y*w+x)*4:(y*w+x)*4+4]);m=bpy.data.materials.new('palette_'+str(key));m.diffuse_color=color;cache[key]=m
 return cache[key]
objects={};pivots={};meshes=[]
for b in g['bones']:
 pivot=v(b.get('pivot',[0,0,0]));ob=bpy.data.objects.new(b['name'],None);bpy.context.collection.objects.link(ob);pivots[b['name']]=pivot
 if b.get('parent'):ob.parent=objects[b['parent']];ob.location=pivot-pivots[b['parent']]
 else:ob.location=pivot
 rot=Euler(tuple(math.radians(x) for x in b.get('rotation',[0,0,0])),'XYZ').to_matrix();ob.rotation_euler=(C@rot@C.inverted()).to_euler();objects[b['name']]=ob
 for i,c in enumerate(b.get('cubes',[])):
  sz=Vector(c['size']);center=Vector(c['origin'])+sz/2;cr=Euler(tuple(math.radians(x) for x in c.get('rotation',[0,0,0])),'XYZ').to_matrix();cp=Vector(c.get('pivot',center));center=cp+cr@(center-cp)
  bpy.ops.mesh.primitive_cube_add(size=1);q=bpy.context.object;q.name=b['name']+'_'+str(i);q.parent=ob;q.location=v(center)-pivot;q.rotation_euler=(C@cr@C.inverted()).to_euler();q.scale=(sz.x,sz.z,sz.y);q.data.materials.append(mat(c['uv']['north']['uv']));meshes.append(q)
bpy.context.view_layer.update();points=[o.matrix_world@Vector(p) for o in meshes for p in o.bound_box];lo=Vector([min(p[i] for p in points) for i in range(3)]);hi=Vector([max(p[i] for p in points) for i in range(3)]);center=(lo+hi)/2;span=(hi-lo).length
bpy.ops.object.camera_add(location=center+Vector((1.1,1.3,.8)).normalized()*span*2);cam=bpy.context.object;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=span*1.16
scene=bpy.context.scene;scene.camera=cam;scene.render.engine='BLENDER_WORKBENCH';scene.display.shading.color_type='MATERIAL';scene.display.shading.show_cavity=True;scene.display.shading.cavity_type='BOTH';scene.render.resolution_x=1200;scene.render.resolution_y=850;scene.render.resolution_percentage=100;scene.render.film_transparent=True;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='Standard';scene.render.filepath=str(Path(a.output).resolve());bpy.ops.render.render(write_still=True)
