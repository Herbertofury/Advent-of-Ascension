const fs=require('fs'),path=require('path'),assert=require('assert'),M=require('./animation_core'),{corners,penetration}=require('./geometry_clearance');
const base=path.join(__dirname,'soul-storm-study/assets/ascension_armory'),g=JSON.parse(fs.readFileSync(path.join(base,'geo_models/gun/soul_storm_geo.json')))['minecraft:geometry'][0],a=JSON.parse(fs.readFileSync(path.join(base,'animations/soul_storm.animation.json'))).animations,model=M.compile(g,a);let failures=[],samples=0;
for(const [name,clip]of Object.entries(a)){
 let times=new Set([0,clip.animation_length]);for(let t=0;t<clip.animation_length;t+=1/120)times.add(t);for(const channels of Object.values(clip.bones))for(const keys of Object.values(channels))for(const t of Object.keys(keys))times.add(Number(t));
 for(const time of times){let p=M.pose(model,name,time);samples++;const solids=g.bones.flatMap(b=>(b.cubes||[]).map((c,i)=>({bone:b.name,id:b.name+':'+i,box:corners(b,c,p.get(b.name))})));
 for(const moving of solids.filter(s=>['spirit_core','pulse_ring','emitter'].includes(s.bone)))for(const fixed of solids){if(moving.bone===fixed.bone)continue;let d=penetration(moving.box,fixed.box);if(d>1e-6&&failures.length<30)failures.push({clip:name,time,moving:moving.id,fixed:fixed.id,depth:d});}
 }
}
const report={scope:'Original moving core, pulse ring and emitter versus other exported solids; 120 Hz plus keys. No hands, native renderer or continuous sweep certification.',samples,failures};assert.equal(failures.length,0);
// Negative fixture: a solid plate through the spirit core must be detected.
const staticPose=M.pose(model,'static_auto',0),core=g.bones.find(b=>b.name==='spirit_core');
const coreBox=corners(core,core.cubes[0],staticPose.get(core.name));
const obstruction={name:'fixture',pivot:[0,0,0]},plate={origin:[-2,.8,2],size:[4,.4,3]};
assert(penetration(coreBox,corners(obstruction,plate,p=>p))>0.01,'Detector must reject a known core obstruction');
console.log('PASS: negative obstruction fixture detected; fixture is not exported.');

report.negative_fixture='Known core-obstruction plate detected; not exported';fs.writeFileSync(path.join(__dirname,'soul-storm-study/spatial-qa.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
