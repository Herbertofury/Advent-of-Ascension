# Original Soul Storm authoring study

Work in progress, not an installable mod. Original geometry, palette, numeric keyframes, cosmetic recoil and tests. AoA identity: Tslat and contributors. Reference pack assets and game binaries are not included.

Requires Python with Pillow and Node. Create a sibling aoa-expansion directory. Run python build_soul_storm.py; python build_soul_storm_lab.py; node test_soul_storm.cjs; node test_soul_storm_hand.cjs; node test_cosmetic_recoil.cjs; node test_soul_storm_viewer.cjs.

The core and emitter moving-solid tests are sampled, not a continuous-collision proof. Right-arm boxes approximate documented Steve/Alex conventions; they do not certify actual hands/FOV/skins. Cosmetic pulses preserve current recoil pose and never authorize gameplay or grant Spirit. No conventional ammunition or mandatory reload is introduced. Native 1.20.1 AoA3.7.1 contracts still need a real tested adapter.

Open: complete hand choreography, original sound/VFX, polished material detail, native TaCZ display/export validation, multiplayer, saved-item migration and measured runtime performance. Seven clips and passing scoped tests do not mean a finished weapon.
