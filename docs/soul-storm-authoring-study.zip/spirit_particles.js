/* Original bounded authoring-only spirit wisps. No entity, damage or resource logic. */
class SpiritParticles {
 constructor(capacity=24){if(!Number.isInteger(capacity)||capacity<1||capacity>256)throw Error('Invalid pool');this.capacity=capacity;this.pool=Array.from({length:capacity},()=>({age:1,life:0}));this.cursor=0;this.sequence=0;}
 burst(origin,count=4){
  if(!Array.isArray(origin)||origin.length!==3||!origin.every(Number.isFinite)||!Number.isInteger(count)||count<0)throw Error('Invalid burst');
  for(let i=0;i<Math.min(count,this.capacity);i++){
   const n=this.sequence;this.sequence=(this.sequence+1)%65536;const angle=n*2.399963229728653,p=this.pool[this.cursor];this.cursor=(this.cursor+1)%this.capacity;
   Object.assign(p,{age:0,life:.28+(n%5)*.025,origin:[...origin],velocity:[Math.cos(angle)*2,Math.sin(angle)*2,-7-(n%3)],size:.11+(n%3)*.035});
  }
 }
 step(dt){if(!Number.isFinite(dt)||dt<0)throw Error('Invalid elapsed time');for(const p of this.pool)if(p.age<p.life)p.age=Math.min(p.life,p.age+dt);}
 get active(){return this.pool.some(p=>p.age<p.life);}
 visible(){return this.pool.filter(p=>p.age<p.life).map(p=>({position:p.origin.map((v,i)=>v+p.velocity[i]*p.age+(i===1?p.age*p.age*1.5:0)),opacity:(1-p.age/p.life)*.55,size:p.size*(1+p.age*2)}));}
 clear(){for(const p of this.pool)p.age=p.life;}
}
if(typeof module!=='undefined')module.exports=SpiritParticles;
