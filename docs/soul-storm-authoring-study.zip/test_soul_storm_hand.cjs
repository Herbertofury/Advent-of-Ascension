const fs=require('fs'),path=require('path'),assert=require('assert'),M=require('./animation_core'),{corners,penetration}=require('./geometry_clearance');
const root=path.join(__dirname,'soul-storm-study'),base=path.join(root,'assets/ascension_armory');let profiles=[];
for(const width of [4,3]){
 const g=JSON.parse(fs.readFileSync(path.join(base,'geo_models/gun/soul_storm_geo.json')))['minecraft:geometry'][0],a=JSON.parse(fs.readFileSync(path.join(base,'animations/soul_storm.animation.json'))).animations,hand=g.bones.find(b=>b.name==='righthand_pos');
 hand.cubes=[{origin:hand.pivot.map((x,i)=>x+[-8+(4-width),0,-2][i]),size:[width,12,4]}];const model=M.compile(g,a);let samples=0,failures=[],gripSeen=false;
 for(const [name,c]of Object.entries(a))for(let f=0;f<=Math.ceil(c.animation_length*120);f++){
  const time=Math.min(f/120,c.animation_length),p=M.pose(model,name,time),box=corners(hand,hand.cubes[0],p.get(hand.name)),fore=corners(hand,{...hand.cubes[0],size:[width,8,4]},p.get(hand.name));samples++;
  for(const b of g.bones)for(const [i,cube] of (b.cubes||[]).entries()){
   if(b===hand)continue;const part=corners(b,cube,p.get(b.name)),d=penetration(box,part);if(d<=1e-6)continue;
   if(b.name==='grip'&&i<=5&&d<=Math.min(...cube.size)+1e-6&&penetration(fore,part)<=1e-6){gripSeen=true;continue;}
   if(failures.length<20)failures.push({name,time,part:b.name+':'+i,depth:d});
  }
 }
 profiles.push({width,samples,gripSeen,failures});
}
const report={scope:'Documented Steve/Alex right-arm box convention at 120Hz. Only named grip components allow palm contact; forearm penetration forbidden. Native renderer/FOV/skin fit untested; left-hand choreography remains open.',profiles};fs.writeFileSync(path.join(root,'hand-fit-qa.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));assert(profiles.every(p=>p.gripSeen&&!p.failures.length));
