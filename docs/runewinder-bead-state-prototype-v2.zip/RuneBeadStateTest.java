import java.util.*;
public final class RuneBeadStateTest {
 static void check(boolean x){if(!x)throw new AssertionError();}
 static void fails(Runnable f){try{f.run();throw new AssertionError("expected invalid input");}
  catch(IllegalArgumentException|IllegalStateException|UnsupportedOperationException expected){}}
 static List<RuneBeadState.Bead> ring(int n){List<RuneBeadState.Bead> b=new ArrayList<>();
  for(int i=0;i<n;i++)b.add(new RuneBeadState.Bead("bead-"+i,i%2==0?RuneBeadState.Element.ICE:RuneBeadState.Element.FIRE));return b;}
 public static void main(String[] args){
  RuneBeadState state=new RuneBeadState("owner:epoch1",ring(8));
  check(state.capacity()==8&&state.remaining()==8);
  List<RuneBeadState.Bead> identity=state.beads();
  for(int i=0;i<8;i++){
   check(state.confirm(i,false,false).isEmpty());check(state.confirm(i,true,true).isEmpty());
   RuneBeadState.Shot shot=state.confirm(i,true,false).orElseThrow();
   check(shot.slot()==i&&shot.element()==identity.get(i).element());check(!state.lit(i));
   check(state.capacity()==8&&state.beads().equals(identity)&&state.remaining()==7-i);
   check(state.confirm(i,true,false).isEmpty());
  }
  check(state.confirm(8,true,false).isEmpty());
  state.simulateSuccessfulManaCharge(0,1,2,3,4,5,6,7);check(state.remaining()==8);
  check(state.confirm(8,true,false).isEmpty()); // empty attempt cannot replay after charge
  check(state.confirm(9,true,false).orElseThrow().slot()==0);
  RuneBeadState.Snapshot snap=state.snapshot();RuneBeadState restored=new RuneBeadState("owner:epoch1",snap);
  check(restored.snapshot().equals(snap));check(restored.confirm(9,true,false).isEmpty());
  check(restored.confirm(10,true,false).orElseThrow().slot()==1);
  fails(()->restored.beads().clear());fails(()->snap.charged().clear());
  int before=restored.remaining();fails(()->restored.simulateSuccessfulManaCharge(0,99));check(restored.remaining()==before);
  fails(()->restored.simulateSuccessfulManaCharge(0,0));check(restored.remaining()==before);
  restored.close();check(restored.confirm(11,true,false).isEmpty());fails(()->restored.simulateSuccessfulManaCharge(0));
  for(int n:new int[]{1,2,8,40,64}){
   RuneBeadState s=new RuneBeadState("n:"+n,ring(n));
   for(int i=0;i<n;i++)check(s.confirm(i,true,false).isPresent());check(s.remaining()==0&&s.capacity()==n);
   s.simulateSuccessfulManaCharge(n-1);check(s.remaining()==1);
   check(s.confirm(n,true,false).orElseThrow().slot()==n-1);check(s.remaining()==0);
  }
  fails(()->new RuneBeadState("zero",ring(0)));fails(()->new RuneBeadState("large",ring(65)));
  fails(()->new RuneBeadState("duplicates",List.of(identity.get(0),identity.get(0))));
  // 10,000 complete cycles retain all bead identities and alternating order.
  RuneBeadState stress=new RuneBeadState("stress:epoch",ring(8));
  for(int cycle=0;cycle<10000;cycle++){
   if(cycle>0)stress.simulateSuccessfulManaCharge(0,1,2,3,4,5,6,7);
   for(int i=0;i<8;i++){var shot=stress.confirm((long)cycle*8+i,true,false).orElseThrow();check(shot.slot()==i&&shot.element()==identity.get(i).element());}
   check(stress.remaining()==0&&stress.capacity()==8&&stress.beads().equals(identity));
  }
  System.out.println("PASS: capacity from bead count, ordered elements, dark/relit persistent beads, replay guards, immutable snapshots, partial-charge policy, atomic invalid-input rejection and 80000 stress shots. Simulated mana only; no native compatibility claim.");
 }
}
