import java.util.*;
/** Deterministic game-state candidate, not a native mana adapter or damage implementation.
 * Existing EmitterSequence guards accepted primary events. Single-thread owner only.
 */
public final class RuneBeadState {
    public enum Element { ICE, FIRE, PURPLE_FIRE, CYAN_SOULFIRE, POISON, FOREST }
    public record Bead(String id, Element element) {
        public Bead { if (id == null || id.isBlank() || id.length()>128 || element==null)
            throw new IllegalArgumentException("bead identity"); }
    }
    public record Shot(int slot, String beadId, Element element) {}
    public record Snapshot(List<Bead> beads, List<Boolean> charged, int next, long lastSequence) {
        public Snapshot { beads=List.copyOf(beads); charged=List.copyOf(charged); }
    }
    private final List<Bead> beads;
    private final boolean[] charged;
    private final EmitterSequence guard = new EmitterSequence(1);
    private final String epoch;
    private int next;
    private long lastSequence = -1;
    private boolean closed;
    public RuneBeadState(String epoch, List<Bead> beads) {
        this(epoch,new Snapshot(beads,Collections.nCopies(beads.size(),true),0,-1));
    }
    public RuneBeadState(String epoch, Snapshot saved) {
        int n=saved.beads().size();
        if(n<1||n>64||saved.charged().size()!=n||saved.next()<0||saved.next()>=n||saved.lastSequence() < -1)
            throw new IllegalArgumentException("snapshot bounds (isolated prototype limit 64)");
        Set<String> ids=new HashSet<>();for(Bead bead:saved.beads())
            if(!ids.add(bead.id()))throw new IllegalArgumentException("duplicate bead identity");
        this.beads=List.copyOf(saved.beads());this.charged=new boolean[n];
        for(int i=0;i<n;i++)this.charged[i]=saved.charged().get(i);
        this.next=saved.next();this.lastSequence=saved.lastSequence();this.epoch=epoch;
        guard.begin(epoch,n);
        // Seed replay protection only; restoration spends no bead and emits no projectile.
        if(lastSequence>=0)guard.confirm(epoch,lastSequence,true,false);
    }
    public int capacity(){return beads.size();}
    public int remaining(){int n=0;for(boolean c:charged)if(c)n++;return n;}
    public List<Bead> beads(){return beads;}
    public boolean lit(int slot){return charged[Objects.checkIndex(slot,charged.length)];}
    public Optional<Shot> confirm(long sequence, boolean accepted, boolean bonus) {
        if(closed||guard.confirm(epoch,sequence,accepted,bonus)<0)return Optional.empty();
        lastSequence=sequence;
        // Partial-charge policy candidate: skip dark beads without changing necklace order.
        for(int scanned=0;scanned<charged.length;scanned++) {
            int slot=(next+scanned)%charged.length;
            if(charged[slot]) {
                charged[slot]=false;next=(slot+1)%charged.length;
                Bead bead=beads.get(slot);return Optional.of(new Shot(slot,bead.id(),bead.element()));
            }
        }
        return Optional.empty();
    }
    /** Test-only charge transition. Does NOT debit mana or certify a provider receipt.
     * Intentionally package-private: native adapters must implement transaction semantics.
     */
    void simulateSuccessfulManaCharge(int... slots) {
        if(closed)throw new IllegalStateException("closed");
        // Validate the entire operation before touching state, including duplicate slots.
        Set<Integer> seen=new HashSet<>();
        for(int slot:slots)if(slot<0||slot>=charged.length||!seen.add(slot))
            throw new IllegalArgumentException("charge slot");
        for(int slot:slots)charged[slot]=true;
    }
    public Snapshot snapshot(){List<Boolean> flags=new ArrayList<>();for(boolean c:charged)flags.add(c);
        return new Snapshot(beads,flags,next,lastSequence);}
    public void close(){guard.end(epoch);closed=true;}
}
