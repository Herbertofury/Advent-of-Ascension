# Runewinder bead-state candidate

This adds the owner-requested persistent bead state to the earlier cosmetic pose-target study. Capacity is the ordered bead list length; a confirmed primary shot turns one charged bead dark without deleting it. The next available charged bead supplies its element. Mixed ice/fire order and bead identities remain unchanged over recharge.

The existing EmitterSequence.java is reused unchanged. Duplicate/rejected/bonus events do not spend beads. Empty accepted-event IDs remain consumed in the replay guard so the same event cannot fire after a recharge. The single-threaded snapshot preserves ordered IDs/elements, charge flags, next cursor and last sequence; it is an immutable in-memory value, not a tested native save-file format.

simulateSuccessfulManaCharge is package-private and test-only. It performs no actual mana debit and must not be exposed as a free gameplay refill. Native providers require an atomic/transactional adapter with explicit failure semantics, cost, authorization and save/network handling. No Ars Nouveau, Iron’s Spells/IronsArms or Botania compatibility is claimed.

Partial-charge policy candidate: dark slots are skipped without rearranging the necklace; confirm this against final gameplay/UI design. The isolated fixture limits necklaces to 64 beads for bounded tests; this is not a final capacity balance decision. A functional capacity upgrade must preserve all bead IDs and provide an authored path that fits the chamber.

Checks cover configurable sizes 1/2/8/40/64, persistent darkness/relighting, mixed sequence, replay after recharge and snapshot restoration, immutable outputs, invalid-charge all-or-nothing validation and 80,000 stress shots. Run all three Java test mains with JDK 17. Tests do not establish native event authority, atomic external mana debit, model/animation quality, networking or performance.

The approved access cover is a smooth transparent sleeve rotating around the chamber like a bank-tube carrier. The earlier segmented reload sheet is rejected; the corrected image is not available. No new graphic substitutes for it in this package.
