package io.github.herbertofury.shyrestudy;

import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;
import net.tslat.aoa3.common.registration.AoAGameRules;
import net.tslat.aoa3.content.capability.volatilestack.VolatileStackCapabilityProvider;
import net.tslat.aoa3.content.item.weapon.maul.BaseMaul;

/** Original bounded native-server fixtures. Direct hook calls do not certify player input or final combat. */
@GameTestHolder(ShyreStudy.MOD_ID)
@PrefixGameTestTemplate(false)
public final class MaulGameTests {
    private static void combined(GameTestHelper h) {
        h.assertTrue(ModList.get().isLoaded("aoa3") && ModList.get().isLoaded("tacz"), "Both AoA and TaCZ must be loaded");
    }
    private static ItemStack stack(String name) {
        return new ItemStack(BuiltInRegistries.ITEM.get(new ResourceLocation("aoa3", name + "_maul")));
    }
    private static double amount(ItemStack stack, Attribute attribute) {
        return stack.getItem().getAttributeModifiers(EquipmentSlot.MAINHAND, stack).get(attribute).stream().mapToDouble(m -> m.getAmount()).sum();
    }
    private static void near(GameTestHelper h, double expected, double actual, String label) {
        h.assertTrue(Math.abs(expected-actual)<.00001, label+" expected="+expected+" actual="+actual);
    }
    @GameTest(template="empty")
    public static void allFiveRegisteredInputs(GameTestHelper h) {
        combined(h);
        String[] names={"coralstone","crystal","electron","horizon","vulcammer"};
        double[] damage={26.5,23.5,25,23,28},knockback={8.5,7.2,2.5,7,8.2};int[] durability={1600,1400,1500,1300,1750};
        for(int i=0;i<names.length;i++){
            ItemStack s=stack(names[i]);h.assertTrue(s.getItem() instanceof BaseMaul,"Original maul class: "+names[i]);
            near(h,damage[i],amount(s,Attributes.ATTACK_DAMAGE),names[i]+" damage addition");
            near(h,knockback[i],amount(s,Attributes.ATTACK_KNOCKBACK),names[i]+" knockback addition");
            near(h,-3.472,amount(s,Attributes.ATTACK_SPEED),names[i]+" speed addition");
            near(h,.5,amount(s,ForgeMod.ENTITY_REACH.get()),names[i]+" reach addition");
            h.assertTrue(s.getMaxDamage()==durability[i],names[i]+" durability");
            h.assertTrue(s.getItem().getAttributeModifiers(EquipmentSlot.OFFHAND,s).isEmpty(),names[i]+" offhand attributes");
        }
        h.succeed();
    }
    private static Zombie entity(GameTestHelper h,int x) {
        Zombie z=h.spawnWithNoFreeWill(EntityType.ZOMBIE,x,1,2);z.getAttribute(Attributes.MAX_HEALTH).setBaseValue(200);z.setHealth(200);return z;
    }
    private static void effect(GameTestHelper h,ItemStack s,Zombie attacker,Zombie target,float charge) {
        attacker.setItemSlot(EquipmentSlot.MAINHAND,s);
        VolatileStackCapabilityProvider.getOrDefault(s,Direction.NORTH).setValue(charge);
        h.assertTrue(s.getItem().hurtEnemy(s,target,attacker),"Original hurtEnemy hook returned true");
    }
    @GameTest(template="empty")
    public static void crystalAtZeroCharge(GameTestHelper h) {
        combined(h);ItemStack s=stack("crystal");Zombie a=entity(h,2),t=entity(h,4);effect(h,s,a,t,0);
        var status=t.getEffect(MobEffects.MOVEMENT_SLOWDOWN);h.assertTrue(status!=null,"Crystal applies slowness without full charge");
        h.assertTrue(status.getDuration()==40 && status.getAmplifier()==1,"Exact requested slowness duration/amplifier");
        h.assertTrue(s.getDamageValue()==1,"Original melee durability helper");h.succeed();
    }
    @GameTest(template="empty")
    public static void horizonChargeBoundary(GameTestHelper h) {
        combined(h);ItemStack s=stack("horizon");Zombie a=entity(h,2),t=entity(h,4);effect(h,s,a,t,.999f);
        h.assertTrue(!t.hasEffect(MobEffects.LEVITATION),"Near-full charge must not qualify");effect(h,s,a,t,1f);
        var status=t.getEffect(MobEffects.LEVITATION);h.assertTrue(status!=null,"Exact full charge requests levitation");
        h.assertTrue(status.getDuration()==35 && status.getAmplifier()==0,"Exact levitation request");
        t.removeEffect(MobEffects.LEVITATION);t.setInvulnerable(true);effect(h,s,a,t,1f);
        h.assertFalse(t.hasEffect(MobEffects.LEVITATION),"Original special-attack immunity remains active");h.succeed();
    }
    @GameTest(template="empty")
    public static void electronStoredMultiplier(GameTestHelper h) {
        combined(h);ItemStack s=stack("electron");var cap=VolatileStackCapabilityProvider.getOrDefault(s,null);
        for(float multiplier:new float[]{0,1,1.5f,2}){
            cap.setValue(multiplier);near(h,2.5*(multiplier==0?1:multiplier),amount(s,Attributes.ATTACK_KNOCKBACK),"Stored multiplier "+multiplier);
        }
        VolatileStackCapabilityProvider.getOrDefault(s,Direction.NORTH).setValue(.25f);
        near(h,.625,amount(s,Attributes.ATTACK_KNOCKBACK),"NORTH and unkeyed accesses alias the same value");
        h.assertTrue(cap == VolatileStackCapabilityProvider.getOrDefault(s,Direction.NORTH),"Same native capability identity");
        var player=FakePlayerFactory.getMinecraft(h.getLevel());player.setItemSlot(EquipmentSlot.MAINHAND,s);player.resetAttackStrengthTicker();
        float captured=player.getAttackStrengthScale(0);cap.setValue(2);
        h.assertFalse(s.getItem().onLeftClickEntity(s,player,entity(h,4)),"Original left-click hook preserves normal attack processing");
        near(h,captured,cap.getValue(),"Original left-click hook overwrites the shared value with attack strength");
        player.setItemSlot(EquipmentSlot.MAINHAND,ItemStack.EMPTY);h.succeed();
    }
    @GameTest(template="empty")
    public static void vulcammerNonDestructiveBoundary(GameTestHelper h) {
        combined(h);h.assertFalse(AoAGameRules.checkDestructiveWeaponPhysics(h.getLevel()),"Fixture requires default non-destructive rule");
        ItemStack s=stack("vulcammer");Zombie a=entity(h,2),t=entity(h,4);t.clearFire();effect(h,s,a,t,.85f);
        h.assertTrue(t.getRemainingFireTicks()<=0,"Exact .85 must not trigger the special effect");effect(h,s,a,t,1f);
        h.assertTrue(t.getRemainingFireTicks()==60,"Non-destructive hostile-target loop requests three seconds of fire");h.succeed();
    }
}
