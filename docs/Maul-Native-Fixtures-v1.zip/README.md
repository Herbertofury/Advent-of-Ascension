# Original maul native-server fixtures

These five fixtures run actual AoA 3.7.1 registered item methods with TaCZ 1.1.8-hotfix2 present in Minecraft 1.20.1 / Forge 47.4.28. They are direct hook/attribute tests, not ordinary player-input, full combat, art, multiplayer or performance acceptance.

Use the original Shyre v8 source bundle as the known Forge project scaffold. Copy MaulGameTests.java into dev/src/main/java/io/github/herbertofury/shyrestudy/. Copy the original empty.nbt fixture into dev/src/main/resources/data/shyre_study/structures/. Apply test-build.patch: it adds AoA to the compile classpath and gives GameTest a separate run-maul-gametest working directory and bounded heap. Use Java 17 and the separately obtained exact dependency archives already listed in the v8 bundle, then run Gradle build and runGameTestServer. The tested workspace used study version 0.0.9-local-study. No game/mod binaries or player/world data are included here.

Retained failure: the first run passed four tests and rejected an incorrect assumption that NORTH and unkeyed capability accesses were separate. The provider ignores direction. The corrected test checks capability object identity and calls the original inherited left-click hook with a Forge fake player, proving that captured attack strength overwrites the same value used by Electron's periodic spirit-derived update. No original AoA implementation was patched to make the tests pass.

The fixture mobs have 200 health to survive the bounded non-destructive explosion case; they are not globally invulnerable, which would incorrectly suppress Horizon's legitimate effect. Horizon's explicit invulnerability negative control is tested separately.

The first failed log and corrected complete log are retained privately; native-checkpoint.json records their hashes and the exact tested scope. The corrected run reported all five required tests passed and exited normally. A reproducible fixture is not a claim of final weapon acceptance.
