"""Original three-channel cosmetic recoil authoring fixture, not native gameplay."""
import bpy,json,argparse,sys
from pathlib import Path
from mathutils import Vector
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args(sys.argv[sys.argv.index('--')+1:]);R=args.output;R.mkdir(parents=True,exist_ok=True);bpy.ops.wm.open_mainfile(filepath=str(args.source));root=bpy.data.objects['Discharge_Root'];centers=[1.16,.68,.2];groups=[];mapping=[]
# Recess only the receiver nose to leave room for the complete moving assembly at peak recoil.
receiver=bpy.data.objects['Receiver spine'];inverse=receiver.matrix_world.inverted();trimmed=0
for v in receiver.data.vertices:
 world=receiver.matrix_world@v.co
 if world.x>2.80:
  world.x=2.80;v.co=inverse@world;trimmed+=1
assert trimmed>0
for i,zc in enumerate(centers):
 e=bpy.data.objects.new('Discharge_emitter_'+str(i+1)+'_top_to_bottom',None);bpy.context.collection.objects.link(e);e.parent=root;groups.append(e)
 glow=bpy.data.materials['V23 bounded red aperture rim'].copy();glow.name='Discharge emitter '+str(i+1)+' local glow'
 for o in list(bpy.data.objects):
  if o.hide_render or not o.name.startswith(('V23 port housing','V23 recessed aperture liner','V23 red aperture outline','V27 recessed energy throat','Muzzle horizontal segment')):continue
  if o.type not in {'MESH','CURVE'}:continue
  z=sum((o.matrix_world@Vector(c)).z for c in o.bound_box)/8
  nearest=min(range(3),key=lambda j:abs(centers[j]-z))
  if nearest!=i:continue
  assert abs(z-zc)<.23,(o.name,z,zc)
  world=o.matrix_world.copy();o.parent=e;o.matrix_world=world
  for slot in o.material_slots:
   if slot.material and slot.material.name=='V23 bounded red aperture rim':slot.material=glow
  mapping.append({'object':o.name,'emitter_index':i,'bone':e.name})
 start=1+i*165
 for frame,x in [(1,0),(start,0),(start+2,-.075),(start+5,.008),(start+9,0),(340,0)]:e.location.x=x;e.keyframe_insert('location',frame=frame)
 p=glow.node_tree.nodes.get('Principled BSDF')
 for frame,strength in [(1,2.0),(start,2.0),(start+1,6),(start+3,2.0),(340,2.0)]:p.inputs['Emission Strength'].default_value=strength;p.inputs['Emission Strength'].keyframe_insert('default_value',frame=frame)
 if e.animation_data:
  for fc in e.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.interpolation='BEZIER';k.handle_left_type='AUTO_CLAMPED';k.handle_right_type='AUTO_CLAMPED'
s=bpy.context.scene;s.render.fps=60;s.render.fps_base=1;s.frame_start=1;s.frame_end=340;s.frame_set(1);bpy.context.view_layer.update()
assert all(any(row['emitter_index']==i for row in mapping)for i in range(3))
bpy.ops.wm.save_as_mainfile(filepath=str(R/'discharge-recoil-study.blend'))
(R/'manifest.json').write_text(json.dumps({'status':'unaccepted cosmetic authoring fixture','mapping':mapping,'fps':60,'shot_start_frames':[1,166,331],'timing_note':'Nominal 55 ticks at 20TPS represented at 60 authoring FPS; not an implemented fire-rate scheduler','native_tested':False,'original_projectile_burst_count':4,'visual_channels':3,'receiver_nose_max_x':2.80,'receiver_nose_trimmed_vertices':trimmed,'limits':['Native confirmed-shot binding remains untested','No full sweep collision, hands or ammo animation QA','Local material keyframes need separate native implementation']},indent=2)+'\n')
print('Mapped current-scene',len(mapping),'parts to',len(groups),'emitter owners')
