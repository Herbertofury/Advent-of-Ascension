# Discharge combined exterior/recoil authoring patch v33

Builds the corrected v32-r3 rooted exterior and existing three-channel recoil in one scene, from the exact v31 authoring input. This is a Blender study and position-only animation fixture, not an installable Minecraft mod or native acceptance.

Requires Blender 4.3.2 and discharge-authoring-study.blend from https://github.com/Herbertofury/Advent-of-Ascension/raw/refs/heads/main/docs/discharge-exterior-authoring-study-v31.zip
Source SHA-256: 81e2a42d29e4f690ba83ed62f67202af47c28e5f6c9e950c8e5b0cbd15b19cc5.

blender -b -t 2 --python-exit-code 1 --python assemble.py -- --source /path/discharge-authoring-study.blend --output /path/v33-output
blender -b -t 2 --python-exit-code 1 --python check.py -- --directory /path/v33-output
blender -b -t 2 --python-exit-code 1 --python check_geometry.py -- --directory /path/v33-output
blender -b -t 2 --python-exit-code 1 --python check_surface_sweep.py -- --directory /path/v33-output
blender -b -t 2 --python-exit-code 1 --python export_clips.py -- --directory /path/v33-output

The first stage validates the original source hash, captures new-part transforms only after dependency-graph evaluation and parents added parts to Discharge_Root. The second stage groups six visible muzzle pieces under each of three cosmetic emitters. The existing v4 local nose-clearance adjustment is retained. The original four-projectile gameplay burst is not changed by three cosmetic channels. Material glow keyframes remain Blender-only until implemented in a native adapter.

Scoped results: 340 integer frames / 6,120 owned-part transform samples; 119,880 quarter-frame moving-versus-other triangle-surface pairs without baseline or new intersections in the tested scene. Same-owner intersections, complete containment, hands, native interpolation, attachment combinations and continuous collision remain outside that result. No universal collision-free claim.

Three exported clips contain 111 keyframes total. The JSON bytes match the previously isolated tested clip data; 18 hash-checked released TaCZ animation parser classes accepted it on Java17/21 with documented helper stand-ins. This is parser evidence, not native bone/coordinate binding, resource scheduling, gameplay, sound, interpolation or performance acceptance. The parser harness is linked through the existing released-parser study, not bundled vendor classes.

The archive stores original build/check tooling and small reports rather than another large full-scene backup. Output scene and exports are generated locally. Re-run native tests and visual QA before any release claim. Full model fidelity, texture baking, hands, gameplay, effects and measured performance are still open.
