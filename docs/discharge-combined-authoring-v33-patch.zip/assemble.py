import argparse,sys,runpy
from pathlib import Path
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);source=a.source.resolve();out=a.output.resolve();saved=list(sys.argv)
try:
 sys.argv=['blender','--','--source',str(source),'--output',str(out/'rooted-exterior')];runpy.run_path(str(R/'root_patch.py'),run_name='__main__')
 sys.argv=['blender','--','--source',str(out/'rooted-exterior/discharge-rear-contour.blend'),'--output',str(out)];runpy.run_path(str(R/'recoil_phase.py'),run_name='__main__')
finally:sys.argv=saved
