import zipfile,io,json,hashlib
from PIL import Image
from pathlib import Path
R=Path(__file__).resolve().parent;P=R.parent/'references';cases=[('Ars Armorer','ars-armorer-v1.0.1.zip','assets/ars_armorer/textures/gun/uv/shotgun_jet_ejector_uv.png','https://www.curseforge.com/minecraft/customization/tacz-ars-armorer-koei'),('Create Armorer','create-armorer-v1.2.0.1-for117.zip','assets/create_armorer/textures/gun/uv/shotgun_db_stone.png','https://www.curseforge.com/minecraft/customization/tacz-create-armorer-koei'),('Helldivers','helldivers-9069318-hotfix.zip','assets/zeta/textures/gun/uv/quasar.png','https://www.curseforge.com/minecraft/customization/tacz-helldivers-escalation-of-freedom')];rows=[]
for title,file,selected,url in cases:
 data=(P/file).read_bytes()
 with zipfile.ZipFile(io.BytesIO(data))as z:
  uv=[n for n in z.namelist()if '/textures/gun/uv/'in n and n.endswith('.png')];sizes={}
  for n in uv:
   im=Image.open(io.BytesIO(z.read(n)));key=f'{im.width}x{im.height}';sizes[key]=sizes.get(key,0)+1
  raw=z.read(selected);im=Image.open(io.BytesIO(raw));rows.append({'pack':title,'archive':file,'archive_sha256':hashlib.sha256(data).hexdigest(),'source':url,'uv_folder_png_count':len(uv),'dimensions_histogram':sizes,'selected_texture':selected,'selected_dimensions':list(im.size),'selected_sha256':hashlib.sha256(raw).hexdigest(),'scope':'Actual archive PNG inspection. UV-folder inventory can include extra shader/alternate maps; not a count of weapons or a runtime material-support claim.'})
(R/'texture-study.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
