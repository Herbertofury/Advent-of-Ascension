# Discharge Shotgun released-file study

Original audit tooling and concept prompts. Obtain AoA3-1.20.1-3.7.1-all.jar from its official release; the game/mod archive and decoded classes are not bundled. AoA belongs to Tslat and contributors.

Set JAVA_HOME to a full JDK and run:

    python audit_discharge.py /path/to/AoA3-1.20.1-3.7.1-all.jar evidence.json

The script verifies the exact archive SHA-512 before using javap for static reading. It checks the ammo/projectile references and the ordered weapon then projectile entity-hit callbacks. Constructor arguments, renderer bootstrap mapping and semantics in the report were also manually traced against this exact release. It does not simulate a running game, final explosion damage, permissions, range or compatibility.

Concept v1 was generated with the built-in image tool using the released sprite as a reference. Concept v2 corrects the cropped bottom grip of C while retaining the design direction. Both variants are preserved in the repository. Generated pixel-style insets are reconstructions; the separately published original sprite and projectile are exact released assets. Effects shown in the concept are proposals, not native-game captures.
