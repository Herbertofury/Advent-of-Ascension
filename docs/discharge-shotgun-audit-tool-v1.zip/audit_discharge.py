"""Read pinned AoA release classes with javap; never execute game classes."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,zipfile
EXPECTED='bdee7d12aab1903e1e74f377d4f0ae7ac948d791f46ec0368d191d86a3d5a03cfbd2e6d1295f1fe690f303b1fa709da89db980543e4d450fc0fdbbf6d9e694e6'
CLASSES=['common.registration.item.AoAWeapons','content.item.weapon.shotgun.DischargeShotgun','content.item.weapon.shotgun.BaseShotgun','content.item.weapon.gun.BaseGun','content.entity.projectile.gun.BaseBullet','content.entity.projectile.gun.DischargeShotEntity','util.WorldUtil','client.AoAEntityRendering']
p=argparse.ArgumentParser(description=__doc__);p.add_argument('jar',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
assert hashlib.sha512(a.jar.read_bytes()).hexdigest()==EXPECTED,'Wrong release archive'
home=os.environ.get('JAVA_HOME');tool=str(Path(home)/'bin'/('javap.exe' if os.name=='nt' else 'javap')) if home else shutil.which('javap')
if not tool:raise SystemExit('Set JAVA_HOME to a full JDK')
text={};hashes={}
with zipfile.ZipFile(a.jar) as z:
 for c in CLASSES:
  name='net.tslat.aoa3.'+c;path=name.replace('.','/')+'.class';hashes[path]=hashlib.sha256(z.read(path)).hexdigest();text[c]=subprocess.check_output([tool,'-c','-p','-classpath',str(a.jar),name],text=True)
 direct_json=[n for n in z.namelist() if n.startswith('data/aoa3/') and n.endswith('.json') and b'aoa3:discharge_shotgun' in z.read(n)]
 assets={n:hashlib.sha256(z.read(n)).hexdigest() for n in ['assets/aoa3/textures/item/discharge_shotgun.png','assets/aoa3/textures/entity/projectile/bullets/discharge_shot.png']}
shot=text['content.item.weapon.shotgun.DischargeShotgun'];bullet=text['content.entity.projectile.gun.BaseBullet'];projectile=text['content.entity.projectile.gun.DischargeShotEntity']
assert 'AoAItems.DISCHARGE_CAPSULE' in shot
assert 'class net/tslat/aoa3/content/entity/projectile/gun/DischargeShotEntity' in shot
assert 'float 2.5f' in shot and 'float 1.8f' in projectile
hit=bullet.split('protected void m_5790_(')[1].split('protected void m_6532_(')[0]
assert hit.index('BaseGun.doImpactDamage:')<hit.index('Method doEntityImpact:')
assert 'Field lifespan:I' in bullet and 'if_icmple' in bullet
report={'scope':'Static released bytecode and exact asset evidence; not game testing','release':'AoA3-1.20.1-3.7.1-all.jar','archive_sha512':EXPECTED,'classes_sha256':hashes,'asset_sha256':assets,
 'registry_constructor':{'method':'AoAWeapons.lambda$static$100','arguments':[0.0,4,160,55,0.0,13.0],'meanings':['base damage input','pellet count','durability input','firing-delay ticks','knockback input','stored recoil input']},
 'behavior':{'ammo':'DISCHARGE_CAPSULE','spawned_projectile':'DischargeShotEntity','ammo_check':'Once before pellet loop','pellet_count':4,'full_automatic':False,'projectile_lifespan_input':4,'projectile_damage_multiplier_input':1.0,'piercing_input':0,'gravity_return':0.0,'entity_hit_call_order':['weapon.doImpactDamage requests explosion strength 2.5 when weapon and living owner exist','projectile.doEntityImpact requests explosion strength 1.8'],'block_hit':'projectile.doBlockImpact requests explosion strength 1.8','impact_position':'WorldUtil overload uses projectile entity coordinates, not the supplied hit-vector argument','expiry':'age > lifespan is checked after superclass tick; do not call input4 an exact four-tick range guarantee','terrain':'WorldUtil consults destructive-weapon physics or mob-griefing rules; not unconditional block destruction'},
 'recoil_caution':'Stored constructor input13 is not degrees or effective camera kick. Inspected BaseGun.getRecoilModifier returns0.35; getRecoilForShot uses1 for zero base damage then multiplies by that getter.',
 'renderer':{'bootstrap_index':107,'factory':'AoAEntityRendering.lambda$static$48','class':'TexturedProjectileRenderer','texture':'textures/entity/projectile/bullets/discharge_shot.png'},
 'direct_data_json_references':direct_json,'acquisition_limit':'No direct matching data JSON reference is not proof that no code-driven or external acquisition route exists','native_upgraded_acceptance':False}
a.output.write_text(json.dumps(report,indent=2)+'\n');print('Pinned release hashes, ammo/projectile references and ordered two-stage entity impact checks passed')
