"""Repair two verified identity-local cosmetic children after a zero-scale-parent export."""
import json,struct
from pathlib import Path

def repair(path):
 raw=Path(path).read_bytes();n,t=struct.unpack_from('<II',raw,12);assert t==0x4e4f534a;doc=json.loads(raw[20:20+n]);root=next(node for node in doc['nodes']if node.get('name')=='Inspection floating gem');children=[doc['nodes'][i]for i in root['children']];assert {n['name']for n in children}=={'Inspect orbit 1','Inspect orbit 2'}
 before=[]
 for node in children:
  before.append({'name':node['name'],'transforms':{k:node[k]for k in ['matrix','translation','rotation','scale']if k in node}})
  for key in ['matrix','translation','rotation','scale']:node.pop(key,None)
 js=json.dumps(doc,separators=(',',':')).encode();js+=b' '*((-len(js))%4);tail=raw[20+n:];out=struct.pack('<4sII',b'glTF',2,20+len(js)+len(tail))+struct.pack('<II',len(js),0x4e4f534a)+js+tail;Path(path).write_bytes(out);return before
