import sys
"""Original cosmetic fantasy-prop blockout. No game mechanics or weapon internals."""
import bpy,bmesh,math,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;bpy.ops.wm.read_factory_settings(use_empty=True)
def mat(name,color,metal=0,rough=.4,glow=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 if glow:p.inputs['Emission Color'].default_value=(*color,1);p.inputs['Emission Strength'].default_value=glow
 return m
gold=mat('Shyre warm sculpted gold',(.62,.32,.025),.78,.36);dark=mat('Shyre charcoal stone frame',(.075,.09,.10),.62,.34);cyan=mat('Shyre cyan mineral',(.015,.32,.40),.32,.3,.6);inner=mat('Shyre aperture shadow',(.009,.015,.02),.15,.5);edge=mat('Shyre bright gold edges',(.8,.49,.065),.8,.24)
# Material microstructure remains restrained and separate from shape/detail quality.
for m in [gold,dark]:
 n=m.node_tree.nodes;links=m.node_tree.links;p=n.get('Principled BSDF');tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=38;tex.inputs['Detail'].default_value=2;bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.04;bump.inputs['Distance'].default_value=.005;links.new(tex.outputs['Fac'],bump.inputs['Height']);links.new(bump.outputs['Normal'],p.inputs['Normal'])
def finish(o,name,m,bevel=.025):
 o.name=name;o.data.materials.append(m)
 if o.type=='MESH':
  bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
  if bm.calc_volume(signed=True)<0:bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
  lengths=[e.calc_length() for e in bm.edges if e.calc_length()>1e-8]
  extents=[max(v.co[i]for v in bm.verts)-min(v.co[i]for v in bm.verts)for i in range(3)]
  if bevel:bevel=min(bevel,min(lengths)*.2,min(x for x in extents if x>1e-8)*.2)
  bm.to_mesh(o.data);bm.free();o.data.update()
 if bevel:
  mod=o.modifiers.new('Soft crafted edges','BEVEL');mod.width=bevel;mod.segments=3
  mod=o.modifiers.new('Weighted face shading','WEIGHTED_NORMAL');mod.keep_sharp=True
 return o
def cyl(name,x,r,depth,m,verts=16):
 bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=r,depth=depth,location=(x,0,.55),rotation=(0,math.pi/2,0));return finish(bpy.context.object,name,m)
def ring(name,x,outer,inside,depth,m,segments=16):
 verts=[]
 for xx,rr in [(x-depth/2,outer),(x+depth/2,outer),(x-depth/2,inside),(x+depth/2,inside)]:
  for t in range(segments):
   angle=t*2*math.pi/segments;radius=rr
   if name.startswith(('Gold rib ','Rib edge ')) and rr==outer:
    phase=int(name.split()[-1])*.71
    radius=rr*(1+.035*math.sin(3*angle+phase)+.018*math.sin(5*angle-phase))
   verts.append((xx,radius*math.cos(angle),.55+radius*math.sin(angle)))
 faces=[]
 for i in range(segments):
  j=(i+1)%segments;faces += [(i,j,segments+j,segments+i),(2*segments+i,3*segments+i,3*segments+j,2*segments+j),(i,2*segments+i,2*segments+j,j),(segments+i,segments+j,3*segments+j,3*segments+i)]
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);return finish(o,name,m,.035)
def prism(name,outline,y,depth,m,bevel=.035):
 v=[(x,yy,z)for yy in [y-depth/2,y+depth/2]for x,z in outline];n=len(outline);f=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n)for i in range(n)];mesh=bpy.data.meshes.new(name);mesh.from_pydata(v,[],f);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);return finish(o,name,m,bevel)
def tube(name,points,r,m):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.bevel_depth=r;c.bevel_resolution=2;s=c.splines.new('POLY');s.points.add(len(points)-1)
 for p,co in zip(s.points,points):p.co=(*co,1)
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);c.materials.append(m);return o
def ribbon(name,points,width,depth,m):
 q=[Vector((p[0],p[2]))for p in points];left=[];right=[]
 for i,p in enumerate(q):
  a=(q[min(i+1,len(q)-1)]-q[max(i-1,0)]).normalized()
  if 0<i<len(q)-1:
   prev=(q[i]-q[i-1]).normalized();n1=Vector((-prev.y,prev.x));nxt=(q[i+1]-q[i]).normalized();n2=Vector((-nxt.y,nxt.x));n=(n1+n2).normalized();offset=n*(width/max(.5,n.dot(n2)))
  else:offset=Vector((-a.y,a.x))*width
  left.append(tuple(p+offset));right.append(tuple(p-offset))
 return prism(name,left+list(reversed(right)),0,depth,m,.035)
cyl('Cyan core housing',1.1,.66,2.65,cyan)
for i,x in enumerate([.25,1.10,1.95]):
 ring('Gold rib '+str(i+1),x,.84,.61,.64,gold)
 ring('Rib edge '+str(i+1),x+.30,.85,.65,.065,edge)
for i,x in enumerate([.25,1.10,1.95]):
 prism('Raised sculpted rib crown '+str(i),[(x-.30,1.12),(x-.30,1.37),(x+.14,1.45),(x+.32,1.29),(x+.32,1.10)],0,1.05,gold,.055)
ring('Front gold lip',2.55,.68,.43,.35,gold);ring('Front cyan inset',2.75,.48,.42,.08,cyan);cyl('Recessed dark face',2.54,.425,.04,inner)
ring('Grey structural collar',-.38,.91,.52,.30,dark);ring('Collar gold seating edge',-.57,.81,.54,.07,edge)
prism('Central gold receiver',[(-1.85,.28),(-1.63,.73),(-.62,1.0),(-.28,.75),(-.38,.1),(-1.2,-.05)],0,.90,gold,.06)
prism('Lower charcoal hand grip',[(-1.65,.25),(-2.05,.08),(-2.43,-.7),(-2.02,-.9),(-1.63,-.3)],0,.42,dark,.08)
prism('Grip end gold accent',[(-2.43,-.68),(-2.02,-.87),(-2.06,-.97),(-2.47,-.78)],0,.45,edge,.025)
loop=[(-.80,1.0),(-.97,1.72),(-1.5,2.04),(-2.22,1.98),(-2.65,1.50),(-2.69,.84),(-2.28,.38),(-1.84,.30)]
ribbon('Hollow rear charcoal loop',[(x,0,z)for x,z in loop],.17,.38,dark)
ribbon('Upper loop gold crown',[(x,0,z+.03)for x,z in loop[1:5]],.19,.42,gold)
tube('Upper loop cyan seam',[(x,.225,z+.035)for x,z in loop[1:5]],.025,cyan)
for side in [-1,1]:
 bpy.ops.mesh.primitive_cylinder_add(vertices=20,radius=.38,depth=.14,location=(-1.02,side*.55,-.1),rotation=(math.pi/2,0,0));finish(bpy.context.object,'Side gold medallion '+str(side),gold,.04)
 bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=.255,location=(-1.02,side*.65,-.1));o=finish(bpy.context.object,'Side cyan mineral '+str(side),cyan,0);o.scale.y=.45
 for i in range(3):
  bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=.105,location=(-1.50+i*.38,side*.48,.58+i*.065));o=finish(bpy.context.object,'Receiver inlay '+str(side)+' '+str(i),cyan,0);o.scale.y=.30
# Decorative seams are projected onto the actual rib surface instead of floating.
seam=mat('Shyre engraved dark gold',(.075,.032,.006),.5,.45)
bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get()
for i,x in enumerate([.25,1.10,1.95]):
 armor=bpy.data.objects['Gold rib '+str(i+1)].evaluated_get(dg)
 for side in [-1,1]:
  pts=[]
  for dx,dz in [(-.25,.14),(-.11,.07),(-.02,.11),(.07,-.01),(.19,-.055),(.26,-.13)]:
   hit,p,n,index=armor.ray_cast(Vector((x+dx,side*2,.55+dz)),Vector((0,-side,0)))
   assert hit,'Unseated rib decoration';pts.append(tuple(p+n*.0015))
  tube('Seated gold fracture '+str(i)+' '+str(side),pts,.006,seam)
facets=[cyan,mat('Shyre mineral deep facet',(.005,.13,.19),.35,.22,.35),mat('Shyre mineral bright facet',(.035,.5,.58),.3,.24,.5)]
for o in bpy.data.objects:
 if o.type=='MESH' and ('Side cyan mineral' in o.name or 'Receiver inlay' in o.name):
  o.data.materials.clear()
  for m in facets:o.data.materials.append(m)
  for p in o.data.polygons:p.material_index=(p.index*7+int(p.normal.z*3))%3
# Replace spherical checkerboard-looking medallions with coherent cut mineral faces.
import bmesh
for o in list(bpy.data.objects):
 if o.name.startswith('Side cyan mineral'):bpy.data.objects.remove(o,do_unlink=True)
gem_base=mat('Shyre cut mineral body',(.015,.31,.40),.16,.16,.25);gem_light=mat('Shyre cut mineral upper faces',(.025,.40,.49),.16,.14,.25);gem_dark=mat('Shyre cut mineral lower faces',(.009,.23,.31),.16,.18,.2)
for side in [-1,1]:
 n=8;v=[]
 for radius,y in [(.255,side*.66),(.13,side*.79)]:
  v += [(-1.02+radius*math.cos(i*2*math.pi/n),y,-.1+radius*math.sin(i*2*math.pi/n))for i in range(n)]
 v.append((-1.02,side*.59,-.1));f=[]
 for i in range(n):
  j=(i+1)%n;f += [(i,j,n+j,n+i),(i,2*n,j)]
 f.append(tuple(range(n,2*n)));mesh=bpy.data.meshes.new('Cut medallion mesh');mesh.from_pydata(v,[],f);mesh.update();bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
 if bm.calc_volume(signed=True)<0:bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
 bm.to_mesh(mesh);bm.free();o=bpy.data.objects.new('Cut cyan medallion '+str(side),mesh);bpy.context.collection.objects.link(o)
 for m in [gem_base,gem_light,gem_dark]:mesh.materials.append(m)
 for p in mesh.polygons:p.material_index=1 if p.normal.z>.35 else 2 if p.normal.z<-.35 else 0
# A separate cosmetic inspect marker, hidden at rest. This is not a finished hand animation.
bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=.23,location=(-1.85,0,1.22));gem=finish(bpy.context.object,'Inspection floating gem',cyan,0)
for frame,scale,rotation in [(1,0,0),(20,1,0),(45,1,math.pi),(70,0,math.pi*2)]:
 gem.scale=(scale,scale,scale);gem.rotation_euler.z=rotation;gem.keyframe_insert('scale',frame=frame);gem.keyframe_insert('rotation_euler',frame=frame)
if gem.animation_data:gem.animation_data.action.name='Shyre cosmetic gem inspection study'
s=bpy.context.scene;s.frame_start=1;s.frame_end=70;s.frame_set(1);s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.seed=0;s.cycles.use_denoising=False;s.render.resolution_x=1200;s.render.resolution_y=850;s.render.resolution_percentage=100
s.world=bpy.data.worlds.new('Shyre studio world');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.012,.018,.025,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.35
for name,loc,power,size,col in [('Key',(2,6,7),1150,7,(1,.89,.70)),('Fill',(-4,-5,4),900,5,(.45,.75,1)),('Rim',(4,-1,6),950,4,(1,.68,.22))]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=col;o.rotation_euler=(Vector((0,0,.6))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(5.0,14.0,6.0));s.camera=bpy.context.object;s.camera.rotation_euler=(Vector((0,0,.6))-s.camera.location).to_track_quat('-Z','Y').to_euler();s.camera.data.type='ORTHO';s.camera.data.ortho_scale=7.5;s.view_settings.view_transform='AgX';s.render.filepath=str(R/'hero-v7.png')
bpy.ops.wm.save_as_mainfile(filepath=str(R/'shyre-prop-study-v7.blend'));None if '--no-render' in sys.argv else bpy.ops.render.render(write_still=True)
(R/'scope-v7.json').write_text(json.dumps({'scope':'Original cosmetic prop blockout and one isolated gem-motion study','source_profile':'Shyre-Blaster-Weapon-Profile','canonical_art':'exec-349e0e57-7138-49d6-a08f-76c79893e676.png','native_accepted':False,'visual_accepted':False,'hand_animation_complete':False},indent=2))
