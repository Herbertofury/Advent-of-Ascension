"""Preview-only static batching from the validated GLB; retain dynamic hierarchy and source."""
import json,struct,copy,numpy as np
from pathlib import Path
R=Path(__file__).resolve().parent
raw=(R/'shyre-authoring-preview-v11.glb').read_bytes();n=struct.unpack_from('<I',raw,12)[0];src=json.loads(raw[20:20+n]);binary=raw[28+n:]
def acc(index):
 a=src['accessors'][index];v=src['bufferViews'][a['bufferView']];fmt={5126:'f',5125:'I',5123:'H',5121:'B'}[a['componentType']];width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];size=struct.calcsize(fmt)*width;off=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size)
 return np.array([struct.unpack_from('<'+fmt*width,binary,off+i*stride)for i in range(a['count'])])
parents={c:i for i,x in enumerate(src['nodes'])for c in x.get('children',[])};world={}
def matrix(i):
 if i in world:return world[i]
 node=src['nodes'][i]
 if 'matrix'in node:m=np.array(node['matrix']).reshape(4,4).T
 else:
  x,y,z,w=node.get('rotation',[0,0,0,1]);rot=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]]);m=np.eye(4);m[:3,:3]=rot@np.diag(node.get('scale',[1,1,1]));m[:3,3]=node.get('translation',[0,0,0])
 world[i]=matrix(parents[i])@m if i in parents else m;return world[i]
root=next(i for i,x in enumerate(src['nodes'])if x.get('name')=='Inspection floating gem');actors=[root,*src['nodes'][root]['children']];assert len(actors)==3
out={k:copy.deepcopy(src[k])for k in ['asset','materials','textures','samplers','extensionsUsed']if k in src};out.update({'accessors':[],'bufferViews':[],'buffers':[],'meshes':[],'nodes':[],'scenes':[{'nodes':[0,1]}],'scene':0,'images':[]});data=bytearray();out['asset']['generator']='Original preview static-batching tool; source: '+src['asset'].get('generator','unspecified')
def view(payload,target=None):
 while len(data)%4:data.append(0)
 i=len(out['bufferViews']);v={'buffer':0,'byteOffset':len(data),'byteLength':len(payload)}
 if target:v['target']=target
 out['bufferViews'].append(v);data.extend(payload);return i
def add(values,ctype=5126,typ=None,target=None):
 ctype=5123 if ctype==5125 and max(np.asarray(values).ravel())<65536 else ctype
 arr=np.asarray(values,dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[ctype]);arr=arr.reshape(len(arr),-1);typ=typ or {1:'SCALAR',2:'VEC2',3:'VEC3',4:'VEC4'}[arr.shape[1]];assert np.isfinite(arr).all();a={'bufferView':view(arr.tobytes(),target),'componentType':ctype,'count':len(arr),'type':typ,'min':arr.min(axis=0).tolist(),'max':arr.max(axis=0).tolist()};out['accessors'].append(a);return len(out['accessors'])-1
for image in src['images']:
 im=copy.deepcopy(image);v=src['bufferViews'][im['bufferView']];off=v.get('byteOffset',0);im['bufferView']=view(binary[off:off+v['byteLength']]);out['images'].append(im)
groups={};components=[]
for i,node in enumerate(src['nodes']):
 if i in actors or 'mesh'not in node:continue
 components.append(node['name']);m=matrix(i);assert np.linalg.det(m[:3,:3])>0
 for p in src['meshes'][node['mesh']]['primitives']:
  assert p.get('mode',4)==4;at=p['attributes'];assert set(at)=={'POSITION','NORMAL','TEXCOORD_0','TANGENT'}
  pos=acc(at['POSITION'])@m[:3,:3].T+m[:3,3];nor=acc(at['NORMAL'])@np.linalg.inv(m[:3,:3]);nor/=np.linalg.norm(nor,axis=1)[:,None];tan=acc(at['TANGENT']);tan[:,:3]=tan[:,:3]@m[:3,:3].T;tan[:,:3]/=np.linalg.norm(tan[:,:3],axis=1)[:,None]
  g=groups.setdefault(p['material'],{'POSITION':[],'NORMAL':[],'TEXCOORD_0':[],'TANGENT':[],'indices':[],'count':0});g['indices'].extend((acc(p['indices']).ravel().astype(int)+g['count']).tolist());g['count']+=len(pos)
  for key,values in [('POSITION',pos),('NORMAL',nor),('TEXCOORD_0',acc(at['TEXCOORD_0'])),('TANGENT',tan)]:g[key].extend(values.tolist())
primitives=[]
for material,g in sorted(groups.items()):primitives.append({'attributes':{k:add(g[k],target=34962)for k in ['POSITION','NORMAL','TEXCOORD_0','TANGENT']},'indices':add(g['indices'],5125,target=34963),'material':material,'mode':4})
out['meshes'].append({'name':'Static preview body','primitives':primitives});out['nodes'].append({'name':'Shyre static preview body','mesh':0,'extras':{'originalComponents':components}});mapping={old:new+1 for new,old in enumerate(actors)}
for old in actors:
 node=copy.deepcopy(src['nodes'][old]);mesh=copy.deepcopy(src['meshes'][node['mesh']])
 for p in mesh['primitives']:
  for key,index in list(p['attributes'].items()):p['attributes'][key]=add(acc(index),target=34962)
  p['indices']=add(acc(p['indices']),5125,target=34963)
 node['mesh']=len(out['meshes']);out['meshes'].append(mesh)
 if 'children'in node:node['children']=[mapping[i]for i in node['children']]
 out['nodes'].append(node)
out['animations']=copy.deepcopy(src['animations'])
for animation in out['animations']:
 for channel in animation['channels']:channel['target']['node']=mapping[channel['target']['node']]
 for sampler in animation['samplers']:
  for key in ['input','output']:sampler[key]=add(acc(sampler[key]))
out['buffers']=[{'byteLength':len(data)}];js=json.dumps(out,separators=(',',':')).encode();js+=b' '*((-len(js))%4);data.extend(b'\0'*((-len(data))%4));result=struct.pack('<4sII',b'glTF',2,28+len(js)+len(data))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(data),0x004e4942)+data
(R/'shyre-authoring-preview-exact-batched.glb').write_bytes(result);print({'meshes':len(out['meshes']),'primitives':sum(len(m['primitives'])for m in out['meshes']),'bytes':len(result)})
