"""Portable web-preview export only. This is not a TaCZ/native export."""
import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'shyre-baked-material-corrected-study.blend'));s=bpy.context.scene;s.frame_set(20)
bpy.ops.object.select_all(action='DESELECT')
for o in list(bpy.data.objects):
 if o.type=='CURVE':
  bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o.select_set(False)
# Freeze the exact loop-triangle decomposition used by the bake, retaining UVs and corner normals.
for o in bpy.data.objects:
 if o.type!='MESH':continue
 old=o.data
 uses_normal=any(slot.material and slot.material.use_nodes and slot.material.node_tree.nodes.get('Bake target basecolor') for slot in o.material_slots)
 if not uses_normal:
  for uv in list(old.uv_layers):old.uv_layers.remove(uv)
  continue
 old.calc_loop_triangles();tris=list(old.loop_triangles);uv=old.uv_layers.active.data
 coords=[tuple(v.co)for v in old.vertices];faces=[tuple(t.vertices)for t in tris];uvs=[tuple(uv[i].uv)for t in tris for i in t.loops];normals=[tuple(old.corner_normals[i].vector)for t in tris for i in t.loops]
 new=bpy.data.meshes.new(old.name+' exact baked triangles');new.from_pydata(coords,[],faces)
 for mat in old.materials:new.materials.append(mat)
 for poly,tri in zip(new.polygons,tris):poly.material_index=tri.material_index;poly.use_smooth=old.polygons[tri.polygon_index].use_smooth
 layer=new.uv_layers.new(name='UVMap')
 for loop,coord in zip(layer.data,uvs):loop.uv=coord
 new.normals_split_custom_set(normals);new.update();o.data=new
for o in bpy.data.objects:o.select_set(o.type=='MESH' and not o.hide_render)
bpy.context.view_layer.objects.active=bpy.data.objects['Inspection floating gem']
# The cosmetic children are authored with fixed identity locals. Assert this before export.
from mathutils import Matrix
root=bpy.data.objects['Inspection floating gem'];children=list(root.children_recursive)
assert {o.name for o in children}=={'Inspect orbit 1','Inspect orbit 2'}
for frame in [1,20,45,70]:
 s.frame_set(frame);bpy.context.view_layer.update()
 for o in children:
  assert o.animation_data is None and not o.constraints
  assert max(abs(o.matrix_basis[i][k]-float(i==k))for i in range(4)for k in range(4))<1e-7
  assert max(abs(o.matrix_parent_inverse[i][k]-float(i==k))for i in range(4)for k in range(4))<1e-7
s.frame_set(20)
bpy.ops.export_scene.gltf(filepath=str(R/'shyre-authoring-preview-v11.glb'),export_format='GLB',export_tangents=True,use_selection=True,export_cameras=False,export_lights=False,export_animations=True,export_frame_range=True,export_force_sampling=True,export_yup=True)

import sys
sys.path.insert(0,str(R))
from repair_inspect_locals import repair
before=repair(R/'shyre-authoring-preview-v11.glb')
(R/'inspect-local-export-repair.json').write_text(json.dumps({'verified_identity_locals_at_frames':[1,20,45,70],'before':before,'scope':'Two cosmetic child transforms only; geometry/material/animation bytes retained','native_accepted':False},indent=2))
