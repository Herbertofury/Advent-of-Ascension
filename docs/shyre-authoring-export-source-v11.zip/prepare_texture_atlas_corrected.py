"""Prepare a reversible UV and texture-bake study from the original authored prop."""
import bpy,json,math
from pathlib import Path
R=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(R/'shyre-prop-study-v11.blend'))
s=bpy.context.scene;s.frame_set(20)
gem=bpy.data.objects['Inspection floating gem'];actors={gem,*gem.children_recursive}
bpy.ops.object.select_all(action='DESELECT')
static=[o for o in list(bpy.data.objects) if o.type in ('MESH','CURVE') and o not in actors and not o.hide_render]
for o in static:o.select_set(True)
bpy.context.view_layer.objects.active=static[0]
bpy.ops.object.convert(target='MESH')
static=list(bpy.context.selected_objects)
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=math.radians(66),island_margin=.012,correct_aspect=True,scale_to_bounds=True);bpy.ops.object.mode_set(mode='OBJECT')
# All selected objects share one atlas layout; bake only the static body.
for o in bpy.context.selected_objects:
 assert o.data.uv_layers.active is not None
mats={slot.material for o in static for slot in o.material_slots if slot.material}
s.render.engine='CYCLES';s.cycles.samples=8;s.cycles.use_denoising=False;s.render.bake.margin=8;s.render.bake.use_clear=False
for kind in ('basecolor','normal'):
 img=bpy.data.images.new('Shyre static '+kind+' atlas',width=1024,height=1024,alpha=True)
 if kind=='normal':img.colorspace_settings.name='Non-Color'
 for mat in mats:
  node=mat.node_tree.nodes.new('ShaderNodeTexImage');node.name='Bake target '+kind;node.image=img;mat.node_tree.nodes.active=node
 if kind=='basecolor':
  restore=[]
  for mat in mats:
   nodes=mat.node_tree.nodes;links=mat.node_tree.links;p=nodes.get('Principled BSDF');out=next(n for n in nodes if n.type=='OUTPUT_MATERIAL' and n.is_active_output);prior=[(l.from_socket,l.to_socket)for l in out.inputs['Surface'].links];em=nodes.new('ShaderNodeEmission');em.inputs['Strength'].default_value=1
   if p.inputs['Base Color'].is_linked:links.new(p.inputs['Base Color'].links[0].from_socket,em.inputs['Color'])
   else:em.inputs['Color'].default_value=p.inputs['Base Color'].default_value
   links.new(em.outputs[0],out.inputs['Surface']);restore.append((mat,prior,em))
  bpy.ops.object.bake(type='EMIT')
  for mat,prior,em in restore:
   mat.node_tree.nodes.remove(em)
   for a,b in prior:mat.node_tree.links.new(a,b)
 else:bpy.ops.object.bake(type='NORMAL',normal_space='TANGENT')
 img.filepath_raw=str(R/('shyre-static-'+('basecolor-corrected' if kind=='basecolor' else kind)+'-1024.png'));img.file_format='PNG';img.save()
bpy.ops.wm.save_as_mainfile(filepath=str(R/'shyre-uv-bake-study.blend'))
(R/'texture-bake-scope.json').write_text(json.dumps({'scope':'Static authored body UV/basecolor/tangent-normal study; original v11 preserved','objects':len(static),'materials':len(mats),'resolution':1024,'native_accepted':False,'visual_accepted':False,'animated_crystal_excluded':True},indent=2))
