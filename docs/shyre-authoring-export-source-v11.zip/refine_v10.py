"""Original fantasy-prop cosmetic trim study. No gameplay changes."""
import bpy,bmesh,math,json
from pathlib import Path
R=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(R/'shyre-prop-study-v8.blend'))
def annulus(name,cx,cy,cz,outer,inner,depth,material):
 n=4 if name.startswith('Inlay') else 16;verts=[]
 for y,r in [(cy-depth/2,outer),(cy+depth/2,outer),(cy-depth/2,inner),(cy+depth/2,inner)]:
  for i in range(n):
   a=2*math.pi*i/n;verts.append((cx+r*math.cos(a),y,cz+r*math.sin(a)))
 faces=[]
 for i in range(n):
  j=(i+1)%n
  faces.extend([(i,j,n+j,n+i),(2*n+i,3*n+i,3*n+j,2*n+j),(i,2*n+i,2*n+j,j),(n+i,n+j,3*n+j,3*n+i)])
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces)
 bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free();mesh.update()
 o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);mesh.materials.append(material)
 bevel=o.modifiers.new('Restrained trim bevel','BEVEL');bevel.width=.008;bevel.segments=2
 return o
edge=bpy.data.materials['Shyre bright gold edges'];gold=bpy.data.materials['Shyre warm sculpted gold']
for side in [-1,1]:
 annulus('Medallion outer stepped trim '+str(side),-1.02,side*.626,-.1,.373,.315,.036,edge)
 annulus('Medallion inner mineral seat '+str(side),-1.02,side*.651,-.1,.305,.258,.035,gold)
 # Trim remains within the existing medallion footprint; no grip geometry moves.
 for i in range(3):
  x=-1.50+i*.38;z=.58+i*.065
  annulus('Inlay gold seat '+str(side)+' '+str(i),x,side*.474,z,.116,.079,.024,edge)
s=bpy.context.scene;s.frame_set(20);s.render.filepath=str(R/'hero-v10.png');s.cycles.samples=48;s.cycles.use_denoising=False
bpy.ops.wm.save_as_mainfile(filepath=str(R/'shyre-prop-study-v10.blend'))
bpy.ops.render.render(write_still=True)
(R/'scope-v10.json').write_text(json.dumps({'scope':'Cosmetic stepped medallion and inlay trim; existing geometry preserved','native_accepted':False,'visual_accepted':False,'hands_tested':False},indent=2))
