import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'shyre-uv-bake-study.blend'));rows=[]
for o in bpy.data.objects:
 if o.type!='MESH' or not o.data.uv_layers.active:continue
 o.data.calc_loop_triangles();uv=o.data.uv_layers.active.data
 for t in o.data.loop_triangles:rows.append({'object':o.name,'uv':[list(uv[i].uv)for i in t.loops]})
(R/'uv-triangles.json').write_text(json.dumps(rows));print(len(rows))
