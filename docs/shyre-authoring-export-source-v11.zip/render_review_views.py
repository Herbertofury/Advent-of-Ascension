"""Deterministic multi-view authoring QA, not game-camera validation."""
import bpy,sys
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;v=sys.argv[sys.argv.index('--')+1] if '--' in sys.argv else 'v10'
bpy.ops.wm.open_mainfile(filepath=str(R/f'shyre-prop-study-{v}.blend'));s=bpy.context.scene;s.frame_set(1);s.cycles.samples=24;s.cycles.use_denoising=False;s.render.resolution_percentage=60
for name,loc in [('opposite',(5,-14,6)),('side',(0,14,.6)),('top',(0,.01,15))]:
 s.camera.location=loc;s.camera.rotation_euler=(Vector((0,0,.6))-s.camera.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/f'{v}-review-{name}.png');bpy.ops.render.render(write_still=True)
