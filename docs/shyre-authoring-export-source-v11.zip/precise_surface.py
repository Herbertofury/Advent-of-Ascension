"""Double-precision nearest-triangle checks for small authored-mesh QA fixtures."""
import numpy as np

def nearest_triangle_distance(point, triangles):
    t=np.asarray(triangles,dtype=np.float64);p=np.asarray(point,dtype=np.float64)
    if t.ndim!=3 or t.shape[1:]!=(3,3) or not len(t):raise ValueError('nonempty triangle array required')
    if not np.isfinite(t).all() or not np.isfinite(p).all():raise ValueError('finite coordinates required')
    a,b,c=t[:,0],t[:,1],t[:,2];ab=b-a;ac=c-a;ap=p-a
    n=np.cross(ab,ac);n2=np.einsum('ij,ij->i',n,n)
    signed=np.einsum('ij,ij->i',ap,n)
    safe=np.where(n2>0,n2,1.)
    projection=p-(signed/safe)[:,None]*n
    aq=projection-a
    u=np.einsum('ij,ij->i',np.cross(aq,ac),n)/safe
    v=np.einsum('ij,ij->i',np.cross(ab,aq),n)/safe
    inside=(n2>0)&(u>=0)&(v>=0)&(u+v<=1)
    distances=np.where(inside,signed*signed/safe,np.inf)
    for x,y in [(a,b),(b,c),(c,a)]:
        d=y-x;length=np.einsum('ij,ij->i',d,d)
        f=np.clip(np.einsum('ij,ij->i',p-x,d)/np.where(length>0,length,1),0,1)
        delta=p-(x+f[:,None]*d)
        distances=np.minimum(distances,np.einsum('ij,ij->i',delta,delta))
    i=int(np.argmin(distances));return float(np.sqrt(max(0.,distances[i]))),i
