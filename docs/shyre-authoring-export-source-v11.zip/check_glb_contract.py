"""Export-specific checks beyond generic format validation; no native acceptance."""
import json,struct,math,copy
from pathlib import Path
R=Path(__file__).resolve().parent
b=(R/'shyre-authoring-preview-v11.glb').read_bytes();magic,version,length=struct.unpack_from('<4sII',b);assert (magic,version,length)==(b'glTF',2,len(b));n,t=struct.unpack_from('<II',b,12);assert t==0x4e4f534a;j=json.loads(b[20:20+n]);start=20+n;size,kind=struct.unpack_from('<II',b,start);assert kind==0x004e4942;binary=b[start+8:start+8+size]
def accessor(index):
 a=j['accessors'][index];v=j['bufferViews'][a['bufferView']];assert a['componentType']==5126
 width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];offset=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',4*width)
 return [struct.unpack_from('<'+'f'*width,binary,offset+i*stride)for i in range(a['count'])]
def check(doc):
 assert len(doc['images'])==2 and all('uri'not in x for x in doc['images'])
 assert all('uri'not in x for x in doc['buffers'])
 normal_mats=[i for i,m in enumerate(doc['materials'])if 'normalTexture'in m];assert len(normal_mats)==11
 for mesh in doc['meshes']:
  for p in mesh['primitives']:
   if p['material']in normal_mats:
    assert all(k in p['attributes']for k in ['TANGENT','NORMAL','TEXCOORD_0'])
 roots=[i for i,x in enumerate(doc['nodes'])if x.get('name')=='Inspection floating gem'];assert len(roots)==1
 root=roots[0];assert len(doc['nodes'][root]['children'])==2
 for i in doc['nodes'][root]['children']:assert not any(k in doc['nodes'][i]for k in ['matrix','translation','rotation','scale']),'Cosmetic orbit local transform must be identity'
 assert len(doc['animations'])==1
 channels=doc['animations'][0]['channels'];assert {c['target']['path']for c in channels}=={'rotation','scale'};assert all(c['target']['node']==root for c in channels)
check(j)
for a in j['accessors']:
 if a['componentType']==5126:
  assert all(math.isfinite(v)for row in accessor(j['accessors'].index(a))for v in row)
for mesh in j['meshes']:
 for p in mesh['primitives']:
  for key in ['NORMAL','TANGENT']:
   if key in p['attributes']:
    for row in accessor(p['attributes'][key]):
     assert abs(sum(v*v for v in row[:3])-1)<1e-3
     if key=='TANGENT':assert abs(abs(row[3])-1)<1e-5
anim=j['animations'][0]
for c in anim['channels']:
 sm=anim['samplers'][c['sampler']];times=[x[0]for x in accessor(sm['input'])];assert all(b>a for a,b in zip(times,times[1:]));assert abs(times[0]-1/24)<1e-6 and abs(times[-1]-70/24)<1e-5
 values=accessor(sm['output'])
 if c['target']['path']=='scale':assert all(-1e-6<=x<=1.00001 for row in values for x in row)
 else:assert all(abs(sum(x*x for x in row)-1)<1e-3 for row in values)
bad=copy.deepcopy(j);del bad['meshes'][0]['primitives'][0]['attributes']['TANGENT']
try:check(bad)
except AssertionError:pass
else:raise AssertionError('Missing-tangent regression was not rejected')
bad=copy.deepcopy(j);child=next(n for n in bad['nodes']if n.get('name')=='Inspection floating gem');bad['nodes'][child['children'][0]]['scale']=[0,0,0]
try:check(bad)
except AssertionError:pass
else:raise AssertionError('Zero-scale child fixture was not rejected')
result={'passed':True,'zero_scale_child_fixture_rejected':True,'meshes':len(j['meshes']),'embedded_images':2,'normal_mapped_materials':11,'animation_count':1,'single_owner_with_two_orbits':True,'finite_normalized_vectors':True,'missing_tangent_fixture_rejected':True,'native_accepted':False}
(R/'glb-contract-qa.json').write_text(json.dumps(result,indent=2));print(result)
