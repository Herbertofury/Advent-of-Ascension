"""Render baked-material roundtrip separately from authored source."""
import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'shyre-uv-bake-study.blend'))
base=bpy.data.images.load(str(R/'shyre-static-basecolor-corrected-1024.png'),check_existing=True);normal=bpy.data.images.load(str(R/'shyre-static-normal-1024.png'),check_existing=True);normal.colorspace_settings.name='Non-Color'
changed=[]
for mat in bpy.data.materials:
 if not mat.use_nodes:continue
 if not mat.node_tree.nodes.get('Bake target basecolor'):continue
 p=mat.node_tree.nodes.get('Principled BSDF');nodes=mat.node_tree.nodes;links=mat.node_tree.links
 for socket in [p.inputs['Base Color'],p.inputs['Normal']]:
  for l in list(socket.links):links.remove(l)
 t=nodes.new('ShaderNodeTexImage');t.image=base;t.extension='EXTEND';links.new(t.outputs['Color'],p.inputs['Base Color'])
 t=nodes.new('ShaderNodeTexImage');t.image=normal;t.extension='EXTEND';n=nodes.new('ShaderNodeNormalMap');n.space='TANGENT';links.new(t.outputs['Color'],n.inputs['Color']);links.new(n.outputs['Normal'],p.inputs['Normal']);changed.append(mat.name)
s=bpy.context.scene;s.frame_set(20);s.render.resolution_percentage=100;s.cycles.samples=48;s.render.filepath=str(R/'baked-material-corrected-review.png');bpy.ops.wm.save_as_mainfile(filepath=str(R/'shyre-baked-material-corrected-study.blend'));bpy.ops.render.render(write_still=True)
(R/'baked-material-corrected-review.json').write_text(json.dumps({'changed_materials':changed,'native_accepted':False,'visual_review_pending':True},indent=2))
