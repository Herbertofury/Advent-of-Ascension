"""Compare world-space static triangles, UVs and shading basis across preview batching."""
import struct,json,sys,numpy as np
from pathlib import Path
R=Path(__file__).resolve().parent
class Asset:
 def __init__(self,name):
  self.raw=(R/name).read_bytes();n=struct.unpack_from('<I',self.raw,12)[0];self.j=json.loads(self.raw[20:20+n]);self.binary=self.raw[28+n:];self.world={};parents={c:i for i,x in enumerate(self.j['nodes'])for c in x.get('children',[])}
  def world(i):
   if i in self.world:return self.world[i]
   x=self.j['nodes'][i]
   if 'matrix'in x:m=np.array(x['matrix']).reshape(4,4).T
   else:
    a,b,c,d=x.get('rotation',[0,0,0,1]);q=np.array([[1-2*(b*b+c*c),2*(a*b-c*d),2*(a*c+b*d)],[2*(a*b+c*d),1-2*(a*a+c*c),2*(b*c-a*d)],[2*(a*c-b*d),2*(b*c+a*d),1-2*(a*a+b*b)]]);m=np.eye(4);m[:3,:3]=q@np.diag(x.get('scale',[1,1,1]));m[:3,3]=x.get('translation',[0,0,0])
   self.world[i]=(world(parents[i])@m)if i in parents else m;return self.world[i]
  for i in range(len(self.j['nodes'])):world(i)
 def acc(self,index):
  a=self.j['accessors'][index];v=self.j['bufferViews'][a['bufferView']];fmt={5126:'f',5125:'I',5123:'H',5121:'B'}[a['componentType']];width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];sz=struct.calcsize(fmt)*width;off=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',sz)
  return np.array([struct.unpack_from('<'+fmt*width,self.binary,off+i*stride)for i in range(a['count'])])
 def triangles(self):
  out={}
  for i,node in enumerate(self.j['nodes']):
   if 'mesh'not in node:continue
   m=self.world[i]
   for p in self.j['meshes'][node['mesh']]['primitives']:
    mat=self.j['materials'][p['material']]
    if 'normalTexture'not in mat:continue
    at=p['attributes'];pos=self.acc(at['POSITION']);pos=pos@m[:3,:3].T+m[:3,3];normal=self.acc(at['NORMAL'])@np.linalg.inv(m[:3,:3]);normal/=np.linalg.norm(normal,axis=1)[:,None];uv=self.acc(at['TEXCOORD_0']);tan=self.acc(at['TANGENT']);tan[:,:3]=tan[:,:3]@m[:3,:3].T;tan[:,:3]/=np.linalg.norm(tan[:,:3],axis=1)[:,None];idx=self.acc(p['indices']).reshape(-1,3).astype(int);data=np.concatenate([pos,normal,uv,tan],axis=1);out.setdefault(mat['name'],[]).extend(data[idx])
  return{k:np.array(v)for k,v in out.items()}
a=Asset('shyre-authoring-preview-v11.glb');b=Asset('shyre-authoring-preview-exact-batched.glb');x=a.triangles();y=b.triangles();assert x.keys()==y.keys();
if '--perturb-uv' in sys.argv:y[next(iter(y))][0,0,6]+=.01
maxerr=np.zeros(12);total=0
for name,left in x.items():
 right=y[name];assert len(left)==len(right);grid={}
 for i,center in enumerate(right[:,:,:3].mean(axis=1)):grid.setdefault(tuple(np.floor(center/1e-4).astype(int)),[]).append(i)
 used=set()
 for tri in left:
  key=np.floor(tri[:,:3].mean(axis=0)/1e-4).astype(int);candidates=[i for dx in [-1,0,1]for dy in [-1,0,1]for dz in [-1,0,1]for i in grid.get((key[0]+dx,key[1]+dy,key[2]+dz),[])if i not in used];assert candidates,(name,'missing triangle')
  choices=[(float(np.max(np.abs(tri-np.roll(right[i],shift,axis=0)))),i,shift)for i in candidates for shift in range(3)];error,i,shift=min(choices);used.add(i);maxerr=np.maximum(maxerr,np.max(np.abs(tri-np.roll(right[i],shift,axis=0)),axis=0));total+=1
 assert len(used)==len(right)
report={'passed':bool(np.max(maxerr)<1e-6),'static_triangles':total,'unbatched_meshes':len(a.j['meshes']),'batched_meshes':len(b.j['meshes']),'unbatched_primitives':sum(len(m['primitives'])for m in a.j['meshes']),'batched_primitives':sum(len(m['primitives'])for m in b.j['meshes']),'maximum_component_errors':maxerr.tolist(),'tolerance':1e-6,'bytes_before':len(a.raw),'bytes_after':len(b.raw),'native_accepted':False,'scope':'Geometry/UV/shading-basis comparison only; material and animation contracts checked separately; no FPS claim'}
(R/('preview-exact-batch-negative-qa.json' if '--perturb-uv' in sys.argv else 'preview-exact-batch-qa.json')).write_text(json.dumps(report,indent=2));print(report)

if not report['passed']:raise SystemExit(1)
