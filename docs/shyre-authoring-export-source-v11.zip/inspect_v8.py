import sys
"""Concept-led cosmetic inspection detail; no native integration claim."""
import bpy,bmesh,math,json
from pathlib import Path
from mathutils import Matrix
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'shyre-prop-study-v7.blend'));s=bpy.context.scene;s.frame_set(20);gem=bpy.data.objects['Inspection floating gem']
verts=[(.18,0,0),(0,.15,0),(-.18,0,0),(0,-.15,0),(0,0,.28),(0,0,-.28)];faces=[(i,(i+1)%4,4)for i in range(4)]+[((i+1)%4,i,5)for i in range(4)];mesh=bpy.data.meshes.new('Shyre inspection cut crystal');mesh.from_pydata(verts,[],faces);bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
if bm.calc_volume(signed=True)<0:bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
bm.to_mesh(mesh);bm.free();mesh.update();gem.data=mesh
for name,col,glow in [('Inspect crystal bright',(.04,.65,.75),.8),('Inspect crystal cyan',(.015,.37,.48),.6),('Inspect crystal deep',(.005,.15,.23),.3)]:
 m=bpy.data.materials.new(name);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*col,1);p.inputs['Metallic'].default_value=.25;p.inputs['Roughness'].default_value=.18;p.inputs['Emission Color'].default_value=(*col,1);p.inputs['Emission Strength'].default_value=glow;mesh.materials.append(m)
for f in mesh.polygons:f.material_index=0 if f.normal.z>.3 and f.normal.y>.1 else 1 if f.normal.z>.0 else 2
orbit=mesh.materials[0].copy();orbit.name='Inspect orbit restrained cyan';orbit.node_tree.nodes.get('Principled BSDF').inputs['Emission Strength'].default_value=1.4
for n,r,tilt in [(1,.36,0),(2,.38,math.pi/2.4)]:
 data=bpy.data.curves.new('Inspect orbit '+str(n),'CURVE');data.dimensions='3D';data.bevel_depth=.009;data.bevel_resolution=1;data.use_fill_caps=True;sp=data.splines.new('POLY');sp.points.add(31);sp.use_cyclic_u=True
 for i,p in enumerate(sp.points):
  t=i*2*math.pi/32;p.co=(r*math.cos(t),r*math.sin(t)*math.cos(tilt),r*math.sin(t)*math.sin(tilt),1)
 obj=bpy.data.objects.new(data.name,data);bpy.context.collection.objects.link(obj);data.materials.append(orbit);obj.parent=gem;obj.matrix_parent_inverse=Matrix.Identity(4);obj.matrix_basis=Matrix.Identity(4)
s.cycles.samples=48;s.cycles.use_denoising=False;s.frame_set(20);s.render.filepath=str(R/'inspect-v8-frame20.png');bpy.ops.wm.save_as_mainfile(filepath=str(R/'shyre-prop-study-v8.blend'));None if '--no-render' in sys.argv else bpy.ops.render.render(write_still=True)
(R/'scope-v8.json').write_text(json.dumps({'scope':'Cut-crystal and restrained orbit geometry on the existing cosmetic inspect action; rooted to one animated owner','native_accepted':False,'visual_accepted':False,'hand_animation_complete':False,'original_gameplay_changed':False},indent=2))
