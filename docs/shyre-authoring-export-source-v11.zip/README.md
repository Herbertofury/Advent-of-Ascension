# Shyre authoring and web-export study

Original cosmetic Blender source. This is not a TaCZ gunpack or an accepted finished weapon. The version-pinned [weapon profile](https://github.com/Herbertofury/Advent-of-Ascension/wiki/Shyre-Blaster-Weapon-Profile) remains the gameplay reference.

## Rebuild from this folder

Tested with Blender 4.3.2, Python 3 and Node.js. Blender supplies NumPy. The official Khronos validator is pinned by package-lock.json.

1. `blender -b -t 2 --python-exit-code 1 --python build-v7.py -- --no-render`
2. `blender -b -t 2 --python-exit-code 1 --python inspect_v8.py -- --no-render`
3. `blender -b -t 2 --python-exit-code 1 --python refine_v10.py`
4. `blender -b -t 2 --python-exit-code 1 --python refine_v11.py`
5. `blender -b -t 2 --python-exit-code 1 --python check_geometry.py -- v11`
6. `blender -b -t 2 --python-exit-code 1 --python check_inspect_group.py -- v11`
7. `blender -b -t 2 --python-exit-code 1 --python prepare_texture_atlas_corrected.py`
8. `blender -b -t 2 --python-exit-code 1 --python review_baked_corrected.py`
9. `blender -b -t 2 --python-exit-code 1 --python export_preview_glb.py`
10. `blender -b -t 2 --python-exit-code 1 --python export_uv_evidence.py`
11. `python check_uv_overlap.py`
12. `npm ci --ignore-scripts --no-audit --no-fund`
13. `node validate_glb.cjs`
14. `python check_glb_contract.py`

`render_review_views.py -- v11`, through Blender's `--python` option, provides side, top and opposite views. Earlier study versions remain separate; this pipeline preserves them rather than overwriting the v8 source.

## Export corrections with evidence

- A diffuse-only bake attenuated metallic gold. It was rejected as an albedo map. The corrected pipeline temporarily routes the actual base-color input through emission at strength 1, bakes it, then restores the original material output.
- Under the same camera, lighting and 48-sample render settings, a local diagnostic mean absolute pixel difference dropped from 37.53 to 0.79 on a 0–255 scale. This is not a perceptual quality score or a game test.
- The first GLB lacked explicit tangents. Simply enabling tangent export left n-gon meshes unresolved. The corrected exporter freezes the exact loop-triangle decomposition with its UVs and corner normals, then exports tangents. This avoids relying on a viewer's different runtime tangent generation.
- The official Khronos glTF validator and the separate authored contract check are required. The latter checks embedded resources, tangent-bearing normal-mapped primitives, finite normalized vectors and one animation owner for the two orbit children. Its missing-tangent negative fixture must fail.
- The UV checker detects positive-area triangle overlaps, degenerate charts and coordinates outside the atlas. It does not certify padding, mip behavior, texel density or artistic detail.

## Known limits

The gold/stone finish and silhouette remain a blockout relative to the premium concept. The 1024-pixel atlases are a portable material study, not final texture art. Hand clearance, full equip/aim/fire/loading animations, gameplay effects, sounds, native export, multiplayer and frame-time tests remain open. The crystal and orbit clearance test covers only the specified static prop and cosmetic motion. Do not claim native compatibility from GLB validity.

## Tool references

- [Blender glTF material/export documentation](https://docs.blender.org/manual/en/4.4/addons/import_export/scene_gltf2.html): the exporter recognizes specific material nodes; Blender shader appearance alone does not prove portable output.
- [Official Khronos glTF Validator](https://github.com/KhronosGroup/glTF-Validator): validates glTF structure and binary data. Its scope is separate from game-specific and artistic acceptance.
- [Khronos Node usage](https://github.com/KhronosGroup/glTF-Validator/blob/main/node/README.md).

## Zero-scale inspection-parent regression

A CPU import-and-render review found that the two orbit children had disappeared from the first GLB even though format validation passed. Exporting the zero-scale rest pose produced erroneous child-local transforms. The authored children have constant identity locals. The exporter now verifies that exact supported hierarchy at the relevant keyed frames, then preserves those identity locals in the GLB while retaining the parent's original scale/rotation animation. Geometry, materials and animation buffer bytes are unchanged by this scoped repair. A zero-scale-child negative fixture must fail. The repaired imported scene visibly contains both orbits at the inspection pose; browser WebGL and native testing remain open.

## Optional web-preview static batching

After the normal export and checks, run `batch_glb_exact.py` and `check_preview_exact_batch.py` through Blender's `--python` option, or with a Python runtime containing NumPy. The checker uses a small uniform-grid broad phase and does not require SciPy. Run `python check_batch_resources.py`, then `node validate_glb.cjs shyre-authoring-preview-exact-batched.glb gltf-validation-exact-batched.json`. The `--perturb-uv` checker option is a negative fixture and must fail.

This scoped preview reduces 51 meshes to 4 and 69 primitives to 16, keeping all 12,900 static triangles. Maximum compared world-position component error is about 1.2e-7, within the fixed 1e-6 tolerance; UV values are unchanged. Material/texture/sampler definitions, embedded image bytes and inspection actor/animation values remain identical. Original editable component meshes and the unbatched export remain retained. The new static node records its authored component names.

Local file bytes fall from 1,969,244 to 1,927,052; local gzip-9 sizes are 702,516 and 692,984 bytes. These are artifact and structure measurements, not FPS or HTTP timings. A matched CPU import render had a diagnostic mean absolute difference of approximately 0.0011/255 in the selected mask. Browser WebGL and native game performance remain unverified.

The batching routine is deliberately constrained to this unskinned static-body plus three-actor inspection hierarchy. Unsupported attribute sets or transforms must fail rather than lose data. Do not use it as a general optimizer for arbitrary rigs, morphs, vertex colors or attachments.
