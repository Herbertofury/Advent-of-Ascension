"""Scoped evaluated-mesh checks; not assembly clearance or native acceptance."""
import bpy,bmesh,json,math,sys
from pathlib import Path
R=Path(__file__).resolve().parent;version=sys.argv[sys.argv.index('--')+1]if'--'in sys.argv else 'v8';assert version in ('v4','v5','v7','v8','v9','v10','v11');bpy.ops.wm.open_mainfile(filepath=str(R/('shyre-prop-study-'+version+'.blend')));s=bpy.context.scene;s.frame_set(20);bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();rows=[]
for o in bpy.data.objects:
 if o.type!='MESH' or o.hide_render:continue
 e=o.evaluated_get(dg);m=e.to_mesh();bm=bmesh.new();bm.from_mesh(m);bm.normal_update();bad_area=sum(f.calc_area()<1e-12 for f in bm.faces);boundary=sum(e.is_boundary for e in bm.edges);nonmanifold=sum(not e.is_manifold for e in bm.edges);finite=all(math.isfinite(v)for p in m.vertices for v in p.co);volume=bm.calc_volume(signed=True);m.calc_loop_triangles()
 rows.append({'name':o.name,'triangles':len(m.loop_triangles),'finite':finite,'near_zero_faces':bad_area,'boundary_edges':boundary,'nonmanifold_edges':nonmanifold,'signed_local_volume':volume});bm.free();e.to_mesh_clear()
failed=[r for r in rows if not r['finite'] or r['near_zero_faces'] or r['nonmanifold_edges'] or r['signed_local_volume']<=0]
(R/('geometry-qa-'+version+'.json')).write_text(json.dumps({'scope':'Visible evaluated mesh topology at frame20; curves, cross-object collisions, hands and native export not qualified','meshes':rows,'failed':failed,'passed':not failed,'native_accepted':False},indent=2));print(json.dumps({'meshes':len(rows),'failed':failed},indent=2))
if failed:raise SystemExit(1)
