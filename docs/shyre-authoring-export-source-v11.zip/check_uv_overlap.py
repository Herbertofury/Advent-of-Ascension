"""Positive-area UV triangle overlap check with a uniform-grid broad phase."""
import json,math
from pathlib import Path
R=Path(__file__).resolve().parent
rows=json.loads((R/'uv-triangles.json').read_text())
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return (a[0]-b[0],a[1]-b[1])
def area(p):return abs(sum(cross(p[i],p[(i+1)%len(p)])for i in range(len(p))))*.5 if len(p)>2 else 0

def overlap(a,b):
 if cross(sub(b[1],b[0]),sub(b[2],b[0]))<0:b=list(reversed(b))
 p=list(a)
 for i in range(3):
  c,d=b[i],b[(i+1)%3];out=[]
  if not p:break
  prev=p[-1];fp=cross(sub(d,c),sub(prev,c))
  for q in p:
   fq=cross(sub(d,c),sub(q,c))
   if (fq>=0)!=(fp>=0):
    t=fp/(fp-fq);out.append((prev[0]+t*(q[0]-prev[0]),prev[1]+t*(q[1]-prev[1])))
   if fq>=0:out.append(q)
   prev=q;fp=fq
  p=out
 return area(p)
assert abs(overlap([(0,0),(1,0),(0,1)],[(0,0),(1,0),(0,1)])-.5)<1e-12
assert overlap([(0,0),(1,0),(0,1)],[(1,0),(1,1),(0,1)])<1e-12
assert overlap([(0,0),(1,0),(0,1)],[(2,2),(3,2),(2,3)])==0
bins={};pairs=set();outofbounds=[];degenerate=[]
for i,row in enumerate(rows):
 p=row['uv']
 if any(not math.isfinite(v)or v< -1e-7 or v>1+1e-7 for q in p for v in q):outofbounds.append(i)
 if area(p)<1e-14:degenerate.append(i)
 x0,x1=[int(v*64)for v in (min(q[0]for q in p),max(q[0]for q in p))];y0,y1=[int(v*64)for v in (min(q[1]for q in p),max(q[1]for q in p))]
 for x in range(x0,x1+1):
  for y in range(y0,y1+1):
   bucket=bins.setdefault((x,y),[])
   for j in bucket:pairs.add((j,i))
   bucket.append(i)
hits=[]
for a,b in pairs:
 overlap_area=overlap(rows[a]['uv'],rows[b]['uv'])
 if overlap_area>1e-10:hits.append({'a':a,'b':b,'objects':[rows[a]['object'],rows[b]['object']],'overlap_area':overlap_area})
result={'triangles':len(rows),'candidate_pairs':len(pairs),'out_of_bounds':outofbounds,'degenerate':degenerate,'positive_area_overlaps':hits,'threshold':1e-10,'passed':not(outofbounds or degenerate or hits),'native_accepted':False,'scope':'UV chart geometry only; padding, mip bleed, texel density and visual detail remain separate'}
(R/'uv-overlap-qa.json').write_text(json.dumps(result,indent=2));print({k:len(v) if isinstance(v,list) else v for k,v in result.items()})
if not result['passed']:raise SystemExit(1)
