"""Restore intentionally two-sided cyan crown decoration after opposite-view QA."""
import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'shyre-prop-study-v10.blend'))
original=bpy.data.objects['Upper loop cyan seam'];reverse=original.copy();reverse.data=original.data.copy();reverse.name='Upper loop cyan seam reverse';bpy.context.collection.objects.link(reverse)
for spline in reverse.data.splines:
 for point in spline.points:point.co.y=-point.co.y
s=bpy.context.scene;s.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=str(R/'shyre-prop-study-v11.blend'))
(R/'scope-v11.json').write_text(json.dumps({'scope':'Two-sided cosmetic crown seam; discovered in opposite-view QA','native_accepted':False,'visual_accepted':False,'hands_tested':False},indent=2))
