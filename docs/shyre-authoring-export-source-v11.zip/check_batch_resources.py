"""Preserve material definitions, embedded image bytes and inspection data across batching."""
import json,struct,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
class GLB:
 def __init__(self,path):
  raw=path.read_bytes();n=struct.unpack_from('<I',raw,12)[0];self.j=json.loads(raw[20:20+n]);self.data=raw[28+n:]
 def view(self,i):
  v=self.j['bufferViews'][i];o=v.get('byteOffset',0);return self.data[o:o+v['byteLength']]
 def acc(self,i):
  a=self.j['accessors'][i];v=self.j['bufferViews'][a['bufferView']];fmt={5126:'f',5125:'I',5123:'H',5121:'B'}[a['componentType']];w={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];o=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',struct.calcsize(fmt)*w);return [struct.unpack_from('<'+fmt*w,self.data,o+k*stride)for k in range(a['count'])]
a=GLB(R/'shyre-authoring-preview-v11.glb');b=GLB(R/'shyre-authoring-preview-exact-batched.glb')
for k in ['materials','textures','samplers','extensionsUsed']:assert a.j[k]==b.j[k],k
for ia,ib in zip(a.j['images'],b.j['images']):assert ia['mimeType']==ib['mimeType']and a.view(ia['bufferView'])==b.view(ib['bufferView'])
assert len(a.j['animations'])==len(b.j['animations'])==1
for aa,bb in zip(a.j['animations'],b.j['animations']):
 assert aa['name']==bb['name'] and len(aa['channels'])==len(bb['channels'])
 for ca,cb in zip(aa['channels'],bb['channels']):
  assert ca['target']['path']==cb['target']['path'];assert a.j['nodes'][ca['target']['node']]['name']==b.j['nodes'][cb['target']['node']]['name']
  sa=aa['samplers'][ca['sampler']];sb=bb['samplers'][cb['sampler']];assert sa['interpolation']==sb['interpolation']
  for k in ['input','output']:assert a.acc(sa[k])==b.acc(sb[k])
for name in ['Inspection floating gem','Inspect orbit 1','Inspect orbit 2']:
 na=next(n for n in a.j['nodes']if n.get('name')==name);nb=next(n for n in b.j['nodes']if n.get('name')==name)
 for k in ['translation','rotation','scale','matrix']:assert na.get(k)==nb.get(k)
 if name.startswith('Inspect orbit'):assert not any(k in nb for k in ['translation','rotation','scale','matrix'])
 ma=a.j['meshes'][na['mesh']];mb=b.j['meshes'][nb['mesh']];assert len(ma['primitives'])==len(mb['primitives'])
 for pa,pb in zip(ma['primitives'],mb['primitives']):
  assert pa['material']==pb['material']and pa.get('mode',4)==pb.get('mode',4)and pa['attributes'].keys()==pb['attributes'].keys()
  for k in pa['attributes']:assert a.acc(pa['attributes'][k])==b.acc(pb['attributes'][k])
  assert a.acc(pa['indices'])==b.acc(pb['indices'])
result={'passed':True,'material_texture_sampler_definitions_unchanged':True,'embedded_images_byte_identical':True,'inspection_animation_values_identical':True,'inspection_actor_geometry_and_locals_preserved':True,'native_accepted':False};(R/'preview-batch-resource-qa.json').write_text(json.dumps(result,indent=2));print(result)
