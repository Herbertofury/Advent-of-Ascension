# Released TML mesh-baker check

This executes the constructor/data-baking path of the **unmodified PolyMesh and PolyMesh$1 classes from official Forge 1.20.1 TaCZ Mesh Loader 0.1.8**. It does not execute a mod entrypoint or GPU draw. The artifact and two class hashes are checked before extraction. Source: https://modrinth.com/mod/tacz-mesh-loader/version/PGQI9VTN ; upstream https://github.com/VellEagle/TacZMeshLoader .

The harness supplies narrow graphics/logging stand-ins and real Gson/JOML dependencies. Graphics cleanup/logging fail if accidentally called. Thus it proves bounded data-baker behavior only, not Minecraft linkage, mixin correctness, shaders, Vulkan, rendering, licensing compatibility or in-game performance.

Run with Python 3 and JDK 17 or 21:

python run_check.py --jar /path/to/tacz-mesh-loader-forge-1.20.1-0.1.8.jar --lib /path/to/dependency-jars --jdk /path/to/jdk/bin --geometry /path/to/soul_storm_transport.geo.json

The library directory needs Gson 2.10, JOML 1.10.5 and fastutil 8.5.9. Dependencies and upstream bytecode are not redistributed here. The archive contains only the test harness and hashes. Java 17 compilation is used on both runtimes.

Checks: pivot subtraction, /16 scaling, Y/V inversion, normalized and pixel UVs, three-corner expansion, Meshy ABCA padded triangle, retained non-triangulated five-corner input, invalid-index rejection. The separate exported-geometry check verifies 13 mesh bones and 81,152 baked vertices, finite attribute arrays, UV bounds and empty GPU caches. It does not establish normal orientation correctness for the complete model or visually correct materials.

## v2: actual fallback emission

The harness also invokes released compileConsumer with a recording sink. It verifies transformed position, UV, tint, light and overlay forwarding. It demonstrates that the fallback emits the negative of stored baked normals. Static source/bytecode inspection shows the VBO upload path uses stored baked normals without that negation. This is a path-parity question for native lighting tests, not evidence of a visible bug in any installed pack. No GPU method is invoked here.

A full transport diagnostic found minimum baked normal length 0.9999999 and zero faces below 0.99. It does not prove correct outward orientation or match authored smooth normals: the inspected released baker forces flat shading.

Use --java /path/to/java to run a separate runtime while compiling with the selected JDK. Both Java17 and Java21 runtime checks passed. No claim of Java21 compilation is made on this machine.
