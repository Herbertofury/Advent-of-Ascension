import bpy
from pathlib import Path
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-sculpt-v13.blend'));scene=bpy.context.scene;scene.render.resolution_x=840;scene.render.resolution_y=540;scene.cycles.samples=12;scene.cycles.use_denoising=False
(R/'motion').mkdir(exist_ok=True)
for frame in range(0,120,4):
 scene.frame_set(frame);scene.render.filepath=str(R/'motion'/f'{frame:03d}.png');bpy.ops.render.render(write_still=True)
