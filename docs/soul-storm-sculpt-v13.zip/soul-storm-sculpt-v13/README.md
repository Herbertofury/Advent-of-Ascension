# Soul Storm sculpt v13

Original Blender authoring study; not a native TaCZ gunpack. Earlier v5-v12 are retained in separate published archives.

This corrects the authoring projectile from a near-vertical ring/flattened sphere to a horizontal XY circular plasma face travelling along +X through a thin horizontal emitter aperture. The actual mesh cross-section is tested against the static slot envelope, including its emissive rim. A UV-mapped disc face reuses the original generated reservoir texture; the rim uses a procedural emissive material. All four emitters retain their authored top-to-bottom recoil order. The Soul Flame atlas remains the default sight.

Run with Blender 4.3.2:
- blender -b -t 4 --python build.py
- blender -b -t 4 --python check.py
- blender -b -t 4 --python render_motion.py

No dependencies beyond Blender are required to regenerate. Build writes its .blend and renders. Texture sources are supplied, and packed in the saved .blend. Denoising is disabled for portability to this CPU build.

QA is bounded: sampled recoil, finite mesh geometry, atlas-cell selection and static disc cross-section clearance. It is not continuous collision detection for the whole gun, a hand-rig test, a native export, gameplay footage or a performance benchmark. The low-alpha border of the supplied VFX source still requires final cleanup/masking. The body and materials remain below the concept target.

Animated preview is 30 sampled frames over two seconds showing one authoring burst then sight/core motion; it is not source weapon cadence. The orbital disc graphics are proposed cosmetic effects, not confirmed original AoA visuals. Original AoA identity belongs to Tslat and contributors.
