import bpy,json,math
from pathlib import Path
R=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(R/'soul-storm-sculpt-v13.blend'))
emitters=[bpy.data.objects[f'Emitter_{i+1}_top_to_bottom'] for i in range(4)];scene=bpy.context.scene;violations=[]
for frame in range(121):
 scene.frame_set(frame//4,subframe=(frame%4)/4)
 moving=[]
 for i,e in enumerate(emitters):
  if not all(math.isfinite(x) for x in e.matrix_world.translation):violations.append('nonfinite pose')
  if not -.28001<=e.location.x<=.00001:violations.append(f'overshoot {i} {frame/4} {e.location.x}')
  if e.location.x<-.001:moving.append(i)
 if len(moving)>1:violations.append(f'overlapping recoil events at {frame/4}: {moving}')
scene.frame_set(0)
meshes=[o for o in bpy.data.objects if o.type=='MESH' and not o.hide_render]
zero=[];duplicate=[]
for o in meshes:
 bad=sum(p.area<1e-10 for p in o.data.polygons)
 if bad:zero.append([o.name,bad])
 coords=[tuple(round(x,7) for x in v.co)for v in o.data.vertices]
 if len(set(coords))<len(coords):duplicate.append([o.name,len(coords)-len(set(coords))])
report={'scope':'Blender authoring geometry/keyframe smoke test; no native hands or continuous collision proof','emitter_count':len(emitters),'samples':121,'recoil_violations':violations,'zero_area_polygons':zero,'duplicate_position_vertices':duplicate,'visible_meshes':len(meshes)}
(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
assert not violations, 'Recoil motion gate failed'
assert not zero, 'Zero-area polygon gate failed'
assert not any(name=='Default soul flame' for name,count in duplicate), 'Flame pole weld gate failed'
# Check all 15 atlas cells in the real animated material; unused cell15 is never sampled.
material=bpy.data.materials['Soul flame atlas surface'];add=next(n for n in material.node_tree.nodes if n.type=='VECT_MATH' and n.operation=='ADD')
observed=[]
for frame in range(0,121):
 scene.frame_set(frame);offset=add.inputs[1].default_value;expected=(frame//8)%15
 actual=int(round(offset[0]*4))+4*int(round((1-offset[1])*4-1));assert actual==expected,(frame,actual,expected);observed.append(actual)
assert set(observed)==set(range(15))
report['atlas_frames_seen']=sorted(set(observed));report['atlas_samples']=121;report['limitations']=['Not native renderer acceptance','Core texture has low nonzero border alpha; final asset cleanup/masking pending','No actual hands, shader-pass or continuous collision proof']
(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS bounded recoil/topology and 15-cell atlas sampling; native/visual acceptance open')
# v13 aperture envelope check. Bounds are conservative mesh-coordinate envelopes,
# not a full weapon/hand continuous collision proof.
from mathutils import Vector
scene.frame_set(0)
disc_checks=[]
for i,z in enumerate([2.85,2.02,1.19,.36]):
 g=bpy.data.objects[f'Authoring_disc_{i+1}']
 children=[o for o in g.children if o.type=='MESH' and not o.hide_render]
 assert len(children)==2,(i,[o.name for o in children])
 # Evaluate at full scale, independent of hidden/flight animation samples.
 for o in children:
  local=[o.matrix_basis @ v.co for v in o.data.vertices]
  y=max(abs(v.y)for v in local);zz=max(abs(v.z)for v in local)
  assert y<=.730001,(o.name,y,'side-wall intersection')
  assert zz<=.080001,(o.name,zz,'upper/lower aperture intersection')
  disc_checks.append({'part':o.name,'half_width':y,'half_thickness':zz,'side_clearance':.73-y,'vertical_clearance':.08-zz})
 face=bpy.data.objects[f'Horizontal soul-disc face {i+1}']
 assert all(abs(v.co.z)<1e-8 for v in face.data.vertices)
 assert max(v.co.x for v in face.data.vertices)-min(v.co.x for v in face.data.vertices)>1.27
report['disc_aperture_envelopes']=disc_checks
report['disc_plane']='XY plane; firing travels +X, matching thin horizontal slot'
report['limits']='Static disc cross-section envelope only; not full moving assembly/hand or native collision proof'
(R/'qa.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS horizontal disc plane and conservative aperture cross-section envelopes')
