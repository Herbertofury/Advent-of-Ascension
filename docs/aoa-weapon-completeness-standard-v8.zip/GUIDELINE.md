# Complete Weapon Standard

**Every weapon is a complete experience, not just a mesh.** This is the mandatory design, implementation and QA contract for the AoA weapon upgrade. All 31 feature groups apply to every weapon review. The first-target register contains 228 weapon IDs; historical/version-exclusive weapons remain additional scope.

## 1. The package each weapon must receive

### Identity, concept and construction
- Exact-version original appearance, function, stats, resource, projectile, effects and acquisition route.
- Canonical concept sheet, side/front/top views, material/texture direction and original-versus-upgraded comparison.
- Accurate silhouette, proportions, grip, hand room, visible supply-to-emitter story and moving-part clearances.
- Original UV/textures with purposeful pixel shading, material separation, edges, wear, seams and emissive detail. Study actual TaCZ pack files, not only promotional pictures.
- Separate concept sheets and acceptance for craftable alternate designs. An interesting alternate cannot silently replace the canonical concept.

### Complete firing and effect package
- Projectile designs and in-flight behavior; alternate projectile concepts and actual resulting values.
- Tracers and trails, including taper, lifetime, color, motion and customization.
- Muzzle flash, smoke, sparks, local light, recoil and sound synchronization.
- Entity/armor/terrain/fluid impacts and any separate area-effect behavior.
- Surface decals: marks, scorch, magical imprints, alignment, fade and bounded cleanup.
- Death/kill/finisher concepts, storyboards, sounds and selectable effects, triggered only by valid confirmed outcomes.
- Configurable projectile, tracer, muzzle, impact, decal and finisher channels. Cosmetics must not secretly change damage or resource use.
- Show original projectiles and impacts alongside new concepts. Label real game captures, extracted assets, concepts and offline renders accurately.

### Crafting and the modular armory
- Recipes, materials, ingredient images, acquisition, loot, achievements, boss rewards and progression.
- Craftable variants with clearly documented mechanical differences.
- Barrels/converters, sights/scopes, receivers, grips/stocks, suppressors/brakes and appropriate fantasy equivalents.
- Ammo/energy/feed modules and visible loading/resource-service stories.
- Dismantling and effect salvage: donor identity, transferable effects, conflicts, stacking, balance, preview and persistence.
- Original skins/mastercraft styles, earned functional charms, static/animated/glowing stickers and custom emblems.
- Visible attachments, tooltip values and authoritative behavior must describe the same resolved build. More barrels can have meaningful effects when designed, but a render is not their implementation.

### Complete animation and audio package
- Idle, equip, holster, supported movement, sprint/crouch and aim transitions.
- Firing, per-emitter recoil, charge, cooling/recovery, blocked/dry input and rapid-repeat handling.
- Tactical/empty reload where appropriate, or the correct energy/resource-service animation. Reloading remains optional where the weapon's resource design calls for it; never replace Spirit/mana with generic bullets for convenience.
- Inspect and playful mastercraft choreography, with safe cancellation and reduced-motion options.
- Hand/prop ownership through extraction, carrying, insertion and release. No floating clips, crushed hand space, clipping triggers or impossible supply paths.
- Fire/charge/handling/reload/inspect/flight/impact/finisher audio, environmental response and source/license evidence.
- First-person, third-person, world-held/dropped and GUI presentation where supported.

### Integration, documentation and quality
- Actual pinned native-stack loading and gameplay, multiplayer authority, resource accounting, save/load/migration and optional-mod compatibility.
- Effective stats, build previews, exact icons, clear tooltips and complete illustrated documentation.
- Startup and frame-time/memory budgets, LODs, bounded effects/caches, no repeated scans, and accessibility controls.
- Retained source files, concepts, previews, receipts, native footage and known defects.

## 2. Concept fidelity is a separate hard gate

A valid file, a successful parser test or a collision check does **not** mean the weapon looks right.

Before modeling, pin the chosen concept and its hash. Identify landmarks: receiver/core, barrel/emitter arrangement, stock, grip, guard, magazines/resource chambers, sights and ornament. Compare their relative size, spacing, curvature and material boundaries. Review the model at the same angle and in six useful views; fix the camera rather than accepting cropped or misleading comparisons.

Before claiming visual acceptance, record paired concept/model evidence and an explicit review of silhouette, proportions, negative space, grip, materials, texture density, color, animation and effects. Preserve any deliberate deviation as an approved alternate or document why a functional adjustment is needed. Do not pass a simplified look-alike merely because it shares the colors.

Owner feedback overrides a previous visual assessment. Failed or unreviewed art stays failed or unreviewed. Automated tools validate evidence and numeric constraints; they cannot certify beauty or concept fidelity.

## 3. Three independent phases for every feature

Each of the 31 catalogue rows records:
1. **Concept/design:** art or storyboard for visible features; a concrete specification for nonvisual systems.
2. **Implementation:** versioned source/asset and integration status.
3. **QA:** scoped evidence, defects and the tested environment.

Use `not_started`, `in_progress`, `blocked`, `ready_for_review` or `passed`. Never substitute a concept for implementation, or a unit test for native acceptance. Every phase needs evidence before `passed`.

An intentional omission requires a reason and explicit owner approval. Never default a feature to “not applicable.” An energy weapon may have resource recovery instead of a conventional magazine reload, but the entire animation/resource feature still needs a design and review.

## 4. Six independent acceptance gates

1. Mechanism continuity and exact-version behavior.
2. Spatial/mesh correctness, hands, attachments and swept motion.
3. Animation ownership, interruption and recovery.
4. Confirmed-shot behavior, feedback and resource consistency.
5. Export and resource loading in the pinned native stack.
6. Native gameplay, networking, saves, performance and visual review.

Check keyframes, dense samples, extrema, transitions and known-bad regression fixtures. Sampled AABB clearance is only that; it is not continuous triangle collision proof. Inspect moving parts at normal and slow speed. Keep authored defaults, optional variants and all supported attachment combinations identifiable; disclose which combinations were actually exercised.

## 5. Performance without hiding losses

Maintain high-detail and LOD sources separately. Benchmark startup, frame times and lows, memory and effects costs in comparable native scenes. Do not call fewer triangles or smaller JSON an FPS result. Preserve resource/animation/visual correctness while optimizing. Exact float32 export equivalence is useful evidence, but it is not native rendering or loading acceptance.

## 6. Current owner-directed corrections

- **Soul Storm:** current grip, proportions and weak floating-looking flame are not canonical-quality accepted. Rework toward the concept. The flame must be rooted in its socket and form a clear crosshair when focusing/aiming; retain optional candle/gem choices. Improve actual texture work with reference-pack study.
- **Discharge Shotgun:** the supplied concept is the explicit visual target. Match it closely; include the depicted craftable variants and their effects. Concept approval is not model/runtime approval.
- **Iominator:** preserve and improve the current looping rear-feed design as a separate craftable alternate. The canonical version must follow the supplied concept. Do not use alternate-design approval to pass canonical fidelity.

## 7. Definition of done

A weapon is fully accepted only when every feature has passed its concept/design, implementation and QA phases (or has an owner-approved documented omission), the canonical visual review is accepted, all six native/technical gates are passed with evidence, and its guide exposes the complete package and remaining compatibility limits. Until then, report the real milestone and open work.

The machine-readable catalogue, manifest template, coverage register and validator enforce completeness bookkeeping. They never grant native or artistic acceptance by themselves.

## 8. Required aesthetic and play-experience self-review

At each meaningful iteration, answer these questions with evidence and specific defects, not a generic score or praise:

1. Would I choose to use this weapon, and what gives it a recognizable AoA identity?
2. Does it match the chosen concept's silhouette, proportions, negative space and material hierarchy from comparable viewpoints?
3. Is it beautiful at normal gameplay scale as well as in a close-up render? Is any part still toy-like, weak, floating, cluttered or awkward?
4. Do firing, recoil, impacts, sound and recovery make its intended power readable? Does feedback stay clear during rapid use?
5. Is the animation enjoyable repeatedly, with responsive input and safe interruption? Are hand clearance and the visible resource path believable within the fictional design?
6. Do attachments and craftable variants create distinct useful play choices, with visible and mechanical changes that agree?
7. Are projectile, muzzle, impact and finisher effects exciting while preserving aiming clarity, accessibility and performance?
8. What is the weakest part now, what concrete change addresses it, and what evidence would show the change worked?

Record observation type: concept inspection, authoring render, offline animation, or native playtest. A render can establish an art defect; it cannot establish that a weapon is fun to play. Native play-feel remains untested until actual interaction is observed. A failed answer stays a tracked defect and prevents complete acceptance where relevant. Do not increase praise to match effort spent.

For the full-set announcement, reconcile all 228 first-target IDs plus the separately inventoried historical/version-exclusive scope. Report exact version coverage, remaining unsupported combinations and evidence. Never announce every AoA weapon complete from the first-target count alone.

## 9. Source-to-export regressions that must be caught

- Measure the actual authoring FPS, frame hold and atlas sequence. Do not assume a default scene rate. Test the presentation sampler against the recorded timing data.
- Evaluate modifiers, curves and transforms before geometry checks. Triangle area and unit-normal length do not prove outward winding. Check intended closed-solid orientation and review open surfaces/culling separately.
- Detect exact duplicated surfaces; review intended overlays instead of blindly deleting them. Stress-test the actual thin-part constructors so new inlays and indicators do not repeat old bevel-collapse defects.
- Compare authoring and exported material appearance using matched camera, lighting, sample count and seed. Preserve procedural coordinate meaning, raw color and emission intensity. A diffuse BSDF contribution is not automatically the intended raw metallic color.
- Preserve per-part ownership through UV packing/baking. Verify positions, UVs, material mapping, corner-normal error and controlled owner motion. A merged still image cannot pass animation ownership.
- Turn critical measured limits into failing tests. Logging a large normal error while returning success is not a pass.
- Prioritize texel density where detail needs it before increasing every texture. Report local error regions, memory assumptions and native limits; background-heavy image averages can hide defects.
- Fail unsupported material/alpha/rig cases explicitly. Do not silently apply an opaque-material pipeline to transparent flame or mixed shaders.
- Keep source revisions and evidence hashes aligned. A corrected authoring scene does not repair an older exported fixture automatically.

These checks supplement concept fidelity, real hand fit, native gameplay and performance testing. They do not replace them.


## Owner-approved visual treatment requirement

Start from one AAA canonical concept grounded in original silhouette and identity. Root personally authors model and textures for Minecraft-fit and concept-faithful selectable treatments. Preserve shared gameplay/attachment semantics. Later craftable variants still get their own derived art and QA; they do not replace the canonical anchor. Owner rejected initial Apoco generic long-rifle direction on2026-10-18.

## 10. Concept evidence and moving-part regressions

Apply these checks when producing illustrated source profiles or moving assemblies:

- Keep actual extracted sprites and recipe ingredient textures separate from generated illustrations. A generated lookalike is not an original asset. Use text-only recipe cards if the actual ingredient images are unavailable; never let invented mushroom/ore icons imply a recipe.
- Count visible pellet markers against the labeled storyboard. A rock-styled weapon may still fire ordinary pellets; read its registered implementation before choosing projectile art. Identify recipe references by exact resource ID, so Boulder does not inherit Boulder Dash or Boulder Bomber evidence.
- Resolve the registered class/factory first. Some named weapons instantiate shared BaseShotgun directly. A missing guessed weapon-named class does not imply missing source behavior.
- For shared shot-level random decisions, establish whether the roll happens before or inside the pellet loop. Presentation and multiplayer code must preserve that decision scope.
- Transform ownership checks and released-parser checks cannot detect mesh intersections. Test evaluated moving geometry against relevant static and independently moving assemblies, record baseline contact separately, and state sampling density and excluded pair classes.
- Preserve same-assembly ownership for trim, liners and emission elements. When a stroke crosses a static receiver, create believable internal space or revise the assembly; do not shrink the trigger, hands or guard merely to hide the problem.
- A triangle-surface test can miss complete solid containment and between-sample collisions. Zero sampled intersections is scoped evidence, not universal collision freedom. Native hand meshes, attachments and exported interpolation need their own tests.
- Keep previous rejected art and model trials identifiable. The corrected result should name the observed defect and test, rather than promoting numeric success to beautiful or fun gameplay.

Observed case: Discharge's v2 recoil fixture passed transforms and parser checks but produced 101 new surface-intersection samples. Assigning associated trim to the channel and making receiver stroke space removed those findings in v4's 110,556 sampled pair checks. This evidence is specific to that authoring scene; it does not approve other weapons or native integration.

## 11. Event identity, reward gates and concept captions

These are observed pitfalls in the inspected AoA 3.7.1 / Minecraft 1.20.1 work, not assumptions about every release:

- Audit the registered firing family before choosing a hook. The full 228-item study found 172 conventional gun paths and 56 blasters; LightSpark/SoulSpark override their use-tick path while retaining the inherited blaster attempt method. Soul Storm belongs to the blaster branch. A conventional BaseGun-only hook misses it.
- A successful blaster attempt can have null ShotInfo and skip doFiringEffects. A visually convenient callback is not automatically the authoritative success boundary. Preserve charge, Spirit spending and subclass behavior.
- GunRecoilPacket carries recoil/time values but not weapon instance, hand, configuration revision or shot ordinal. Do not infer identity from whichever weapon is held when it arrives. Prediction, observer updates and swaps require explicit integration.
- Consume the existing confirmed-shot core's resolved emitterIndex. Counting received events locally is wrong when ordinals have gaps: shots 1 and 5 both select lane 0 in a four-emitter layout. Test stale/duplicate events, wrong instance/session and configuration changes across the real adapter boundary.
- Separate conditional reward eligibility, pool gate, roll count and relative weight. Crystaneer's table has a 20% pool gate and 565 total relative weight after its qualifying lethal-impact path; that does not mean every hit can award a gem, that weight 100 means 100%, or that modded duplicate-impact behavior is already safe.
- Inspect text embedded in generated artwork as well as its shapes. Reject labels implying in-game implementation, official materials/lore or exact original art where only a concept exists. Correct the image before publishing; a caption elsewhere does not repair misleading embedded text.
- Recipe ingredients and names are clues, not implementations: Clown Cracker's Confetti Piles do not replace its Metal Slug ammunition, and Red Rocket's name does not make it a rocket launcher. Keep optional functional conversions explicitly separate from original mode.
- Compare material revisions at matching viewpoint/lighting. Added procedural noise that merely looks grainier is not automatically better texture work. Retain a rejected candidate without promoting the current asset or resetting acceptance gates.

Evidence: Confirmed-Shot-Presentation, Crystaneer-Weapon-Profile, Red-Rocket-Weapon-Profile, Clown-Cracker-Weapon-Profile and Hive-Cracker-Weapon-Profile in the project wiki. Native acceptance remains separate from these offline/source checks.


## 12. Concept-view consistency and reproducible authoring

Apply these checks when revising illustrated weapon sheets or publishing Blender-generated sources:

- Check the same prop revision in the hero, side and inspection views. Sweet Tooth's revised hero retained an obsolete doubled collar in its inspection inset; a corrected hero alone did not close the sheet review. Keep old revisions labeled and correct the affected image itself.
- Review hand use in the actual facing direction. In a left-facing conventional prop, a rear shooting grip belongs behind its trigger toward the stock, not in front toward the muzzle. Do not accept an open guard as sufficient if the grip arrangement still prevents a natural reach. Fantasy alternate controls need their own intentional usability explanation.
- Generated labels such as “silhouette match” or a definitive origin sentence require their own evidence. Sludge Sniper's labels were changed to “design study” and “proposed art direction”; a separate caption does not make an unsupported image label valid.
- Require a clean archive extraction and a failing process exit on authoring-script errors. Use Blender's --python-exit-code option. The optional-sight scene saved before a later manifest-writing error; its existence was not evidence of a successful build. Preserve geometry checks separately from packaging checks.
- Scripted custom-property changes may leave stale evaluated visibility until the dependency graph is tagged. Test the exact helper used to switch variants, including viewport and render visibility, rather than testing only manually scrubbed frames.
- Audit bundled helper-library semantics before naming effect levels. EffectsLib 1.7's builder subtracts one from its level before constructing Minecraft's amplifier: builder level 3 is Speed III. Sweet Tooth also buffs the shooter after successful attack, not the target or every cosmetic shot. Keep these facts pinned to the inspected release.

Evidence: Soul-Storm-Optional-Sight-Workshop, Sludge-Sniper-Weapon-Profile and Sweet-Tooth-Weapon-Profile. These examples guide scoped review; they do not certify native gameplay.

- Honor source PNG alpha before judging silhouette or passing a flattened reference to art/model tools. Discarding alpha can expose hidden RGB as false geometry; render a neutral-background reference while preserving the original texture. The Discharge Sniper example demonstrates this failure mode.


## 13. Refresh profile discovery without resetting review state

The earlier coverage builder merged saved rows after deriving existing_profile from the queue. Saved null links overwrote newly discovered profiles: the feature register still exposed only 13 references while the armory had more than 50. Refresh derived links after preserving previous review metadata.

Use refresh_coverage.py with explicit --queue, --coverage, --output and --receipt paths, or build_standard.py --docs. The helper rejects duplicate IDs, inventory/family drift and invalid profile URLs. Missing queue metadata does not erase an older reference. It changes only existing_profile, retaining manifests, statuses, overrides and unknown extension data. Replaced links remain in its receipt.

Nine tests cover preservation, replacement receipts, missing metadata, idempotence and rejected inconsistent inputs. The full builder output is compared with the helper's expected result. This repairs discoverability only; a linked profile is not proof that any feature or native gate has passed.

## 14. Preserve the current register and discover actual manifests

Use the docs-side weapon-feature-coverage.json as the current review source when present. The archived coverage.json is only a fallback for a missing current file. Older bundled state must not overwrite newer review decisions or unknown extensions. Seed known owner-direction defaults only when that override key is absent; never replace the entire overrides dictionary.

build_standard.py now performs both profile refresh and existing-manifest discovery. link_manifests.py links actual feature-status records by exact registry ID and source target, rejecting duplicate, conflicting or unknown records. It changes no phase status. Three full-builder regressions cover current-over-archive precedence, unknown override preservation and conflicting manifest rejection; seven standalone discovery tests and nine profile-refresh tests cover their helper boundaries.

## 15. Check evaluated size as well as parent-following

Discharge's r2 decorative fasteners followed the root but were visibly oversized: parenting captured matrix_world immediately after scale assignment, before Blender's dependency graph had updated. Evaluate the scene before capturing the transform to preserve. Then check intended dimensions, compare world-space geometry before/after reparenting and render the actual rebuilt scene. Passing root-following and manifold tests does not prove size or visual fidelity. Preserve the rejected result as a diagnostic rather than calling it accepted.
