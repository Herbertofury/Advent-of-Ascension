# Soul Storm v31 recoil transport prototype

Status: source-authored presentation clips and original Lua adapter; not an installable gunpack. Native geometry/bone binding, full state-machine integration, arms, material effects and gameplay remain untested.

## What is included

- Four top-to-bottom recoil clips sampled from the published v31 Blender scene.
- Two synchronized aliases per clip: the owner’s solid and illuminated sibling groups. Omitting the second track would permit a visually detached glowing component in this transport convention.
- An original `emitter_cycle.lua` presentation adapter with four reused tracks and no per-frame update callback.
- Tests, scoped export receipts and evidence from the released TaCZ animation parser and context API.

## Host responsibilities

Reserve a dedicated, non-conflicting animation track line before creating the adapter. Supply the real native `PLAY_ONCE_STOP` value, then call `M.new(context, dedicated_line, PLAY_ONCE_STOP)` for this instance. It verifies the four clip names before allocating its four tracks. The prototype accepts dedicated line indices 0–63 as a defensive bound.

Call `instance.on_confirmed_shot(sequence)` exactly once for each confirmed presentation event, with a monotonically increasing nonnegative safe integer. Do not call it from a raw mouse button or per-pellet callback. Establish and test the actual engine event bridge separately. Duplicate and out-of-order sequences are ignored; the adapter does not consume ammunition, spawn projectiles, apply damage or decide fire cadence.

The sequence belongs to this adapter instance. A fresh instance starts at the top lane; persistence across swaps is not implemented. Never share a module-global mutable lane index between weapons or players.

Call `instance.close()` when the host disposes/swaps the weapon. It attempts cleanup of all four tracks even if one fails, returns errors, and only retries failed tracks on a later explicit close call. It does not poll or retry itself. No shots are accepted after closing starts.

## Geometry and animation contract

The aliases are `emitter_1_top_to_bottom` through `emitter_4_top_to_bottom`, each with an `_illuminated` sibling. The actual native model must provide those aliases or an explicitly verified owner-parent equivalent. The older v15 transport naming convention informs the aliases; it is not evidence that the complete v31 geometry is already exported or installed.

Blender -X maps to model +Z at four model units per authoring unit. Each presentation clip samples five authoring frames at 60fps into 41 keys per track. This is animation timing, not a released-game shot interval. Material opacity/emission, flame focus, projectiles, sound and camera recoil are not contained in these position tracks.

## Evidence

- 4 clips, 8 tracks, 328 keys parsed by the actual released TaCZ 1.1.8-hotfix2 animation parser classes on Java17 and Java21, with the existing narrow helper stand-ins documented by the parser study.
- 401 comparisons per clip; maximum sampled linear error about 0.003077 model units.
- Eight Python contract tests reject missing illuminated tracks, divergent tracks, missing owners and nonfinite input.
- Original LuaJ fixture: 10,000 events, 20,022 assertions, one initial four-track allocation. Context is a mock; this does not benchmark Minecraft or prove native callback/binding behavior.
- Released `AnimationStateContext` method signatures checked directly. No guessed API names.

Native integration must also test interrupted animations, rapid weapon swaps, missing clips, reload/inspect collisions, multiplayer presentation, exact attachment variants, shader paths and frame-time lows. A passing parser is not a playable weapon acceptance result.
