"""Export presentation tracks; native model/bone binding remains a separate gate."""
import bpy,json,math,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;src=R.parent/'soul-storm-grip-ornament-v31/soul-storm-ornament-study.blend';bpy.ops.wm.open_mainfile(filepath=str(src));s=bpy.context.scene;clips={};owners=[];max_error=0
for i,start in enumerate([1,7,13,19],1):
 o=bpy.data.objects[f'Emitter_{i}_top_to_bottom'];keys={};sample=[]
 for k in range(41):
  frame=start+5*k/40;s.frame_set(math.floor(frame),subframe=frame%1);v=-4*o.location.x;keys[f'{(5*k/40/60):.9f}']=[0,0,v];sample.append(v)
 for k in range(401):
  frame=start+5*k/400;s.frame_set(math.floor(frame),subframe=frame%1);v=-4*o.location.x;index=min(39,k//10);fraction=k/10-index;approx=sample[index]*(1-fraction)+sample[index+1]*fraction;max_error=max(max_error,abs(v-approx))
 # The existing transport convention uses sibling solid/illuminated groups.
 # Both must move together; a native hierarchy may instead use one owner parent.
 aliases=[o.name.lower(),o.name.lower()+'_illuminated'];clip={'animation_length':5/60,'loop':False,'bones':{name:{'position':keys}for name in aliases}};clips[f'shoot_emitter_{i}']=clip
 descendants=[]
 for child in s.objects:
  parent=child.parent
  while parent:
   if parent==o:
    if not child.hide_render:descendants.append(child.name)
    break
   parent=parent.parent
 owners.append({'source_owner':o.name,'intended_transport_aliases':aliases,'visible_source_descendants':sorted(descendants),'sample_peak_model_units':max(sample)})
assert max_error<.005,max_error
out={'format_version':'1.8.0','animations':clips};(R/'soul_storm_recoil.animation.json').write_text(json.dumps(out,indent=2)+'\n');report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'clip_count':4,'keys_per_track':41,'tracks_per_clip':2,'sample_comparisons_per_clip':401,'maximum_linear_sample_error_model_units':max_error,'axis_mapping':'Blender -X maps to model +Z, four model units per authoring unit','owners':owners,'native_game_tested':False,'geometry_binding_tested':False,'limits':['Position-only clips; no material, flame, projectile, camera or sound tracks','Paired solid/illuminated aliases prevent intentionally exporting a solid-only movement contract','Actual v31 native geometry must supply those aliases or an explicitly verified owner-parent equivalent','This is no firing scheduler and does not establish source gameplay cadence']};(R/'clip-export-qa.json').write_text(json.dumps(report,indent=2)+'\n');print({k:report[k]for k in ['clip_count','keys_per_track','maximum_linear_sample_error_model_units']})
