-- Original presentation-only adapter. The host owns confirmed-shot events,
-- dedicated track-line reservation, geometry binding and all gameplay state.
local M = {}
local function integer(n)
    return type(n) == 'number' and n == n and n ~= math.huge and n ~= -math.huge and n >= 0 and n <= 9007199254740991 and n % 1 == 0
end
function M.new(context, dedicated_line, play_once_stop)
    assert(integer(dedicated_line) and dedicated_line <= 63, 'Invalid dedicated track line')
    assert(play_once_stop ~= nil, 'Host must supply native PLAY_ONCE_STOP')
    local names = {}
    for i = 1, 4 do
        names[i] = 'shoot_emitter_' .. i
        if not context:hasAnimationPrototype(names[i]) then return nil, 'missing_clip:' .. names[i] end
    end
    context:ensureTrackLineSize(dedicated_line + 1)
    context:ensureTracksAmount(dedicated_line, 4)
    local tracks = {}
    for i = 1, 4 do
        tracks[i] = context:getTrack(dedicated_line, i - 1)
        assert(integer(tracks[i]), 'Invalid native track')
    end
    local next_lane, last_sequence, disposed = 1, -1, false
    local instance = {}
    function instance.on_confirmed_shot(sequence)
        if disposed then return false, 'disposed' end
        if not integer(sequence) then return false, 'invalid_sequence' end
        if sequence <= last_sequence then return false, 'stale_or_duplicate' end
        local lane = next_lane
        if not context:hasAnimationPrototype(names[lane]) then return false, 'missing_clip:' .. names[lane] end
        local ok, err = pcall(function()
            context:stopAnimation(tracks[lane])
            context:runAnimation(names[lane], tracks[lane], true, play_once_stop, 0)
        end)
        if not ok then return false, 'animation_error:' .. tostring(err) end
        last_sequence = sequence
        next_lane = lane % 4 + 1
        return true, lane
    end
    local cleanup_pending = {tracks[1], tracks[2], tracks[3], tracks[4]}
    function instance.close()
        disposed = true
        local failed, errors = {}, {}
        for _, track in ipairs(cleanup_pending) do
            local ok, err = pcall(function() context:stopAnimation(track) end)
            if not ok then failed[#failed + 1] = track; errors[#errors + 1] = tostring(err) end
        end
        cleanup_pending = failed
        return #failed == 0, errors
    end
    return instance
end
return M
