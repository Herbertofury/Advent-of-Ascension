import unittest,json,copy,math
from pathlib import Path
R=Path(__file__).resolve().parent;J=json.loads((R/'soul_storm_recoil.animation.json').read_text())
def validate(j):
 a=j['animations'];assert len(a)==4
 for i in range(1,5):
  clip=a[f'shoot_emitter_{i}'];base=f'emitter_{i}_top_to_bottom';assert set(clip['bones'])=={base,base+'_illuminated'};p=clip['bones'][base]['position'];q=clip['bones'][base+'_illuminated']['position'];assert p==q;assert len(p)==41
  ts=list(map(float,p));assert ts==sorted(ts)and ts[0]==0 and abs(ts[-1]-clip['animation_length'])<1e-8
  for v in p.values():assert len(v)==3 and all(math.isfinite(x)for x in v)and v[0]==v[1]==0 and v[2]>=-1e-7
  assert max(v[2]for v in p.values())>1 and abs(list(p.values())[0][2])<1e-7 and abs(list(p.values())[-1][2])<1e-7
class Contract(unittest.TestCase):
 def test_valid(self):validate(J)
 def test_missing_glow_rejected(self):
  j=copy.deepcopy(J);del j['animations']['shoot_emitter_1']['bones']['emitter_1_top_to_bottom_illuminated']
  with self.assertRaises(AssertionError):validate(j)
 def test_drift_rejected(self):
  j=copy.deepcopy(J);j['animations']['shoot_emitter_2']['bones']['emitter_2_top_to_bottom_illuminated']['position']['0.000000000']=[0,0,1]
  with self.assertRaises(AssertionError):validate(j)
 def test_incomplete_owner_rejected(self):
  j=copy.deepcopy(J);del j['animations']['shoot_emitter_4']
  with self.assertRaises(AssertionError):validate(j)
 def test_nonfinite_rejected(self):
  j=copy.deepcopy(J)
  for b in j['animations']['shoot_emitter_3']['bones'].values():b['position']['0.000000000']=[0,0,float('nan')]
  with self.assertRaises(AssertionError):validate(j)
 def test_no_loop(self):self.assertTrue(all(not c['loop']for c in J['animations'].values()))
 def test_scoped_status(self):self.assertFalse(json.loads((R/'clip-export-qa.json').read_text())['geometry_binding_tested'])
 def test_owner_descendants(self):self.assertTrue(all(x['visible_source_descendants']for x in json.loads((R/'clip-export-qa.json').read_text())['owners']))
if __name__=='__main__':unittest.main()
