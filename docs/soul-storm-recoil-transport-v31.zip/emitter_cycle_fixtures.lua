local checks = 0
local function check(x, message) assert(x, message); checks = checks + 1 end
local function context()
    local c = {runs = {}, stops = 0, ensure = 0, missing = {}, fail = false}
    function c:hasAnimationPrototype(name) return not self.missing[name] end
    function c:ensureTrackLineSize(n) self.lines = n end
    function c:ensureTracksAmount(line, n) self.ensure = self.ensure + 1; self.amount = n end
    function c:getTrack(line, i) return line * 4 + i end
    function c:stopAnimation(track) self.stops = self.stops + 1; if self.bad_track==track then error('stop fixture') end end
    function c:runAnimation(name, track, blend, mode, transition)
        if self.fail then error('fixture failure') end
        check(blend == true and mode == 'harness_stop' and transition == 0, 'native call contract')
        self.runs[#self.runs + 1] = {name = name, track = track}
    end
    return c
end
local c = context(); local x = assert(M.new(c, 3, 'harness_stop'))
for i=0,9999 do local ok,lane=x.on_confirmed_shot(i);check(ok and lane==i%4+1,'round robin') end
check(c.ensure==1 and c.amount==4,'bounded allocation');check(#c.runs==10000,'one animation per event')
check(not x.on_confirmed_shot(9999),'duplicate rejected');check(not x.on_confirmed_shot(3),'out of order rejected');check(not x.on_confirmed_shot(-1),'negative rejected');check(not x.on_confirmed_shot(0/0),'NaN rejected');check(not x.on_confirmed_shot(1.5),'fraction rejected')
local other=context();local y=assert(M.new(other,3,'harness_stop'));local ok,lane=y.on_confirmed_shot(0);check(ok and lane==1,'instance isolation')
c.missing.shoot_emitter_1=true;check(not x.on_confirmed_shot(10000),'missing runtime clip');c.missing.shoot_emitter_1=nil;c.fail=true;check(not x.on_confirmed_shot(10000),'failed run');c.fail=false;local ok,lane=x.on_confirmed_shot(10000);check(ok and lane==1,'failure did not advance')
local before=c.stops;x.close();check(c.stops==before+4,'all four stopped');x.close();check(c.stops==before+4,'idempotent close');check(not x.on_confirmed_shot(10001),'closed rejects')
local missing=context();missing.missing.shoot_emitter_3=true;local absent,reason=M.new(missing,1,'harness_stop');check(absent==nil and missing.ensure==0,'validate before allocation')
check(not pcall(function()M.new(context(),-1,'harness_stop')end),'negative line rejected');check(not pcall(function()M.new(context(),math.huge,'harness_stop')end),'infinite line rejected')
local broken=context();local z=assert(M.new(broken,3,'harness_stop'));broken.bad_track=13;local clean,errors=z.close();check(not clean and #errors==1 and broken.stops==4,'attempt every cleanup track');broken.bad_track=nil;local clean=z.close();check(clean and broken.stops==5,'retry only failed cleanup');check(not y.on_confirmed_shot(9007199254740992),'unsafe numeric sequence rejected')
print('PASS original Lua emitter adapter: '..checks..' assertions; 10000-event bounded-track fixture. Context is a mock, not native gameplay.')
