import java.nio.file.*;
import org.luaj.vm2.*;
import org.luaj.vm2.lib.jse.JsePlatform;
public class EmitterLuaCheck {
 public static void main(String[] args)throws Exception {
  Globals g=JsePlatform.standardGlobals();
  for(String key:new String[]{"os","io","luajava","package","require","dofile","loadfile"})g.set(key,LuaValue.NIL);
  // Harness sentinels, not claimed to be native engine enum values.
  g.set("PLAY_ONCE_HOLD","harness_hold");g.set("PLAY_ONCE_STOP","harness_stop");g.set("INPUT_SHOOT","harness_shoot");
  LuaValue mod=g.load(Files.readString(Path.of(args[0])),"original_emitter_cycle").call();g.set("M",mod);
  g.load(Files.readString(Path.of(args[1])),"emitter_cycle_fixtures").call();
 }
}
