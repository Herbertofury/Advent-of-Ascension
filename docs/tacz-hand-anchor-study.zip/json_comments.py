"""Remove JSON line/block comments without altering quoted content. Not a general Gson emulator."""
def strip_comments(text):
 out=[];i=0;quoted=False;escape=False
 while i<len(text):
  c=text[i]
  if quoted:
   out.append(c)
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':quoted=False
   i+=1;continue
  if c=='"':quoted=True;out.append(c);i+=1;continue
  if text.startswith('//',i):
   while i<len(text)and text[i]!='\n':out.append(' ');i+=1
  elif text.startswith('/*',i):
   end=text.find('*/',i+2)
   if end<0:raise ValueError('Unterminated block comment')
   out.extend('\n'if c=='\n'else' 'for c in text[i:end+2]);i=end+2
  else:out.append(c);i+=1
 return ''.join(out)
