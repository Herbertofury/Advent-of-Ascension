"""Structural hand-anchor preflight. Does not certify actual hand fit or native rendering."""
import json,math,argparse
from pathlib import Path
REQUIRED=('lefthand_pos','righthand_pos')
def audit(data,require_first_person_anchors=True):
 errors=[];geometries=data.get('minecraft:geometry',[])
 if not isinstance(geometries,list)or len(geometries)!=1:return {'errors':['Expected one explicitly selected geometry'],'hand_fit_accepted':False}
 bones=geometries[0].get('bones',[]);by={}
 for b in bones:
  name=b.get('name')
  if not isinstance(name,str)or not name:errors.append('Invalid bone name');continue
  if name in by:errors.append('Duplicate bone '+name)
  by[name]=b
 for name in REQUIRED:
  if name not in by and require_first_person_anchors:errors.append('Missing functional anchor '+name)
  elif name in by:
   p=by[name].get('pivot')
   if not isinstance(p,list)or len(p)!=3 or any(isinstance(v,bool)or not isinstance(v,(int,float))or not math.isfinite(v)for v in p):errors.append('Anchor requires finite explicit pivot '+name)
 for name,b in by.items():
  parent=b.get('parent')
  if parent is not None and parent not in by:errors.append('Missing parent for '+name)
  seen=set();cur=name
  while cur in by:
   if cur in seen:errors.append('Parent cycle at '+name);break
   seen.add(cur);cur=by[cur].get('parent')
 return {'errors':errors,'functional_anchors':{n:{'pivot':by[n].get('pivot'),'parent':by[n].get('parent')}for n in REQUIRED if n in by},'scope':'Names, uniqueness, explicit pivots and parent graph only; no animation, player skin, pose or collision proof','hand_fit_accepted':False}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);a=p.parse_args();r=audit(json.loads(a.model.read_text()));print(json.dumps(r,indent=2));raise SystemExit(bool(r['errors']))
