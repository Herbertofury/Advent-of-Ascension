import zipfile,json,hashlib,copy,argparse
from pathlib import Path
from audit_anchors import audit
from json_comments import strip_comments
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--jar',type=Path,default=R.parent/'references/tacz-1.20.1-1.1.8-hotfix2.jar');p.add_argument('--model',type=Path,default=R.parent/'soul-storm-v15-transport/soul_storm_transport.geo.json');args=p.parse_args();jar=args.jar;rows=[]
with zipfile.ZipFile(jar)as z:
 roles={}
 for name in z.namelist():
  if '/display/guns/'not in name or not name.endswith('.json'):continue
  d=json.loads(strip_comments(z.read(name).decode()))
  for role,resource in [('primary',d.get('model')),('lod',d.get('lod',{}).get('model'))]:
   if not isinstance(resource,str)or':'not in resource:continue
   ns,path=resource.split(':',1);key='assets/tacz/custom/tacz_default_gun/assets/'+ns+'/geo_models/'+path+'.json';roles.setdefault(key,set()).add(role)
 for name in z.namelist():
  if '/geo_models/gun/'not in name or not name.endswith('.json'):continue
  raw=z.read(name);d=json.loads(raw);model_roles=sorted(roles.get(name,[]));result=audit(d,require_first_person_anchors='primary'in model_roles or not model_roles);rows.append({'roles_from_display':model_roles,'file':name,'sha256':hashlib.sha256(raw).hexdigest(),**result})
soul=args.model;result={'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'released_gun_models':rows,'soul_v15_transport':{'sha256':hashlib.sha256(soul.read_bytes()).hexdigest(),**audit(json.loads(soul.read_text()))}}
(R/'hand-anchor-evidence.json').write_text(json.dumps(result,indent=2)+'\n');print('Released models',len(rows),'passing role-aware structure',sum(not r['errors']for r in rows));print('Primary',sum('primary'in r['roles_from_display']for r in rows),'LOD',sum('lod'in r['roles_from_display']for r in rows));print('Transport errors',result['soul_v15_transport']['errors'])
from test_anchors import run_tests
run_tests()
