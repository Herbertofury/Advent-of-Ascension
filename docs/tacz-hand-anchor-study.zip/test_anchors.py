import copy,json
from audit_anchors import audit
from json_comments import strip_comments
def run_tests():
 good={'minecraft:geometry':[{'bones':[{'name':'root'},{'name':'lefthand_pos','parent':'root','pivot':[0,0,0]},{'name':'righthand_pos','parent':'root','pivot':[0,0,0]}]}]};assert not audit(good)['errors']
 for typ in ['missing','duplicate','cycle','parent','nan','bool']:
  d=copy.deepcopy(good);b=d['minecraft:geometry'][0]['bones']
  if typ=='missing':b.pop()
  if typ=='duplicate':b.append(copy.deepcopy(b[1]))
  if typ=='cycle':b[0]['parent']='lefthand_pos'
  if typ=='parent':b[1]['parent']='absent'
  if typ=='nan':b[1]['pivot'][0]=float('nan')
  if typ=='bool':b[1]['pivot'][0]=True
  assert audit(d)['errors'],typ
 print('PASS valid fixture and six rejection cases; native hand fit remains untested')

if __name__=="__main__":run_tests()
